<?php
/**
 * Silent Browser - Account Registration, Authentication, Cross-Device Sync & Releases API
 * Authorized by: Silent Bot LLC
 * Staging Portal: https://silentbrowser.silentbot.online/
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$envCandidates = [dirname(__DIR__) . '/.env', __DIR__ . '/.env'];
foreach ($envCandidates as $envPath) {
    if (is_file($envPath) && is_readable($envPath)) {
        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            foreach ($lines as $line) {
                $trimmed = trim($line);
                if ($trimmed === '' || str_starts_with($trimmed, '#') || !str_contains($trimmed, '=')) {
                    continue;
                }
                [$k, $v] = explode('=', $trimmed, 2);
                $k = trim($k);
                $v = trim($v, " \t\n\r\0\x0B\"'");
                if ($k !== '' && getenv($k) === false && !isset($_ENV[$k])) {
                    $_ENV[$k] = $v;
                }
            }
        }
        break;
    }
}

function silentEnv(string $key, string $default = ''): string {
    $val = getenv($key);
    if ($val !== false && $val !== '') {
        return $val;
    }
    return (string)($_ENV[$key] ?? $default);
}

$allowedOrigins = [
    'https://browser.silentbot.online',
    'https://silentbrowser.silentbot.online',
    'https://silentbot.online'
];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Silent-Client');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$portalUrl = rtrim(silentEnv('SILENT_PORTAL_URL', 'https://silentbrowser.silentbot.online'), '/') . '/';
$action = $_GET['action'] ?? 'status';

$defaultReleases = [
    'android' => [
        'name' => 'Android (7.0 – 16+)',
        'version' => '1.0.0',
        'version_code' => 3,
        'package' => 'silent-browser-v1.0.0-android.apk',
        'availability' => 'RELEASE_KEYSTORE_REQUIRED',
        'signing_status' => 'Source & debug build verified (versionCode 3); release upload keystore signing required before public distribution',
        'url' => $portalUrl . '#downloads',
        'checksum_url' => $portalUrl . 'releases/SHA256SUMS.txt'
    ],
    'windows' => [
        'name' => 'Windows 10/11 (x64)',
        'version' => '1.0.0',
        'package' => 'SilentBrowser-Setup-x64.exe',
        'portable_package' => 'SilentBrowser-Portable-x64.exe',
        'availability' => 'UNSIGNED_STAGING_BINARY',
        'signing_status' => 'Compiled .NET 4.8 staging installer/portable binary; Authenticode signing and Windows VM QA required before production',
        'url' => $portalUrl . 'releases/SilentBrowser-Setup-x64.exe',
        'portable_url' => $portalUrl . 'releases/SilentBrowser-Portable-x64.exe',
        'checksum_url' => $portalUrl . 'releases/SHA256SUMS.txt'
    ],
    'ios' => [
        'name' => 'iPhone / iPad (iOS 15+)',
        'version' => '1.0.0',
        'package' => 'Not built in current staging bundle',
        'availability' => 'NOT_BUILT',
        'signing_status' => 'Requires native Xcode / App Store Connect distribution',
        'url' => $portalUrl . '#compatibility',
        'checksum_url' => null
    ],
    'macos' => [
        'name' => 'macOS (Apple Silicon & Intel)',
        'version' => '1.0.0',
        'package' => 'Not built in current staging bundle',
        'availability' => 'NOT_BUILT',
        'signing_status' => 'Requires macOS build, Developer ID signing & notarization',
        'url' => $portalUrl . '#compatibility',
        'checksum_url' => null
    ],
    'other' => [
        'name' => 'Linux (x86_64 AppImage)',
        'version' => '1.0.0',
        'package' => 'Not built in current staging bundle',
        'availability' => 'NOT_BUILT',
        'signing_status' => 'Pending Linux desktop packaging & runtime test',
        'url' => $portalUrl . '#compatibility',
        'checksum_url' => null
    ]
];

$dbHost = silentEnv('SILENT_DB_HOST', 'localhost');
$dbPort = (int)silentEnv('SILENT_DB_PORT', '3306');
if ($dbPort <= 0 || $dbPort > 65535) $dbPort = 3306;
$dbName = silentEnv('SILENT_DB_NAME', '');
$dbUser = silentEnv('SILENT_DB_USER', '');
$dbPass = silentEnv('SILENT_DB_PASS', '');

function connectPdo(string $host, int $port, string $name, string $user, string $pass): ?PDO {
    if ($name === '' || $user === '' || $pass === '') {
        return null;
    }
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    return new PDO($dsn, $user, $pass, $options);
}

if ($action === 'status') {
    $dbConnected = false;
    try {
        $pdo = connectPdo($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
        if ($pdo !== null) {
            $pdo->query('SELECT 1');
            $dbConnected = true;
        }
    } catch (\Throwable $e) {
        $dbConnected = false;
    }

    echo json_encode([
        'status' => 'online',
        'app' => 'Silent Browser Backend',
        'portal' => $portalUrl,
        'database_connected' => $dbConnected,
        'version' => '1.0.0',
        'timestamp' => time()
    ]);
    exit;
}

if ($action === 'releases') {
    $channel = (($_GET['channel'] ?? 'stable') === 'beta') ? 'beta' : 'stable';
    echo json_encode([
        'status' => 'success',
        'version' => '1.0.0',
        'version_code' => 3,
        'channel' => $channel,
        'portal' => $portalUrl,
        'release_notes' => [
            'White-theme default with instant Black & Midnight DataStore theme switching',
            'Proximity sensor Panic Wipe toggle and local data clear workflow',
            'Granular Sync Conflicts resolution (Keep Local, Use Remote, Merge)',
            'On-device tracker/scam request blocking with DNT: 1 and Sec-GPC: 1 headers'
        ],
        'future_update' => [
            'version' => 'v1.1.0',
            'version_code' => 4,
            'target_window' => 'Upcoming Release (Build 4)',
            'title' => 'Multi-Hop Stealth Routing & Passkey Cloud Sync',
            'summary' => 'Next scheduled Silent Browser release featuring chained privacy relays, hardware passkey sync unlock, and per-domain sandbox profiles.',
            'highlights' => [
                'Dual-hop Tor + WireGuard relay chaining for sensitive workspaces',
                'Hardware FIDO2 / Passkey biometric vault & sync verification',
                'Per-site isolated script & cookie partition rules',
                'Adaptive tablet & foldable split-workspace multitasking'
            ],
            'readiness_percent' => 82,
            'opt_in_available' => true
        ],
        'roadmap' => [
            [
                'id' => 'ms_v1_0_0',
                'version' => 'v1.0.0',
                'target_window' => 'Current Production (Build 3)',
                'title' => 'Core Privacy Suite & White-First Command Hub',
                'summary' => 'Production baseline with Amnesic Panic Wipe, AES-256-GCM vault, Virtual Shielded IP, and cross-device sync conflict resolution.',
                'status' => 'SHIPPED',
                'progress_percent' => 100
            ],
            [
                'id' => 'ms_v1_1_0',
                'version' => 'v1.1.0',
                'target_window' => 'Next Future Update (Q2 Release)',
                'title' => 'Multi-Hop Stealth Routing & Passkey Sync',
                'summary' => 'Dual-hop encrypted relay chaining, hardware passkey protection for encrypted cloud sync, and per-origin sandbox profiles.',
                'status' => 'IN_PROGRESS',
                'progress_percent' => 82
            ],
            [
                'id' => 'ms_v1_2_0',
                'version' => 'v1.2.0',
                'target_window' => 'Upcoming Milestone',
                'title' => 'Encrypted Tab Groups & Offline Reading Vault',
                'summary' => 'Sync pinned workspace tab collections via QR handoff and archive sanitized offline web snapshots inside encrypted local storage.',
                'status' => 'UPCOMING',
                'progress_percent' => 45
            ],
            [
                'id' => 'ms_v2_0_0',
                'version' => 'v2.0.0',
                'target_window' => 'Long-Term Architecture',
                'title' => 'Distributed Relay Mesh & Universal Workspaces',
                'summary' => 'Unified desktop-mobile session parity with ephemeral onion workspace containers and hardware security key master locks.',
                'status' => 'UPCOMING',
                'progress_percent' => 20
            ]
        ],
        'platforms' => $defaultReleases
    ]);
    exit;
}

if ($action === 'feed') {
    $cacheFile = sys_get_temp_dir() . '/silent_browser_live_feed_v1.json';
    $forceRefresh = isset($_GET['refresh']) && $_GET['refresh'] === '1';
    if (!$forceRefresh && is_file($cacheFile) && (time() - filemtime($cacheFile)) < 900) {
        $cached = @file_get_contents($cacheFile);
        if (is_string($cached) && $cached !== '') {
            header('Cache-Control: public, max-age=300');
            echo $cached;
            exit;
        }
    }

    $fetchRemote = static function (string $url): ?string {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_TIMEOUT => 6,
                CURLOPT_USERAGENT => 'SilentBrowser/1.0.0 (Staging Live Feed; +https://silentbrowser.silentbot.online/)',
                CURLOPT_HTTPHEADER => ['Accept: application/json']
            ]);
            $res = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code >= 200 && $code < 300 && is_string($res)) {
                return $res;
            }
        }
        $ctx = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 5,
                'header' => "User-Agent: SilentBrowser/1.0.0\r\nAccept: application/json\r\n"
            ]
        ]);
        $raw = @file_get_contents($url, false, $ctx);
        return is_string($raw) ? $raw : null;
    };

    $sanitizeImg = static function (?string $img): ?string {
        if (!$img) return null;
        $img = trim($img);
        if ($img === '' || strtolower($img) === 'null') return null;
        if (str_starts_with($img, 'http://')) {
            $img = 'https://' . substr($img, 7);
        }
        return preg_match('/^https:\/\//i', $img) ? $img : null;
    };

    $newsItems = [];
    $devRaw = $fetchRemote('https://dev.to/api/articles?top=1&per_page=8');
    if ($devRaw !== null) {
        $devArr = json_decode($devRaw, true);
        if (is_array($devArr)) {
            foreach ($devArr as $art) {
                if (!is_array($art)) continue;
                $title = trim((string)($art['title'] ?? ''));
                $url = trim((string)($art['url'] ?? ''));
                if ($title === '' || $url === '') continue;
                $img = $sanitizeImg($art['cover_image'] ?? ($art['social_image'] ?? ($art['user']['profile_image_90'] ?? null)));
                $author = trim((string)($art['user']['name'] ?? 'DEV Daily'));
                $reactions = (int)($art['positive_reactions_count'] ?? 0);
                $comments = (int)($art['comments_count'] ?? 0);
                $newsItems[] = [
                    'id' => 'news_' . (string)($art['id'] ?? count($newsItems)),
                    'category' => 'news',
                    'source' => 'Daily Tech News',
                    'title' => $title,
                    'summary' => trim((string)($art['description'] ?? ($author . ' · ' . $comments . ' comments'))),
                    'url' => $url,
                    'image' => $img,
                    'metric' => $reactions . ' reactions · ' . $comments . ' comments',
                    'published_at' => (string)($art['published_at'] ?? gmdate('c'))
                ];
                if (count($newsItems) >= 6) break;
            }
        }
    }

    $githubItems = [];
    $sinceDate = gmdate('Y-m-d', time() - 7 * 86400);
    $ghRaw = $fetchRemote('https://api.github.com/search/repositories?q=' . rawurlencode('pushed:>=' . $sinceDate . ' stars:>500') . '&sort=stars&order=desc&per_page=8');
    if ($ghRaw === null) {
        $ghRaw = $fetchRemote('https://api.github.com/search/repositories?q=' . rawurlencode('stars:>3000') . '&sort=updated&order=desc&per_page=8');
    }
    if ($ghRaw !== null) {
        $ghJson = json_decode($ghRaw, true);
        $ghList = $ghJson['items'] ?? null;
        if (is_array($ghList)) {
            foreach ($ghList as $repo) {
                if (!is_array($repo)) continue;
                $fullName = trim((string)($repo['full_name'] ?? ''));
                $htmlUrl = trim((string)($repo['html_url'] ?? ''));
                if ($fullName === '' || $htmlUrl === '') continue;
                $stars = (int)($repo['stargazers_count'] ?? 0);
                $lang = trim((string)($repo['language'] ?? 'Open Source'));
                $starsLabel = $stars >= 1000 ? number_format($stars / 1000, 1) . 'K ★' : ($stars . ' ★');
                $ogImg = 'https://opengraph.githubassets.com/1/' . $fullName;
                $avatarImg = $sanitizeImg($repo['owner']['avatar_url'] ?? null);
                $githubItems[] = [
                    'id' => 'gh_' . (string)($repo['id'] ?? count($githubItems)),
                    'category' => 'github',
                    'source' => 'Trending GitHub',
                    'title' => $fullName,
                    'summary' => trim((string)($repo['description'] ?? 'Open-source repository on GitHub')),
                    'url' => $htmlUrl,
                    'image' => $ogImg,
                    'avatar' => $avatarImg,
                    'metric' => $starsLabel . ($lang !== '' ? ' · ' . $lang : ''),
                    'published_at' => (string)($repo['pushed_at'] ?? gmdate('c'))
                ];
                if (count($githubItems) >= 6) break;
            }
        }
    }

    $items = [];
    $max = max(count($newsItems), count($githubItems));
    for ($i = 0; $i < $max; $i++) {
        if (isset($newsItems[$i])) $items[] = $newsItems[$i];
        if (isset($githubItems[$i])) $items[] = $githubItems[$i];
    }

    $payload = json_encode([
        'status' => count($items) > 0 ? 'live' : 'degraded',
        'updated_utc' => gmdate('Y-m-d H:i:s') . ' UTC',
        'portal' => $portalUrl,
        'news_count' => count($newsItems),
        'github_count' => count($githubItems),
        'items' => $items
    ]);

    if (is_string($payload) && count($items) > 0) {
        @file_put_contents($cacheFile, $payload);
    }
    echo $payload ?: json_encode(['status' => 'degraded', 'items' => []]);
    exit;
}

if ($dbName === '' || $dbUser === '' || $dbPass === '') {
    http_response_code(503);
    echo json_encode([
        'status' => 'not_configured',
        'message' => 'Set SILENT_DB_NAME, SILENT_DB_USER, and SILENT_DB_PASS in server environment variables.'
    ]);
    exit;
}

try {
    $pdo = connectPdo($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit;
}

if ($action === 'relays') {
    $rows = $pdo->query("SELECT node_code, location, virtual_ip, protocol, latency_ms FROM silent_browser_relay_nodes WHERE is_active = 1 ORDER BY latency_ms ASC")->fetchAll();
    echo json_encode(['status' => 'success', 'relays' => $rows]);
    exit;
}

function readJsonBody(): array {
    $raw = file_get_contents('php://input');
    $decoded = json_decode((string)$raw, true);
    return is_array($decoded) ? $decoded : [];
}

// 1. Register User Endpoint
if ($action === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = readJsonBody();
    $email = filter_var(trim((string)($input['email'] ?? '')), FILTER_VALIDATE_EMAIL);
    $pass = (string)($input['password'] ?? '');

    if (!$email || strlen($pass) < 6) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password (min 6 chars).']);
        exit;
    }

    $hash = password_hash($pass, PASSWORD_BCRYPT);
    try {
        $stmt = $pdo->prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)");
        $stmt->execute([$email, $hash]);
        $userId = $pdo->lastInsertId();

        $token = bin2hex(random_bytes(32));
        $expires = gmdate('Y-m-d H:i:s', time() + 86400 * 30);
        $sess = $pdo->prepare("INSERT INTO user_sessions (user_id, token, expires_at) VALUES (?, ?, ?)");
        $sess->execute([$userId, $token, $expires]);

        echo json_encode(['status' => 'success', 'user_id' => $userId, 'email' => $email, 'token' => $token]);
    } catch (\PDOException $e) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Email already registered or database error.']);
    }
    exit;
}

// 2. Login User Endpoint
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = readJsonBody();
    $email = trim((string)($input['email'] ?? ''));
    $pass = (string)($input['password'] ?? '');

    $stmt = $pdo->prepare("SELECT id, email, password_hash FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($pass, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password.']);
        exit;
    }

    $token = bin2hex(random_bytes(32));
    $expires = gmdate('Y-m-d H:i:s', time() + 86400 * 30);
    $sess = $pdo->prepare("INSERT INTO user_sessions (user_id, token, expires_at) VALUES (?, ?, ?)");
    $sess->execute([$user['id'], $token, $expires]);

    echo json_encode(['status' => 'success', 'user_id' => $user['id'], 'email' => $user['email'], 'token' => $token]);
    exit;
}

// Helper: authenticate bearer token
function authenticateUser(PDO $pdo): ?array {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_starts_with($authHeader, 'Bearer ') ? substr($authHeader, 7) : '';
    if ($token === '') return null;

    $stmt = $pdo->prepare("SELECT u.id, u.email FROM user_sessions s JOIN users u ON s.user_id = u.id WHERE s.token = ? AND s.expires_at >= UTC_TIMESTAMP()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    return $user ?: null;
}

if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_starts_with($authHeader, 'Bearer ') ? substr($authHeader, 7) : '';
    if ($token !== '') {
        $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE token = ?");
        $stmt->execute([$token]);
    }
    echo json_encode(['status' => 'success']);
    exit;
}

// 3. Sync Push Endpoint (Timestamp-based conflict resolution prioritizing local/newest client timestamps)
if ($action === 'sync_push' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = authenticateUser($pdo);
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status' => 'unauthorized']);
        exit;
    }

    $input = readJsonBody();
    $userId = $user['id'];
    $defaultClientTs = (int)(round(microtime(true) * 1000));
    $appliedCount = 0;
    $skippedConflicts = [];

    // Push Settings with client_timestamp conflict guard (>= favors local mobile state on tie or newer timestamp)
    if (isset($input['settings']) && is_array($input['settings'])) {
        $st = $input['settings'];
        $settingsTs = max(1, (int)($st['client_timestamp'] ?? $defaultClientTs));
        $forceOverwrite = !empty($st['force_local_override']);

        $existingStmt = $pdo->prepare("SELECT client_timestamp FROM browser_settings WHERE user_id = ?");
        $existingStmt->execute([$userId]);
        $existingSettings = $existingStmt->fetch();
        $serverSettingsTs = $existingSettings ? (int)$existingSettings['client_timestamp'] : 0;

        if ($forceOverwrite || $settingsTs >= $serverSettingsTs) {
            $sStmt = $pdo->prepare(
                "INSERT INTO browser_settings
                 (user_id, engine_mode, search_engine_id, adblock_enabled, fingerprint_shield, https_everywhere, javascript_enabled, block_third_party_cookies, dnt_enabled, anti_scam_enabled, shielded_ip_enabled, active_relay_location, clean_stealth_mode, suggestions_enabled, always_incognito, auto_purge_tab_closure, selected_user_agent, client_timestamp)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   engine_mode = VALUES(engine_mode),
                   search_engine_id = VALUES(search_engine_id),
                   adblock_enabled = VALUES(adblock_enabled),
                   fingerprint_shield = VALUES(fingerprint_shield),
                   https_everywhere = VALUES(https_everywhere),
                   javascript_enabled = VALUES(javascript_enabled),
                   block_third_party_cookies = VALUES(block_third_party_cookies),
                   dnt_enabled = VALUES(dnt_enabled),
                   anti_scam_enabled = VALUES(anti_scam_enabled),
                   shielded_ip_enabled = VALUES(shielded_ip_enabled),
                   active_relay_location = VALUES(active_relay_location),
                   clean_stealth_mode = VALUES(clean_stealth_mode),
                   suggestions_enabled = VALUES(suggestions_enabled),
                   always_incognito = VALUES(always_incognito),
                   auto_purge_tab_closure = VALUES(auto_purge_tab_closure),
                   selected_user_agent = VALUES(selected_user_agent),
                   client_timestamp = VALUES(client_timestamp)"
            );
            $sStmt->execute([
                $userId,
                substr((string)($st['engine_mode'] ?? 'MULTI_ENGINE'), 0, 32),
                substr((string)($st['search_engine_id'] ?? 'silent_stealth'), 0, 32),
                !empty($st['adblock_enabled']) ? 1 : 0,
                !empty($st['fingerprint_shield']) ? 1 : 0,
                !empty($st['https_everywhere']) ? 1 : 0,
                !empty($st['javascript_enabled']) ? 1 : 0,
                !empty($st['block_third_party_cookies']) ? 1 : 0,
                !empty($st['dnt_enabled']) ? 1 : 0,
                !empty($st['anti_scam_enabled']) ? 1 : 0,
                !empty($st['shielded_ip_enabled']) ? 1 : 0,
                substr((string)($st['active_relay_location'] ?? 'Zurich, Switzerland'), 0, 64),
                !empty($st['clean_stealth_mode']) ? 1 : 0,
                !empty($st['suggestions_enabled']) ? 1 : 0,
                !empty($st['always_incognito']) ? 1 : 0,
                !empty($st['auto_purge_tab_closure']) ? 1 : 0,
                substr((string)($st['selected_user_agent'] ?? 'Tor Browser (Spoofed)'), 0, 64),
                $settingsTs
            ]);
            $appliedCount++;
        } else {
            $skippedConflicts[] = [
                'item_type' => 'settings',
                'local_timestamp' => $settingsTs,
                'server_timestamp' => $serverSettingsTs
            ];
        }
    }

    // Push Browsing Sync Items (Bookmarks & History) using ON DUPLICATE KEY UPDATE and timestamp-based conflict protection
    if (isset($input['items']) && is_array($input['items'])) {
        $checkStmt = $pdo->prepare(
            "SELECT title, folder, category, is_pinned, visit_count, client_timestamp FROM browsing_sync_items WHERE user_id = ? AND item_type = ? AND url = ? LIMIT 1"
        );
        $itemStmt = $pdo->prepare(
            "INSERT INTO browsing_sync_items (user_id, item_type, title, url, folder, category, is_pinned, visit_count, client_timestamp)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               title = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(title), title),
               folder = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(folder), folder),
               category = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(category), category),
               is_pinned = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(is_pinned), is_pinned),
               visit_count = GREATEST(visit_count, VALUES(visit_count)),
               client_timestamp = GREATEST(client_timestamp, VALUES(client_timestamp))"
        );
        foreach (array_slice($input['items'], 0, 500) as $item) {
            if (!is_array($item)) continue;
            $url = substr(trim((string)($item['url'] ?? '')), 0, 512);
            if (!preg_match('/^https?:\/\//i', $url)) continue;
            $itemType = substr(trim((string)($item['item_type'] ?? 'bookmark')), 0, 24);
            $title = substr(trim((string)($item['title'] ?? $url)), 0, 160);
            $folder = substr(trim((string)($item['folder'] ?? 'Favorites')), 0, 64);
            $category = substr(trim((string)($item['category'] ?? 'General')), 0, 64);
            $isPinned = !empty($item['is_pinned']) ? 1 : 0;
            $visitCount = max(0, (int)($item['visit_count'] ?? 0));
            $clientTs = max(1, (int)($item['client_timestamp'] ?? $defaultClientTs));
            $forceLocal = !empty($item['force_local']);

            $checkStmt->execute([$userId, $itemType, $url]);
            $existing = $checkStmt->fetch();
            if ($existing && !$forceLocal && (int)$existing['client_timestamp'] > $clientTs) {
                $skippedConflicts[] = [
                    'item_type' => $itemType,
                    'url' => $url,
                    'local_title' => $title,
                    'local_timestamp' => $clientTs,
                    'remote_title' => $existing['title'],
                    'remote_timestamp' => (int)$existing['client_timestamp']
                ];
                continue;
            }

            $itemStmt->execute([$userId, $itemType, $title, $url, $folder, $category, $isPinned, $visitCount, $clientTs]);
            $appliedCount++;
        }
    }

    echo json_encode([
        'status' => 'success',
        'message' => 'Cloud sync push completed.',
        'applied_count' => $appliedCount,
        'conflicts' => $skippedConflicts,
        'timestamp' => time()
    ]);
    exit;
}

// 4. Sync Pull Endpoint (Supports since_timestamp delta filtering + full client_timestamp metadata)
if ($action === 'sync_pull') {
    $user = authenticateUser($pdo);
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status' => 'unauthorized']);
        exit;
    }

    $userId = $user['id'];
    $sinceTs = max(0, (int)($_GET['since_timestamp'] ?? 0));

    $sStmt = $pdo->prepare("SELECT * FROM browser_settings WHERE user_id = ?");
    $sStmt->execute([$userId]);
    $settings = $sStmt->fetch() ?: null;

    if ($sinceTs > 0) {
        $iStmt = $pdo->prepare("SELECT item_type, title, url, folder, category, is_pinned, visit_count, client_timestamp, updated_at FROM browsing_sync_items WHERE user_id = ? AND client_timestamp >= ? ORDER BY client_timestamp DESC LIMIT 500");
        $iStmt->execute([$userId, $sinceTs]);
    } else {
        $iStmt = $pdo->prepare("SELECT item_type, title, url, folder, category, is_pinned, visit_count, client_timestamp, updated_at FROM browsing_sync_items WHERE user_id = ? ORDER BY client_timestamp DESC LIMIT 500");
        $iStmt->execute([$userId]);
    }
    $items = $iStmt->fetchAll();

    echo json_encode([
        'status' => 'success',
        'settings' => $settings,
        'items' => $items,
        'server_timestamp' => (int)(round(microtime(true) * 1000)),
        'timestamp' => time()
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['status' => 'unknown_action']);
?>
