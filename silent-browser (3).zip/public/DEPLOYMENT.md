# Silent Browser Staging Portal, Backend & Release Deployment Guide

**Publisher:** Silent Bot LLC  
**Staging Target:** `https://silentbrowser.silentbot.online/`  
**Untouched Production Portal:** `https://browser.silentbot.online/` (do not overwrite without separate approval)  
**Support Contact:** `silentbrowser@silentbot.online` | `+1 (530) 481-6886`

---

## 1. Staging Web & API Bundle (`/public/`)

- `index.html` — White-theme default responsive portal (`#08783A` accent) with persisted Dark mode toggle, honest platform compatibility status, v1.0.0 release notes, system requirements, installation verification instructions, FAQ, and scoped Privacy Policy & Terms of Service.
- `api.php` — Prepared-PDO JSON backend supporting:
  - `?action=status` (portal + database health check)
  - `?action=releases` (cross-platform release status & roadmap JSON)
  - `?action=relays` (Virtual Shielded IP relay directory)
  - `?action=register`, `?action=login`, `?action=logout`
  - `?action=sync_push` / `?action=sync_pull` (timestamp-based conflict resolution prioritizing local device storage)
- `search.php` — Multi-engine private search redirect/JSON gateway supporting `silent`, `duckduckgo`, `brave`, `startpage`, `ecosia`, `google`, `bing`, and `yahoo`.
- `opensearch.xml`, `robots.txt`, `sitemap.xml` — Search descriptor and crawler metadata configured for `https://silentbrowser.silentbot.online/`.
- `db.sql` — Non-destructive MySQL/MariaDB schema (`CREATE TABLE IF NOT EXISTS`) & idempotent seed rows.
- `.htaccess` — Enforces HTTPS, security headers, and blocks direct HTTP access to `.env`, `db.sql`, and `DEPLOYMENT.md`.
- `.env.example` — Environment template (`SILENT_PORTAL_URL`, `SILENT_DB_HOST`, `SILENT_DB_PORT`, `SILENT_DB_NAME`, `SILENT_DB_USER`, `SILENT_DB_PASS`).

---

## 2. Staging Deployment Checklist

1. **Back Up Existing Target First**:
   Archive the existing staging web root and database before uploading files. Confirm `browser.silentbot.online` is excluded from all sync/upload commands.
2. **Isolate Staging Environment & Database**:
   Create a dedicated staging `.env` **one directory above the staging document root** (`chmod 600 .env`) with `SILENT_PORTAL_URL="https://silentbrowser.silentbot.online/"` and **separate staging database credentials** (never reuse production database credentials on staging).
3. **Upload `/public/` to Staging Document Root**:
   Deploy the contents of `public/` to the `silentbrowser.silentbot.online` document root and upload verified signed release artifacts + `SHA256SUMS.txt` under `/releases/`.
4. **Verify Staging HTTPS & Endpoints**:
   ```bash
   curl -fsSI "https://silentbrowser.silentbot.online/"
   curl -fsS "https://silentbrowser.silentbot.online/api.php?action=status"
   curl -fsS "https://silentbrowser.silentbot.online/api.php?action=releases"
   ```
