<?php
/**
 * Silent Browser Portal Gateway & Content Negotiator
 * Staging Host: https://silentbrowser.silentbot.online/
 */

header('Link: <https://silentbrowser.silentbot.online/llms.txt>; rel="alternate"; type="text/markdown", <https://silentbrowser.silentbot.online/.well-known/mcp/server-card.json>; rel="service-desc"; type="application/json"');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

$acceptHeader = $_SERVER['HTTP_ACCEPT'] ?? '';
$format = $_GET['format'] ?? '';

if ($format === 'markdown' || $format === 'md' || str_contains($acceptHeader, 'text/markdown')) {
    header('Content-Type: text/markdown; charset=utf-8');
    if (file_exists(__DIR__ . '/llms.txt')) {
        readfile(__DIR__ . '/llms.txt');
    } else {
        echo "# Silent Browser\n\nStaging portal: https://silentbrowser.silentbot.online/\n";
    }
    exit;
}

header('Content-Type: text/html; charset=utf-8');
if (file_exists(__DIR__ . '/index.html')) {
    readfile(__DIR__ . '/index.html');
} else {
    echo "<h1>Silent Browser</h1><p>Staging portal online.</p>";
}
?>
