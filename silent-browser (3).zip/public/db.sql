-- Silent Browser Database Schema (MySQL / MariaDB)
-- Staging Target: https://silentbrowser.silentbot.online/
-- Untouched Production: https://browser.silentbot.online/
-- Encoding: utf8mb4

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(191) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT(20) NOT NULL,
  `token` VARCHAR(128) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_token` (`token`),
  KEY `idx_session_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `browser_settings` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT(20) NOT NULL,
  `engine_mode` VARCHAR(32) NOT NULL DEFAULT 'MULTI_ENGINE',
  `search_engine_id` VARCHAR(32) NOT NULL DEFAULT 'silent_stealth',
  `adblock_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `fingerprint_shield` TINYINT(1) NOT NULL DEFAULT 1,
  `https_everywhere` TINYINT(1) NOT NULL DEFAULT 1,
  `javascript_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `block_third_party_cookies` TINYINT(1) NOT NULL DEFAULT 1,
  `dnt_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `anti_scam_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `shielded_ip_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `active_relay_location` VARCHAR(64) NOT NULL DEFAULT 'Zurich, Switzerland',
  `clean_stealth_mode` TINYINT(1) NOT NULL DEFAULT 1,
  `suggestions_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `always_incognito` TINYINT(1) NOT NULL DEFAULT 0,
  `auto_purge_tab_closure` TINYINT(1) NOT NULL DEFAULT 1,
  `selected_user_agent` VARCHAR(64) NOT NULL DEFAULT 'Tor Browser (Spoofed)',
  `client_timestamp` BIGINT(20) NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_settings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `browsing_sync_items` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT(20) NOT NULL,
  `item_type` VARCHAR(24) NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `url` VARCHAR(512) NOT NULL,
  `folder` VARCHAR(64) NOT NULL DEFAULT 'Favorites',
  `category` VARCHAR(64) NOT NULL DEFAULT 'General',
  `is_pinned` TINYINT(1) NOT NULL DEFAULT 0,
  `visit_count` INT(11) NOT NULL DEFAULT 0,
  `client_timestamp` BIGINT(20) NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_type_url` (`user_id`, `item_type`, `url`(191)),
  KEY `idx_sync_timestamp` (`client_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_qr_handoff` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(64) NOT NULL,
  `encrypted_envelope` TEXT NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_qr_session` (`session_id`),
  KEY `idx_qr_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_relay_nodes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `node_code` VARCHAR(32) NOT NULL,
  `location` VARCHAR(64) NOT NULL,
  `virtual_ip` VARCHAR(45) NOT NULL,
  `protocol` VARCHAR(48) NOT NULL,
  `latency_ms` INT(11) NOT NULL DEFAULT 25,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_node_code` (`node_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `silent_browser_relay_nodes` (`node_code`, `location`, `virtual_ip`, `protocol`, `latency_ms`, `is_active`)
VALUES
  ('CH-ZRH-01', 'Zurich, Switzerland',   '185.220.101.42', 'Tor Onion Circuit',     18, 1),
  ('NL-AMS-02', 'Amsterdam, Netherlands','195.35.39.21',   'Netherlands Privacy Relay', 24, 1),
  ('SE-ARN-03', 'Stockholm, Sweden',     '193.138.218.72', 'Mullvad Privacy Relay', 31, 1),
  ('DE-FRA-04', 'Frankfurt, Germany',    '149.202.180.9',  'Silent Safe Relay',     22, 1),
  ('SG-SIN-05', 'Singapore',             '103.253.41.88',  'Asia Stealth Node',     55, 1)
ON DUPLICATE KEY UPDATE
  `location` = VALUES(`location`),
  `virtual_ip` = VALUES(`virtual_ip`),
  `protocol` = VALUES(`protocol`),
  `latency_ms` = VALUES(`latency_ms`),
  `is_active` = VALUES(`is_active`);

CREATE TABLE IF NOT EXISTS `silent_browser_releases` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `platform` VARCHAR(24) NOT NULL,
  `version` VARCHAR(32) NOT NULL,
  `filename` VARCHAR(128) NOT NULL,
  `download_url` VARCHAR(255) NOT NULL,
  `sha256_checksum` VARCHAR(128) DEFAULT NULL,
  `size_label` VARCHAR(32) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_platform_version` (`platform`, `version`),
  KEY `idx_platform_active` (`platform`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `silent_browser_releases` (`platform`, `version`, `filename`, `download_url`, `sha256_checksum`, `size_label`, `is_active`)
VALUES
  ('android', '1.0.0', 'silent-browser-v1.0.0-android.apk', 'https://silentbrowser.silentbot.online/#downloads', 'AWAITING_RELEASE_KEYSTORE_SIGNING', 'Pending Release Sign', 1),
  ('windows', '1.0.0', 'SilentBrowser-Setup-x64.exe', 'https://silentbrowser.silentbot.online/releases/SilentBrowser-Setup-x64.exe', 'fd63a16329aa87d675d109719e29cd1c0c0d5ff0c2edb1e6336bb02531edc7e7', '74 KB (Unsigned)', 1)
ON DUPLICATE KEY UPDATE
  `filename` = VALUES(`filename`),
  `download_url` = VALUES(`download_url`),
  `sha256_checksum` = VALUES(`sha256_checksum`),
  `size_label` = VALUES(`size_label`),
  `is_active` = VALUES(`is_active`);

CREATE TABLE IF NOT EXISTS `silent_browser_portal_sections` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `section_key` VARCHAR(48) NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `subtitle` VARCHAR(255) NOT NULL,
  `sort_order` INT(11) NOT NULL DEFAULT 0,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_section_key` (`section_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_audit_logs` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `event_type` VARCHAR(32) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_type_time` (`event_type`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
