<?php
/**
 * Silent Browser - Multi-Engine Private Search Gateway
 * Publisher: Silent Bot LLC | Staging: https://silentbrowser.silentbot.online/
 */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

$portalUrl = getenv('SILENT_PORTAL_URL') ?: 'https://silentbrowser.silentbot.online/';
$query = substr(trim(str_replace(["\r", "\n"], '', (string)($_GET['q'] ?? ''))), 0, 512);
$engine = strtolower(trim((string)($_GET['engine'] ?? 'silent')));

if ($query === '') {
    echo json_encode([
        'status' => 'idle',
        'app' => 'Silent Search Engine Gateway',
        'portal' => $portalUrl,
        'version' => '1.0.0',
        'engines_supported' => ['silent', 'duckduckgo', 'brave', 'startpage', 'mojeek', 'ecosia', 'google', 'bing', 'yahoo'],
        'publisher' => 'Silent Bot LLC'
    ]);
    exit;
}

$mode = ($_GET['mode'] ?? 'redirect') === 'json' ? 'json' : 'redirect';
$encoded = urlencode($query);

$endpoints = [
    'silent'     => "https://duckduckgo.com/?q=" . $encoded . "&kp=-2&kz=-1&kac=-1&kn=1",
    'duckduckgo' => "https://duckduckgo.com/?q=" . $encoded,
    'brave'      => "https://search.brave.com/search?q=" . $encoded,
    'startpage'  => "https://www.startpage.com/do/search?q=" . $encoded,
    'mojeek'     => "https://www.mojeek.com/search?q=" . $encoded,
    'ecosia'     => "https://www.ecosia.org/search?q=" . $encoded,
    'google'     => "https://www.google.com/search?q=" . $encoded,
    'bing'       => "https://www.bing.com/search?q=" . $encoded,
    'yahoo'      => "https://search.yahoo.com/search?p=" . $encoded
];

$safeEngine = array_key_exists($engine, $endpoints) ? $engine : 'silent';
$targetUrl = $endpoints[$safeEngine];

if ($mode === 'redirect') {
    header("Location: " . $targetUrl, true, 302);
    exit;
}

echo json_encode([
    'status' => 'success',
    'query' => $query,
    'engine' => $safeEngine,
    'target_url' => $targetUrl,
    'timestamp' => time()
]);
?>
