(function () {
  var root = document.documentElement;

  function readSaved() {
    try {
      var a = localStorage.getItem('sb-theme');
      var b = localStorage.getItem('sb_theme');
      var v = a || b || 'light';
      return v === 'dark' ? 'dark' : 'light';
    } catch (e) {
      return 'light';
    }
  }

  function applyTheme(theme) {
    var normalized = theme === 'dark' ? 'dark' : 'light';
    root.setAttribute('data-theme', normalized);
    try {
      localStorage.setItem('sb-theme', normalized);
      localStorage.setItem('sb_theme', normalized);
    } catch (e) {}

    document.querySelectorAll('[data-theme-label], #theme-toggle-label').forEach(function (el) {
      el.textContent = normalized === 'dark' ? 'White Theme' : 'Black Theme';
    });
    document.querySelectorAll('.theme-icon-moon').forEach(function (el) {
      el.style.display = normalized === 'dark' ? 'none' : 'inline-flex';
    });
    document.querySelectorAll('.theme-icon-sun').forEach(function (el) {
      el.style.display = normalized === 'dark' ? 'inline-flex' : 'none';
    });
  }

  applyTheme(readSaved());

  document.addEventListener('DOMContentLoaded', function () {
    applyTheme(readSaved());

    document.querySelectorAll('[data-theme-toggle], #theme-toggle-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(next);
      });
    });

    var menuBtn = document.getElementById('menu-toggle-btn');
    var navWrap = document.getElementById('primary-navigation');
    if (menuBtn && navWrap) {
      menuBtn.addEventListener('click', function () {
        var isOpen = navWrap.classList.toggle('open');
        menuBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    }
  });
})();
