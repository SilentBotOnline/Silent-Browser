package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testSearchEngineUrlFormats() {
    val query = "silent browser"
    val encoded = java.net.URLEncoder.encode(query, "UTF-8")

    val googleUrl = "https://www.google.com/search?q=%s".replace("%s", encoded)
    val braveUrl = "https://search.brave.com/search?q=%s".replace("%s", encoded)
    val duckUrl = "https://duckduckgo.com/?q=%s".replace("%s", encoded)
    val yahooUrl = "https://search.yahoo.com/search?p=%s".replace("%s", encoded)
    val bingUrl = "https://www.bing.com/search?q=%s".replace("%s", encoded)

    assertTrue(googleUrl.contains("google.com/search?q=silent+browser"))
    assertTrue(braveUrl.contains("search.brave.com/search?q=silent+browser"))
    assertTrue(duckUrl.contains("duckduckgo.com/?q=silent+browser"))
    assertTrue(yahooUrl.contains("search.yahoo.com/search?p=silent+browser"))
    assertTrue(bingUrl.contains("bing.com/search?q=silent+browser"))
  }
}
