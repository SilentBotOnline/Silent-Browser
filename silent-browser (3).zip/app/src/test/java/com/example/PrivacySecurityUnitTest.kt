package com.example

import com.example.data.local.BrowserPreferencesDataStore
import com.example.data.network.DevOpsService
import com.example.data.network.DiscoveryCategory
import com.example.data.network.DiscoveryFeedItem
import com.example.data.network.DiscoveryFeedService
import com.example.data.network.NetworkRequestInterceptor
import com.example.data.model.AccountAuthUiState
import com.example.data.model.AppUpdateManager
import com.example.data.model.AppUpdateStatus
import com.example.data.model.AppUpdateUiState
import com.example.data.model.AuthSheetMode
import com.example.data.model.Bookmark
import com.example.data.model.ConflictTimestampRelation
import com.example.data.model.EngineMode
import com.example.data.model.RoadmapMilestoneStatus
import com.example.data.model.SyncConflictItem
import com.example.data.model.SyncConflictResolution
import com.example.data.model.SyncConflictResolver
import com.example.data.model.UpdateChannel
import com.example.data.privacy.PrivacyEngine
import com.example.data.privacy.RequestBlockCategory
import com.example.data.security.CryptoVault
import com.example.data.security.QrSyncManager
import com.example.data.security.QrSyncPrivacySettings
import com.example.ui.theme.AppThemePreset
import com.example.ui.theme.BrowserThemeMode
import com.example.ui.theme.SilentColors
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.security.GeneralSecurityException

class PrivacySecurityUnitTest {

    @Test
    fun dntInterceptor_appendsHeadersWhenEnabled() {
        NetworkRequestInterceptor.resetCounter()
        NetworkRequestInterceptor.isDntEnabled = true

        var capturedDnt: String? = null
        var capturedGpc: String? = null

        val client = OkHttpClient.Builder()
            .addInterceptor(NetworkRequestInterceptor)
            .addInterceptor { chain ->
                val req = chain.request()
                capturedDnt = req.header("DNT")
                capturedGpc = req.header("Sec-GPC")
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body("{}".toResponseBody())
                    .build()
            }
            .build()

        val request = Request.Builder().url("https://silentbot.online/").build()
        client.newCall(request).execute().close()

        assertEquals("1", capturedDnt)
        assertEquals("1", capturedGpc)
        assertEquals(1, NetworkRequestInterceptor.interceptedDntCount.value)
    }

    @Test
    fun dntInterceptor_omitsHeadersWhenDisabled() {
        NetworkRequestInterceptor.isDntEnabled = false
        assertTrue(NetworkRequestInterceptor.buildPrivacyHeaders().isEmpty())
        NetworkRequestInterceptor.isDntEnabled = true
    }

    @Test
    fun privacyEngine_blocksTrackersAndScamThreats() {
        assertTrue(PrivacyEngine.isBlocked("https://www.google-analytics.com/collect"))
        assertTrue(PrivacyEngine.isBlocked("https://pixel.facebook.com/tr"))
        assertFalse(PrivacyEngine.isBlocked("https://silentbot.online/silentbrowser"))

        assertTrue(PrivacyEngine.isScamOrBotThreat("https://paypal-verify.example.com/login"))
        assertTrue(PrivacyEngine.isScamOrBotThreat("https://xn--pple-43d.com/auth"))
        assertTrue(PrivacyEngine.isScamOrBotThreat("https://coinhive.com/lib/miner.js"))
        assertFalse(PrivacyEngine.isScamOrBotThreat("https://duckduckgo.com/?q=privacy"))
    }

    @Test
    fun discoveryFeed_filtersScamUrlsAndUpgradesHttps() {
        val raw = listOf(
            DiscoveryFeedItem(
                id = "1",
                title = "torproject/tor",
                subtitle = "Privacy onion router",
                url = "http://github.com/torproject/tor",
                source = "GitHub Viral",
                metricBadge = "9.5k ★",
                category = DiscoveryCategory.GITHUB_VIRAL
            ),
            DiscoveryFeedItem(
                id = "2",
                title = "Phishing Scam Link",
                subtitle = "Verify account now",
                url = "https://paypal-verify.example.com/login",
                source = "Hacker News",
                metricBadge = "1 pts",
                category = DiscoveryCategory.TECH_NEWS
            )
        )

        val result = DiscoveryFeedService.filterFeedItems(
            rawItems = raw,
            enforceHttps = true,
            enforceAntiScam = true
        )

        assertEquals(1, result.filteredThreatsCount)
        assertEquals(1, result.items.size)
        assertEquals("https://github.com/torproject/tor", result.items.first().url)

        val devToSample = """
            [
              {
                "id": 42,
                "title": "Privacy Engineering Notes",
                "url": "https://dev.to/silent/privacy-notes",
                "positive_reactions_count": 88,
                "comments_count": 12,
                "cover_image": "http://media2.dev.to/cover.png",
                "user": { "name": "Security Researcher" }
              }
            ]
        """.trimIndent()
        val parsedDevTo = DiscoveryFeedService.parseDevToArticlesJson(devToSample)
        assertEquals(1, parsedDevTo.size)
        val filteredDevTo = DiscoveryFeedService.filterFeedItems(parsedDevTo, enforceHttps = true, enforceAntiScam = true)
        assertEquals("https://media2.dev.to/cover.png", filteredDevTo.items.first().imageUrl)

        val ghSample = """
            {
              "items": [
                {
                  "id": 99,
                  "full_name": "privacy/shield",
                  "html_url": "https://github.com/privacy/shield",
                  "description": "Local filter engine",
                  "stargazers_count": 4200,
                  "language": "Kotlin",
                  "owner": { "avatar_url": "https://avatars.githubusercontent.com/u/1?v=4" }
                }
              ]
            }
        """.trimIndent()
        val parsedGh = DiscoveryFeedService.parseGitHubSearchJson(ghSample, DiscoveryCategory.GITHUB_VIRAL, "GitHub Trending")
        assertEquals("https://avatars.githubusercontent.com/u/1?v=4", parsedGh.first().imageUrl)
    }

    @Test
    fun discoveryFeed_fallbackDirectoryReturnsSafeVerifiedItems() {
        val fallback = DiscoveryFeedService.fallbackDirectoryResult(
            enforceHttps = true,
            enforceAntiScam = true
        )

        assertTrue(fallback.isFallback)
        assertTrue(fallback.items.isNotEmpty())
        assertTrue(fallback.items.all { it.url.startsWith("https://") })
        assertTrue(fallback.items.any { it.category == DiscoveryCategory.TECH_NEWS })
        assertTrue(fallback.items.any { it.category == DiscoveryCategory.GITHUB_VIRAL })
        assertTrue(fallback.items.any { it.category == DiscoveryCategory.WEB_HIGHLIGHTS })
    }

    @Test
    fun devOpsService_portalAndEnvConfigAreSafe() {
        assertEquals("https://browser.silentbot.online/", DevOpsService.PRIMARY_WEB_PORTAL_URL)
        assertEquals("https://silentbrowser.silentbot.online/", DevOpsService.MIRROR_PORTAL_URL)
        assertEquals("https://silentbot.online/silentbrowser", DevOpsService.OFFICIAL_PORTAL_URL)
        assertEquals("srv1169.hstgr.io", DevOpsService.DEFAULT_DB_HOST)
        assertEquals(3306, DevOpsService.DEFAULT_DB_PORT)
        assertEquals("u562139744_silentbrowser", DevOpsService.DEFAULT_DB_NAME)

        val phpApi = DevOpsService.generatePhpApiScript()
        assertTrue(phpApi.contains("getenv('SILENT_DB_PASS')"))
        assertTrue(phpApi.contains("https://browser.silentbot.online/"))
        assertTrue(phpApi.contains("silent_browser_relay_nodes"))
        assertTrue(phpApi.contains("silent_browser_portal_sections"))
        assertTrue(phpApi.contains("'version' => '1.0.0'"))
        assertTrue(phpApi.contains("'version_code' => 3"))
        assertTrue(phpApi.contains("'future_update'"))
        assertFalse(phpApi.contains("@Silentbrowser@2026@"))

        val sqlSchema = DevOpsService.generateSqlScript()
        listOf(
            "silent_browser_sync",
            "silent_browser_bookmarks",
            "silent_browser_settings_profiles",
            "silent_browser_qr_handoff",
            "silent_browser_relay_nodes",
            "silent_browser_releases",
            "silent_browser_portal_sections",
            "silent_browser_audit_logs"
        ).forEach { table ->
            assertTrue("Missing SQL table $table", sqlSchema.contains(table))
        }

        val openSearch = DevOpsService.generateOpenSearchXml()
        assertTrue(openSearch.contains("https://browser.silentbot.online/search.php"))
    }

    @Test
    fun cryptoVault_generatesStrongPasswordsWithHighEntropy() {
        val pw1 = CryptoVault.generateStrongPassword(length = 20)
        val pw2 = CryptoVault.generateStrongPassword(length = 20)

        assertEquals(20, pw1.length)
        assertNotEquals(pw1, pw2)
        assertTrue(CryptoVault.calculateEntropyScore(pw1) >= 70)
    }

    private fun samplePrivacySettings(): QrSyncPrivacySettings {
        return QrSyncPrivacySettings(
            engineMode = "MULTI_ENGINE",
            searchEngineId = "silent_stealth",
            adblockEnabled = true,
            fingerprintShieldEnabled = true,
            httpsEverywhereEnabled = true,
            javascriptEnabled = false,
            thirdPartyCookiesBlocked = true,
            doNotTrackEnabled = true,
            antiScamProtectionEnabled = true,
            shieldedIpEnabled = true,
            activeRelayLocation = "Zurich, Switzerland",
            cleanStealthMode = true,
            suggestionsEnabled = false,
            alwaysIncognito = true,
            autoPurgeOnTabClosure = true,
            selectedUserAgent = "Tor Browser (Spoofed)"
        )
    }

    @Test
    fun qrSync_encryptsAndDecryptsBookmarksAndPrivacySettings() {
        val nowMs = 1_750_000_000_000L
        val bookmarks = listOf(
            Bookmark(
                id = 1,
                title = "Silent Portal",
                url = "https://browser.silentbot.online/",
                folder = "Favorites",
                category = "Portal",
                visitCount = 12,
                isPinned = true
            ),
            Bookmark(
                id = 2,
                title = "Tor Project",
                url = "https://www.torproject.org/",
                folder = "Privacy & Tor",
                category = "Privacy",
                visitCount = 5,
                isPinned = false
            )
        )
        val settings = samplePrivacySettings()

        val session = QrSyncManager.generateEncryptedSyncSession(
            bookmarks = bookmarks,
            privacySettings = settings,
            includeBookmarks = true,
            includeSettings = true,
            ttlSeconds = 300,
            nowMs = nowMs
        )

        assertTrue(session.qrPayload.startsWith("silentbrowser://sync?v=1"))
        assertFalse(session.qrPayload.contains("browser.silentbot.online"))
        assertFalse(session.qrPayload.contains("Zurich"))
        assertFalse(session.qrPayload.contains(session.pairingCode.replace("-", "")))

        val decrypted = QrSyncManager.decryptSyncSession(
            qrPayload = session.qrPayload,
            pairingCode = session.pairingCode,
            nowMs = nowMs + 60_000L
        )

        assertEquals(session.sessionId, decrypted.sessionId)
        assertEquals(2, decrypted.bookmarks.size)
        assertEquals("https://browser.silentbot.online/", decrypted.bookmarks.first().url)
        assertTrue(decrypted.bookmarks.first().isPinned)
        assertNotNull(decrypted.privacySettings)
        assertEquals(settings, decrypted.privacySettings)
    }

    @Test
    fun qrSync_rejectsWrongPairingCodeAndTamperedPayload() {
        val nowMs = 1_750_000_000_000L
        val session = QrSyncManager.generateEncryptedSyncSession(
            bookmarks = listOf(Bookmark(title = "Docs", url = "https://silentbot.online/silentbrowser")),
            privacySettings = samplePrivacySettings(),
            ttlSeconds = 300,
            nowMs = nowMs
        )

        try {
            QrSyncManager.decryptSyncSession(
                qrPayload = session.qrPayload,
                pairingCode = "WRONG-CODE-9999",
                nowMs = nowMs + 5_000L
            )
            fail("Expected wrong pairing code to fail AES-GCM verification")
        } catch (_: GeneralSecurityException) {
            // Expected
        }

        val tamperedUri = session.qrPayload.replace("&exp=", "&exp=9")
        try {
            QrSyncManager.decryptSyncSession(
                qrPayload = tamperedUri,
                pairingCode = session.pairingCode,
                nowMs = nowMs + 5_000L
            )
            fail("Expected tampered expiration parameter to fail AAD authentication")
        } catch (_: GeneralSecurityException) {
            // Expected
        }
    }

    @Test
    fun qrSync_rejectsExpiredSessionAndGeneratesValidMatrix() {
        val nowMs = 1_750_000_000_000L
        val session = QrSyncManager.generateEncryptedSyncSession(
            bookmarks = emptyList(),
            privacySettings = samplePrivacySettings(),
            includeBookmarks = false,
            includeSettings = true,
            ttlSeconds = 120,
            nowMs = nowMs
        )

        try {
            QrSyncManager.decryptSyncSession(
                qrPayload = session.qrPayload,
                pairingCode = session.pairingCode,
                nowMs = nowMs + 125_000L
            )
            fail("Expected expired QR session to be rejected")
        } catch (_: IllegalStateException) {
            // Expected
        }

        val matrix = QrSyncManager.generateQrMatrix(session.qrPayload)
        assertTrue(matrix.size >= 21)
        assertEquals(matrix.size, matrix[0].size)
        assertTrue(matrix.any { row -> row.any { it } })
    }

    @Test
    fun qrSync_capsLargeBookmarkListForReliableQrDensity() {
        val nowMs = 1_750_000_000_000L
        val largeList = (1..120).map { idx ->
            Bookmark(
                id = idx.toLong(),
                title = "Bookmark Entry Number $idx - Privacy Directory",
                url = "https://example$idx.silentbot.online/research/item/$idx?ref=privacy",
                folder = "Research",
                category = "Web",
                visitCount = idx,
                isPinned = idx == 120
            )
        }

        val session = QrSyncManager.generateEncryptedSyncSession(
            bookmarks = largeList,
            privacySettings = samplePrivacySettings(),
            ttlSeconds = 300,
            nowMs = nowMs
        )

        assertTrue(session.wasTruncatedForQrCapacity)
        assertTrue(session.qrPayload.length <= 1850)
        assertTrue(session.bookmarkCount in 1 until 120)

        val decrypted = QrSyncManager.decryptSyncSession(
            qrPayload = session.qrPayload,
            pairingCode = session.pairingCode,
            nowMs = nowMs + 1_000L
        )
        assertTrue(decrypted.bookmarks.first().isPinned)
        assertEquals(session.bookmarkCount, decrypted.bookmarks.size)
    }

    @Test
    fun themeAndBranding_whiteThemeTokensAndCleanLabelsMatchSpec() {
        val white = SilentColors.WhiteExtended
        assertFalse(white.isDark)
        assertEquals(0xFFFFFFFF.toInt(), white.screenBackground.value.toInt().takeIf { false } ?: (0xFFFFFFFF).toInt())
        assertEquals(androidx.compose.ui.graphics.Color(0xFFFFFFFF), SilentColors.WhiteBg)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFF5F7F6), SilentColors.WhiteSurface)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF17231C), SilentColors.WhiteTextPrimary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF667085), SilentColors.WhiteTextSecondary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF08783A), SilentColors.WhiteBrandPrimary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF0A9650), SilentColors.WhiteBrandSecondary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFE5EAE7), SilentColors.WhiteBorder)

        assertEquals(BrowserThemeMode.WHITE, AppThemePreset.WHITE.mode)
        assertEquals("Midnight Theme", AppThemePreset.MIDNIGHT.title)
        assertEquals("White Theme", AppThemePreset.WHITE.title)
        assertEquals("Black Theme", AppThemePreset.BLACK.title)
        assertFalse(EngineMode.entries.any { it.title.contains("QUANTUM 2.0", ignoreCase = true) })
        assertFalse(EngineMode.entries.any { it.subtitle.contains("QUANTUM 2.0", ignoreCase = true) })
    }

    @Test
    fun authInputValidation_enforcesEmailPasswordAndConfirmRules() {
        assertNull(
            SyncConflictResolver.validateAuthInput(
                AccountAuthUiState(
                    mode = AuthSheetMode.SIGN_IN,
                    email = "privacy@silentbot.online",
                    password = "strongpass"
                )
            )
        )
        assertNotNull(
            SyncConflictResolver.validateAuthInput(
                AccountAuthUiState(mode = AuthSheetMode.SIGN_IN, email = "bad-email", password = "strongpass")
            )
        )
        assertNotNull(
            SyncConflictResolver.validateAuthInput(
                AccountAuthUiState(mode = AuthSheetMode.SIGN_IN, email = "privacy@silentbot.online", password = "123")
            )
        )
        assertNotNull(
            SyncConflictResolver.validateAuthInput(
                AccountAuthUiState(
                    mode = AuthSheetMode.CREATE_ACCOUNT,
                    email = "privacy@silentbot.online",
                    password = "strongpass",
                    confirmPassword = "different"
                )
            )
        )
        assertNull(
            SyncConflictResolver.validateAuthInput(
                AccountAuthUiState(
                    mode = AuthSheetMode.CREATE_ACCOUNT,
                    email = "privacy@silentbot.online",
                    password = "strongpass",
                    confirmPassword = "strongpass"
                )
            )
        )
    }

    @Test
    fun syncConflictResolution_prioritizesMobileLocalStorageAndSupportsAllModes() {
        assertTrue(SyncConflictResolver.shouldPrioritizeLocalAutomatic(localTimestamp = 2000L, remoteTimestamp = 2000L))
        assertTrue(SyncConflictResolver.shouldPrioritizeLocalAutomatic(localTimestamp = 3000L, remoteTimestamp = 2000L))
        assertFalse(SyncConflictResolver.shouldPrioritizeLocalAutomatic(localTimestamp = 1000L, remoteTimestamp = 2000L))

        val conflict = SyncConflictItem(
            id = "bookmark:https://browser.silentbot.online/",
            itemType = "bookmark",
            url = "https://browser.silentbot.online/",
            localTitle = "Mobile Local Portal",
            localTimestamp = 5_000L,
            localFolder = "Pinned",
            localCategory = "Portal",
            localIsPinned = true,
            localVisitCount = 9,
            remoteTitle = "Desktop Remote Portal",
            remoteTimestamp = 5_000L,
            remoteFolder = "General",
            remoteCategory = "Web",
            remoteIsPinned = false,
            remoteVisitCount = 12
        )

        val keepLocal = SyncConflictResolver.resolveConflict(conflict, SyncConflictResolution.KEEP_LOCAL, nowMs = 6_000L)
        assertTrue(keepLocal.prioritizedLocal)
        assertEquals("Mobile Local Portal", keepLocal.winnerTitle)
        assertEquals("Pinned", keepLocal.winnerFolder)
        assertEquals(12, keepLocal.winnerVisitCount)
        assertEquals(6_000L, keepLocal.resolvedTimestamp)

        val useRemote = SyncConflictResolver.resolveConflict(conflict, SyncConflictResolution.USE_REMOTE, nowMs = 6_000L)
        assertFalse(useRemote.prioritizedLocal)
        assertEquals("Desktop Remote Portal", useRemote.winnerTitle)
        assertEquals("General", useRemote.winnerFolder)

        val merged = SyncConflictResolver.resolveConflict(conflict, SyncConflictResolution.MERGE, nowMs = 6_000L)
        assertTrue(merged.prioritizedLocal)
        assertTrue(merged.winnerTitle.startsWith("Mobile Local Portal"))
        assertTrue(merged.winnerIsPinned)
        assertEquals(12, merged.winnerVisitCount)
    }

    @Test
    fun activeBrowsingUrlCheck_controlsAutoHideBottomBarState() {
        assertFalse(SyncConflictResolver.isBrowsingUrlActive(""))
        assertFalse(SyncConflictResolver.isBrowsingUrlActive("   "))
        assertFalse(SyncConflictResolver.isBrowsingUrlActive("about:blank"))
        assertTrue(SyncConflictResolver.isBrowsingUrlActive("https://browser.silentbot.online/"))
    }

    @Test
    fun syncConflictClassification_identifiesTimestampMismatchesAccurately() {
        assertEquals(
            ConflictTimestampRelation.LOCAL_NEWER,
            SyncConflictResolver.classifyTimestampMismatch(localTimestamp = 8000L, remoteTimestamp = 5000L)
        )
        assertEquals(
            ConflictTimestampRelation.REMOTE_NEWER,
            SyncConflictResolver.classifyTimestampMismatch(localTimestamp = 4000L, remoteTimestamp = 5000L)
        )
        assertEquals(
            ConflictTimestampRelation.EQUAL_TIE,
            SyncConflictResolver.classifyTimestampMismatch(localTimestamp = 5000L, remoteTimestamp = 5000L)
        )
        assertTrue(
            SyncConflictResolver.hasConflictMismatch(
                localTitle = "Local Note",
                localFolder = "Favorites",
                localTimestamp = 5000L,
                remoteTitle = "Remote Note",
                remoteFolder = "Favorites",
                remoteTimestamp = 4500L
            )
        )
        assertFalse(
            SyncConflictResolver.hasConflictMismatch(
                localTitle = "Same Title",
                localFolder = "Favorites",
                localTimestamp = 5000L,
                remoteTitle = "Same Title",
                remoteFolder = "Favorites",
                remoteTimestamp = 5000L
            )
        )
        assertEquals("Local +1m 5s", SyncConflictResolver.formatTimestampDelta(localTimestamp = 65_000L, remoteTimestamp = 0L))
        assertEquals("Remote +45s", SyncConflictResolver.formatTimestampDelta(localTimestamp = 0L, remoteTimestamp = 45_000L))
        assertEquals("0s delta", SyncConflictResolver.formatTimestampDelta(localTimestamp = 5_000L, remoteTimestamp = 5_000L))
    }

    @Test
    fun appUpdateManager_comparesSemanticVersionsAndDetectsNewerBuilds() {
        assertTrue(AppUpdateManager.compareVersions("v1.1.0", "1.0.0") > 0)
        assertTrue(AppUpdateManager.compareVersions("1.0.1", "1.0.0") > 0)
        assertTrue(AppUpdateManager.compareVersions("2.0.0", "v1.9.9") > 0)
        assertTrue(AppUpdateManager.compareVersions("0.1-prod", "1.0.0") < 0)
        assertEquals(0, AppUpdateManager.compareVersions("v1.0.0", "1.0.0"))
        assertTrue(AppUpdateManager.compareVersions("1.1.0-beta", "1.1.0") < 0)

        assertTrue(
            AppUpdateManager.isUpdateNewer(
                currentVersionName = "1.0.0",
                currentVersionCode = 3,
                remoteVersionName = "1.0.0",
                remoteVersionCode = 4
            )
        )
        assertTrue(
            AppUpdateManager.isUpdateNewer(
                currentVersionName = "1.0.0",
                currentVersionCode = 3,
                remoteVersionName = "1.1.0",
                remoteVersionCode = 3
            )
        )
        assertFalse(
            AppUpdateManager.isUpdateNewer(
                currentVersionName = "1.0.0",
                currentVersionCode = 3,
                remoteVersionName = "1.0.0",
                remoteVersionCode = 3
            )
        )
    }

    @Test
    fun appUpdateManager_handlesOfflineFallbackAndFutureRoadmapMilestones() {
        val stableOffline = AppUpdateManager.parseReleaseCatalog(
            rawJson = null,
            currentVersionName = "1.0.0",
            currentVersionCode = 3,
            channel = UpdateChannel.STABLE
        )
        assertEquals(AppUpdateStatus.CHECK_FAILED, stableOffline.status)
        assertEquals("1.0.0", stableOffline.latestVersionName)
        assertEquals(3, stableOffline.latestVersionCode)
        assertTrue(stableOffline.roadmap.any { it.status == RoadmapMilestoneStatus.SHIPPED })
        assertTrue(stableOffline.roadmap.any { it.status == RoadmapMilestoneStatus.IN_PROGRESS })
        assertTrue(stableOffline.roadmap.any { it.status == RoadmapMilestoneStatus.UPCOMING })
        assertTrue(stableOffline.platformArtifacts.any { it.platformKey == "android" })

        val betaOffline = AppUpdateManager.parseReleaseCatalog(
            rawJson = "",
            currentVersionName = "1.0.0",
            currentVersionCode = 3,
            channel = UpdateChannel.BETA
        )
        assertEquals(AppUpdateStatus.FUTURE_PREVIEW, betaOffline.status)
        assertTrue(betaOffline.futureUpdate.versionTag.startsWith("v1."))

        val uiStateUpdatable = AppUpdateUiState(
            currentVersionName = "1.0.0",
            currentVersionCode = 3,
            latestVersionName = "1.1.0",
            latestVersionCode = 4,
            status = AppUpdateStatus.UP_TO_DATE
        )
        assertTrue(uiStateUpdatable.isUpdateAvailable)
    }

    @Test
    fun privacyEngine_evaluateRequestAndCustomRulesWorkAccurately() {
        val adDecision = PrivacyEngine.evaluateRequest("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js")
        assertTrue(adDecision.blocked)
        assertEquals(RequestBlockCategory.AD_NETWORK, adDecision.category)

        val trackerDecision = PrivacyEngine.evaluateRequest("https://www.google-analytics.com/g/collect?v=2")
        assertTrue(trackerDecision.blocked)
        assertEquals(RequestBlockCategory.ANALYTICS_TRACKER, trackerDecision.category)

        val minerDecision = PrivacyEngine.evaluateRequest("https://coinhive.com/lib/coinhive.min.js")
        assertTrue(minerDecision.blocked)
        assertEquals(RequestBlockCategory.CRYPTOMINER_BOT, minerDecision.category)

        val adPathDecision = PrivacyEngine.evaluateRequest("https://news.example.com/prebid/auction.js")
        assertTrue(adPathDecision.blocked)
        assertEquals(RequestBlockCategory.AD_NETWORK, adPathDecision.category)
        assertEquals("path:/prebid", adPathDecision.matchedRule)

        val customBlockDecision = PrivacyEngine.evaluateRequest(
            url = "https://metrics.partner.example.org/beacon",
            blockedOverrides = setOf("partner.example.org"),
            allowedOverrides = emptySet()
        )
        assertTrue(customBlockDecision.blocked)
        assertEquals(RequestBlockCategory.CUSTOM_RULE, customBlockDecision.category)

        val allowOverrideDecision = PrivacyEngine.evaluateRequest(
            url = "https://www.google-analytics.com/collect",
            blockedOverrides = emptySet(),
            allowedOverrides = setOf("google-analytics.com")
        )
        assertFalse(allowOverrideDecision.blocked)
        assertEquals(RequestBlockCategory.ALLOWED, allowOverrideDecision.category)
        assertEquals("allow:google-analytics.com", allowOverrideDecision.matchedRule)

        // Scam shield remains enforced even if user accidentally allowlists domain
        val scamStillBlocked = PrivacyEngine.evaluateRequest(
            url = "https://paypal-verify.example.com/signin",
            allowedOverrides = setOf("example.com")
        )
        assertTrue(scamStillBlocked.blocked)
        assertEquals(RequestBlockCategory.SCAM_PHISHING, scamStillBlocked.category)

        assertEquals("ads.example.com", PrivacyEngine.normalizeDomainInput("https://*.ads.example.com/banner?id=1"))
        assertNull(PrivacyEngine.normalizeDomainInput("not a domain"))
    }

    @Test
    fun browserPreferencesDataStore_resolvesWhiteBlackMidnightAndLegacyThemes() {
        assertEquals(AppThemePreset.WHITE, BrowserPreferencesDataStore.resolveThemePreset("white"))
        assertEquals(AppThemePreset.BLACK, BrowserPreferencesDataStore.resolveThemePreset("black"))
        assertEquals(AppThemePreset.MIDNIGHT, BrowserPreferencesDataStore.resolveThemePreset("midnight"))
        assertEquals(AppThemePreset.MIDNIGHT, BrowserPreferencesDataStore.resolveThemePreset("cyber_midnight"))
        assertEquals(AppThemePreset.WHITE, BrowserPreferencesDataStore.resolveThemePreset(null))
        assertEquals(AppThemePreset.WHITE, BrowserPreferencesDataStore.resolveThemePreset("unknown_theme"))
    }
}
