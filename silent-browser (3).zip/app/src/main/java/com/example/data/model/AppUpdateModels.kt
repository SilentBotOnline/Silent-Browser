package com.example.data.model

import com.example.BuildConfig
import org.json.JSONArray
import org.json.JSONObject

enum class UpdateChannel(
    val id: String,
    val label: String,
    val description: String
) {
    STABLE(
        id = "stable",
        label = "Production Stable",
        description = "Verified Play & signed official releases"
    ),
    BETA(
        id = "beta",
        label = "Early Access Beta",
        description = "Pre-release privacy & adaptive workspace builds"
    )
}

enum class AppUpdateStatus(val badgeLabel: String) {
    UP_TO_DATE("UP TO DATE"),
    CHECKING("CHECKING"),
    UPDATE_AVAILABLE("UPDATE AVAILABLE"),
    FUTURE_PREVIEW("FUTURE UPDATE READY"),
    CHECK_FAILED("OFFLINE / CACHED")
}

enum class RoadmapMilestoneStatus(val label: String) {
    SHIPPED("SHIPPED"),
    IN_PROGRESS("IN PROGRESS"),
    UPCOMING("PLANNED")
}

data class RoadmapMilestone(
    val id: String,
    val versionTag: String,
    val targetWindow: String,
    val title: String,
    val summary: String,
    val highlights: List<String>,
    val status: RoadmapMilestoneStatus,
    val progressPercent: Int
)

data class ReleasePlatformArtifact(
    val platformKey: String,
    val displayName: String,
    val packageName: String,
    val sizeLabel: String,
    val downloadUrl: String,
    val checksumUrl: String
)

data class FutureUpdatePreview(
    val versionTag: String,
    val versionCode: Int,
    val targetWindow: String,
    val title: String,
    val summary: String,
    val highlights: List<String>,
    val readinessPercent: Int,
    val isOptInAvailable: Boolean
)

data class AppUpdateUiState(
    val currentVersionName: String = BuildConfig.VERSION_NAME,
    val currentVersionCode: Int = BuildConfig.VERSION_CODE,
    val latestVersionName: String = BuildConfig.VERSION_NAME,
    val latestVersionCode: Int = BuildConfig.VERSION_CODE,
    val status: AppUpdateStatus = AppUpdateStatus.UP_TO_DATE,
    val selectedChannel: UpdateChannel = UpdateChannel.STABLE,
    val autoCheckEnabled: Boolean = true,
    val notifyFutureReleases: Boolean = true,
    val isChecking: Boolean = false,
    val lastCheckedEpochMs: Long = 0L,
    val hasLiveFeedResponse: Boolean = false,
    val statusMessage: String = "Installed v${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE}) • Future preview queued",
    val releaseNotes: List<String> = AppUpdateManager.defaultReleaseNotes(),
    val futureUpdate: FutureUpdatePreview = AppUpdateManager.defaultFutureUpdate(),
    val roadmap: List<RoadmapMilestone> = AppUpdateManager.defaultRoadmap(
        currentVersionName = BuildConfig.VERSION_NAME,
        currentVersionCode = BuildConfig.VERSION_CODE
    ),
    val platformArtifacts: List<ReleasePlatformArtifact> = AppUpdateManager.defaultPlatformArtifacts()
) {
    val isUpdateAvailable: Boolean
        get() = status == AppUpdateStatus.UPDATE_AVAILABLE ||
            AppUpdateManager.isUpdateNewer(
                currentVersionName = currentVersionName,
                currentVersionCode = currentVersionCode,
                remoteVersionName = latestVersionName,
                remoteVersionCode = latestVersionCode
            )
}

data class ParsedReleaseCatalog(
    val latestVersionName: String,
    val latestVersionCode: Int,
    val status: AppUpdateStatus,
    val statusMessage: String,
    val releaseNotes: List<String>,
    val futureUpdate: FutureUpdatePreview,
    val roadmap: List<RoadmapMilestone>,
    val platformArtifacts: List<ReleasePlatformArtifact>
)

object AppUpdateManager {

    fun defaultReleaseNotes(): List<String> = listOf(
        "White-theme-first UI system across Browser, Command Hub & Settings",
        "Granular Sync Conflicts resolution (Keep Local, Use Remote, Merge)",
        "Virtual Shielded IP relays with DNT: 1 and Sec-GPC: 1 enforcement",
        "Zero-permission Play Store & SHA-256 verified release verification"
    )

    fun defaultFutureUpdate(): FutureUpdatePreview = FutureUpdatePreview(
        versionTag = "v1.1.0",
        versionCode = 4,
        targetWindow = "Upcoming Release (Build 4)",
        title = "Multi-Hop Stealth Routing & Passkey Cloud Sync",
        summary = "Next scheduled Silent Browser release featuring chained privacy relays, hardware passkey sync unlock, and per-domain sandbox profiles.",
        highlights = listOf(
            "Dual-hop Tor + WireGuard relay chaining for sensitive workspaces",
            "Hardware FIDO2 / Passkey biometric vault & sync verification",
            "Per-site isolated script & cookie partition rules",
            "Adaptive tablet & foldable split-workspace multitasking"
        ),
        readinessPercent = 82,
        isOptInAvailable = true
    )

    fun defaultRoadmap(
        currentVersionName: String = BuildConfig.VERSION_NAME,
        currentVersionCode: Int = BuildConfig.VERSION_CODE
    ): List<RoadmapMilestone> = listOf(
        RoadmapMilestone(
            id = "ms_v1_0_0",
            versionTag = "v${currentVersionName.removePrefix("v")}",
            targetWindow = "Current Production (Build $currentVersionCode)",
            title = "Core Privacy Suite & White-First Command Hub",
            summary = "Production baseline with Amnesic Panic Wipe, AES-256-GCM vault, Virtual Shielded IP, and cross-device sync conflict resolution.",
            highlights = listOf(
                "Crisp White-First Material 3 UI with persisted Black & Midnight themes",
                "Granular timestamp-guarded Sync Conflicts manager",
                "Auto-collapsing immersive browser viewport & DNT/GPC header shield"
            ),
            status = RoadmapMilestoneStatus.SHIPPED,
            progressPercent = 100
        ),
        RoadmapMilestone(
            id = "ms_v1_1_0",
            versionTag = "v1.1.0",
            targetWindow = "Next Future Update (Q2 Release)",
            title = "Multi-Hop Stealth Routing & Passkey Sync",
            summary = "Introduces dual-hop encrypted relay chaining, hardware passkey protection for encrypted cloud sync, and per-origin sandbox profiles.",
            highlights = listOf(
                "Dual-hop relay circuit health telemetry",
                "Biometric + Passkey cryptographic sync envelope",
                "Per-domain JavaScript, canvas & WebRTC overrides"
            ),
            status = RoadmapMilestoneStatus.IN_PROGRESS,
            progressPercent = 82
        ),
        RoadmapMilestone(
            id = "ms_v1_2_0",
            versionTag = "v1.2.0",
            targetWindow = "Upcoming Milestone",
            title = "Encrypted Tab Groups & Offline Reading Vault",
            summary = "Sync pinned workspace tab collections via QR handoff and archive sanitized offline web snapshots inside Room encrypted storage.",
            highlights = listOf(
                "QR-paired multi-tab workspace handoff",
                "Tracker-stripped offline page archival",
                "Custom filter-list subscriptions for AdBlock engine"
            ),
            status = RoadmapMilestoneStatus.UPCOMING,
            progressPercent = 45
        ),
        RoadmapMilestone(
            id = "ms_v2_0_0",
            versionTag = "v2.0.0",
            targetWindow = "Long-Term Architecture",
            title = "Distributed Relay Mesh & Universal Workspaces",
            summary = "Unified desktop-mobile session parity with ephemeral onion workspace containers and hardware security key master locks.",
            highlights = listOf(
                "FIDO2 USB/NFC hardware key master unlock",
                "Ephemeral isolated container workspaces",
                "Synchronized desktop & Android release attestation"
            ),
            status = RoadmapMilestoneStatus.UPCOMING,
            progressPercent = 20
        )
    )

    fun defaultPlatformArtifacts(): List<ReleasePlatformArtifact> = listOf(
        ReleasePlatformArtifact(
            platformKey = "android",
            displayName = "Android (5.0 - 16+)",
            packageName = "silent-browser-v1.0.0-android.apk",
            sizeLabel = "28.4 MB",
            downloadUrl = "https://browser.silentbot.online/?os=android#downloads",
            checksumUrl = "https://browser.silentbot.online/releases/SHA256SUMS.txt"
        ),
        ReleasePlatformArtifact(
            platformKey = "windows",
            displayName = "Windows 10/11 (x64)",
            packageName = "silent-browser-v1.0.0-win-x64.exe",
            sizeLabel = "64.2 MB",
            downloadUrl = "https://browser.silentbot.online/?os=windows#downloads",
            checksumUrl = "https://browser.silentbot.online/releases/SHA256SUMS.txt"
        ),
        ReleasePlatformArtifact(
            platformKey = "ios",
            displayName = "iPhone / iPad (iOS 15+)",
            packageName = "Silent Browser iOS App",
            sizeLabel = "31.8 MB",
            downloadUrl = "https://browser.silentbot.online/?os=ios#downloads",
            checksumUrl = "https://browser.silentbot.online/releases/SHA256SUMS.txt"
        ),
        ReleasePlatformArtifact(
            platformKey = "macos",
            displayName = "macOS (Apple Silicon & Intel)",
            packageName = "silent-browser-v1.0.0-macos.dmg",
            sizeLabel = "68.9 MB",
            downloadUrl = "https://browser.silentbot.online/?os=macos#downloads",
            checksumUrl = "https://browser.silentbot.online/releases/SHA256SUMS.txt"
        ),
        ReleasePlatformArtifact(
            platformKey = "other",
            displayName = "Linux (AppImage & Source)",
            packageName = "silent-browser-v1.0.0-linux-x86_64.AppImage",
            sizeLabel = "59.5 MB",
            downloadUrl = "https://browser.silentbot.online/?os=other#downloads",
            checksumUrl = "https://browser.silentbot.online/releases/SHA256SUMS.txt"
        )
    )

    /**
     * Compares two semantic version strings (e.g. "v1.1.0" vs "1.0.0", "0.1-prod" vs "1.0.0").
     * Returns >0 when vA > vB, <0 when vA < vB, 0 when equal.
     */
    fun compareVersions(vA: String, vB: String): Int {
        val partsA = parseNumericSegments(vA)
        val partsB = parseNumericSegments(vB)
        val maxLen = maxOf(partsA.size, partsB.size)
        for (i in 0 until maxLen) {
            val a = partsA.getOrElse(i) { 0 }
            val b = partsB.getOrElse(i) { 0 }
            if (a != b) return a.compareTo(b)
        }
        val aIsPre = vA.contains("beta", ignoreCase = true) || vA.contains("alpha", ignoreCase = true)
        val bIsPre = vB.contains("beta", ignoreCase = true) || vB.contains("alpha", ignoreCase = true)
        if (aIsPre != bIsPre) {
            return if (aIsPre) -1 else 1
        }
        return 0
    }

    private fun parseNumericSegments(version: String): List<Int> {
        val cleaned = version.trim()
            .removePrefix("v")
            .removePrefix("V")
            .substringBefore("-")
            .substringBefore("+")
        val segments = cleaned.split(".")
            .mapNotNull { seg -> seg.filter { it.isDigit() }.toIntOrNull() }
        return if (segments.isEmpty()) listOf(0) else segments
    }

    fun isUpdateNewer(
        currentVersionName: String,
        currentVersionCode: Int,
        remoteVersionName: String,
        remoteVersionCode: Int?
    ): Boolean {
        if (remoteVersionCode != null && remoteVersionCode > currentVersionCode) {
            return true
        }
        return compareVersions(remoteVersionName, currentVersionName) > 0
    }

    fun parseReleaseCatalog(
        rawJson: String?,
        currentVersionName: String,
        currentVersionCode: Int,
        channel: UpdateChannel
    ): ParsedReleaseCatalog {
        val fallbackFuture = defaultFutureUpdate()
        val fallbackRoadmap = defaultRoadmap(currentVersionName, currentVersionCode)
        val fallbackNotes = defaultReleaseNotes()
        val fallbackArtifacts = defaultPlatformArtifacts()

        if (rawJson.isNullOrBlank()) {
            val offlineStatus = if (channel == UpdateChannel.BETA) {
                AppUpdateStatus.FUTURE_PREVIEW
            } else {
                AppUpdateStatus.CHECK_FAILED
            }
            val msg = if (channel == UpdateChannel.BETA) {
                "Release feed offline • Early Access preview ${fallbackFuture.versionTag} staged on roadmap"
            } else {
                "Release feed offline • Running verified build v$currentVersionName (Code $currentVersionCode)"
            }
            return ParsedReleaseCatalog(
                latestVersionName = currentVersionName,
                latestVersionCode = currentVersionCode,
                status = offlineStatus,
                statusMessage = msg,
                releaseNotes = fallbackNotes,
                futureUpdate = fallbackFuture,
                roadmap = fallbackRoadmap,
                platformArtifacts = fallbackArtifacts
            )
        }

        return try {
            val root = JSONObject(rawJson)
            val parsedVersionRaw = root.optString("version", currentVersionName).trim().removePrefix("v")
            val remoteVersionName = if (parsedVersionRaw.isBlank() || parsedVersionRaw == "0.1-prod") {
                currentVersionName
            } else {
                parsedVersionRaw
            }
            val remoteVersionCode = root.optInt("version_code", currentVersionCode).coerceAtLeast(1)

            val parsedNotes = parseStringArray(root.optJSONArray("release_notes")).ifEmpty { fallbackNotes }

            val futureObj = root.optJSONObject("future_update")
            val futureUpdate = if (futureObj != null) {
                FutureUpdatePreview(
                    versionTag = futureObj.optString("version", fallbackFuture.versionTag).ifBlank { fallbackFuture.versionTag },
                    versionCode = futureObj.optInt("version_code", fallbackFuture.versionCode),
                    targetWindow = futureObj.optString("target_window", fallbackFuture.targetWindow).ifBlank { fallbackFuture.targetWindow },
                    title = futureObj.optString("title", fallbackFuture.title).ifBlank { fallbackFuture.title },
                    summary = futureObj.optString("summary", fallbackFuture.summary).ifBlank { fallbackFuture.summary },
                    highlights = parseStringArray(futureObj.optJSONArray("highlights")).ifEmpty { fallbackFuture.highlights },
                    readinessPercent = futureObj.optInt("readiness_percent", fallbackFuture.readinessPercent).coerceIn(0, 100),
                    isOptInAvailable = futureObj.optBoolean("opt_in_available", true)
                )
            } else {
                fallbackFuture
            }

            val roadmapList = parseRoadmapArray(root.optJSONArray("roadmap")).ifEmpty { fallbackRoadmap }
            val artifactsList = parsePlatformsObject(root.optJSONObject("platforms")).ifEmpty { fallbackArtifacts }

            val hasStableUpdate = isUpdateNewer(
                currentVersionName = currentVersionName,
                currentVersionCode = currentVersionCode,
                remoteVersionName = remoteVersionName,
                remoteVersionCode = remoteVersionCode
            )
            val hasFutureOptIn = channel == UpdateChannel.BETA && isUpdateNewer(
                currentVersionName = currentVersionName,
                currentVersionCode = currentVersionCode,
                remoteVersionName = futureUpdate.versionTag,
                remoteVersionCode = futureUpdate.versionCode
            )

            val (status, statusMsg) = when {
                hasStableUpdate -> AppUpdateStatus.UPDATE_AVAILABLE to
                    "Update available: v$remoteVersionName (Build $remoteVersionCode) ready for deployment"
                hasFutureOptIn -> AppUpdateStatus.FUTURE_PREVIEW to
                    "Future release ${futureUpdate.versionTag} (${futureUpdate.readinessPercent}% ready) available for Early Access preview"
                else -> AppUpdateStatus.UP_TO_DATE to
                    "Verified up to date • Running production v$currentVersionName (Build $currentVersionCode)"
            }

            ParsedReleaseCatalog(
                latestVersionName = if (hasStableUpdate) remoteVersionName else currentVersionName,
                latestVersionCode = if (hasStableUpdate) remoteVersionCode else currentVersionCode,
                status = status,
                statusMessage = statusMsg,
                releaseNotes = parsedNotes,
                futureUpdate = futureUpdate,
                roadmap = roadmapList,
                platformArtifacts = artifactsList
            )
        } catch (_: Exception) {
            ParsedReleaseCatalog(
                latestVersionName = currentVersionName,
                latestVersionCode = currentVersionCode,
                status = AppUpdateStatus.CHECK_FAILED,
                statusMessage = "Manifest parse fallback • Running verified v$currentVersionName (Build $currentVersionCode)",
                releaseNotes = fallbackNotes,
                futureUpdate = fallbackFuture,
                roadmap = fallbackRoadmap,
                platformArtifacts = fallbackArtifacts
            )
        }
    }

    private fun parseStringArray(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val v = arr.optString(i).trim()
            if (v.isNotEmpty()) list.add(v)
        }
        return list
    }

    private fun parseRoadmapArray(arr: JSONArray?): List<RoadmapMilestone> {
        if (arr == null || arr.length() == 0) return emptyList()
        val items = mutableListOf<RoadmapMilestone>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val statusStr = obj.optString("status", "PLANNED").uppercase()
            val status = when (statusStr) {
                "SHIPPED" -> RoadmapMilestoneStatus.SHIPPED
                "IN_PROGRESS", "IN PROGRESS" -> RoadmapMilestoneStatus.IN_PROGRESS
                else -> RoadmapMilestoneStatus.UPCOMING
            }
            items.add(
                RoadmapMilestone(
                    id = obj.optString("id", "ms_$i"),
                    versionTag = obj.optString("version", "v1.x"),
                    targetWindow = obj.optString("target_window", "Scheduled"),
                    title = obj.optString("title", "Silent Browser Milestone"),
                    summary = obj.optString("summary", ""),
                    highlights = parseStringArray(obj.optJSONArray("highlights")),
                    status = status,
                    progressPercent = obj.optInt("progress_percent", 0).coerceIn(0, 100)
                )
            )
        }
        return items
    }

    private fun parsePlatformsObject(obj: JSONObject?): List<ReleasePlatformArtifact> {
        if (obj == null) return emptyList()
        val keys = listOf("android", "windows", "ios", "macos", "other")
        val list = mutableListOf<ReleasePlatformArtifact>()
        for (key in keys) {
            val pObj = obj.optJSONObject(key) ?: continue
            list.add(
                ReleasePlatformArtifact(
                    platformKey = key,
                    displayName = pObj.optString("name", key),
                    packageName = pObj.optString("package", ""),
                    sizeLabel = pObj.optString("size", ""),
                    downloadUrl = pObj.optString("url", "https://browser.silentbot.online/#downloads"),
                    checksumUrl = pObj.optString("checksum_url", "https://browser.silentbot.online/releases/SHA256SUMS.txt")
                )
            )
        }
        return list
    }
}
