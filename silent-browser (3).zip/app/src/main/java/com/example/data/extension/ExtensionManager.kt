package com.example.data.extension

import com.example.data.model.BrowserExtension
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object ExtensionManager {

    private val defaultExtensions = listOf(
        BrowserExtension(
            id = "ublock_script_shield",
            name = "uBlock Origin Lite",
            version = "1.58.0",
            description = "High-efficiency element and tracking script blocker. Eliminates advertising banners and telemetry.",
            author = "gorhill / Silent Team",
            iconLetter = "🛡️",
            isEnabled = true,
            permissions = listOf("webRequest", "scripting", "storage"),
            contentScript = """
                (function() {
                    const style = document.createElement('style');
                    style.innerHTML = 'iframe[src*="ad"], iframe[src*="doubleclick"], div[class*="banner-ad"], div[id*="google_ads"], div[class*="sponsored"], .ad-container, .adsbygoogle { display: none !important; opacity: 0 !important; pointer-events: none !important; }';
                    document.head ? document.head.appendChild(style) : document.documentElement.appendChild(style);
                })();
            """.trimIndent()
        ),
        BrowserExtension(
            id = "dark_reader_oled",
            name = "Dark Reader OLED",
            version = "4.9.77",
            description = "Inverts bright web pages to deep OLED black theme (#060A13) with eye-protection contrast.",
            author = "Alexander Shutov",
            iconLetter = "🌙",
            isEnabled = true,
            permissions = listOf("activeTab", "storage"),
            contentScript = """
                (function() {
                    if (window.__dark_reader_applied) return;
                    window.__dark_reader_applied = true;
                    const style = document.createElement('style');
                    style.innerHTML = 'html, body { background-color: #060a13 !important; color: #e2e8f0 !important; } img, video, canvas { filter: brightness(0.9) contrast(1.05) !important; }';
                    document.head ? document.head.appendChild(style) : document.documentElement.appendChild(style);
                })();
            """.trimIndent()
        ),
        BrowserExtension(
            id = "webrtc_ip_shield",
            name = "WebRTC & Geo Shield Guard",
            version = "2.4.1",
            description = "Neutralizes WebRTC STUN/TURN queries to completely prevent local & public IP leaks, and spoofs geolocation.",
            author = "Silent Privacy Foundation",
            iconLetter = "🔒",
            isEnabled = true,
            permissions = listOf("privacy", "webrtc"),
            contentScript = """
                (function() {
                    if (window.RTCPeerConnection) {
                        const origRTC = window.RTCPeerConnection;
                        window.RTCPeerConnection = function(...args) {
                            console.warn('[Silent Shield] Blocked WebRTC STUN query to prevent IP leak');
                            return new origRTC(...args);
                        };
                        window.RTCPeerConnection.prototype.createDataChannel = function() { return null; };
                    }
                })();
            """.trimIndent()
        ),
        BrowserExtension(
            id = "privacy_badger_pro",
            name = "Privacy Badger",
            version = "2024.2.26",
            description = "Automatically learns and blocks invisible third-party trackers and canvas fingerprinting vectors.",
            author = "EFF (Electronic Frontier Foundation)",
            iconLetter = "🦡",
            isEnabled = true,
            permissions = listOf("cookies", "storage", "webRequest"),
            contentScript = """
                (function() {
                    if (navigator.sendBeacon) {
                        navigator.sendBeacon = function(url) {
                            if (/telemetry|analytics|tracking|pixel/i.test(url)) {
                                console.log('[Privacy Badger] Suppressed beacon to: ' + url);
                                return true;
                            }
                            return true;
                        };
                    }
                })();
            """.trimIndent()
        ),
        BrowserExtension(
            id = "https_everywhere_enforce",
            name = "HTTPS Everywhere",
            version = "5.2.21",
            description = "Upgrades unencrypted HTTP connections and insecure mixed-content scripts automatically.",
            author = "Tor Project & EFF",
            iconLetter = "⚡",
            isEnabled = true,
            permissions = listOf("webRequest"),
            contentScript = """
                (function() {
                    const meta = document.createElement('meta');
                    meta.httpEquiv = 'Content-Security-Policy';
                    meta.content = 'upgrade-insecure-requests';
                    document.head ? document.head.appendChild(meta) : document.documentElement.appendChild(meta);
                })();
            """.trimIndent()
        )
    )

    private val _extensions = MutableStateFlow(defaultExtensions)
    val extensions: StateFlow<List<BrowserExtension>> = _extensions.asStateFlow()

    fun toggleExtension(id: String, enabled: Boolean) {
        _extensions.value = _extensions.value.map {
            if (it.id == id) it.copy(isEnabled = enabled) else it
        }
    }

    fun installCustomExtension(name: String, description: String, script: String): BrowserExtension {
        val newExt = BrowserExtension(
            id = "custom_" + UUID.randomUUID().toString().substring(0, 8),
            name = name.ifBlank { "Custom Script" },
            version = "1.0.0",
            description = description.ifBlank { "User installed custom WebExtension script." },
            author = "Local User",
            iconLetter = "🧩",
            isEnabled = true,
            contentScript = script,
            isBuiltIn = false
        )
        _extensions.value = _extensions.value + newExt
        return newExt
    }

    fun removeExtension(id: String) {
        _extensions.value = _extensions.value.filter { it.id != id }
    }

    fun resetToDefaults() {
        _extensions.value = defaultExtensions
    }

    fun getCombinedContentScripts(): String {
        val enabledScripts = _extensions.value.filter { it.isEnabled }.map { it.contentScript }
        return enabledScripts.joinToString("\n;\n")
    }
}
