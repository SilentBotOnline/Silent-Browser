package com.example.data.model

import java.util.UUID

enum class DownloadStatus {
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    CANCELLED,
    FAILED
}

data class DownloadItem(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val url: String,
    val downloadPath: String,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val status: DownloadStatus = DownloadStatus.DOWNLOADING,
    val speedKbps: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
) {
    val progress: Float
        get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f

    val progressPercent: Int
        get() = (progress * 100).toInt()
}
