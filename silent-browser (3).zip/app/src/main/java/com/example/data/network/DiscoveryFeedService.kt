package com.example.data.network

import com.example.data.privacy.PrivacyEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

enum class DiscoveryCategory(val label: String) {
    ALL("All"),
    TECH_NEWS("Latest News"),
    GITHUB_VIRAL("Trending GitHub"),
    WEB_HIGHLIGHTS("Web Highlights")
}

data class DiscoveryFeedItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val url: String,
    val source: String,
    val metricBadge: String,
    val category: DiscoveryCategory,
    val imageUrl: String? = null
)

data class DiscoveryFeedResult(
    val items: List<DiscoveryFeedItem>,
    val filteredThreatsCount: Int,
    val errorMessage: String? = null,
    val isFallback: Boolean = false
)

object DiscoveryFeedService {

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val mapAdapter by lazy {
        val type = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
        moshi.adapter<Map<String, Any?>>(type)
    }

    private val listAdapter by lazy {
        val type = Types.newParameterizedType(List::class.java, Any::class.java)
        moshi.adapter<List<Any?>>(type)
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(NetworkRequestInterceptor)
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    suspend fun fetchDiscoveryFeed(
        enforceHttps: Boolean = true,
        enforceAntiScam: Boolean = true
    ): DiscoveryFeedResult = withContext(Dispatchers.IO) {
        try {
            coroutineScope {
                val githubViralDeferred = async { fetchTrendingGitHubRepos() }
                val dailyNewsDeferred = async { fetchDevToDailyTechNews() }
                val hackerNewsDeferred = async { fetchHackerNewsStories() }
                val webHighlightsDeferred = async { fetchPrivacyWebHighlights() }

                val githubItems = githubViralDeferred.await()
                val devToItems = dailyNewsDeferred.await()
                val hnItems = hackerNewsDeferred.await()
                val webItems = webHighlightsDeferred.await()

                val newsItems = mutableListOf<DiscoveryFeedItem>()
                val newsMax = maxOf(devToItems.size, hnItems.size)
                for (i in 0 until newsMax) {
                    if (i < devToItems.size) newsItems.add(devToItems[i])
                    if (i < hnItems.size) newsItems.add(hnItems[i])
                }

                val combined = mutableListOf<DiscoveryFeedItem>()
                val maxSize = maxOf(githubItems.size, newsItems.size, webItems.size)
                for (i in 0 until maxSize) {
                    if (i < newsItems.size) combined.add(newsItems[i])
                    if (i < githubItems.size) combined.add(githubItems[i])
                    if (i < webItems.size) combined.add(webItems[i])
                }

                if (combined.isEmpty()) {
                    return@coroutineScope fallbackDirectoryResult(
                        enforceHttps = enforceHttps,
                        enforceAntiScam = enforceAntiScam,
                        notice = "Live GitHub & news feeds unreachable. Showing verified privacy directory — tap Refresh to retry."
                    )
                }

                filterFeedItems(
                    rawItems = combined,
                    enforceHttps = enforceHttps,
                    enforceAntiScam = enforceAntiScam
                )
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (_: Throwable) {
            fallbackDirectoryResult(
                enforceHttps = enforceHttps,
                enforceAntiScam = enforceAntiScam,
                notice = "Live feed sync interrupted. Showing verified privacy directory — tap Refresh to retry."
            )
        }
    }

    internal fun fallbackDirectoryResult(
        enforceHttps: Boolean = true,
        enforceAntiScam: Boolean = true,
        notice: String? = "Showing verified privacy & security directory."
    ): DiscoveryFeedResult {
        val fallbackRaw = listOf(
            DiscoveryFeedItem(
                id = "fallback_hn_front",
                title = "Hacker News: Security & Systems Engineering Discussions",
                subtitle = "news.ycombinator.com · Live tech & security frontpage",
                url = "https://news.ycombinator.com",
                source = "Hacker News",
                metricBadge = "LIVE INDEX",
                category = DiscoveryCategory.TECH_NEWS
            ),
            DiscoveryFeedItem(
                id = "fallback_gh_tor",
                title = "torproject/tor",
                subtitle = "Anonymizing overlay network and onion routing core repository",
                url = "https://github.com/torproject/tor",
                source = "GitHub Viral",
                metricBadge = "9.6K ★ · C",
                category = DiscoveryCategory.GITHUB_VIRAL
            ),
            DiscoveryFeedItem(
                id = "fallback_web_privacyguides",
                title = "Privacy Guides: Open-Source Privacy & Security Tools",
                subtitle = "privacyguides.org · Community-vetted browsers, VPNs, and encryption tools",
                url = "https://www.privacyguides.org",
                source = "Privacy Web",
                metricBadge = "VERIFIED",
                category = DiscoveryCategory.WEB_HIGHLIGHTS
            ),
            DiscoveryFeedItem(
                id = "fallback_gh_privacy_topic",
                title = "GitHub Trending: Open-Source Privacy Repositories",
                subtitle = "github.com/topics/privacy · Tracked open-source encryption & anti-tracking projects",
                url = "https://github.com/topics/privacy",
                source = "GitHub Viral",
                metricBadge = "OPEN SOURCE",
                category = DiscoveryCategory.GITHUB_VIRAL
            ),
            DiscoveryFeedItem(
                id = "fallback_web_eff",
                title = "Electronic Frontier Foundation: Surveillance Self-Defense",
                subtitle = "eff.org · Guides for defending against tracking, phishing, and bots",
                url = "https://www.eff.org",
                source = "Privacy Web",
                metricBadge = "DNT: 1",
                category = DiscoveryCategory.WEB_HIGHLIGHTS
            )
        )
        val filtered = filterFeedItems(
            rawItems = fallbackRaw,
            enforceHttps = enforceHttps,
            enforceAntiScam = enforceAntiScam
        )
        return filtered.copy(
            errorMessage = notice,
            isFallback = true
        )
    }

    internal fun filterFeedItems(
        rawItems: List<DiscoveryFeedItem>,
        enforceHttps: Boolean,
        enforceAntiScam: Boolean
    ): DiscoveryFeedResult {
        var blockedCount = 0
        val sanitized = mutableListOf<DiscoveryFeedItem>()
        val seenUrls = mutableSetOf<String>()
        val seenIds = mutableSetOf<String>()

        for (item in rawItems) {
            val trimmedUrl = item.url.trim()
            if (trimmedUrl.isEmpty()) continue

            if (enforceAntiScam && PrivacyEngine.isScamOrBotThreat(trimmedUrl)) {
                blockedCount++
                continue
            }

            val upgradedUrl = if (enforceHttps && trimmedUrl.startsWith("http://", ignoreCase = true)) {
                "https://" + trimmedUrl.removePrefix("http://").removePrefix("HTTP://")
            } else {
                trimmedUrl
            }

            val upgradedImage = item.imageUrl?.trim()?.takeIf {
                it.isNotEmpty() && !it.equals("null", ignoreCase = true) &&
                    !(enforceAntiScam && PrivacyEngine.isScamOrBotThreat(it))
            }?.let { rawImg ->
                if (enforceHttps && rawImg.startsWith("http://", ignoreCase = true)) {
                    "https://" + rawImg.removePrefix("http://").removePrefix("HTTP://")
                } else {
                    rawImg
                }
            }

            if (seenUrls.add(upgradedUrl)) {
                val uniqueId = if (seenIds.add(item.id)) item.id else "${item.category.name}_${item.id}"
                sanitized.add(item.copy(id = uniqueId, url = upgradedUrl, imageUrl = upgradedImage))
            }
        }

        return DiscoveryFeedResult(
            items = sanitized,
            filteredThreatsCount = blockedCount,
            errorMessage = null,
            isFallback = false
        )
    }

    private fun recentIsoDateDaysAgo(days: Int): String {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        cal.add(java.util.Calendar.DAY_OF_YEAR, -days)
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")
        return fmt.format(cal.time)
    }

    private fun fetchTrendingGitHubRepos(): List<DiscoveryFeedItem> {
        val recentDate = recentIsoDateDaysAgo(7)
        val primaryQuery = "pushed:>=$recentDate+stars:>500"
        return queryGitHubSearch(
            "https://api.github.com/search/repositories?q=$primaryQuery&sort=stars&order=desc&per_page=8",
            DiscoveryCategory.GITHUB_VIRAL,
            "GitHub Trending"
        ).ifEmpty {
            queryGitHubSearch(
                "https://api.github.com/search/repositories?q=stars:>3000&sort=updated&order=desc&per_page=8",
                DiscoveryCategory.GITHUB_VIRAL,
                "GitHub Trending"
            )
        }
    }

    private fun queryGitHubSearch(
        endpointUrl: String,
        category: DiscoveryCategory,
        sourceTag: String
    ): List<DiscoveryFeedItem> {
        return try {
            val request = Request.Builder()
                .url(endpointUrl)
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "SilentBrowser/1.0.0 (Privacy-First Android)")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string() ?: return emptyList()
                parseGitHubSearchJson(body, category, sourceTag)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun fetchPrivacyWebHighlights(): List<DiscoveryFeedItem> {
        return queryGitHubSearch(
            "https://api.github.com/search/repositories?q=topic:privacy+stars:>400&sort=updated&order=desc&per_page=8",
            DiscoveryCategory.WEB_HIGHLIGHTS,
            "Privacy Web"
        )
    }

    private fun fetchDevToDailyTechNews(): List<DiscoveryFeedItem> {
        return try {
            val request = Request.Builder()
                .url("https://dev.to/api/articles?top=1&per_page=8")
                .header("Accept", "application/json")
                .header("User-Agent", "SilentBrowser/1.0.0 (Privacy-First Android)")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string() ?: return emptyList()
                parseDevToArticlesJson(body)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private suspend fun fetchHackerNewsStories(): List<DiscoveryFeedItem> = coroutineScope {
        try {
            val topIdsRequest = Request.Builder()
                .url("https://hacker-news.firebaseio.com/v0/topstories.json")
                .header("User-Agent", "SilentBrowser/1.0.0 (Privacy-First Android)")
                .build()

            val topIds = client.newCall(topIdsRequest).execute().use { response ->
                if (!response.isSuccessful) return@coroutineScope emptyList()
                val body = response.body?.string() ?: return@coroutineScope emptyList()
                val parsed = listAdapter.fromJson(body).orEmpty()
                parsed.take(8).mapNotNull { (it as? Number)?.toLong() }
            }

            topIds.map { id ->
                async(Dispatchers.IO) {
                    try {
                        val itemRequest = Request.Builder()
                            .url("https://hacker-news.firebaseio.com/v0/item/$id.json")
                            .header("User-Agent", "SilentBrowser/1.0.0 (Privacy-First Android)")
                            .build()
                        client.newCall(itemRequest).execute().use { resp ->
                            if (!resp.isSuccessful) return@async null
                            val itemBody = resp.body?.string() ?: return@async null
                            parseHackerNewsItemJson(itemBody, id)
                        }
                    } catch (_: Throwable) {
                        null
                    }
                }
            }.awaitAll().filterNotNull()
        } catch (ce: CancellationException) {
            throw ce
        } catch (_: Throwable) {
            emptyList()
        }
    }

    @Suppress("UNCHECKED_CAST")
    internal fun parseGitHubSearchJson(
        jsonString: String,
        category: DiscoveryCategory,
        sourceTag: String
    ): List<DiscoveryFeedItem> {
        return try {
            val root = mapAdapter.fromJson(jsonString) ?: return emptyList()
            val itemsArray = root["items"] as? List<*> ?: return emptyList()
            val results = mutableListOf<DiscoveryFeedItem>()
            for (i in itemsArray.indices) {
                val obj = itemsArray[i] as? Map<String, Any?> ?: continue
                val fullName = (obj["full_name"] as? String)?.trim().orEmpty()
                val htmlUrl = (obj["html_url"] as? String)?.trim().orEmpty()
                if (fullName.isEmpty() || htmlUrl.isEmpty()) continue

                val desc = (obj["description"] as? String)?.trim()
                    ?.takeIf { it.isNotBlank() && it != "null" }
                    ?: "Open-source repository on GitHub"
                val stars = (obj["stargazers_count"] as? Number)?.toInt() ?: 0
                val language = (obj["language"] as? String)?.trim()
                    ?.takeIf { it.isNotBlank() && it != "null" }
                val starsFormatted = if (stars >= 1000) {
                    String.format(java.util.Locale.US, "%.1fK ★", stars / 1000.0)
                } else {
                    "$stars ★"
                }
                val badge = if (language != null) "$starsFormatted · $language" else starsFormatted
                val ownerMap = obj["owner"] as? Map<String, Any?>
                val ownerAvatar = (ownerMap?.get("avatar_url") as? String)?.trim()
                    ?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                val ogPreview = ownerAvatar ?: "https://opengraph.githubassets.com/1/$fullName"
                val repoId = (obj["id"] as? Number)?.toLong() ?: i.toLong()

                results.add(
                    DiscoveryFeedItem(
                        id = "gh_$repoId",
                        title = fullName,
                        subtitle = desc,
                        url = htmlUrl,
                        source = sourceTag,
                        metricBadge = badge,
                        category = category,
                        imageUrl = ogPreview
                    )
                )
            }
            results
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Suppress("UNCHECKED_CAST")
    internal fun parseDevToArticlesJson(jsonString: String): List<DiscoveryFeedItem> {
        return try {
            val arr = listAdapter.fromJson(jsonString) ?: return emptyList()
            val results = mutableListOf<DiscoveryFeedItem>()
            for (i in arr.indices) {
                val obj = arr[i] as? Map<String, Any?> ?: continue
                val title = (obj["title"] as? String)?.trim().orEmpty()
                val url = (obj["url"] as? String)?.trim().orEmpty()
                if (title.isEmpty() || url.isEmpty()) continue
                val reactions = (obj["positive_reactions_count"] as? Number)?.toInt() ?: 0
                val comments = (obj["comments_count"] as? Number)?.toInt() ?: 0
                val userMap = obj["user"] as? Map<String, Any?>
                val author = (userMap?.get("name") as? String)?.trim()
                    ?.takeIf { it.isNotBlank() } ?: "DEV Daily"
                val cover = (obj["cover_image"] as? String)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                } ?: (obj["social_image"] as? String)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                } ?: (userMap?.get("profile_image_90") as? String)?.trim()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
                val articleId = (obj["id"] as? Number)?.toLong() ?: i.toLong()

                results.add(
                    DiscoveryFeedItem(
                        id = "devto_$articleId",
                        title = title,
                        subtitle = "$author · $comments comments",
                        url = url,
                        source = "Daily Tech News",
                        metricBadge = "$reactions ♥",
                        category = DiscoveryCategory.TECH_NEWS,
                        imageUrl = cover
                    )
                )
            }
            results
        } catch (_: Exception) {
            emptyList()
        }
    }

    internal fun parseHackerNewsItemJson(jsonString: String, fallbackId: Long): DiscoveryFeedItem? {
        return try {
            val obj = mapAdapter.fromJson(jsonString) ?: return null
            val title = (obj["title"] as? String)?.trim().orEmpty()
            if (title.isEmpty()) return null
            val rawUrl = (obj["url"] as? String)?.trim().orEmpty()
            val finalUrl = if (rawUrl.isNotEmpty() && rawUrl != "null") {
                rawUrl
            } else {
                "https://news.ycombinator.com/item?id=$fallbackId"
            }
            val score = (obj["score"] as? Number)?.toInt() ?: 0
            val comments = (obj["descendants"] as? Number)?.toInt() ?: 0
            val host = try {
                java.net.URI(finalUrl).host?.removePrefix("www.") ?: "news.ycombinator.com"
            } catch (_: Exception) {
                "news.ycombinator.com"
            }

            DiscoveryFeedItem(
                id = "hn_$fallbackId",
                title = title,
                subtitle = "$host · $comments discussions",
                url = finalUrl,
                source = "Hacker News",
                metricBadge = "$score pts",
                category = DiscoveryCategory.TECH_NEWS
            )
        } catch (_: Exception) {
            null
        }
    }
}
