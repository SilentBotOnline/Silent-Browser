package com.example.data.security

import com.example.data.model.Bookmark
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.GeneralSecurityException
import java.security.SecureRandom
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class QrSyncPrivacySettings(
    val engineMode: String,
    val searchEngineId: String,
    val adblockEnabled: Boolean,
    val fingerprintShieldEnabled: Boolean,
    val httpsEverywhereEnabled: Boolean,
    val javascriptEnabled: Boolean,
    val thirdPartyCookiesBlocked: Boolean,
    val doNotTrackEnabled: Boolean,
    val antiScamProtectionEnabled: Boolean,
    val shieldedIpEnabled: Boolean,
    val activeRelayLocation: String,
    val cleanStealthMode: Boolean,
    val suggestionsEnabled: Boolean,
    val alwaysIncognito: Boolean,
    val autoPurgeOnTabClosure: Boolean,
    val selectedUserAgent: String
)

data class QrSyncBookmarkItem(
    val title: String,
    val url: String,
    val folder: String,
    val category: String,
    val isPinned: Boolean
)

data class QrSyncPayload(
    val version: Int = 1,
    val sessionId: String,
    val origin: String = "android",
    val createdAtMs: Long,
    val expiresAtMs: Long,
    val bookmarksIncluded: Boolean,
    val settingsIncluded: Boolean,
    val bookmarks: List<QrSyncBookmarkItem> = emptyList(),
    val privacySettings: QrSyncPrivacySettings? = null
)

data class QrSyncSession(
    val sessionId: String,
    val qrPayload: String,
    val pairingCode: String,
    val createdAtMs: Long,
    val expiresAtMs: Long,
    val bookmarkCount: Int,
    val totalAvailableBookmarks: Int,
    val wasTruncatedForQrCapacity: Boolean,
    val includesBookmarks: Boolean,
    val includesSettings: Boolean,
    val payloadBytes: Int
)

/**
 * Ephemeral AES-256-GCM + PBKDF2-HMAC-SHA256 QR transfer bundle generator and verifier.
 * - Uses fresh SecureRandom salt, IV, session ID, and single-session pairing code on every run.
 * - Never embeds the decryption secret inside the QR payload itself.
 * - Pure-Kotlin RFC 4648 Base64URL implementation ensures Android API 24+ and JVM test compatibility.
 */
object QrSyncManager {

    const val DEFAULT_TTL_SECONDS = 300
    private const val MAX_QR_URI_LENGTH = 1850
    private const val PBKDF2_ITERATIONS = 100_000
    private const val AES_KEY_BITS = 256
    private const val GCM_TAG_BITS = 128
    private const val GCM_IV_BYTES = 12
    private const val SALT_BYTES = 16
    private const val SESSION_ID_BYTES = 8
    private const val PAIRING_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    private const val BASE64_URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    private val secureRandom = SecureRandom()

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val payloadAdapter by lazy {
        moshi.adapter(QrSyncPayload::class.java)
    }

    fun generateEncryptedSyncSession(
        bookmarks: List<Bookmark>,
        privacySettings: QrSyncPrivacySettings,
        includeBookmarks: Boolean = true,
        includeSettings: Boolean = true,
        ttlSeconds: Int = DEFAULT_TTL_SECONDS,
        nowMs: Long = System.currentTimeMillis()
    ): QrSyncSession {
        require(includeBookmarks || includeSettings) {
            "Select at least bookmarks or privacy settings to sync."
        }
        val safeTtl = ttlSeconds.coerceIn(30, 900)
        val createdAtMs = nowMs
        val expiresAtSec = (createdAtMs / 1000L) + safeTtl.toLong()
        val expiresAtMs = expiresAtSec * 1000L

        val sessionIdBytes = ByteArray(SESSION_ID_BYTES).also { secureRandom.nextBytes(it) }
        val sessionId = base64UrlEncode(sessionIdBytes)

        val pairingCode = generatePairingCode()
        val salt = ByteArray(SALT_BYTES).also { secureRandom.nextBytes(it) }
        val iv = ByteArray(GCM_IV_BYTES).also { secureRandom.nextBytes(it) }
        val secretKey = deriveAesKey(pairingCode, salt, sessionId, expiresAtSec)

        val candidateBookmarks = if (includeBookmarks) {
            bookmarks
                .sortedWith(compareByDescending<Bookmark> { it.isPinned }.thenByDescending { it.visitCount })
                .map {
                    QrSyncBookmarkItem(
                        title = it.title.take(80),
                        url = it.url.take(256),
                        folder = it.folder.take(40),
                        category = it.category.take(40),
                        isPinned = it.isPinned
                    )
                }
        } else {
            emptyList()
        }

        // Fit maximum bookmarks cleanly inside scannable QR density cap
        var includedCount = candidateBookmarks.size
        var encodedUri: String
        var wasTruncated = false

        while (true) {
            val subset = if (includedCount < candidateBookmarks.size) {
                candidateBookmarks.take(includedCount)
            } else {
                candidateBookmarks
            }
            val payload = QrSyncPayload(
                version = 1,
                sessionId = sessionId,
                createdAtMs = createdAtMs,
                expiresAtMs = expiresAtMs,
                bookmarksIncluded = includeBookmarks,
                settingsIncluded = includeSettings,
                bookmarks = subset,
                privacySettings = if (includeSettings) privacySettings else null
            )
            encodedUri = encryptPayloadToUri(
                payload = payload,
                secretKey = secretKey,
                salt = salt,
                iv = iv,
                sessionId = sessionId,
                expiresAtSec = expiresAtSec
            )
            if (encodedUri.length <= MAX_QR_URI_LENGTH || includedCount == 0) {
                break
            }
            wasTruncated = true
            includedCount = if (includedCount > 12) (includedCount * 2) / 3 else includedCount - 1
        }

        return QrSyncSession(
            sessionId = sessionId,
            qrPayload = encodedUri,
            pairingCode = pairingCode,
            createdAtMs = createdAtMs,
            expiresAtMs = expiresAtMs,
            bookmarkCount = includedCount,
            totalAvailableBookmarks = bookmarks.size,
            wasTruncatedForQrCapacity = wasTruncated,
            includesBookmarks = includeBookmarks,
            includesSettings = includeSettings,
            payloadBytes = encodedUri.toByteArray(Charsets.UTF_8).size
        )
    }

    fun decryptSyncSession(
        qrPayload: String,
        pairingCode: String,
        nowMs: Long = System.currentTimeMillis()
    ): QrSyncPayload {
        val params = parseSyncUri(qrPayload)
        val version = params["v"] ?: throw IllegalArgumentException("Missing QR sync version.")
        require(version == "1") { "Unsupported QR sync protocol version: $version" }

        val sessionId = params["id"]?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("Missing session identifier.")
        val expSec = params["exp"]?.toLongOrNull()
            ?: throw IllegalArgumentException("Missing expiration timestamp.")
        val saltB64 = params["salt"]
            ?: throw IllegalArgumentException("Missing salt parameter.")
        val ivB64 = params["iv"]
            ?: throw IllegalArgumentException("Missing initialization vector.")
        val ctB64 = params["ct"]
            ?: throw IllegalArgumentException("Missing encrypted payload.")

        val nowSec = nowMs / 1000L
        if (nowSec > expSec) {
            throw IllegalStateException("Temporary QR sync session has expired. Generate a fresh code.")
        }

        val salt = base64UrlDecode(saltB64)
        val iv = base64UrlDecode(ivB64)
        val ciphertext = base64UrlDecode(ctB64)
        if (iv.size != GCM_IV_BYTES || salt.size < 8) {
            throw IllegalArgumentException("Malformed cryptographic envelope parameters.")
        }

        val normalizedCode = normalizePairingCode(pairingCode)
        val secretKey = deriveAesKey(normalizedCode, salt, sessionId, expSec)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        cipher.updateAAD(buildAad(sessionId, expSec))

        val compressedBytes = try {
            cipher.doFinal(ciphertext)
        } catch (ex: GeneralSecurityException) {
            throw GeneralSecurityException("Invalid pairing code or corrupted QR payload.", ex)
        }

        val jsonBytes = gunzip(compressedBytes)
        val json = jsonBytes.toString(Charsets.UTF_8)
        return payloadAdapter.fromJson(json)
            ?: throw IllegalStateException("Failed to decode decrypted QR sync payload.")
    }

    fun generateQrMatrix(content: String): Array<BooleanArray> {
        require(content.isNotBlank()) { "QR content cannot be blank." }
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 0, 0, hints)
        return Array(bitMatrix.height) { y ->
            BooleanArray(bitMatrix.width) { x ->
                bitMatrix.get(x, y)
            }
        }
    }

    private fun encryptPayloadToUri(
        payload: QrSyncPayload,
        secretKey: SecretKeySpec,
        salt: ByteArray,
        iv: ByteArray,
        sessionId: String,
        expiresAtSec: Long
    ): String {
        val json = payloadAdapter.toJson(payload)
        val compressed = gzip(json.toByteArray(Charsets.UTF_8))

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        cipher.updateAAD(buildAad(sessionId, expiresAtSec))
        val ciphertext = cipher.doFinal(compressed)

        return buildString {
            append("silentbrowser://sync?v=1")
            append("&id=").append(sessionId)
            append("&exp=").append(expiresAtSec)
            append("&salt=").append(base64UrlEncode(salt))
            append("&iv=").append(base64UrlEncode(iv))
            append("&ct=").append(base64UrlEncode(ciphertext))
        }
    }

    private fun deriveAesKey(
        pairingCode: String,
        salt: ByteArray,
        sessionId: String,
        expiresAtSec: Long
    ): SecretKeySpec {
        val normalized = normalizePairingCode(pairingCode)
        val keyMaterial = "$normalized|$sessionId|$expiresAtSec".toCharArray()
        val spec = PBEKeySpec(keyMaterial, salt, PBKDF2_ITERATIONS, AES_KEY_BITS)
        return try {
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val keyBytes = factory.generateSecret(spec).encoded
            SecretKeySpec(keyBytes, "AES")
        } finally {
            spec.clearPassword()
            keyMaterial.fill('\u0000')
        }
    }

    private fun buildAad(sessionId: String, expiresAtSec: Long): ByteArray {
        return "SB_SYNC_V1|$sessionId|$expiresAtSec".toByteArray(Charsets.UTF_8)
    }

    private fun generatePairingCode(): String {
        val raw = CharArray(12) {
            PAIRING_ALPHABET[secureRandom.nextInt(PAIRING_ALPHABET.length)]
        }
        return "${raw.concatToString(0, 4)}-${raw.concatToString(4, 8)}-${raw.concatToString(8, 12)}"
    }

    private fun normalizePairingCode(code: String): String {
        return code.trim().uppercase().replace("-", "").replace(" ", "")
    }

    private fun parseSyncUri(uri: String): Map<String, String> {
        val prefix = "silentbrowser://sync?"
        if (!uri.startsWith(prefix)) {
            throw IllegalArgumentException("Unrecognized Silent Browser QR sync URI.")
        }
        val query = uri.substring(prefix.length)
        val result = linkedMapOf<String, String>()
        query.split("&").forEach { pair ->
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val key = pair.substring(0, idx)
                val value = pair.substring(idx + 1)
                result[key] = value
            }
        }
        return result
    }

    private fun gzip(input: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(input) }
        return bos.toByteArray()
    }

    private fun gunzip(input: ByteArray): ByteArray {
        GZIPInputStream(ByteArrayInputStream(input)).use { gis ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(1024)
            while (true) {
                val read = gis.read(buffer)
                if (read <= 0) break
                out.write(buffer, 0, read)
            }
            return out.toByteArray()
        }
    }

    internal fun base64UrlEncode(data: ByteArray): String {
        if (data.isEmpty()) return ""
        val sb = StringBuilder((data.size * 4 + 2) / 3)
        var i = 0
        while (i < data.size) {
            val b0 = data[i].toInt() and 0xFF
            val hasB1 = i + 1 < data.size
            val hasB2 = i + 2 < data.size
            val b1 = if (hasB1) data[i + 1].toInt() and 0xFF else 0
            val b2 = if (hasB2) data[i + 2].toInt() and 0xFF else 0

            sb.append(BASE64_URL_ALPHABET[(b0 ushr 2) and 0x3F])
            sb.append(BASE64_URL_ALPHABET[((b0 shl 4) or (b1 ushr 4)) and 0x3F])
            if (hasB1) {
                sb.append(BASE64_URL_ALPHABET[((b1 shl 2) or (b2 ushr 6)) and 0x3F])
            }
            if (hasB2) {
                sb.append(BASE64_URL_ALPHABET[b2 and 0x3F])
            }
            i += 3
        }
        return sb.toString()
    }

    internal fun base64UrlDecode(encoded: String): ByteArray {
        if (encoded.isEmpty()) return ByteArray(0)
        val clean = encoded.trimEnd('=')
        val out = ByteArrayOutputStream((clean.length * 3) / 4 + 2)
        var buffer = 0
        var bitsCollected = 0
        for (ch in clean) {
            val value = when (ch) {
                in 'A'..'Z' -> ch - 'A'
                in 'a'..'z' -> ch - 'a' + 26
                in '0'..'9' -> ch - '0' + 52
                '-' -> 62
                '_' -> 63
                else -> throw IllegalArgumentException("Invalid Base64URL character.")
            }
            buffer = (buffer shl 6) or value
            bitsCollected += 6
            if (bitsCollected >= 8) {
                bitsCollected -= 8
                out.write((buffer ushr bitsCollected) and 0xFF)
            }
        }
        return out.toByteArray()
    }
}
