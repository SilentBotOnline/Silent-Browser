package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AppThemePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.silentBrowserPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "silent_browser_settings"
)

data class StoredAppearanceAndPanicSettings(
    val themePreset: AppThemePreset,
    val proximityPanicEnabled: Boolean
)

object BrowserPreferencesDataStore {
    val THEME_PRESET_KEY = stringPreferencesKey("theme_preset")
    val PROXIMITY_PANIC_KEY = booleanPreferencesKey("proximity_panic_enabled")

    fun resolveThemePreset(id: String?): AppThemePreset {
        return when (id?.trim()?.lowercase()) {
            AppThemePreset.WHITE.id, "light" -> AppThemePreset.WHITE
            AppThemePreset.BLACK.id, "dark", "amoled" -> AppThemePreset.BLACK
            AppThemePreset.MIDNIGHT.id, "cyber_midnight" -> AppThemePreset.MIDNIGHT
            AppThemePreset.OBSIDIAN_MINT.id -> AppThemePreset.OBSIDIAN_MINT
            AppThemePreset.QUANTUM_VIOLET.id -> AppThemePreset.QUANTUM_VIOLET
            else -> AppThemePreset.WHITE
        }
    }

    suspend fun seedFromLegacyPrefsIfNeeded(
        context: Context,
        legacyPrefs: SharedPreferences
    ) {
        val legacyThemeId = legacyPrefs.getString("theme_preset", AppThemePreset.WHITE.id)
        val legacyPanicEnabled = legacyPrefs.getBoolean("proximity_panic_enabled", false)
        context.applicationContext.silentBrowserPreferencesDataStore.edit { prefs ->
            if (THEME_PRESET_KEY !in prefs) {
                prefs[THEME_PRESET_KEY] = resolveThemePreset(legacyThemeId).id
            }
            if (PROXIMITY_PANIC_KEY !in prefs) {
                prefs[PROXIMITY_PANIC_KEY] = legacyPanicEnabled
            }
        }
    }

    fun observeSettings(
        context: Context,
        defaultTheme: AppThemePreset = AppThemePreset.WHITE,
        defaultProximityPanic: Boolean = false
    ): Flow<StoredAppearanceAndPanicSettings> {
        return context.applicationContext.silentBrowserPreferencesDataStore.data
            .catch { exception ->
                if (exception is IOException) {
                    emit(emptyPreferences())
                } else {
                    throw exception
                }
            }
            .map { prefs ->
                val theme = prefs[THEME_PRESET_KEY]?.let(::resolveThemePreset) ?: defaultTheme
                val panic = prefs[PROXIMITY_PANIC_KEY] ?: defaultProximityPanic
                StoredAppearanceAndPanicSettings(
                    themePreset = theme,
                    proximityPanicEnabled = panic
                )
            }
    }

    suspend fun saveThemePreset(context: Context, preset: AppThemePreset) {
        context.applicationContext.silentBrowserPreferencesDataStore.edit { prefs ->
            prefs[THEME_PRESET_KEY] = preset.id
        }
    }

    suspend fun saveProximityPanicEnabled(context: Context, enabled: Boolean) {
        context.applicationContext.silentBrowserPreferencesDataStore.edit { prefs ->
            prefs[PROXIMITY_PANIC_KEY] = enabled
        }
    }
}
