package com.example.data.model

data class BrowserExtension(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val author: String,
    val iconLetter: String,
    val isEnabled: Boolean = true,
    val permissions: List<String> = listOf("storage", "scripting", "activeTab"),
    val contentScript: String,
    val isBuiltIn: Boolean = true,
    val options: Map<String, String> = emptyMap()
)
