package com.example.data.security

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedPayload(
    val ciphertext: String,
    val iv: String
)

object CryptoVault {
    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    private const val IV_LENGTH_BYTE = 12
    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256

    private val salt = "SILENT_BROWSER_VAULT_SALT_SECURE_AES256".toByteArray(Charsets.UTF_8)
    private val masterSeed = "SILENT_CYBER_MASTER_KEY_V1_2026".toCharArray()

    private val secureRandom = SecureRandom()

    private fun getSecretKey(): SecretKey {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(masterSeed, salt, ITERATIONS, KEY_LENGTH)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }

    fun encrypt(plaintext: String): EncryptedPayload {
        if (plaintext.isEmpty()) return EncryptedPayload("", "")
        val key = getSecretKey()
        val iv = ByteArray(IV_LENGTH_BYTE)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance(ALGORITHM)
        val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)

        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(
            ciphertext = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
            iv = Base64.encodeToString(iv, Base64.NO_WRAP)
        )
    }

    fun decrypt(ciphertextBase64: String, ivBase64: String): String {
        if (ciphertextBase64.isEmpty() || ivBase64.isEmpty()) return ""
        try {
            val key = getSecretKey()
            val ciphertext = Base64.decode(ciphertextBase64, Base64.NO_WRAP)
            val iv = Base64.decode(ivBase64, Base64.NO_WRAP)

            val cipher = Cipher.getInstance(ALGORITHM)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)

            val decrypted = cipher.doFinal(ciphertext)
            return String(decrypted, Charsets.UTF_8)
        } catch (_: Exception) {
            return ""
        }
    }

    fun generateStrongPassword(
        length: Int = 16,
        includeUppercase: Boolean = true,
        includeLowercase: Boolean = true,
        includeDigits: Boolean = true,
        includeSymbols: Boolean = true
    ): String {
        val upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val lower = "abcdefghijklmnopqrstuvwxyz"
        val digits = "0123456789"
        val symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?"

        val charPool = StringBuilder()
        if (includeUppercase) charPool.append(upper)
        if (includeLowercase) charPool.append(lower)
        if (includeDigits) charPool.append(digits)
        if (includeSymbols) charPool.append(symbols)

        if (charPool.isEmpty()) charPool.append(lower)

        val result = StringBuilder(length)
        for (i in 0 until length) {
            val randomIndex = secureRandom.nextInt(charPool.length)
            result.append(charPool[randomIndex])
        }
        return result.toString()
    }

    fun calculateEntropyScore(password: String): Int {
        if (password.isEmpty()) return 0
        var score = 0
        if (password.length >= 8) score += 20
        if (password.length >= 14) score += 25
        if (password.length >= 18) score += 15
        if (password.any { it.isUpperCase() }) score += 10
        if (password.any { it.isLowerCase() }) score += 10
        if (password.any { it.isDigit() }) score += 10
        if (password.any { !it.isLetterOrDigit() }) score += 10
        return score.coerceIn(0, 100)
    }
}
