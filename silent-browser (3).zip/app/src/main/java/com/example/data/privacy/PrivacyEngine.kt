package com.example.data.privacy

import java.util.UUID

enum class RequestBlockCategory(val label: String) {
    AD_NETWORK("AD NETWORK"),
    ANALYTICS_TRACKER("TRACKER"),
    SCAM_PHISHING("SCAM / PHISHING"),
    CRYPTOMINER_BOT("MINER / BOT"),
    CUSTOM_RULE("CUSTOM BLOCK"),
    ALLOWED("ALLOWED")
}

data class PrivacyFilterDecision(
    val blocked: Boolean,
    val category: RequestBlockCategory,
    val host: String,
    val matchedRule: String,
    val reason: String
)

data class BlockedRequestRecord(
    val id: String = UUID.randomUUID().toString(),
    val host: String,
    val url: String,
    val category: RequestBlockCategory,
    val matchedRule: String,
    val timestampMs: Long = System.currentTimeMillis()
)

data class LiveProbeResponse(
    val inputUrl: String,
    val host: String,
    val filterDecision: PrivacyFilterDecision,
    val httpStatusCode: Int? = null,
    val latencyMs: Long? = null,
    val dntHeaderSent: Boolean = false,
    val gpcHeaderSent: Boolean = false,
    val serverHeader: String? = null,
    val timestampMs: Long = System.currentTimeMillis(),
    val summary: String
)

data class PrivacyAuditItem(
    val name: String,
    val passed: Boolean,
    val detail: String
)

data class PrivacyAuditReport(
    val scorePercent: Int,
    val passedCount: Int,
    val totalChecks: Int,
    val items: List<PrivacyAuditItem>,
    val generatedAtMs: Long = System.currentTimeMillis()
)

object PrivacyEngine {

    val AD_NETWORK_HOSTS = hashSetOf(
        "googlesyndication.com",
        "doubleclick.net",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "adnxs.com",
        "criteo.com",
        "criteo.net",
        "taboola.com",
        "outbrain.com",
        "amazon-adsystem.com",
        "rubiconproject.com",
        "openx.net",
        "pubmatic.com",
        "casalemedia.com",
        "zedo.com",
        "popads.net",
        "propellerads.com",
        "adcolony.com",
        "unityads.unity3d.com",
        "vungle.com",
        "applovin.com",
        "inmobi.com",
        "media.net",
        "adroll.com",
        "ads.yahoo.com",
        "advertising.com"
    )

    val ANALYTICS_TRACKER_HOSTS = hashSetOf(
        "google-analytics.com",
        "googletagmanager.com",
        "facebook.net",
        "connect.facebook.net",
        "pixel.facebook.com",
        "analytics.twitter.com",
        "scorecardresearch.com",
        "hotjar.com",
        "branch.io",
        "appsflyer.com",
        "quantserve.com",
        "chartbeat.com",
        "newrelic.com",
        "nr-data.net",
        "sentry.io",
        "segment.io",
        "mixpanel.com",
        "amplitude.com",
        "clicky.com",
        "statcounter.com",
        "flurry.com",
        "yandex.ru/metrika",
        "mc.yandex.ru",
        "clarity.ms",
        "fullstory.com"
    )

    val TRACKER_AND_AD_HOSTS: HashSet<String> = HashSet<String>().apply {
        addAll(AD_NETWORK_HOSTS)
        addAll(ANALYTICS_TRACKER_HOSTS)
    }

    val CRYPTOMINER_HOSTS = hashSetOf(
        "coinhive.com",
        "coin-hive.com",
        "cryptoloot.pro",
        "minero.cc",
        "jsecoin.com",
        "authedmine.com",
        "webminepool.com"
    )

    val SCAM_AND_BOT_HOSTS = hashSetOf(
        "coinhive.com",
        "coin-hive.com",
        "cryptoloot.pro",
        "minero.cc",
        "jsecoin.com",
        "authedmine.com",
        "webminepool.com",
        "malware-traffic-analysis.net",
        "phishing-check-verify.com",
        "account-security-update-alert.com",
        "bot-telemetry-collect.net",
        "credential-harvest-relay.org"
    )

    private val AD_PATH_MARKERS = listOf(
        "/pagead/",
        "/adsbygoogle",
        "/adserver",
        "/prebid",
        "/doubleclick",
        "ad_banner",
        "sponsored-ads"
    )

    private val SUSPICIOUS_SCAM_PATTERNS = listOf(
        "paypal-verify",
        "apple-id-locked",
        "metamask-restore",
        "wallet-connect-airdrop",
        "secure-login-verify-account",
        "bank-security-update-now",
        "crypto-giveaway-claim"
    )

    @Volatile
    var customBlockedDomains: Set<String> = emptySet()

    @Volatile
    var customAllowedDomains: Set<String> = emptySet()

    fun normalizeDomainInput(raw: String): String? {
        val cleaned = raw.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
            .substringBefore("?")
            .substringBefore(":")
            .removePrefix("*.")
            .trim('.')
        return if (cleaned.contains(".") && !cleaned.contains(" ")) cleaned else null
    }

    fun extractHost(url: String): String? {
        val withoutScheme = when {
            url.startsWith("http://", ignoreCase = true) -> url.substring(7)
            url.startsWith("https://", ignoreCase = true) -> url.substring(8)
            else -> url
        }
        val hostPart = withoutScheme.substringBefore('/').substringBefore(':').substringBefore('?')
        return hostPart.lowercase().ifBlank { null }
    }

    private fun hostMatchesSet(host: String, domains: Collection<String>): String? {
        for (domain in domains) {
            val clean = domain.trim().lowercase()
            if (clean.isEmpty()) continue
            if (host == clean || host.endsWith(".$clean")) {
                return clean
            }
        }
        return null
    }

    fun evaluateRequest(
        url: String?,
        adblockEnabled: Boolean = true,
        antiScamEnabled: Boolean = true,
        blockedOverrides: Set<String> = customBlockedDomains,
        allowedOverrides: Set<String> = customAllowedDomains
    ): PrivacyFilterDecision {
        if (url.isNullOrBlank()) {
            return PrivacyFilterDecision(
                blocked = false,
                category = RequestBlockCategory.ALLOWED,
                host = "",
                matchedRule = "none",
                reason = "Empty URL"
            )
        }
        val lower = url.lowercase()
        val host = extractHost(lower) ?: return PrivacyFilterDecision(
            blocked = false,
            category = RequestBlockCategory.ALLOWED,
            host = "",
            matchedRule = "none",
            reason = "No host present"
        )

        // 1. Check Scam / Phishing / Cryptominer Guard first (always protects even if domain allowlisted unless explicitly safe)
        if (antiScamEnabled) {
            val minerHit = hostMatchesSet(host, CRYPTOMINER_HOSTS)
            if (minerHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.CRYPTOMINER_BOT,
                    host = host,
                    matchedRule = minerHit,
                    reason = "Blocked unauthorized cryptominer / bot host ($minerHit)"
                )
            }
            val scamHit = hostMatchesSet(host, SCAM_AND_BOT_HOSTS)
            if (scamHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.SCAM_PHISHING,
                    host = host,
                    matchedRule = scamHit,
                    reason = "Blocked known phishing/scam relay ($scamHit)"
                )
            }
            if (host.startsWith("xn--") || host.contains(".xn--")) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.SCAM_PHISHING,
                    host = host,
                    matchedRule = "punycode-homograph",
                    reason = "Blocked suspicious IDN punycode homograph domain"
                )
            }
            val patternHit = SUSPICIOUS_SCAM_PATTERNS.firstOrNull { lower.contains(it) }
            if (patternHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.SCAM_PHISHING,
                    host = host,
                    matchedRule = patternHit,
                    reason = "Blocked suspicious credential/scam URL pattern ($patternHit)"
                )
            }
        }

        // 2. User Trusted Allowlist Exception
        val allowHit = hostMatchesSet(host, allowedOverrides)
        if (allowHit != null) {
            return PrivacyFilterDecision(
                blocked = false,
                category = RequestBlockCategory.ALLOWED,
                host = host,
                matchedRule = "allow:$allowHit",
                reason = "Permitted by trusted allowlist rule ($allowHit)"
            )
        }

        // 3. AdBlock, Custom Rules & Analytics Trackers
        if (adblockEnabled) {
            val customHit = hostMatchesSet(host, blockedOverrides)
            if (customHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.CUSTOM_RULE,
                    host = host,
                    matchedRule = "custom:$customHit",
                    reason = "Blocked by custom user filter rule ($customHit)"
                )
            }

            val adHit = hostMatchesSet(host, AD_NETWORK_HOSTS)
            if (adHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.AD_NETWORK,
                    host = host,
                    matchedRule = adHit,
                    reason = "Blocked ad network request ($adHit)"
                )
            }

            val trackerHit = hostMatchesSet(host, ANALYTICS_TRACKER_HOSTS)
            if (trackerHit != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.ANALYTICS_TRACKER,
                    host = host,
                    matchedRule = trackerHit,
                    reason = "Blocked analytics & tracking pixel ($trackerHit)"
                )
            }

            val pathMarker = AD_PATH_MARKERS.firstOrNull { lower.contains(it) }
            if (pathMarker != null) {
                return PrivacyFilterDecision(
                    blocked = true,
                    category = RequestBlockCategory.AD_NETWORK,
                    host = host,
                    matchedRule = "path:$pathMarker",
                    reason = "Blocked ad script / asset path ($pathMarker)"
                )
            }
        }

        return PrivacyFilterDecision(
            blocked = false,
            category = RequestBlockCategory.ALLOWED,
            host = host,
            matchedRule = "clean",
            reason = "Clean request allowed (privacy headers applied)"
        )
    }

    fun isBlocked(url: String?): Boolean {
        val decision = evaluateRequest(
            url = url,
            adblockEnabled = true,
            antiScamEnabled = false
        )
        return decision.blocked
    }

    fun isScamOrBotThreat(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        val host = extractHost(lower) ?: return false

        for (scamHost in SCAM_AND_BOT_HOSTS) {
            if (host == scamHost || host.endsWith(".$scamHost")) {
                return true
            }
        }

        // Punycode homograph check for deceptive lookalike domains
        if (host.startsWith("xn--") || host.contains(".xn--")) {
            return true
        }

        return SUSPICIOUS_SCAM_PATTERNS.any { pattern -> lower.contains(pattern) }
    }

    fun buildPrivacyHeaders(doNotTrackEnabled: Boolean): Map<String, String> {
        return if (doNotTrackEnabled) {
            mapOf(
                "DNT" to "1",
                "Sec-GPC" to "1"
            )
        } else {
            emptyMap()
        }
    }

    const val TOR_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; rv:109.0) Gecko/20100101 Firefox/115.0"
    const val DESKTOP_USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    const val IPHONE_USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"

    val AD_BLOCK_COSMETIC_JS = """
        (function() {
            if (window.__silentCosmeticAdBlock) return;
            window.__silentCosmeticAdBlock = true;
            try {
                const styleId = '__silent_adblock_cosmetic_css';
                if (!document.getElementById(styleId)) {
                    const style = document.createElement('style');
                    style.id = styleId;
                    style.textContent = [
                        'ins.adsbygoogle',
                        '[id^="google_ads_"]',
                        '[id^="div-gpt-ad"]',
                        '[data-ad-slot]',
                        '[data-google-query-id]',
                        'iframe[src*="doubleclick.net"]',
                        'iframe[src*="googlesyndication.com"]',
                        'iframe[src*="taboola.com"]',
                        'iframe[src*="outbrain.com"]',
                        '.ad-banner',
                        '.sponsored-ad',
                        '.advertisement'
                    ].join(',') + '{ display: none !important; visibility: hidden !important; height: 0 !important; min-height: 0 !important; }';
                    (document.head || document.documentElement).appendChild(style);
                }
            } catch(e) {}
        })();
    """.trimIndent()

    val DNT_NETWORK_INTERCEPTOR_JS = """
        (function() {
            if (window.__silentDntInstalled) return;
            window.__silentDntInstalled = true;
            try {
                Object.defineProperty(navigator, 'globalPrivacyControl', { get: () => true, configurable: true });
                Object.defineProperty(navigator, 'doNotTrack', { get: () => '1', configurable: true });

                const origFetch = window.fetch;
                if (origFetch) {
                    window.fetch = function(input, init) {
                        const nextInit = Object.assign({}, init || {});
                        const headers = new Headers(nextInit.headers || (input instanceof Request ? input.headers : undefined));
                        if (!headers.has('DNT')) headers.set('DNT', '1');
                        if (!headers.has('Sec-GPC')) headers.set('Sec-GPC', '1');
                        nextInit.headers = headers;
                        return origFetch.call(this, input, nextInit);
                    };
                }

                const origOpen = XMLHttpRequest.prototype.open;
                const origSend = XMLHttpRequest.prototype.send;
                XMLHttpRequest.prototype.open = function() {
                    this.__silentNeedsDnt = true;
                    return origOpen.apply(this, arguments);
                };
                XMLHttpRequest.prototype.send = function() {
                    if (this.__silentNeedsDnt) {
                        try {
                            this.setRequestHeader('DNT', '1');
                            this.setRequestHeader('Sec-GPC', '1');
                        } catch(e) {}
                        this.__silentNeedsDnt = false;
                    }
                    return origSend.apply(this, arguments);
                };
            } catch(e) {}
        })();
    """.trimIndent()

    val FINGERPRINT_SHIELD_JS = """
        (function() {
            try {
                // Global Privacy Control & Do Not Track
                Object.defineProperty(navigator, 'globalPrivacyControl', { get: () => true, configurable: true });
                Object.defineProperty(navigator, 'doNotTrack', { get: () => '1', configurable: true });
                
                // Hardware concurrency spoofing
                Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 4, configurable: true });
                Object.defineProperty(navigator, 'deviceMemory', { get: () => 8, configurable: true });

                // Anti-Bot & WebRTC IP Leak Guard
                if (window.RTCPeerConnection) {
                    const OrigRTC = window.RTCPeerConnection;
                    window.RTCPeerConnection = function(config) {
                        const safeConfig = Object.assign({}, config || {}, { iceTransportPolicy: 'relay' });
                        return new OrigRTC(safeConfig);
                    };
                }

                // Canvas Fingerprint Poisoning (adds imperceptible micro-noise)
                const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
                CanvasRenderingContext2D.prototype.getImageData = function(x, y, w, h) {
                    const imgData = origGetImageData.apply(this, arguments);
                    for (let i = 0; i < imgData.data.length; i += 40) {
                        imgData.data[i] = imgData.data[i] ^ 1;
                    }
                    return imgData;
                };

                const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
                HTMLCanvasElement.prototype.toDataURL = function() {
                    const ctx = this.getContext('2d');
                    if (ctx) {
                        try {
                            const d = ctx.getImageData(0, 0, Math.min(10, this.width || 1), Math.min(10, this.height || 1));
                            ctx.putImageData(d, 0, 0);
                        } catch(e) {}
                    }
                    return origToDataURL.apply(this, arguments);
                };

                // WebGL Vendor Masking
                const getParameter = WebGLRenderingContext.prototype.getParameter;
                WebGLRenderingContext.prototype.getParameter = function(param) {
                    if (param === 37445) return 'Silent Graphics Engine';
                    if (param === 37446) return 'Silent Neural GPU Matrix';
                    return getParameter.apply(this, arguments);
                };
            } catch(e) {}
        })();
    """.trimIndent()
}
