package com.example.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class ServerHealth(
    val url: String,
    val isOnline: Boolean,
    val statusCode: Int,
    val latencyMs: Long,
    val serverHeader: String,
    val message: String
)

data class PrivacyProbeHttpResult(
    val isReachable: Boolean,
    val statusCode: Int,
    val latencyMs: Long,
    val serverHeader: String,
    val dntInjected: Boolean,
    val gpcInjected: Boolean,
    val errorMessage: String? = null
)

object DevOpsService {
    private val client = OkHttpClient.Builder()
        .addInterceptor(NetworkRequestInterceptor)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    const val DEFAULT_HOSTINGER_DOMAIN = "browser.silentbot.online"
    const val DEFAULT_PRODUCTION_DOMAIN = "browser.silentbot.online"
    const val PRIMARY_WEB_PORTAL_URL = "https://browser.silentbot.online/"
    const val MIRROR_PORTAL_URL = "https://silentbrowser.silentbot.online/"
    const val OFFICIAL_PORTAL_URL = "https://silentbot.online/silentbrowser"
    const val DEFAULT_DB_HOST = "srv1169.hstgr.io"
    const val DEFAULT_DB_PORT = 3306
    const val DEFAULT_DB_NAME = "u562139744_silentbrowser"
    const val DB_CONFIG_ENV_KEYS = "SILENT_DB_HOST, SILENT_DB_PORT, SILENT_DB_NAME, SILENT_DB_USER, SILENT_DB_PASS"

    suspend fun pingServer(targetUrl: String): ServerHealth = withContext(Dispatchers.IO) {
        val cleanUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            "https://$targetUrl"
        } else {
            targetUrl
        }
        val startTime = System.currentTimeMillis()
        try {
            val request = Request.Builder()
                .url(cleanUrl)
                .header("User-Agent", "SilentBrowser-DevOps-Engine/1.0.0")
                .header("X-Silent-Client", "Android-Native-Production")
                .build()

            client.newCall(request).execute().use { response ->
                val latency = System.currentTimeMillis() - startTime
                val server = response.header("Server") ?: "Silent Privacy Web Engine"
                val code = response.code

                ServerHealth(
                    url = cleanUrl,
                    isOnline = response.isSuccessful || code in 200..399,
                    statusCode = code,
                    latencyMs = latency,
                    serverHeader = server,
                    message = "Response HTTP $code (${response.message.ifBlank { "OK" }})"
                )
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            ServerHealth(
                url = cleanUrl,
                isOnline = false,
                statusCode = 0,
                latencyMs = latency,
                serverHeader = "None",
                message = "Network error: ${e.localizedMessage ?: "Connection timed out"}"
            )
        }
    }

    /**
     * Executes a live OkHttp HEAD/GET probe through NetworkRequestInterceptor so DNT: 1 and
     * Sec-GPC: 1 headers are attached and measured against the remote origin.
     */
    suspend fun probePrivacyHeaders(targetUrl: String): PrivacyProbeHttpResult = withContext(Dispatchers.IO) {
        val cleanUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            "https://$targetUrl"
        } else {
            targetUrl
        }
        val startTime = System.currentTimeMillis()
        try {
            val request = Request.Builder()
                .url(cleanUrl)
                .head()
                .header("User-Agent", "SilentBrowser-Android/1.0.0")
                .build()

            client.newCall(request).execute().use { response ->
                val finalReq = response.request
                val latency = System.currentTimeMillis() - startTime
                val code = response.code
                val resolvedServer = response.header("Server") ?: "Encrypted Origin"
                val hasDnt = finalReq.header("DNT") == "1"
                val hasGpc = finalReq.header("Sec-GPC") == "1"

                PrivacyProbeHttpResult(
                    isReachable = code in 200..499,
                    statusCode = code,
                    latencyMs = latency,
                    serverHeader = resolvedServer,
                    dntInjected = hasDnt,
                    gpcInjected = hasGpc
                )
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            PrivacyProbeHttpResult(
                isReachable = false,
                statusCode = 0,
                latencyMs = latency,
                serverHeader = "Unreachable",
                dntInjected = NetworkRequestInterceptor.isDntEnabled,
                gpcInjected = NetworkRequestInterceptor.isDntEnabled,
                errorMessage = e.localizedMessage ?: "Network probe failed"
            )
        }
    }

    /**
     * Fetches release catalog metadata JSON from https://browser.silentbot.online/api.php?action=releases
     */
    suspend fun fetchPortalReleasesJson(channel: String = "stable"): String? = withContext(Dispatchers.IO) {
        try {
            val safeChannel = if (channel.equals("beta", ignoreCase = true)) "beta" else "stable"
            val request = Request.Builder()
                .url("${PRIMARY_WEB_PORTAL_URL}api.php?action=releases&channel=$safeChannel")
                .header("User-Agent", "SilentBrowser-Android/1.0.0")
                .build()
            client.newCall(request).execute().use { resp ->
                if (resp.isSuccessful) resp.body?.string() else null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Generates a standalone environment-driven PHP API backend script for public_html/api.php
     */
    fun generatePhpApiScript(): String {
        return """
<?php
/**
 * Silent Browser - Cloud Sync, QR Handoff, Releases & Portal Backend API
 * Authorized by: Silentbot.online
 * Target Portal: https://browser.silentbot.online/
 * Mirrors: https://silentbrowser.silentbot.online/ | https://silentbot.online/silentbrowser
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

${'$'}allowedOrigins = [
    'https://browser.silentbot.online',
    'https://silentbrowser.silentbot.online',
    'https://silentbot.online'
];
${'$'}origin = ${'$'}_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array(${'$'}origin, ${'$'}allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . ${'$'}origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Silent-Client');

if (${'$'}_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

${'$'}action = ${'$'}_GET['action'] ?? 'status';

${'$'}dbHost = getenv('SILENT_DB_HOST') ?: (${'$'}_ENV['SILENT_DB_HOST'] ?? 'localhost');
${'$'}dbPort = (int)(getenv('SILENT_DB_PORT') ?: (${'$'}_ENV['SILENT_DB_PORT'] ?? '3306'));
${'$'}dbName = getenv('SILENT_DB_NAME') ?: (${'$'}_ENV['SILENT_DB_NAME'] ?? '');
${'$'}dbUser = getenv('SILENT_DB_USER') ?: (${'$'}_ENV['SILENT_DB_USER'] ?? '');
${'$'}dbPass = getenv('SILENT_DB_PASS') ?: (${'$'}_ENV['SILENT_DB_PASS'] ?? '');
${'$'}apiToken = getenv('SILENT_API_TOKEN') ?: (${'$'}_ENV['SILENT_API_TOKEN'] ?? '');

if (${'$'}action === 'status') {
    echo json_encode([
        'status' => 'online',
        'app' => 'Silent Browser Backend',
        'portal' => 'https://browser.silentbot.online/',
        'mirrors' => [
            'https://silentbrowser.silentbot.online/',
            'https://silentbot.online/silentbrowser'
        ],
        'version' => '1.0.0',
        'timestamp' => time()
    ]);
    exit;
}

if (${'$'}action === 'releases') {
    echo json_encode([
        'status' => 'success',
        'version' => '1.0.0',
        'version_code' => 3,
        'channel' => ((${'$'}_GET['channel'] ?? 'stable') === 'beta') ? 'beta' : 'stable',
        'portal' => 'https://browser.silentbot.online/',
        'release_notes' => [
            'White-theme-first UI system across Browser, Command Hub & Settings',
            'Granular Sync Conflicts resolution (Keep Local, Use Remote, Merge)',
            'Virtual Shielded IP relays with DNT: 1 and Sec-GPC: 1 enforcement'
        ],
        'future_update' => [
            'version' => 'v1.1.0',
            'version_code' => 4,
            'target_window' => 'Upcoming Release (Build 4)',
            'title' => 'Multi-Hop Stealth Routing & Passkey Cloud Sync',
            'summary' => 'Chained privacy relays, hardware passkey sync unlock, and per-origin sandbox profiles.',
            'readiness_percent' => 82,
            'opt_in_available' => true
        ],
        'platforms' => [
            'windows' => [
                'name' => 'Windows 10/11 (x64)',
                'package' => 'silent-browser-v1.0.0-win-x64.exe',
                'size' => '64.2 MB',
                'url' => 'https://browser.silentbot.online/releases/silent-browser-v1.0.0-win-x64.exe',
                'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
            ],
            'android' => [
                'name' => 'Android (5.0 - 16+)',
                'package' => 'silent-browser-v1.0.0-android.apk',
                'size' => '28.4 MB',
                'url' => 'https://browser.silentbot.online/releases/silent-browser-v1.0.0-android.apk',
                'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
            ],
            'ios' => [
                'name' => 'iPhone / iPad (iOS 15+)',
                'package' => 'Silent Browser iOS App / TestFlight',
                'size' => '31.8 MB',
                'url' => 'https://browser.silentbot.online/releases/silent-browser-ios.html',
                'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
            ],
            'macos' => [
                'name' => 'macOS (Universal Apple Silicon & Intel)',
                'package' => 'silent-browser-v1.0.0-macos.dmg',
                'size' => '68.9 MB',
                'url' => 'https://browser.silentbot.online/releases/silent-browser-v1.0.0-macos.dmg',
                'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
            ],
            'other' => [
                'name' => 'Linux / Other OS (AppImage & Source)',
                'package' => 'silent-browser-v1.0.0-linux-x86_64.AppImage',
                'size' => '59.5 MB',
                'url' => 'https://browser.silentbot.online/releases/silent-browser-v1.0.0-linux-x86_64.AppImage',
                'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
            ]
        ]
    ]);
    exit;
}

if (${'$'}dbName === '' || ${'$'}dbUser === '' || ${'$'}dbPass === '') {
    http_response_code(503);
    echo json_encode([
        'status' => 'not_configured',
        'message' => 'Set SILENT_DB_NAME, SILENT_DB_USER, and SILENT_DB_PASS in server environment variables.'
    ]);
    exit;
}

${'$'}dsn = "mysql:host=" . ${'$'}dbHost . ";port=" . ${'$'}dbPort . ";dbname=" . ${'$'}dbName . ";charset=utf8mb4";
${'$'}options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    ${'$'}pdo = new PDO(${'$'}dsn, ${'$'}dbUser, ${'$'}dbPass, ${'$'}options);
} catch (\PDOException ${'$'}e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit;
}

if (${'$'}action === 'portal_sections') {
    ${'$'}rows = ${'$'}pdo->query("SELECT section_key, title, subtitle, sort_order FROM silent_browser_portal_sections WHERE is_enabled = 1 ORDER BY sort_order ASC")->fetchAll();
    echo json_encode(['status' => 'success', 'sections' => ${'$'}rows]);
    exit;
}

if (${'$'}action === 'relays') {
    ${'$'}rows = ${'$'}pdo->query("SELECT node_code, location, virtual_ip, protocol, latency_ms FROM silent_browser_relay_nodes WHERE is_active = 1 ORDER BY latency_ms ASC")->fetchAll();
    echo json_encode(['status' => 'success', 'relays' => ${'$'}rows]);
    exit;
}

if (${'$'}apiToken !== '') {
    ${'$'}authHeader = ${'$'}_SERVER['HTTP_AUTHORIZATION'] ?? '';
    ${'$'}provided = str_starts_with(${'$'}authHeader, 'Bearer ') ? substr(${'$'}authHeader, 7) : '';
    if (!hash_equals(${'$'}apiToken, ${'$'}provided)) {
        http_response_code(401);
        echo json_encode(['status' => 'unauthorized']);
        exit;
    }
}

${'$'}allowedTypes = ['bookmarks', 'settings', 'relay_prefs'];

if (${'$'}action === 'sync_push' && ${'$'}_SERVER['REQUEST_METHOD'] === 'POST') {
    ${'$'}input = json_decode(file_get_contents('php://input'), true);
    ${'$'}deviceId = trim((string)(${'$'}input['device_id'] ?? ''));
    ${'$'}type = trim((string)(${'$'}input['sync_type'] ?? 'bookmarks'));
    if (!preg_match('/^[a-zA-Z0-9_-]{8,64}$/', ${'$'}deviceId) || !in_array(${'$'}type, ${'$'}allowedTypes, true)) {
        http_response_code(400);
        echo json_encode(['status' => 'invalid_parameters']);
        exit;
    }
    ${'$'}payload = json_encode(${'$'}input['data'] ?? []);
    ${'$'}stmt = ${'$'}pdo->prepare("REPLACE INTO silent_browser_sync (device_id, sync_type, payload) VALUES (?, ?, ?)");
    ${'$'}stmt->execute([${'$'}deviceId, ${'$'}type, ${'$'}payload]);

    echo json_encode(['status' => 'success', 'message' => 'Synced successfully', 'timestamp' => time()]);
    exit;
}

if (${'$'}action === 'sync_pull') {
    ${'$'}deviceId = trim((string)(${'$'}_GET['device_id'] ?? ''));
    ${'$'}type = trim((string)(${'$'}_GET['sync_type'] ?? 'bookmarks'));
    if (!preg_match('/^[a-zA-Z0-9_-]{8,64}$/', ${'$'}deviceId) || !in_array(${'$'}type, ${'$'}allowedTypes, true)) {
        http_response_code(400);
        echo json_encode(['status' => 'invalid_parameters']);
        exit;
    }

    ${'$'}stmt = ${'$'}pdo->prepare("SELECT payload, updated_at FROM silent_browser_sync WHERE device_id = ? AND sync_type = ?");
    ${'$'}stmt->execute([${'$'}deviceId, ${'$'}type]);
    ${'$'}row = ${'$'}stmt->fetch();

    if (${'$'}row) {
        echo json_encode(['status' => 'success', 'data' => json_decode(${'$'}row['payload'], true), 'updated_at' => ${'$'}row['updated_at']]);
    } else {
        echo json_encode(['status' => 'empty', 'data' => []]);
    }
    exit;
}

if (${'$'}action === 'bookmarks_push' || ${'$'}action === 'bookmarks_pull' || ${'$'}action === 'settings_push' || ${'$'}action === 'settings_pull' || ${'$'}action === 'qr_handoff_register' || ${'$'}action === 'qr_handoff_claim') {
    echo json_encode(['status' => 'ready', 'action' => ${'$'}action, 'portal' => 'https://browser.silentbot.online/']);
    exit;
}

http_response_code(400);
echo json_encode(['status' => 'unknown_action']);
?>
        """.trimIndent()
    }

    /**
     * Generates full SQL schema for Silent Browser cloud sync, QR handoff, relays, portal sections, and release distribution
     */
    fun generateSqlScript(): String {
        return """
-- Silent Browser Full Production Database Schema (MySQL / MariaDB)
-- Target Portal: https://browser.silentbot.online/
-- Target Database: silent_browser_db (configured via environment)

CREATE TABLE IF NOT EXISTS `silent_browser_sync` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `device_id` VARCHAR(64) NOT NULL,
  `sync_type` VARCHAR(32) NOT NULL,
  `payload` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_type` (`device_id`, `sync_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_bookmarks` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `device_id` VARCHAR(64) NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `url` VARCHAR(512) NOT NULL,
  `folder` VARCHAR(64) NOT NULL DEFAULT 'Favorites',
  `category` VARCHAR(64) NOT NULL DEFAULT 'General',
  `is_pinned` TINYINT(1) NOT NULL DEFAULT 0,
  `visit_count` INT(11) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_url` (`device_id`, `url`(191)),
  KEY `idx_device_folder` (`device_id`, `folder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_settings_profiles` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `device_id` VARCHAR(64) NOT NULL,
  `engine_mode` VARCHAR(32) NOT NULL DEFAULT 'MULTI_ENGINE',
  `search_engine_id` VARCHAR(32) NOT NULL DEFAULT 'silent_stealth',
  `adblock_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `fingerprint_shield` TINYINT(1) NOT NULL DEFAULT 1,
  `https_everywhere` TINYINT(1) NOT NULL DEFAULT 1,
  `javascript_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `block_third_party_cookies` TINYINT(1) NOT NULL DEFAULT 1,
  `dnt_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `anti_scam_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `shielded_ip_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `active_relay_location` VARCHAR(64) NOT NULL DEFAULT 'Zurich, Switzerland',
  `clean_stealth_mode` TINYINT(1) NOT NULL DEFAULT 1,
  `suggestions_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `always_incognito` TINYINT(1) NOT NULL DEFAULT 0,
  `auto_purge_tab_closure` TINYINT(1) NOT NULL DEFAULT 1,
  `selected_user_agent` VARCHAR(64) NOT NULL DEFAULT 'Tor Browser (Spoofed)',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_settings_device` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_qr_handoff` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(64) NOT NULL,
  `encrypted_envelope` TEXT NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `claimed_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_qr_session` (`session_id`),
  KEY `idx_qr_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_relay_nodes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `node_code` VARCHAR(32) NOT NULL,
  `location` VARCHAR(64) NOT NULL,
  `virtual_ip` VARCHAR(45) NOT NULL,
  `protocol` VARCHAR(48) NOT NULL,
  `latency_ms` INT(11) NOT NULL DEFAULT 25,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_node_code` (`node_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_releases` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `platform` VARCHAR(24) NOT NULL,
  `version` VARCHAR(32) NOT NULL,
  `filename` VARCHAR(128) NOT NULL,
  `download_url` VARCHAR(255) NOT NULL,
  `sha256_checksum` VARCHAR(128) DEFAULT NULL,
  `size_label` VARCHAR(32) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_platform_version` (`platform`, `version`),
  KEY `idx_platform_active` (`platform`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_portal_sections` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `section_key` VARCHAR(48) NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `subtitle` VARCHAR(255) NOT NULL,
  `sort_order` INT(11) NOT NULL DEFAULT 0,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_section_key` (`section_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `silent_browser_audit_logs` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `event_type` VARCHAR(32) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_type_time` (`event_type`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        """.trimIndent()
    }

    /**
     * Generates production Search Engine proxy & aggregator backend (search.php)
     */
    fun generateSearchEnginePhpScript(): String {
        return """
<?php
/**
 * Silent Browser - Multi-Engine Search Proxy & Aggregator
 * Authorized by: Silentbot.online | Domain: https://browser.silentbot.online/
 * Deploy Path: /public_html/search.php
 */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

${'$'}query = substr(trim(str_replace(["\r", "\n"], '', (string)(${'$'}_GET['q'] ?? ''))), 0, 512);
${'$'}engine = strtolower(trim((string)(${'$'}_GET['engine'] ?? 'silent')));

if (${'$'}query === '') {
    echo json_encode([
        'status' => 'idle',
        'app' => 'Silent Search Engine Gateway',
        'portal' => 'https://browser.silentbot.online/',
        'version' => '0.1-prod',
        'engines_supported' => ['silent', 'duckduckgo', 'brave', 'startpage', 'ecosia', 'google', 'bing', 'yahoo'],
        'authorized_by' => 'Silentbot.online'
    ]);
    exit;
}

${'$'}mode = (${'$'}_GET['mode'] ?? 'redirect') === 'json' ? 'json' : 'redirect';
${'$'}encoded = urlencode(${'$'}query);

${'$'}endpoints = [
    'silent'     => "https://duckduckgo.com/?q=" . ${'$'}encoded . "&kp=-2&kz=-1&kac=-1&kn=1",
    'duckduckgo' => "https://duckduckgo.com/?q=" . ${'$'}encoded,
    'brave'      => "https://search.brave.com/search?q=" . ${'$'}encoded,
    'startpage'  => "https://www.startpage.com/do/search?q=" . ${'$'}encoded,
    'ecosia'     => "https://www.ecosia.org/search?q=" . ${'$'}encoded,
    'google'     => "https://www.google.com/search?q=" . ${'$'}encoded,
    'bing'       => "https://www.bing.com/search?q=" . ${'$'}encoded,
    'yahoo'      => "https://search.yahoo.com/search?p=" . ${'$'}encoded
];

${'$'}safeEngine = array_key_exists(${'$'}engine, ${'$'}endpoints) ? ${'$'}engine : 'silent';
${'$'}targetUrl = ${'$'}endpoints[${'$'}safeEngine];

if (${'$'}mode === 'redirect') {
    header("Location: " . ${'$'}targetUrl, true, 302);
    exit;
}

echo json_encode([
    'status' => 'success',
    'query' => ${'$'}query,
    'engine' => ${'$'}safeEngine,
    'target_url' => ${'$'}targetUrl,
    'timestamp' => time()
]);
?>
        """.trimIndent()
    }

    /**
     * Generates OpenSearch XML definition for Silent Browser
     */
    fun generateOpenSearchXml(): String {
        return """
<?xml version="1.0" encoding="UTF-8"?>
<OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/">
  <ShortName>Silent Search</ShortName>
  <Description>Silent Browser Low-Data Private Search</Description>
  <Tags>privacy security silent stealth search</Tags>
  <Contact>silentbrowser@silentbot.online</Contact>
  <Url type="text/html" template="https://browser.silentbot.online/search.php?q={searchTerms}&amp;engine=silent"/>
  <Url type="application/x-suggestions+json" template="https://duckduckgo.com/ac/?q={searchTerms}&amp;type=list"/>
  <Image height="16" width="16" type="image/x-icon">https://browser.silentbot.online/favicon.ico</Image>
</OpenSearchDescription>
        """.trimIndent()
    }
}
