package com.example.data.network

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Network request interceptor that automatically appends 'DNT: 1' (Do Not Track)
 * and 'Sec-GPC: 1' (Global Privacy Control) headers to all outgoing browser and
 * service network traffic when Do Not Track is enabled.
 */
object NetworkRequestInterceptor : Interceptor {

    @Volatile
    var isDntEnabled: Boolean = true

    private val _interceptedDntCount = MutableStateFlow(0)
    val interceptedDntCount: StateFlow<Int> = _interceptedDntCount.asStateFlow()

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        if (!isDntEnabled) {
            return chain.proceed(originalRequest)
        }

        val modifiedRequest = originalRequest.newBuilder()
            .header("DNT", "1")
            .header("Sec-GPC", "1")
            .build()

        _interceptedDntCount.value += 1
        return chain.proceed(modifiedRequest)
    }

    fun recordWebViewDntRequest() {
        if (isDntEnabled) {
            _interceptedDntCount.value += 1
        }
    }

    fun buildPrivacyHeaders(): Map<String, String> {
        return if (isDntEnabled) {
            mapOf(
                "DNT" to "1",
                "Sec-GPC" to "1"
            )
        } else {
            emptyMap()
        }
    }

    fun resetCounter() {
        _interceptedDntCount.value = 0
    }
}
