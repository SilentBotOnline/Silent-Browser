package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Bookmark
import com.example.data.model.HistoryItem
import com.example.data.model.PasswordEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<Bookmark>>

    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    suspend fun getAllBookmarksOnce(): List<Bookmark>

    @Query("SELECT DISTINCT folder FROM bookmarks WHERE folder != ''")
    fun getAllFolders(): Flow<List<String>>

    @Query("SELECT * FROM bookmarks WHERE folder = :folder ORDER BY createdAt DESC")
    fun getBookmarksByFolder(folder: String): Flow<List<Bookmark>>

    @Query("SELECT * FROM bookmarks ORDER BY visitCount DESC, lastVisited DESC LIMIT :limit")
    fun getFrequentlyVisited(limit: Int = 10): Flow<List<Bookmark>>

    @Query("SELECT * FROM bookmarks WHERE isPinned = 1 ORDER BY lastVisited DESC")
    fun getPinnedBookmarks(): Flow<List<Bookmark>>

    @Query("UPDATE bookmarks SET visitCount = visitCount + 1, lastVisited = :timestamp WHERE id = :id")
    suspend fun incrementVisitCount(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE bookmarks SET isPinned = :isPinned WHERE id = :id")
    suspend fun setPinned(id: Long, isPinned: Boolean)

    @Query("UPDATE bookmarks SET folder = :newFolder WHERE folder = :oldFolder")
    suspend fun renameFolder(oldFolder: String, newFolder: String)

    @Query("DELETE FROM bookmarks WHERE folder = :folder")
    suspend fun deleteFolder(folder: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: Bookmark): Long

    @Update
    suspend fun updateBookmark(bookmark: Bookmark)

    @Delete
    suspend fun deleteBookmark(bookmark: Bookmark)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    suspend fun getBookmarkByUrl(url: String): Bookmark?

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE url = :url)")
    suspend fun isBookmarked(url: String): Boolean

    @Query("DELETE FROM bookmarks")
    suspend fun clearAllBookmarks()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY visitTime DESC LIMIT 200")
    fun getAllHistory(): Flow<List<HistoryItem>>

    @Query("SELECT * FROM history ORDER BY visitTime DESC LIMIT 200")
    suspend fun getAllHistoryOnce(): List<HistoryItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: HistoryItem): Long

    @Delete
    suspend fun deleteHistory(item: HistoryItem)

    @Query("DELETE FROM history")
    suspend fun clearAllHistory()
}

@Dao
interface PasswordDao {
    @Query("SELECT * FROM passwords ORDER BY lastUsed DESC")
    fun getAllPasswords(): Flow<List<PasswordEntry>>

    @Query("SELECT * FROM passwords WHERE domain LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%' OR username LIKE '%' || :query || '%' ORDER BY lastUsed DESC")
    fun searchPasswords(query: String): Flow<List<PasswordEntry>>

    @Query("SELECT * FROM passwords WHERE domain = :domain ORDER BY lastUsed DESC")
    suspend fun getPasswordsForDomain(domain: String): List<PasswordEntry>

    @Query("SELECT * FROM passwords WHERE id = :id LIMIT 1")
    suspend fun getPasswordById(id: Long): PasswordEntry?

    @Query("UPDATE passwords SET lastUsed = :timestamp, useCount = useCount + 1 WHERE id = :id")
    suspend fun recordPasswordUsage(id: Long, timestamp: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPassword(entry: PasswordEntry): Long

    @Update
    suspend fun updatePassword(entry: PasswordEntry)

    @Delete
    suspend fun deletePassword(entry: PasswordEntry)

    @Query("DELETE FROM passwords")
    suspend fun clearAllPasswords()
}
