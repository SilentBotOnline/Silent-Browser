package com.example.data.model

import java.util.UUID

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Tab",
    val url: String = "about:blank",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val blockedTrackersCount: Int = 0,
    val isIncognito: Boolean = false,
    val engineMode: EngineMode = EngineMode.MULTI_ENGINE
)
