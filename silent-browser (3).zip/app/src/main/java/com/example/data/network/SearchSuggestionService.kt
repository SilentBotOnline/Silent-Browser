package com.example.data.network

import com.example.data.model.Bookmark
import com.example.data.model.HistoryItem
import com.example.data.model.SearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

enum class SuggestionType {
    QUERY,
    BOOKMARK,
    HISTORY,
    DIRECT_URL
}

data class SearchSuggestion(
    val text: String,
    val type: SuggestionType = SuggestionType.QUERY,
    val sourceEngine: String = "Silent",
    val url: String? = null
)

object SearchSuggestionService {

    private val client = OkHttpClient.Builder()
        .addInterceptor(NetworkRequestInterceptor)
        .connectTimeout(1500, TimeUnit.MILLISECONDS)
        .readTimeout(1500, TimeUnit.MILLISECONDS)
        .build()

    /**
     * Fetches real-time suggestions from multiple engines and combines them with
     * local bookmarks and history matches.
     */
    suspend fun getMultiEngineSuggestions(
        query: String,
        activeEngine: SearchEngine,
        bookmarks: List<Bookmark> = emptyList(),
        history: List<HistoryItem> = emptyList(),
        includeWebEngines: Boolean = true
    ): List<SearchSuggestion> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        val results = mutableListOf<SearchSuggestion>()

        // 1. Direct URL detection if query looks like a domain
        if (trimmed.contains(".") && !trimmed.contains(" ") && !trimmed.startsWith("http")) {
            results.add(
                SearchSuggestion(
                    text = "https://$trimmed",
                    type = SuggestionType.DIRECT_URL,
                    sourceEngine = "Go to URL",
                    url = "https://$trimmed"
                )
            )
        }

        // 2. Match local bookmarks (instant & private)
        val matchedBookmarks = bookmarks
            .filter { it.title.contains(trimmed, ignoreCase = true) || it.url.contains(trimmed, ignoreCase = true) }
            .take(3)
            .map {
                SearchSuggestion(
                    text = it.title,
                    type = SuggestionType.BOOKMARK,
                    sourceEngine = "Bookmark [${it.folder}]",
                    url = it.url
                )
            }
        results.addAll(matchedBookmarks)

        // 3. Match local browsing history
        val matchedHistory = history
            .filter { it.title.contains(trimmed, ignoreCase = true) || it.url.contains(trimmed, ignoreCase = true) }
            .take(3)
            .map {
                SearchSuggestion(
                    text = it.title,
                    type = SuggestionType.HISTORY,
                    sourceEngine = "History",
                    url = it.url
                )
            }
        results.addAll(matchedHistory)

        // 4. Fetch live web suggestions in parallel if enabled
        if (includeWebEngines) {
            val encoded = try {
                URLEncoder.encode(trimmed, "UTF-8")
            } catch (_: Exception) {
                trimmed
            }

            coroutineScope {
                val ddgDeferred = async { fetchDuckDuckGoSuggestions(encoded) }
                val googleDeferred = async { fetchGoogleSuggestions(encoded) }

                val ddgSuggestions = ddgDeferred.await()
                val googleSuggestions = googleDeferred.await()

                // If active engine is DuckDuckGo or Silent, prioritize DDG suggestions
                val primary = if (activeEngine == SearchEngine.GOOGLE) googleSuggestions else ddgSuggestions
                val secondary = if (activeEngine == SearchEngine.GOOGLE) ddgSuggestions else googleSuggestions

                val seenTexts = results.map { it.text.lowercase() }.toMutableSet()
                seenTexts.add(trimmed.lowercase())

                for (sug in primary) {
                    if (seenTexts.add(sug.text.lowercase())) {
                        results.add(sug)
                    }
                }
                for (sug in secondary) {
                    if (seenTexts.add(sug.text.lowercase())) {
                        results.add(sug)
                    }
                }
            }
        }

        // Cap to top 8 suggestions for clean mobile UI
        results.take(8)
    }

    private fun fetchDuckDuckGoSuggestions(encodedQuery: String): List<SearchSuggestion> {
        return try {
            val url = "https://duckduckgo.com/ac/?q=$encodedQuery&type=list"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:120.0) Gecko/120.0 Firefox/120.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyStr = response.body?.string() ?: return emptyList()

                val jsonArray = JSONArray(bodyStr)
                if (jsonArray.length() >= 2) {
                    val suggestionsArray = jsonArray.getJSONArray(1)
                    val list = mutableListOf<SearchSuggestion>()
                    for (i in 0 until suggestionsArray.length()) {
                        val text = suggestionsArray.getString(i)
                        list.add(
                            SearchSuggestion(
                                text = text,
                                type = SuggestionType.QUERY,
                                sourceEngine = "DuckDuckGo"
                            )
                        )
                    }
                    list
                } else {
                    emptyList()
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun fetchGoogleSuggestions(encodedQuery: String): List<SearchSuggestion> {
        return try {
            val url = "https://suggestqueries.google.com/complete/search?client=chrome&q=$encodedQuery"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyStr = response.body?.string() ?: return emptyList()

                val jsonArray = JSONArray(bodyStr)
                if (jsonArray.length() >= 2) {
                    val suggestionsArray = jsonArray.getJSONArray(1)
                    val list = mutableListOf<SearchSuggestion>()
                    for (i in 0 until suggestionsArray.length()) {
                        val text = suggestionsArray.getString(i)
                        list.add(
                            SearchSuggestion(
                                text = text,
                                type = SuggestionType.QUERY,
                                sourceEngine = "Multi-Engine"
                            )
                        )
                    }
                    list
                } else {
                    emptyList()
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
