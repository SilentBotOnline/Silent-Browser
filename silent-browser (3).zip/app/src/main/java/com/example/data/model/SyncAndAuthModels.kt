package com.example.data.model

enum class AuthSheetMode {
    SIGN_IN,
    CREATE_ACCOUNT
}

data class AccountAuthUiState(
    val isSheetOpen: Boolean = false,
    val mode: AuthSheetMode = AuthSheetMode.SIGN_IN,
    val displayName: String = "",
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val isPasswordVisible: Boolean = false,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null
)

enum class SyncConflictResolution {
    KEEP_LOCAL,
    USE_REMOTE,
    MERGE
}

data class SyncConflictItem(
    val id: String,
    val itemType: String, // "bookmark" or "history"
    val url: String,
    val localTitle: String,
    val localTimestamp: Long,
    val localFolder: String = "Favorites",
    val localCategory: String = "General",
    val localIsPinned: Boolean = false,
    val localVisitCount: Int = 0,
    val remoteTitle: String,
    val remoteTimestamp: Long,
    val remoteFolder: String = "Favorites",
    val remoteCategory: String = "General",
    val remoteIsPinned: Boolean = false,
    val remoteVisitCount: Int = 0
)

data class MergedSyncOutcome(
    val winnerTitle: String,
    val winnerFolder: String,
    val winnerCategory: String,
    val winnerIsPinned: Boolean,
    val winnerVisitCount: Int,
    val resolvedTimestamp: Long,
    val prioritizedLocal: Boolean
)

object SyncConflictResolver {
    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun validateAuthInput(state: AccountAuthUiState): String? {
        val cleanEmail = state.email.trim()
        if (cleanEmail.isEmpty()) {
            return "Please enter your email address."
        }
        if (!EMAIL_REGEX.matches(cleanEmail)) {
            return "Please enter a valid email address."
        }
        if (state.password.length < 6) {
            return "Password must be at least 6 characters."
        }
        if (state.mode == AuthSheetMode.CREATE_ACCOUNT && state.confirmPassword != state.password) {
            return "Passwords do not match."
        }
        return null
    }

    /**
     * Timestamp-based conflict resolution that strictly prioritizes local mobile storage
     * as the source of truth on equal timestamps or whenever KEEP_LOCAL is chosen.
     */
    fun resolveConflict(
        conflict: SyncConflictItem,
        resolution: SyncConflictResolution,
        nowMs: Long = System.currentTimeMillis()
    ): MergedSyncOutcome {
        return when (resolution) {
            SyncConflictResolution.KEEP_LOCAL -> MergedSyncOutcome(
                winnerTitle = conflict.localTitle.ifBlank { conflict.url },
                winnerFolder = conflict.localFolder.ifBlank { "Favorites" },
                winnerCategory = conflict.localCategory.ifBlank { "General" },
                winnerIsPinned = conflict.localIsPinned,
                winnerVisitCount = maxOf(conflict.localVisitCount, conflict.remoteVisitCount),
                resolvedTimestamp = maxOf(conflict.localTimestamp, conflict.remoteTimestamp, nowMs),
                prioritizedLocal = true
            )

            SyncConflictResolution.USE_REMOTE -> MergedSyncOutcome(
                winnerTitle = conflict.remoteTitle.ifBlank { conflict.localTitle.ifBlank { conflict.url } },
                winnerFolder = conflict.remoteFolder.ifBlank { conflict.localFolder },
                winnerCategory = conflict.remoteCategory.ifBlank { conflict.localCategory },
                winnerIsPinned = conflict.remoteIsPinned,
                winnerVisitCount = maxOf(conflict.localVisitCount, conflict.remoteVisitCount),
                resolvedTimestamp = maxOf(conflict.remoteTimestamp, nowMs),
                prioritizedLocal = false
            )

            SyncConflictResolution.MERGE -> {
                // Local mobile record wins ties (localTimestamp >= remoteTimestamp)
                val localIsSource = conflict.localTimestamp >= conflict.remoteTimestamp
                val baseTitle = if (localIsSource) conflict.localTitle else conflict.remoteTitle
                val otherTitle = if (localIsSource) conflict.remoteTitle else conflict.localTitle
                val mergedTitle = when {
                    baseTitle.isBlank() -> otherTitle.ifBlank { conflict.url }
                    otherTitle.isBlank() || baseTitle.equals(otherTitle, ignoreCase = true) -> baseTitle
                    else -> "$baseTitle | $otherTitle".take(160)
                }
                MergedSyncOutcome(
                    winnerTitle = mergedTitle,
                    winnerFolder = if (localIsSource) conflict.localFolder else conflict.remoteFolder,
                    winnerCategory = if (localIsSource) conflict.localCategory else conflict.remoteCategory,
                    winnerIsPinned = conflict.localIsPinned || conflict.remoteIsPinned,
                    winnerVisitCount = maxOf(conflict.localVisitCount, conflict.remoteVisitCount),
                    resolvedTimestamp = maxOf(conflict.localTimestamp, conflict.remoteTimestamp, nowMs),
                    prioritizedLocal = localIsSource
                )
            }
        }
    }

    /**
     * Evaluates whether a local vs remote entry represents an automatic local-win
     * or a timestamp/metadata conflict that should be surfaced to the user.
     */
    fun shouldPrioritizeLocalAutomatic(localTimestamp: Long, remoteTimestamp: Long): Boolean {
        return localTimestamp >= remoteTimestamp
    }

    fun hasConflictMismatch(
        localTitle: String,
        localFolder: String,
        localTimestamp: Long,
        remoteTitle: String,
        remoteFolder: String,
        remoteTimestamp: Long
    ): Boolean {
        if (localTimestamp == remoteTimestamp &&
            localTitle.trim().equals(remoteTitle.trim(), ignoreCase = true) &&
            localFolder.trim().equals(remoteFolder.trim(), ignoreCase = true)
        ) {
            return false
        }
        return localTimestamp != remoteTimestamp ||
            !localTitle.trim().equals(remoteTitle.trim(), ignoreCase = true) ||
            !localFolder.trim().equals(remoteFolder.trim(), ignoreCase = true)
    }

    fun isBrowsingUrlActive(url: String): Boolean {
        val clean = url.trim()
        return clean.isNotEmpty() && !clean.equals("about:blank", ignoreCase = true)
    }

    fun classifyTimestampMismatch(localTimestamp: Long, remoteTimestamp: Long): ConflictTimestampRelation {
        return when {
            localTimestamp > remoteTimestamp -> ConflictTimestampRelation.LOCAL_NEWER
            remoteTimestamp > localTimestamp -> ConflictTimestampRelation.REMOTE_NEWER
            else -> ConflictTimestampRelation.EQUAL_TIE
        }
    }

    fun formatTimestampDelta(localTimestamp: Long, remoteTimestamp: Long): String {
        val diffMs = kotlin.math.abs(localTimestamp - remoteTimestamp)
        if (diffMs < 1000L) return if (diffMs == 0L) "0s delta" else "${diffMs}ms delta"
        val totalSec = diffMs / 1000L
        val days = totalSec / 86_400L
        val hours = (totalSec % 86_400L) / 3600L
        val mins = (totalSec % 3600L) / 60L
        val secs = totalSec % 60L
        val span = when {
            days > 0 -> "${days}d ${hours}h"
            hours > 0 -> "${hours}h ${mins}m"
            mins > 0 -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
        return when {
            localTimestamp > remoteTimestamp -> "Local +$span"
            remoteTimestamp > localTimestamp -> "Remote +$span"
            else -> "0s delta"
        }
    }
}

enum class ConflictTimestampRelation(val badgeLabel: String) {
    LOCAL_NEWER("LOCAL NEWER"),
    REMOTE_NEWER("REMOTE NEWER"),
    EQUAL_TIE("TIE • LOCAL PRIORITY")
}
