package com.example.data.model

enum class EngineMode(
    val title: String,
    val subtitle: String,
    val badge: String,
    val description: String
) {
    BRAVE_SHIELD(
        title = "Brave Shield",
        subtitle = "Aggressive Adblock & Trackers Guard",
        badge = "SHIELD ACTIVE",
        description = "Blocks third-party trackers, cryptominers, popups, and invasive video ads before loading."
    ),
    TOR_HYBRID(
        title = "Tor Hybrid",
        subtitle = "Onion Routing & Identity Obfuscation",
        badge = "ONION ROUTED",
        description = "Enforces strict anonymity headers, .onion gateway resolution, and removes identifiable telemetry."
    ),
    TAILS_AMNESIC(
        title = "Tails Amnesic",
        subtitle = "Zero-Footprint RAM Execution",
        badge = "AMNESIC RAM",
        description = "Leaves zero traces on the device. All cookies, cache, and history are vaporized on tab close or panic."
    ),
    MULLVAD_SECURE(
        title = "Mullvad Stealth",
        subtitle = "Encrypted DoH & WebRTC Leak Shield",
        badge = "VPN SHIELD",
        description = "Spoofs network origin, blocks WebRTC IP leaks, and enforces Encrypted DNS-over-HTTPS."
    ),
    MULTI_ENGINE(
        title = "Silent Multi-Engine",
        subtitle = "Unified Multi-Layer Privacy Matrix",
        badge = "STEALTH MATRIX",
        description = "Combines Tor headers, Brave ad blocking, Tails volatile memory, and Mullvad leak prevention into one interface."
    )
}
