package com.example.data.model

enum class SearchEngine(
    val id: String,
    val displayName: String,
    val queryUrl: String,
    val iconLetter: String,
    val brandColorHex: Long,
    val isStealthPrivate: Boolean = false
) {
    SILENT_STEALTH(
        id = "silent",
        displayName = "Silent Search",
        queryUrl = "https://duckduckgo.com/?q=%s&kp=-2&kz=-1&kac=-1&kn=1",
        iconLetter = "⚡",
        brandColorHex = 0xFF00E5FF,
        isStealthPrivate = true
    ),
    DUCKDUCKGO(
        id = "duckduckgo",
        displayName = "DuckDuckGo",
        queryUrl = "https://duckduckgo.com/?q=%s",
        iconLetter = "🦆",
        brandColorHex = 0xFFDE5833
    ),
    BRAVE(
        id = "brave",
        displayName = "Brave Search",
        queryUrl = "https://search.brave.com/search?q=%s",
        iconLetter = "🦁",
        brandColorHex = 0xFFFF5500
    ),
    STARTPAGE(
        id = "startpage",
        displayName = "Startpage",
        queryUrl = "https://www.startpage.com/do/search?q=%s",
        iconLetter = "SP",
        brandColorHex = 0xFF0052CC
    ),
    GOOGLE(
        id = "google",
        displayName = "Google",
        queryUrl = "https://www.google.com/search?q=%s",
        iconLetter = "G",
        brandColorHex = 0xFF4285F4
    ),
    YAHOO(
        id = "yahoo",
        displayName = "Yahoo Search",
        queryUrl = "https://search.yahoo.com/search?p=%s",
        iconLetter = "Y!",
        brandColorHex = 0xFF720E9E
    ),
    BING(
        id = "bing",
        displayName = "Microsoft Bing",
        queryUrl = "https://www.bing.com/search?q=%s",
        iconLetter = "B",
        brandColorHex = 0xFF008373
    ),
    ECOSIA(
        id = "ecosia",
        displayName = "Ecosia",
        queryUrl = "https://www.ecosia.org/search?q=%s",
        iconLetter = "🌱",
        brandColorHex = 0xFF00A389
    ),
    MOJEEK(
        id = "mojeek",
        displayName = "Mojeek",
        queryUrl = "https://www.mojeek.com/search?q=%s",
        iconLetter = "M",
        brandColorHex = 0xFF4BA64F
    );

    fun buildSearchUrl(rawQuery: String): String {
        val encoded = try {
            java.net.URLEncoder.encode(rawQuery.trim(), "UTF-8")
        } catch (_: Exception) {
            rawQuery.trim().replace(" ", "+")
        }
        return queryUrl.replace("%s", encoded)
    }
}
