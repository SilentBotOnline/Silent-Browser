package com.example

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import com.example.ui.components.AccountAuthModal
import com.example.ui.components.SyncConflictDialog
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.BookmarksHistoryScreen
import com.example.ui.screens.BrowserScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DevOpsScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.ExtensionsScreen
import com.example.ui.screens.LegalScreen
import com.example.ui.screens.PasswordVaultScreen
import com.example.ui.screens.PrivacyDashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TabsOverviewScreen
import com.example.ui.theme.BrowserThemeMode
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SilentColors
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                SilentColors.WhiteBg.toArgb(),
                SilentColors.WhiteBg.toArgb()
            ),
            navigationBarStyle = SystemBarStyle.light(
                SilentColors.WhiteBg.toArgb(),
                SilentColors.WhiteBg.toArgb()
            )
        )

        handleIntent(intent)

        setContent {
            val context = LocalContext.current
            val themePreset by viewModel.selectedThemePreset.collectAsState()
            val proximityPanicEnabled by viewModel.proximityPanicEnabled.collectAsState()

            DisposableEffect(proximityPanicEnabled, context) {
                if (!proximityPanicEnabled) {
                    onDispose { }
                } else {
                    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
                    val proximitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
                    if (sensorManager == null || proximitySensor == null) {
                        onDispose { }
                    } else {
                        var wasFar = false
                        val listener = object : SensorEventListener {
                            override fun onSensorChanged(event: SensorEvent) {
                                val distance = event.values.firstOrNull() ?: return
                                val maxRange = proximitySensor.maximumRange
                                val isNear = distance < maxRange && distance <= 1.5f
                                if (!isNear) {
                                    wasFar = true
                                } else if (wasFar) {
                                    wasFar = false
                                    viewModel.panicPurge()
                                    Toast.makeText(context, "Panic Wipe triggered", Toast.LENGTH_SHORT).show()
                                }
                            }

                            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
                        }
                        sensorManager.registerListener(listener, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
                        onDispose {
                            sensorManager.unregisterListener(listener)
                        }
                    }
                }
            }

            LaunchedEffect(themePreset) {
                val ext = when (themePreset.mode) {
                    BrowserThemeMode.BLACK -> SilentColors.BlackExtended
                    BrowserThemeMode.WHITE -> SilentColors.WhiteExtended
                    BrowserThemeMode.MIDNIGHT -> SilentColors.MidnightExtended
                }
                val topArgb = ext.topBarSurface.toArgb()
                val bottomArgb = ext.bottomBarSurface.toArgb()
                enableEdgeToEdge(
                    statusBarStyle = if (ext.isDark) {
                        SystemBarStyle.dark(topArgb)
                    } else {
                        SystemBarStyle.light(topArgb, topArgb)
                    },
                    navigationBarStyle = if (ext.isDark) {
                        SystemBarStyle.dark(bottomArgb)
                    } else {
                        SystemBarStyle.light(bottomArgb, bottomArgb)
                    }
                )
            }

            MyApplicationTheme(themePreset = themePreset) {
                val silent = MaterialTheme.silentColors
                val currentScreen by viewModel.currentScreen.collectAsState()
                val authUiState by viewModel.authUiState.collectAsState()
                val showSyncConflictDialog by viewModel.showSyncConflictDialog.collectAsState()
                val syncConflicts by viewModel.syncConflicts.collectAsState()

                BackHandler(
                    enabled = currentScreen != ScreenDestination.DASHBOARD &&
                        currentScreen != ScreenDestination.BROWSER
                ) {
                    viewModel.navigateTo(ScreenDestination.DASHBOARD)
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = silent.screenBackground
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(cyberAtmosphericBrush(themePreset))
                            .statusBarsPadding()
                    ) {
                        Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                            when (screen) {
                                ScreenDestination.BROWSER -> BrowserScreen(viewModel)
                                ScreenDestination.DASHBOARD -> DashboardScreen(viewModel)
                                ScreenDestination.PRIVACY_DASHBOARD -> PrivacyDashboardScreen(viewModel)
                                ScreenDestination.TABS_OVERVIEW -> TabsOverviewScreen(viewModel)
                                ScreenDestination.DEVOPS_CENTER -> DevOpsScreen(viewModel)
                                ScreenDestination.BOOKMARKS_HISTORY -> BookmarksHistoryScreen(viewModel)
                                ScreenDestination.PASSWORD_VAULT -> PasswordVaultScreen(viewModel)
                                ScreenDestination.DOWNLOADS -> DownloadsScreen(viewModel)
                                ScreenDestination.SETTINGS -> SettingsScreen(viewModel)
                                ScreenDestination.EXTENSIONS -> ExtensionsScreen(viewModel)
                                ScreenDestination.LEGAL -> LegalScreen(viewModel)
                                ScreenDestination.ABOUT -> AboutScreen(viewModel)
                                ScreenDestination.ACCOUNT -> AccountScreen(viewModel)
                            }
                        }

                        if (authUiState.isSheetOpen) {
                            AccountAuthModal(viewModel = viewModel)
                        }

                        if (showSyncConflictDialog && syncConflicts.isNotEmpty()) {
                            SyncConflictDialog(
                                viewModel = viewModel,
                                onDismiss = { viewModel.dismissSyncConflictDialog() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            val url = intent.dataString
            if (!url.isNullOrBlank()) {
                viewModel.openUrl(url)
            }
        }
    }
}
