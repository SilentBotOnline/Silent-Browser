package com.example.ui.screens

import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkRemove
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchEngine
import com.example.ui.components.CyberCard
import com.example.ui.components.QrSyncDialog
import com.example.ui.components.SecuritySetupWizardDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AppThemePreset
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination
import java.io.File

@Composable
fun SettingsScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors

    // Theme & Setup State
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val showSetupWizardModal by viewModel.showSetupWizardModal.collectAsState()

    // Privacy & Shields State
    val adblockEnabled by viewModel.adblockEnabled.collectAsState()
    val fingerprintShieldEnabled by viewModel.fingerprintShieldEnabled.collectAsState()
    val httpsEverywhereEnabled by viewModel.httpsEverywhereEnabled.collectAsState()
    val javascriptEnabled by viewModel.javascriptEnabled.collectAsState()
    val thirdPartyCookiesBlocked by viewModel.thirdPartyCookiesBlocked.collectAsState()
    val doNotTrackEnabled by viewModel.doNotTrackEnabled.collectAsState()
    val antiScamEnabled by viewModel.antiScamProtectionEnabled.collectAsState()
    val dntHeadersSent by viewModel.dntHeadersSentCount.collectAsState()
    val proximityPanicEnabled by viewModel.proximityPanicEnabled.collectAsState()

    // Virtual Shielded IP & Relay State
    val shieldedIpEnabled by viewModel.shieldedIpEnabled.collectAsState()
    val activeRelayNode by viewModel.activeRelayNode.collectAsState()

    // Incognito Private Browsing State
    val alwaysIncognito by viewModel.alwaysIncognito.collectAsState()
    val autoPurgeOnTabClosure by viewModel.autoPurgeOnTabClosure.collectAsState()

    // Password Vault & Autofill State
    val passwords by viewModel.passwords.collectAsState()
    val autofillEnabled by viewModel.autofillEnabled.collectAsState()

    // Extensions State
    val extensions by viewModel.extensions.collectAsState()

    // Search & Suggestions State
    val suggestionsEnabled by viewModel.suggestionsEnabled.collectAsState()
    val cleanStealthMode by viewModel.cleanStealthMode.collectAsState()
    val selectedUserAgent by viewModel.selectedUserAgent.collectAsState()
    val activeSearchEngine by viewModel.activeSearchEngine.collectAsState()

    // Download & Storage State
    val downloadLocation by viewModel.downloadLocation.collectAsState()

    // Bookmarks & Ephemeral Encrypted QR Sync State
    val bookmarks by viewModel.bookmarks.collectAsState()
    val qrSyncSession by viewModel.qrSyncSession.collectAsState()
    val isGeneratingQrSync by viewModel.isGeneratingQrSync.collectAsState()
    val qrSyncIncludeBookmarks by viewModel.qrSyncIncludeBookmarks.collectAsState()
    val qrSyncIncludeSettings by viewModel.qrSyncIncludeSettings.collectAsState()
    val qrSyncError by viewModel.qrSyncError.collectAsState()

    // Dialog States
    var showQrSyncDialog by remember { mutableStateOf(false) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showClearBookmarksDialog by remember { mutableStateOf(false) }
    var showClearPasswordsDialog by remember { mutableStateOf(false) }
    var showPanicDialog by remember { mutableStateOf(false) }
    var showDownloadPathDialog by remember { mutableStateOf(false) }
    var customPathInput by remember { mutableStateOf(downloadLocation) }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = silent.accentSuccess
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = "SETTINGS & SYSTEM CONTROL",
                            color = silent.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Security, Privacy, Themes & Customization",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) },
                    modifier = Modifier.size(48.dp).testTag("settings_top_privacy_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.PrivacyTip,
                        contentDescription = "Privacy Dashboard",
                        tint = silent.accentSuccess
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 0. TOP GOVERNANCE & QUICK PORTALS
            item {
                CyberCard(
                    borderColor = silent.accentSuccess.copy(alpha = 0.5f),
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "LEGAL, PRIVACY DASHBOARD & SETUP",
                            color = silent.accentInfo,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.LEGAL) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_legal_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, CyberPurple.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Gavel, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Legal & Policy", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_privacy_dash_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.accentSuccess.copy(alpha = 0.7f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Privacy HUD", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = { viewModel.openDefaultBrowserSettings(context) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("settings_default_browser_btn"),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = silent.secondaryButtonBackground,
                                contentColor = silent.secondaryButtonContent
                            ),
                            border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Set Silent Browser as Default Browser", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        val productionReady = doNotTrackEnabled && antiScamEnabled && adblockEnabled
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.chipDefaultBackground)
                                .border(
                                    1.dp,
                                    if (productionReady) silent.badgeSuccessBorder else silent.badgeWarningBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.openSetupWizard() }
                                .padding(10.dp)
                                .testTag("settings_setup_wizard_row"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = if (productionReady) silent.accentSuccess else silent.accentWarning,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (productionReady) "Production Security Profile Active" else "Custom Security Profile",
                                        color = silent.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Panic Wipe armed • Tap to calibrate search & shield profile",
                                        color = silent.textSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            StatusBadge(
                                text = if (productionReady) "ACTIVE" else "CUSTOM",
                                color = if (productionReady) silent.accentSuccess else silent.accentWarning
                            )
                        }
                    }
                }
            }

            // 0.5. ENCRYPTED SYNC VIA QR (MOBILE -> DESKTOP)
            item {
                Text(
                    text = "SYNC VIA QR (MOBILE → DESKTOP)",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = null,
                                    tint = silent.accentInfo,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Encrypted Desktop Handoff",
                                        color = silent.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Transfers ${bookmarks.size} saved bookmarks & active privacy shields via 5-min ephemeral AES-256-GCM QR.",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(text = "AES-256", color = silent.accentSuccess)
                        }

                        Button(
                            onClick = {
                                viewModel.generateQrSyncSession()
                                showQrSyncDialog = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("settings_sync_via_qr_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = silent.primaryButtonBackground,
                                contentColor = silent.primaryButtonContent
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode2,
                                contentDescription = null,
                                tint = silent.primaryButtonContent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sync via QR (Generate Temporary Code)",
                                color = silent.primaryButtonContent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // 1. THEME (RADIO BUTTON GROUP)
            item {
                Text(
                    text = "THEME",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(
                        modifier = Modifier
                            .padding(14.dp)
                            .selectableGroup(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Theme", color = silent.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val themeOptions = listOf(
                            AppThemePreset.WHITE to "White",
                            AppThemePreset.BLACK to "Black",
                            AppThemePreset.MIDNIGHT to "Midnight"
                        )
                        themeOptions.forEach { (preset, label) ->
                            val isSelected = themePreset == preset
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) silent.chipSelectedBackground else silent.screenBackground)
                                    .border(1.dp, if (isSelected) silent.chipSelectedBorder else silent.cardBorder, RoundedCornerShape(8.dp))
                                    .selectable(
                                        selected = isSelected,
                                        onClick = { viewModel.setThemePreset(preset) },
                                        role = Role.RadioButton
                                    )
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                                    .testTag("appearance_radio_${preset.id}"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    androidx.compose.material3.RadioButton(
                                        selected = isSelected,
                                        onClick = null,
                                        colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                            selectedColor = silent.accentSuccess,
                                            unselectedColor = silent.textMuted
                                        ),
                                        modifier = Modifier.testTag("radio_btn_${preset.id}")
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = label,
                                            color = if (isSelected) silent.chipSelectedContent else silent.textPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(preset.subtitle, color = silent.textMuted, fontSize = 10.sp)
                                    }
                                }
                                if (isSelected) {
                                    StatusBadge(text = "ACTIVE", color = silent.accentSuccess)
                                }
                            }
                        }
                    }
                }
            }

            // 2. PASSWORD VAULT & AUTO-FILL CREDENTIALS
            item {
                Text(
                    text = "PASSWORD VAULT & AUTO-FILL CREDENTIALS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            title = "Login Form Auto-Fill Engine",
                            description = "Detects login fields and injects AES-256 GCM decrypted credentials cleanly.",
                            checked = autofillEnabled,
                            onCheckedChange = {
                                viewModel.toggleAutofill(it)
                                Toast.makeText(context, "Auto-Fill ${if (it) "Enabled" else "Disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Encrypted Logins Stored", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("PBKDF2 + AES-256 GCM Local Store", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            StatusBadge(text = "${passwords.size} SAVED", color = silent.accentSuccess)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.PASSWORD_VAULT) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_open_vault_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open Vault", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = { showClearPasswordsDialog = true },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_clear_passwords_button"),
                                border = BorderStroke(1.dp, silent.accentError.copy(alpha = 0.7f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = silent.accentError, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear Vault", color = silent.accentError, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 3. DEFAULT SEARCH & SUGGESTION MATRIX
            item {
                Text(
                    text = "SEARCH & REAL-TIME SUGGESTION ENGINE",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            title = "Real-Time Multi-Engine Suggestions",
                            description = "Fetches instant query completions from multiple engines as you type in the omnibox.",
                            checked = suggestionsEnabled,
                            onCheckedChange = {
                                viewModel.toggleSuggestions(it)
                                Toast.makeText(context, "Search suggestions ${if (it) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Clean Stealth Search Mode",
                            description = "Uses Silent Search by default without showing external browser corporate branding.",
                            checked = cleanStealthMode,
                            onCheckedChange = {
                                viewModel.toggleCleanStealthMode(it)
                                Toast.makeText(context, "Clean Stealth Mode ${if (it) "engaged" else "disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Text(
                            text = "Configured Default Search Engine:",
                            color = silent.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            SearchEngine.values().forEach { engine ->
                                val isSelected = activeSearchEngine == engine
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) silent.chipSelectedBackground else silent.screenBackground)
                                        .border(
                                            1.dp,
                                            if (isSelected) silent.chipSelectedBorder else silent.cardBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            viewModel.setSearchEngine(engine)
                                            Toast.makeText(context, "Default search engine set to ${engine.displayName}", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                        .testTag("engine_option_${engine.id}"),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = engine.iconLetter,
                                            fontSize = 14.sp,
                                            color = if (isSelected) silent.accentSuccess else silent.textSecondary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = engine.displayName,
                                                color = if (isSelected) silent.chipSelectedContent else silent.textPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (engine.isStealthPrivate) {
                                                Text(
                                                    text = "Zero-logging, anti-tracking, clean private gateway",
                                                    color = silent.accentSuccess,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }
                                    if (isSelected) {
                                        StatusBadge(text = "DEFAULT", color = silent.accentSuccess)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. VIRTUAL SHIELDED IP & RELAY MATRIX
            item {
                Text(
                    text = "VIRTUAL SHIELDED IP & RELAY MATRIX",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(
                    borderColor = if (shieldedIpEnabled) silent.badgeSuccessBorder else silent.cardBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            title = "Virtual Shielded IP Routing",
                            description = "Masks real device IP, WebRTC, and ISP identifiers behind encrypted relay nodes.",
                            checked = shieldedIpEnabled,
                            onCheckedChange = {
                                viewModel.toggleShieldedIp(it)
                                Toast.makeText(context, "Shielded IP ${if (it) "Enabled" else "Disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        if (shieldedIpEnabled) {
                            HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Current Relay Node:", color = silent.textSecondary, fontSize = 11.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(activeRelayNode.flag, fontSize = 14.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(activeRelayNode.location, color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("IP: ${activeRelayNode.virtualIp} (${activeRelayNode.latencyMs}ms)", color = silent.accentSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }

                                Button(
                                    onClick = {
                                        viewModel.rotateShieldedIp()
                                        Toast.makeText(context, "Rotated to ${viewModel.activeRelayNode.value.location}", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = silent.secondaryButtonBackground,
                                        contentColor = silent.accentSuccess
                                    ),
                                    border = BorderStroke(1.dp, silent.accentSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.heightIn(min = 48.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rotate IP", color = silent.accentSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                viewModel.relayNodes.forEach { node ->
                                    val isNodeActive = node == activeRelayNode
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 48.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isNodeActive) silent.chipSelectedBackground else silent.screenBackground)
                                            .border(1.dp, if (isNodeActive) silent.chipSelectedBorder else silent.cardBorder, RoundedCornerShape(8.dp))
                                            .clickable {
                                                viewModel.selectRelayNode(node)
                                                Toast.makeText(context, "Connected to ${node.location}", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(node.flag, fontSize = 14.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(node.location, color = if (isNodeActive) silent.chipSelectedContent else silent.textPrimary, fontSize = 12.sp, fontWeight = if (isNodeActive) FontWeight.Bold else FontWeight.Normal)
                                                Text("IP: ${node.virtualIp} • ${node.protocol}", color = silent.textMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                        if (isNodeActive) {
                                            StatusBadge(text = "CONNECTED", color = silent.accentSuccess)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. PRIVATE BROWSING (INCOGNITO) CONTROLS
            item {
                Text(
                    text = "PRIVATE BROWSING (INCOGNITO) CONTROLS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            title = "Always Incognito Mode",
                            description = "Opens all new tabs in private mode by default. History and form data are never recorded to disk.",
                            checked = alwaysIncognito,
                            onCheckedChange = {
                                viewModel.toggleAlwaysIncognito(it)
                                Toast.makeText(context, "Always Incognito ${if (it) "Active" else "Disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Auto-Purge on Tab Closure",
                            description = "Automatically destroys session cookies, local web cache, and authentication tokens whenever an individual tab is closed.",
                            checked = autoPurgeOnTabClosure,
                            onCheckedChange = {
                                viewModel.toggleAutoPurgeOnTabClosure(it)
                                Toast.makeText(context, "Tab Auto-Purge ${if (it) "Active" else "Disabled"}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // 6. BROWSER EXTENSIONS & USERSCRIPTS HUB
            item {
                Text(
                    text = "BROWSER EXTENSIONS & USERSCRIPTS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Extension, contentDescription = null, tint = silent.accentWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("WebExtension Runtime Engine", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    val activeCount = extensions.count { it.isEnabled }
                                    Text("$activeCount active / ${extensions.size} installed", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            StatusBadge(text = "COMPATIBLE", color = silent.accentWarning)
                        }

                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.EXTENSIONS) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = silent.secondaryButtonBackground,
                                contentColor = silent.secondaryButtonContent
                            ),
                            border = BorderStroke(1.dp, silent.accentWarning),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Extension, contentDescription = null, tint = silent.accentWarning, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Manage Installed Extensions & Scripts", color = silent.secondaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }

            // 7. ACTIVE PRIVACY, ANTI-SCAM & DNT:1 MATRIX
            item {
                Text(
                    text = "PRIVACY, ANTI-SCAM & DNT: 1 INTERCEPTOR",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingSwitchRow(
                            title = "Network Do Not Track (DNT: 1) Interceptor",
                            description = "Automatically appends 'DNT: 1' & 'Sec-GPC: 1' to outgoing traffic ($dntHeadersSent intercepted).",
                            checked = doNotTrackEnabled,
                            onCheckedChange = { viewModel.toggleDoNotTrack(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Anti-Scammer, Phishing & Bot Attack Shield",
                            description = "Blocks suspicious homograph phishing URLs, cryptominers, and bot telemetry payloads.",
                            checked = antiScamEnabled,
                            onCheckedChange = { viewModel.toggleAntiScamProtection(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Ad & Telemetry Blocker",
                            description = "Intercepts tracking beacons, analytics scripts, and ads before connection.",
                            checked = adblockEnabled,
                            onCheckedChange = { viewModel.toggleAdblock(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Canvas, WebGL & WebRTC Poisoning",
                            description = "Injects undetectable noise and masks WebRTC leaks to defeat browser fingerprinting.",
                            checked = fingerprintShieldEnabled,
                            onCheckedChange = { viewModel.toggleFingerprintShield(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "HTTPS Everywhere",
                            description = "Automatically upgrades unencrypted HTTP requests to encrypted HTTPS.",
                            checked = httpsEverywhereEnabled,
                            onCheckedChange = { viewModel.toggleHttpsEverywhere(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "Block Third-Party Cookies",
                            description = "Isolates site cookie jars to prevent cross-site identity tracking.",
                            checked = thirdPartyCookiesBlocked,
                            onCheckedChange = { viewModel.toggleThirdPartyCookies(it) }
                        )

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        SettingSwitchRow(
                            title = "JavaScript Execution",
                            description = "Controls dynamic web scripts. Disable for high-security, text-only HTML viewing.",
                            checked = javascriptEnabled,
                            onCheckedChange = { viewModel.toggleJavascript(it) }
                        )
                    }
                }
            }

            // 8. USER AGENT IDENTITY SPOOFER
            item {
                Text(
                    text = "IDENTITY & USER-AGENT SPOOFER",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "Tor Browser (Spoofed)" to "Disguises browser as Tor Browser Bundle (Linux x86_64)",
                            "Desktop Linux" to "Appears as Ubuntu Desktop Firefox 120.0",
                            "iPhone Safari" to "Appears as Apple iOS Safari 17.1",
                            "Default Android" to "Native Android System WebKit"
                        ).forEach { (uaTitle, desc) ->
                            val isSelected = selectedUserAgent == uaTitle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) silent.chipSelectedBackground else silent.screenBackground)
                                    .border(1.dp, if (isSelected) silent.chipSelectedBorder else silent.cardBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.setUserAgent(uaTitle)
                                        Toast.makeText(context, "Identity switched to $uaTitle", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = uaTitle,
                                        color = if (isSelected) silent.chipSelectedContent else silent.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Text(text = desc, color = silent.textMuted, fontSize = 10.sp)
                                }
                                if (isSelected) {
                                    StatusBadge(text = "ACTIVE", color = silent.accentSuccess)
                                }
                            }
                        }
                    }
                }
            }

            // 9. DOWNLOAD STORAGE & LOCATION CHANGE SYSTEM
            item {
                Text(
                    text = "DOWNLOAD STORAGE & LOCATION",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Active Storage Directory:", color = silent.textSecondary, fontSize = 11.sp)
                            StatusBadge(text = "PERSISTENT", color = silent.accentSuccess)
                        }

                        Text(
                            text = downloadLocation,
                            color = silent.accentWarning,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    customPathInput = downloadLocation
                                    showDownloadPathDialog = true
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_change_download_location"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change Location", color = silent.secondaryButtonContent, fontSize = 11.sp)
                            }

                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.DOWNLOADS) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("View Downloads", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 10. DATA, CACHE & STORAGE MANAGEMENT
            item {
                Text(
                    text = "DATA, CACHE & PRIVACY CLEANERS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.screenBackground)
                                .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.clearBrowsingCache(context)
                                    Toast.makeText(context, "Web cache and DOM storage cleared!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CleaningServices, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Clear Web Cache & DOM Storage", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Frees internal cached web assets", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            Text("PURGE", color = silent.accentInfo, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.screenBackground)
                                .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.clearCookies()
                                    Toast.makeText(context, "Cookies and active sessions wiped!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Cookie, contentDescription = null, tint = silent.accentWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Clear Cookies & Session Tokens", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Signs out of all web logins", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            Text("WIPE", color = silent.accentWarning, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.screenBackground)
                                .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                                .clickable { showClearHistoryDialog = true }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = silent.accentError, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Clear Browsing History", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Deletes all visited page records", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            Text("DELETE", color = silent.accentError, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.screenBackground)
                                .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                                .clickable { showClearBookmarksDialog = true }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BookmarkRemove, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Clear Saved Bookmarks", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Removes all organized folder bookmarks", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            Text("DELETE", color = CyberPurple, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 11. PANIC WIPE PROXIMITY SENSOR TRIGGER & MANUAL RESET ZONE
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "PANIC WIPE",
                        color = silent.accentInfo,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            SettingSwitchRow(
                                title = "Panic Wipe",
                                description = "Enable proximity sensor trigger to instantly wipe browsing history, cookies, site storage, and active tabs.",
                                checked = proximityPanicEnabled,
                                onCheckedChange = {
                                    viewModel.toggleProximityPanic(it)
                                    Toast.makeText(
                                        context,
                                        "Panic Wipe proximity trigger ${if (it) "enabled" else "disabled"}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                switchModifier = Modifier.testTag("settings_proximity_panic_switch")
                            )
                        }
                    }

                    Button(
                        onClick = { showPanicDialog = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("settings_panic_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.panicArmedBackground,
                            contentColor = silent.panicArmedContent
                        ),
                        border = BorderStroke(1.dp, silent.panicArmedBackground),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "EMERGENCY PANIC PURGE (ARMED)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.resetAllSettings()
                            Toast.makeText(context, "Settings restored to production privacy defaults!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = silent.secondaryButtonContent
                        ),
                        border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = silent.textSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset Shields to Recommended Defaults", fontSize = 11.sp)
                    }
                }
            }

            // 12. ABOUT, PRODUCTION ROADMAP & PORTAL SUPPORT SECTION
            item {
                Text(
                    text = "ABOUT, ARCHITECTURE & PORTAL SUPPORT",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Production Architecture v1.0.0", color = silent.accentSuccess, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            StatusBadge(text = "LIVE RELEASE", color = silent.accentSuccess)
                        }

                        RoadmapMilestoneRow("Phase 1 — Core Stealth & Shielded IP", "Relay routing headers, DNT: 1 interceptor, Incognito auto-purge", "LIVE", silent.accentSuccess)
                        RoadmapMilestoneRow("Phase 2 — Encrypted Vault & Extensions", "AES-256 GCM Password Manager, WebExtension runtime, Bookmarks SQLite", "LIVE", silent.accentSuccess)
                        RoadmapMilestoneRow("Phase 3 — Anti-Scam & Bot Defense", "Phishing guard, Canvas/WebGL noise, WebRTC leak prevention", "LIVE", silent.accentInfo)
                        RoadmapMilestoneRow("Phase 4 — Cross-Device Timestamp Sync", "Local-first conflict resolution, OpenSearch XML & encrypted QR sync", "LIVE", silent.accentSuccess)

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.DEVOPS_CENTER) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Sync Diagnostics", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }

                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.ABOUT) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Full About", color = silent.secondaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Publisher:", color = silent.textSecondary, fontSize = 11.sp)
                            Text("Silent Bot LLC", color = silent.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Publish Portal:", color = silent.textSecondary, fontSize = 11.sp)
                            Text("browser.silentbot.online", color = silent.accentSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.openSupportEmail(context) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Email, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Email Support", color = silent.secondaryButtonContent, fontSize = 11.sp)
                            }

                            Button(
                                onClick = { viewModel.callSupportPhone(context) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Call Hotline", color = silent.secondaryButtonContent, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSetupWizardModal) {
        SecuritySetupWizardDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.dismissSetupWizard() }
        )
    }

    if (showQrSyncDialog) {
        QrSyncDialog(
            session = qrSyncSession,
            isGenerating = isGeneratingQrSync,
            includeBookmarks = qrSyncIncludeBookmarks,
            includeSettings = qrSyncIncludeSettings,
            totalBookmarksCount = bookmarks.size,
            errorMessage = qrSyncError,
            onToggleIncludeBookmarks = { viewModel.toggleQrSyncIncludeBookmarks(it) },
            onToggleIncludeSettings = { viewModel.toggleQrSyncIncludeSettings(it) },
            onRegenerate = { viewModel.generateQrSyncSession() },
            onBurn = { viewModel.invalidateQrSyncSession("Burned by user / TTL expired.") },
            onDismiss = {
                showQrSyncDialog = false
                viewModel.invalidateQrSyncSession("QR Sync modal closed.")
            }
        )
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            containerColor = silent.cardBackground,
            title = { Text("Wipe Browsing History?", color = silent.accentError, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently remove all visited page URLs and timestamps from your device.", color = silent.textSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearHistory()
                        showClearHistoryDialog = false
                        Toast.makeText(context, "History wiped completely.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = silent.panicArmedBackground, contentColor = silent.panicArmedContent)
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    if (showClearBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showClearBookmarksDialog = false },
            containerColor = silent.cardBackground,
            title = { Text("Delete All Bookmarks?", color = silent.accentError, fontWeight = FontWeight.Bold) },
            text = { Text("All saved bookmarks and custom folders will be deleted permanently.", color = silent.textSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllBookmarks()
                        showClearBookmarksDialog = false
                        Toast.makeText(context, "Bookmarks deleted.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = silent.panicArmedBackground, contentColor = silent.panicArmedContent)
                ) {
                    Text("Delete All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearBookmarksDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    if (showClearPasswordsDialog) {
        AlertDialog(
            onDismissRequest = { showClearPasswordsDialog = false },
            containerColor = silent.cardBackground,
            title = { Text("Purge Password Vault?", color = silent.accentError, fontWeight = FontWeight.Bold) },
            text = { Text("This permanently deletes all ${passwords.size} AES-256 encrypted login entries from local storage.", color = silent.textSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllPasswords()
                        showClearPasswordsDialog = false
                        Toast.makeText(context, "Password vault cleared.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = silent.panicArmedBackground, contentColor = silent.panicArmedContent)
                ) {
                    Text("Purge Vault", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearPasswordsDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    if (showPanicDialog) {
        AlertDialog(
            onDismissRequest = { showPanicDialog = false },
            containerColor = silent.cardBackground,
            title = { Text("Trigger Amnesic Panic Purge?", color = silent.accentError, fontWeight = FontWeight.Bold) },
            text = { Text("This will instantly close all open tabs, wipe all browser cookies, delete HTML5 storage, and erase all navigation history.", color = silent.textSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.panicPurge()
                        showPanicDialog = false
                        Toast.makeText(context, "Amnesic RAM wipe complete. All tracks eliminated.", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = silent.panicArmedBackground, contentColor = silent.panicArmedContent)
                ) {
                    Text("PURGE NOW", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPanicDialog = false }) {
                    Text("Abort", color = silent.textSecondary)
                }
            }
        )
    }

    if (showDownloadPathDialog) {
        val internalPrivatePath = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
            "SilentDownloads"
        ).absolutePath
        val vaultSubPath = File(context.filesDir, "EncryptedVaultDownloads").absolutePath

        AlertDialog(
            onDismissRequest = { showDownloadPathDialog = false },
            containerColor = silent.cardBackground,
            title = { Text("Configure Download Folder", color = silent.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Quick Location Presets:", color = silent.textSecondary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { customPathInput = internalPrivatePath },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            border = BorderStroke(1.dp, silent.secondaryButtonBorder)
                        ) {
                            Text("Standard", color = silent.accentInfo, fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = { customPathInput = vaultSubPath },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            border = BorderStroke(1.dp, silent.badgeSuccessBorder)
                        ) {
                            Text("Sandbox", color = silent.accentSuccess, fontSize = 10.sp)
                        }
                    }

                    Text("Custom Directory Path:", color = silent.textSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = customPathInput,
                        onValueChange = { customPathInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        textStyle = TextStyle(color = silent.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customPathInput.isNotBlank()) {
                            viewModel.setDownloadLocation(customPathInput.trim())
                            showDownloadPathDialog = false
                            Toast.makeText(context, "Download location updated!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDownloadPathDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun RoadmapMilestoneRow(
    title: String,
    details: String,
    status: String,
    color: Color
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(silent.screenBackground)
            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(details, color = silent.textSecondary, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        StatusBadge(text = status, color = color, isPulsing = false)
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    switchModifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = silent.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = description, color = silent.textSecondary, fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = switchModifier,
            colors = SwitchDefaults.colors(
                checkedThumbColor = silent.primaryButtonContent,
                checkedTrackColor = silent.accentSuccess,
                uncheckedThumbColor = silent.textMuted,
                uncheckedTrackColor = silent.chipDefaultBackground
            )
        )
    }
}
