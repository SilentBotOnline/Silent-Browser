package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LaptopMac
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun AboutScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val silent = MaterialTheme.silentColors

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = silent.accentSuccess
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "ABOUT SILENT BROWSER",
                    color = silent.textPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Official Identity Header
            item {
                CyberCard(
                    borderColor = silent.accentSuccess.copy(alpha = 0.6f),
                    backgroundColor = silent.cardBackground
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.silent_browser_logo),
                            contentDescription = "Silent Browser Logo",
                            modifier = Modifier
                                .size(80.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.5.dp, silent.accentSuccess, RoundedCornerShape(16.dp))
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "SILENT BROWSER",
                            color = silent.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "Release Version 1.0.0 Production",
                            color = silent.accentSuccess,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Published by Silent Bot LLC • Silentbot.online",
                            color = silent.textSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusBadge(text = "PRODUCTION READY", color = silent.accentSuccess)
                            StatusBadge(text = "GPL-3.0 CORE", color = silent.accentInfo)
                        }
                    }
                }
            }

            // Contact & Official Portals Card
            item {
                Text(
                    text = "PUBLISHER & CONTACT CREDENTIALS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clickable {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://browser.silentbot.online/"))
                                    context.startActivity(intent)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Primary Web Portal", color = silent.textSecondary, fontSize = 10.sp)
                                Text("https://browser.silentbot.online/", color = silent.accentSuccess, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clickable {
                                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:silentbrowser@silentbot.online"))
                                    context.startActivity(intent)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Official Support Email", color = silent.textSecondary, fontSize = 10.sp)
                                Text("silentbrowser@silentbot.online", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clickable {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+15304816886"))
                                    context.startActivity(intent)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = silent.accentWarning, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Telephone Hotline", color = silent.textSecondary, fontSize = 10.sp)
                                Text("+1 (530) 481-6886", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Official Release Mirrors", color = silent.textSecondary, fontSize = 10.sp)
                                Text("https://silentbrowser.silentbot.online/", color = silent.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                Text("https://silentbot.online/silentbrowser", color = silent.textMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            // Architecture & Device Compatibility Roadmap
            item {
                Text(
                    text = "DEVICE COMPATIBILITY & CROSS-PLATFORM BUILDS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("• Android Platform:", color = silent.accentSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("  Compatible across Android phones, tablets, and foldables with adaptive edge-to-edge layout.", color = silent.textSecondary, fontSize = 11.sp)

                        Text("• Cross-Platform Roadmap & Portal:", color = silent.accentInfo, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("  - Android (.apk): Native Kotlin / Jetpack Compose app (Build v1.0.0)", color = silent.textSecondary, fontSize = 11.sp)
                        Text("  - Desktop & Apple targets: Published on portal when signed & verified", color = silent.textSecondary, fontSize = 11.sp)
                        Text("  - Primary Portal: https://browser.silentbot.online/", color = silent.accentSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                        Text("• Privacy Scope:", color = silent.accentWarning, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("  No first-party behavioral ad telemetry. Panic Wipe clears active tabs, cookies, site storage, and local history immediately (OS WebView process caches may remain until exit).", color = silent.textSecondary, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            AboutOsChip("Windows", Icons.Default.DesktopWindows) {
                                viewModel.openPlatformDownload("windows")
                            }
                            AboutOsChip("Android", Icons.Default.PhoneAndroid) {
                                viewModel.openPlatformDownload("android")
                            }
                            AboutOsChip("iPhone", Icons.Default.PhoneIphone) {
                                viewModel.openPlatformDownload("ios")
                            }
                            AboutOsChip("Mac", Icons.Default.LaptopMac) {
                                viewModel.openPlatformDownload("macos")
                            }
                            AboutOsChip("Other OS", Icons.AutoMirrored.Filled.OpenInNew) {
                                viewModel.openInExternalApp(context, "https://browser.silentbot.online/?os=other#downloads")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.openPublishPortal() },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Language, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Public Site", color = silent.primaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.openOfficialPortal() },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Public, contentDescription = null, tint = silent.secondaryButtonContent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("All OS Builds", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.LEGAL) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Gavel, contentDescription = null, tint = silent.secondaryButtonContent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Terms & Privacy", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.navigateTo(ScreenDestination.DEVOPS_CENTER) },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync & Diagnostics", color = silent.primaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Copyright © 2023-2030 Silent Bot LLC • Silentbot.online. All Rights Reserved.",
                    color = silent.textMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun AboutOsChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(silent.chipDefaultBackground)
            .border(1.dp, silent.chipDefaultBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = silent.accentInfo, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, color = silent.chipDefaultContent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
