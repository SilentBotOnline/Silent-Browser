package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.security.QrSyncManager
import com.example.data.security.QrSyncSession
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.silentColors
import kotlinx.coroutines.delay

@Composable
fun QrSyncDialog(
    session: QrSyncSession?,
    isGenerating: Boolean,
    includeBookmarks: Boolean,
    includeSettings: Boolean,
    totalBookmarksCount: Int,
    errorMessage: String?,
    onToggleIncludeBookmarks: (Boolean) -> Unit,
    onToggleIncludeSettings: (Boolean) -> Unit,
    onRegenerate: () -> Unit,
    onBurn: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val clipboardManager = LocalClipboardManager.current
    var revealPairingCode by remember { mutableStateOf(true) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(session?.sessionId, session?.expiresAtMs) {
        if (session != null) {
            while (true) {
                val current = System.currentTimeMillis()
                nowMs = current
                if (current >= session.expiresAtMs) {
                    onBurn()
                    break
                }
                delay(1000L)
            }
        }
    }

    val remainingSeconds = remember(session?.expiresAtMs, nowMs) {
        if (session == null) 0L
        else ((session.expiresAtMs - nowMs) / 1000L).coerceAtLeast(0L)
    }

    val countdownText = remember(remainingSeconds) {
        val mins = remainingSeconds / 60L
        val secs = remainingSeconds % 60L
        String.format("%02d:%02d", mins, secs)
    }

    val timerColor = when {
        remainingSeconds <= 15L -> CyberRed
        remainingSeconds <= 60L -> CyberOrange
        else -> silent.accentSuccess
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 20.dp)
                .widthIn(max = 520.dp),
            shape = RoundedCornerShape(16.dp),
            color = silent.topBarSurface,
            border = BorderStroke(1.dp, silent.cardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(silent.chipSelectedBackground)
                                .border(1.dp, silent.chipSelectedBorder, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode2,
                                contentDescription = null,
                                tint = silent.primaryButtonBackground,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SYNC VIA QR (E2EE)",
                                color = silent.textPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Encrypted Mobile → Desktop Transfer",
                                color = silent.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("qr_sync_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close QR Sync",
                            tint = silent.textMuted
                        )
                    }
                }

                // Live TTL + Encryption Status Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(silent.cardBackground)
                        .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = silent.accentSuccess,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AES-256-GCM • PBKDF2",
                            color = silent.textPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (session != null) {
                        StatusBadge(
                            text = "EXPIRES $countdownText",
                            color = timerColor,
                            isPulsing = remainingSeconds <= 60L
                        )
                    } else {
                        StatusBadge(
                            text = "BURNED",
                            color = CyberOrange,
                            isPulsing = false
                        )
                    }
                }

                // Sync Scope Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SyncScopeToggleChip(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qr_sync_toggle_bookmarks"),
                        icon = Icons.Default.Bookmark,
                        label = "Bookmarks ($totalBookmarksCount)",
                        selected = includeBookmarks,
                        accent = silent.accentSuccess,
                        onClick = { onToggleIncludeBookmarks(!includeBookmarks) }
                    )
                    SyncScopeToggleChip(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qr_sync_toggle_settings"),
                        icon = Icons.Default.Shield,
                        label = "Privacy Settings",
                        selected = includeSettings,
                        accent = silent.primaryButtonBackground,
                        onClick = { onToggleIncludeSettings(!includeSettings) }
                    )
                }

                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = CyberRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberRed.copy(alpha = 0.12f))
                            .border(1.dp, CyberRed.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    )
                }

                // Scannable QR Matrix Box
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    when {
                        isGenerating -> {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(silent.cardBackground)
                                    .border(1.dp, silent.cardBorder, RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CircularProgressIndicator(color = silent.primaryButtonBackground, strokeWidth = 3.dp)
                                    Text(
                                        text = "Deriving ephemeral 256-bit key...",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        session != null -> {
                            val matrix = remember(session.qrPayload) {
                                runCatching { QrSyncManager.generateQrMatrix(session.qrPayload) }.getOrNull()
                            }

                            if (matrix != null && matrix.isNotEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    border = BorderStroke(2.dp, silent.primaryButtonBackground.copy(alpha = 0.7f)),
                                    modifier = Modifier
                                        .widthIn(max = 244.dp)
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .semantics {
                                            contentDescription = "Encrypted QR Code for Silent Browser Desktop Sync"
                                        }
                                        .testTag("qr_sync_matrix_canvas")
                                ) {
                                    Canvas(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(14.dp)
                                    ) {
                                        val count = matrix.size
                                        val cellW = size.width / count.toFloat()
                                        val cellH = size.height / count.toFloat()
                                        drawRect(color = Color.White)
                                        for (y in 0 until count) {
                                            val row = matrix[y]
                                            for (x in 0 until count) {
                                                if (row[x]) {
                                                    drawRect(
                                                        color = Color.Black,
                                                        topLeft = Offset(x * cellW, y * cellH),
                                                        size = Size(cellW + 0.4f, cellH + 0.4f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Text(
                                    text = "Unable to render QR matrix for current payload.",
                                    color = CyberRed,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        else -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 160.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(silent.cardBackground)
                                    .border(1.dp, CyberOrange.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteForever,
                                        contentDescription = null,
                                        tint = CyberOrange,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Text(
                                        text = "QR Session Burned / Expired",
                                        color = CyberOrange,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Temporary keys were purged from memory. Tap Regenerate to mint a new one-time code.",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                if (session != null) {
                    if (session.wasTruncatedForQrCapacity) {
                        Text(
                            text = "Included top ${session.bookmarkCount} of ${session.totalAvailableBookmarks} bookmarks to maintain reliable desktop camera scan density.",
                            color = silent.accentWarning,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.badgeWarningBackground)
                                .border(1.dp, silent.badgeWarningBorder, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        )
                    }

                    // One-Time Pairing Code Section (never inside QR itself)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(silent.cardBackground)
                            .border(1.dp, silent.badgeSuccessBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ONE-TIME PAIRING CODE",
                                color = silent.accentSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Session ${session.sessionId.take(6)} • ${session.payloadBytes}B",
                                color = silent.textMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (revealPairingCode) session.pairingCode else "••••-••••-••••",
                                color = silent.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.2.sp,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("qr_sync_pairing_code_text")
                            )

                            IconButton(
                                onClick = { revealPairingCode = !revealPairingCode },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("qr_sync_toggle_code_visibility")
                            ) {
                                Icon(
                                    imageVector = if (revealPairingCode) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (revealPairingCode) "Hide pairing code" else "Reveal pairing code",
                                    tint = silent.textSecondary
                                )
                            }

                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(session.pairingCode))
                                    Toast.makeText(context, "One-time pairing code copied", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("qr_sync_copy_code_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy pairing code",
                                    tint = silent.accentSuccess
                                )
                            }
                        }

                        HorizontalDivider(color = silent.barDivider, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "1. Open Silent Browser Desktop (browser.silentbot.online)\n2. Scan QR & enter pairing code above to decrypt",
                                color = silent.textSecondary,
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(session.qrPayload))
                                    Toast.makeText(context, "Encrypted QR sync payload copied", Toast.LENGTH_SHORT).show()
                                },
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("qr_sync_copy_uri_button")
                            ) {
                                Text("Copy URI", color = silent.primaryButtonBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Bottom Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onBurn()
                            Toast.makeText(context, "Temporary QR key purged from RAM", Toast.LENGTH_SHORT).show()
                        },
                        enabled = session != null && !isGenerating,
                        border = BorderStroke(1.dp, CyberRed.copy(alpha = if (session != null) 0.7f else 0.3f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("qr_sync_burn_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = null,
                            tint = if (session != null) CyberRed else silent.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Burn QR",
                            color = if (session != null) CyberRed else silent.textMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onRegenerate,
                        enabled = !isGenerating,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.primaryButtonBackground,
                            contentColor = silent.primaryButtonContent
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("qr_sync_regenerate_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Regenerate",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncScopeToggleChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) silent.chipSelectedBackground else silent.chipDefaultBackground)
            .border(1.dp, if (selected) accent else silent.chipDefaultBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) accent else silent.textMuted,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = if (selected) accent else silent.textSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}
