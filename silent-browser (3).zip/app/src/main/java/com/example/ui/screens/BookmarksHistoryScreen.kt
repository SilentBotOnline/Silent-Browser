package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ImportExport
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Bookmark
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class BookmarkSortOrder {
    RECENTLY_ADDED,
    MOST_VISITED,
    ALPHABETICAL
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksHistoryScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val frequentlyVisited by viewModel.frequentlyVisited.collectAsState()
    val pinnedBookmarks by viewModel.pinnedBookmarks.collectAsState()
    val history by viewModel.history.collectAsState()
    val activeTab = viewModel.activeTab

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedFolder by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var sortOrder by remember { mutableStateOf(BookmarkSortOrder.RECENTLY_ADDED) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showBackupMenu by remember { mutableStateOf(false) }

    // Dialog States
    var showAddBookmarkDialog by remember { mutableStateOf(false) }
    var showEditBookmarkDialog by remember { mutableStateOf(false) }
    var bookmarkToEdit by remember { mutableStateOf<Bookmark?>(null) }

    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderNameInput by remember { mutableStateOf("") }

    var showRenameFolderDialog by remember { mutableStateOf(false) }
    var folderToRename by remember { mutableStateOf("") }
    var renamedFolderInput by remember { mutableStateOf("") }

    var showDeleteFolderDialog by remember { mutableStateOf(false) }
    var folderToDelete by remember { mutableStateOf("") }

    var showExportDialog by remember { mutableStateOf(false) }
    var exportJsonContent by remember { mutableStateOf("") }

    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonInput by remember { mutableStateOf("") }

    // Add Bookmark Form Fields
    var newTitle by remember { mutableStateOf("") }
    var newUrl by remember { mutableStateOf("") }
    var newFolder by remember { mutableStateOf("Favorites") }
    var newIsPinned by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    val existingFolders = remember(bookmarks) {
        val folderSet = linkedSetOf("Favorites", "Work", "Privacy & Tor", "DevOps & Cloud", "Reading")
        bookmarks.forEach {
            if (it.folder.isNotBlank()) folderSet.add(it.folder)
        }
        folderSet.toList()
    }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
            ) {
                // Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = silent.accentSuccess
                        )
                    }

                    Text(
                        text = when (selectedTabIndex) {
                            0 -> "BOOKMARKS VAULT"
                            1 -> "TOP QUICK ACCESS"
                            else -> "BROWSING HISTORY"
                        },
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selectedTabIndex == 0 || selectedTabIndex == 1) {
                            Box {
                                IconButton(
                                    onClick = { showBackupMenu = true },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ImportExport,
                                        contentDescription = "Backup and Restore",
                                        tint = silent.accentWarning
                                    )
                                }
                                DropdownMenu(
                                    expanded = showBackupMenu,
                                    onDismissRequest = { showBackupMenu = false },
                                    modifier = Modifier.background(silent.cardBackground)
                                ) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Export Bookmarks (JSON)", color = silent.textPrimary, fontSize = 12.sp)
                                            }
                                        },
                                        onClick = {
                                            showBackupMenu = false
                                            exportJsonContent = viewModel.exportBookmarksJson()
                                            showExportDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ContentPaste, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Import Bookmarks (JSON)", color = silent.textPrimary, fontSize = 12.sp)
                                            }
                                        },
                                        onClick = {
                                            showBackupMenu = false
                                            importJsonInput = ""
                                            showImportDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.CreateNewFolder, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("New Folder", color = silent.textPrimary, fontSize = 12.sp)
                                            }
                                        },
                                        onClick = {
                                            showBackupMenu = false
                                            newFolderNameInput = ""
                                            showNewFolderDialog = true
                                        }
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    val currentUrl = activeTab?.url ?: ""
                                    val currentTitle = activeTab?.title ?: ""
                                    newTitle = if (currentUrl != "about:blank" && currentUrl.isNotBlank()) currentTitle else ""
                                    newUrl = if (currentUrl != "about:blank" && currentUrl.isNotBlank()) currentUrl else ""
                                    newFolder = if (selectedFolder != "All") selectedFolder else "Favorites"
                                    newIsPinned = false
                                    showAddBookmarkDialog = true
                                },
                                modifier = Modifier.size(48.dp).testTag("add_bookmark_top_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add Bookmark",
                                    tint = silent.accentSuccess
                                )
                            }
                        } else if (history.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.clearHistory() },
                                modifier = Modifier.size(48.dp).testTag("clear_history_top_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Clear History",
                                    tint = silent.accentError
                                )
                            }
                        }
                    }
                }

                // Main Navigation Tabs
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = silent.topBarSurface,
                    contentColor = silent.accentSuccess,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = silent.accentSuccess
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Bookmarks (${bookmarks.size})", fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Top Access (${frequentlyVisited.size})", fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 2,
                        onClick = { selectedTabIndex = 2 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("History (${history.size})", fontSize = 12.sp)
                            }
                        }
                    )
                }

                // Folder horizontal chips
                if (selectedTabIndex == 0) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FolderChip(
                            title = "All Bookmarks (${bookmarks.size})",
                            isSelected = selectedFolder == "All",
                            onClick = { selectedFolder = "All" }
                        )

                        existingFolders.forEach { folderName ->
                            val folderCount = bookmarks.count { it.folder.equals(folderName, ignoreCase = true) }
                            FolderChip(
                                title = "$folderName ($folderCount)",
                                isSelected = selectedFolder.equals(folderName, ignoreCase = true),
                                onClick = { selectedFolder = folderName },
                                onLongClick = {
                                    folderToRename = folderName
                                    renamedFolderInput = folderName
                                    showRenameFolderDialog = true
                                }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .heightIn(min = 38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(silent.chipDefaultBackground)
                                .border(1.dp, CyberPurple.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clickable {
                                    newFolderNameInput = ""
                                    showNewFolderDialog = true
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Folder", color = CyberPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Search Filter & Sort Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("bookmarks_search_input"),
                        placeholder = { Text("Search by title, URL or folder...", color = silent.textMuted, fontSize = 12.sp) },
                        singleLine = true,
                        textStyle = TextStyle(color = silent.textPrimary, fontSize = 13.sp),
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(48.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = silent.textMuted, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.cardBackground,
                            unfocusedContainerColor = silent.cardBackground
                        )
                    )

                    if (selectedTabIndex == 0) {
                        Box {
                            OutlinedButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier.heightIn(min = 48.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, silent.cardBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                )
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort", tint = silent.accentSuccess, modifier = Modifier.size(18.dp))
                            }
                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false },
                                modifier = Modifier.background(silent.cardBackground)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Recently Added", color = if (sortOrder == BookmarkSortOrder.RECENTLY_ADDED) silent.accentSuccess else silent.textPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        sortOrder = BookmarkSortOrder.RECENTLY_ADDED
                                        showSortMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Most Visited", color = if (sortOrder == BookmarkSortOrder.MOST_VISITED) silent.accentSuccess else silent.textPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        sortOrder = BookmarkSortOrder.MOST_VISITED
                                        showSortMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Alphabetical (A-Z)", color = if (sortOrder == BookmarkSortOrder.ALPHABETICAL) silent.accentSuccess else silent.textPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        sortOrder = BookmarkSortOrder.ALPHABETICAL
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        when (selectedTabIndex) {
            0 -> {
                val filteredBookmarks = bookmarks.filter {
                    val matchesFolder = (selectedFolder == "All") || it.folder.equals(selectedFolder, ignoreCase = true)
                    val matchesSearch = it.title.contains(searchQuery, ignoreCase = true) ||
                            it.url.contains(searchQuery, ignoreCase = true) ||
                            it.folder.contains(searchQuery, ignoreCase = true)
                    matchesFolder && matchesSearch
                }.let { list ->
                    when (sortOrder) {
                        BookmarkSortOrder.RECENTLY_ADDED -> list.sortedByDescending { it.createdAt }
                        BookmarkSortOrder.MOST_VISITED -> list.sortedByDescending { it.visitCount }
                        BookmarkSortOrder.ALPHABETICAL -> list.sortedBy { it.title.lowercase(Locale.ROOT) }
                    }
                }

                if (filteredBookmarks.isEmpty()) {
                    EmptyStateView(
                        paddingValues = paddingValues,
                        message = if (searchQuery.isNotBlank()) "No bookmarks matching '$searchQuery'"
                        else if (selectedFolder != "All") "Folder '$selectedFolder' is empty"
                        else "No bookmarks saved yet in your secure vault",
                        buttonText = "Add Bookmark",
                        onButtonClick = {
                            newTitle = activeTab?.title ?: ""
                            newUrl = if (activeTab?.url != "about:blank") activeTab?.url ?: "" else ""
                            newFolder = if (selectedFolder != "All") selectedFolder else "Favorites"
                            showAddBookmarkDialog = true
                        }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (selectedFolder != "All" && selectedFolder != "Favorites") {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Folder: $selectedFolder",
                                        color = silent.accentInfo,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Row {
                                        TextButton(onClick = {
                                            folderToRename = selectedFolder
                                            renamedFolderInput = selectedFolder
                                            showRenameFolderDialog = true
                                        }) {
                                            Text("Rename", color = silent.accentInfo, fontSize = 11.sp)
                                        }
                                        TextButton(onClick = {
                                            folderToDelete = selectedFolder
                                            showDeleteFolderDialog = true
                                        }) {
                                            Text("Delete Folder", color = silent.accentError, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }

                        items(filteredBookmarks, key = { it.id }) { bookmark ->
                            BookmarkCard(
                                bookmark = bookmark,
                                onOpen = { viewModel.openBookmark(bookmark) },
                                onEdit = {
                                    bookmarkToEdit = bookmark
                                    showEditBookmarkDialog = true
                                },
                                onTogglePin = { viewModel.toggleBookmarkPin(bookmark) },
                                onDelete = { viewModel.deleteBookmark(bookmark) }
                            )
                        }
                    }
                }
            }
            1 -> {
                val allTopBookmarks = (frequentlyVisited + pinnedBookmarks).distinctBy { it.id }.sortedByDescending {
                    if (it.isPinned) 1000 + it.visitCount else it.visitCount
                }

                if (allTopBookmarks.isEmpty()) {
                    EmptyStateView(
                        paddingValues = paddingValues,
                        message = "No frequently visited or pinned bookmarks yet.\nAs you visit bookmarked sites, they appear here for 1-tap access.",
                        buttonText = "Browse Bookmarks",
                        onButtonClick = { selectedTabIndex = 0 }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(
                                text = "FREQUENTLY VISITED & PINNED URLS",
                                color = silent.accentSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        items(allTopBookmarks, key = { it.id }) { bookmark ->
                            BookmarkCard(
                                bookmark = bookmark,
                                onOpen = { viewModel.openBookmark(bookmark) },
                                onEdit = {
                                    bookmarkToEdit = bookmark
                                    showEditBookmarkDialog = true
                                },
                                onTogglePin = { viewModel.toggleBookmarkPin(bookmark) },
                                onDelete = { viewModel.deleteBookmark(bookmark) }
                            )
                        }
                    }
                }
            }
            2 -> {
                val filteredHistory = history.filter {
                    it.title.contains(searchQuery, ignoreCase = true) || it.url.contains(searchQuery, ignoreCase = true)
                }

                if (filteredHistory.isEmpty()) {
                    EmptyStateView(
                        paddingValues = paddingValues,
                        message = if (searchQuery.isNotBlank()) "No history matching '$searchQuery'" else "No browsing history recorded in this session",
                        buttonText = null,
                        onButtonClick = {}
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredHistory, key = { it.id }) { item ->
                            CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.openUrl(item.url) }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.title,
                                            color = silent.textPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = item.url,
                                            color = silent.textSecondary,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = dateFormat.format(Date(item.visitTime)),
                                            color = silent.textMuted,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Row {
                                        IconButton(
                                            onClick = {
                                                viewModel.saveBookmark(item.title, item.url, "Favorites")
                                                Toast.makeText(context, "Added to Bookmarks", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Default.Bookmark, contentDescription = "Bookmark", tint = silent.accentSuccess, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteHistoryItem(item) },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = silent.textMuted, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 1. ADD BOOKMARK DIALOG
    if (showAddBookmarkDialog) {
        AlertDialog(
            onDismissRequest = { showAddBookmarkDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text(
                    text = "SAVE TO BOOKMARK VAULT",
                    color = silent.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Bookmark Title", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = newUrl,
                        onValueChange = { newUrl = it },
                        label = { Text("Web URL (https://...)", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    Text("Select or Create Folder:", color = silent.textSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        existingFolders.forEach { folder ->
                            val isChosen = newFolder == folder
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isChosen) silent.chipSelectedBackground else silent.chipDefaultBackground)
                                    .border(1.dp, if (isChosen) silent.chipSelectedBorder else silent.cardBorder, RoundedCornerShape(6.dp))
                                    .clickable { newFolder = folder }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = folder,
                                    color = if (isChosen) silent.chipSelectedContent else silent.textPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newFolder,
                        onValueChange = { newFolder = it },
                        label = { Text("Custom Folder Name", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Pin to Top Quick Access", color = silent.textPrimary, fontSize = 12.sp)
                        Switch(
                            checked = newIsPinned,
                            onCheckedChange = { newIsPinned = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = silent.primaryButtonContent, checkedTrackColor = silent.accentSuccess)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newUrl.isNotBlank()) {
                            viewModel.saveBookmark(
                                title = newTitle.ifBlank { newUrl },
                                url = newUrl,
                                folder = newFolder.ifBlank { "Favorites" },
                                isPinned = newIsPinned
                            )
                            showAddBookmarkDialog = false
                            Toast.makeText(context, "Saved to $newFolder", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Save Bookmark", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBookmarkDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // 2. EDIT BOOKMARK DIALOG
    bookmarkToEdit?.let { bookmark ->
        if (showEditBookmarkDialog) {
            var editTitle by remember { mutableStateOf(bookmark.title) }
            var editUrl by remember { mutableStateOf(bookmark.url) }
            var editFolder by remember { mutableStateOf(bookmark.folder) }
            var editPinned by remember { mutableStateOf(bookmark.isPinned) }

            AlertDialog(
                onDismissRequest = { showEditBookmarkDialog = false },
                containerColor = silent.cardBackground,
                title = {
                    Text("EDIT BOOKMARK", color = silent.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = editTitle,
                            onValueChange = { editTitle = it },
                            label = { Text("Title", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editUrl,
                            onValueChange = { editUrl = it },
                            label = { Text("URL", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editFolder,
                            onValueChange = { editFolder = it },
                            label = { Text("Folder", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Pinned to Quick Access", color = silent.textPrimary, fontSize = 12.sp)
                            Switch(
                                checked = editPinned,
                                onCheckedChange = { editPinned = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = silent.primaryButtonContent, checkedTrackColor = silent.accentSuccess)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.updateBookmark(
                                bookmark.copy(
                                    title = editTitle,
                                    url = editUrl,
                                    folder = editFolder.ifBlank { "Favorites" },
                                    isPinned = editPinned
                                )
                            )
                            showEditBookmarkDialog = false
                            Toast.makeText(context, "Bookmark updated", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.primaryButtonBackground,
                            contentColor = silent.primaryButtonContent
                        )
                    ) {
                        Text("Update", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditBookmarkDialog = false }) {
                        Text("Cancel", color = silent.textSecondary)
                    }
                }
            )
        }
    }

    // 3. NEW FOLDER DIALOG
    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("CREATE NEW FOLDER", color = CyberPurple, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter a distinct name for your new bookmark collection:", color = silent.textSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = newFolderNameInput,
                        onValueChange = { newFolderNameInput = it },
                        placeholder = { Text("e.g. Research, Tech, Banking", color = silent.textMuted) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPurple,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = newFolderNameInput.trim()
                        if (name.isNotBlank()) {
                            selectedFolder = name
                            showNewFolderDialog = false
                            Toast.makeText(context, "Folder '$name' ready. Add bookmarks to it!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPurple, contentColor = Color.White)
                ) {
                    Text("Create Folder", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // 4. RENAME FOLDER DIALOG
    if (showRenameFolderDialog) {
        AlertDialog(
            onDismissRequest = { showRenameFolderDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("RENAME FOLDER", color = silent.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Rename folder '$folderToRename':", color = silent.textSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = renamedFolderInput,
                        onValueChange = { renamedFolderInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = renamedFolderInput.trim()
                        if (target.isNotBlank() && target != folderToRename) {
                            viewModel.renameBookmarkFolder(folderToRename, target)
                            if (selectedFolder == folderToRename) selectedFolder = target
                            showRenameFolderDialog = false
                            Toast.makeText(context, "Folder renamed to $target", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Rename", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameFolderDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // 5. DELETE FOLDER DIALOG
    if (showDeleteFolderDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteFolderDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("DELETE FOLDER '$folderToDelete'?", color = silent.accentError, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "This will remove the folder '$folderToDelete' and all bookmarks contained within it.",
                    color = silent.textSecondary,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteBookmarkFolder(folderToDelete)
                        selectedFolder = "All"
                        showDeleteFolderDialog = false
                        Toast.makeText(context, "Folder deleted", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.panicArmedBackground,
                        contentColor = silent.panicArmedContent
                    )
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteFolderDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // 6. EXPORT BACKUP DIALOG
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("EXPORT BOOKMARKS (JSON)", color = silent.accentWarning, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Copy your structured bookmark snapshot for offline backup:", color = silent.textSecondary, fontSize = 11.sp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(silent.screenBackground)
                            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = exportJsonContent,
                            color = silent.accentSuccess,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Bookmarks JSON", exportJsonContent))
                        showExportDialog = false
                        Toast.makeText(context, "Bookmarks JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy to Clipboard", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = silent.textSecondary)
                }
            }
        )
    }

    // 7. IMPORT BACKUP DIALOG
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("IMPORT BOOKMARKS (JSON)", color = silent.accentSuccess, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paste JSON array containing bookmark objects (with title, url, folder):", color = silent.textSecondary, fontSize = 11.sp)
                    OutlinedTextField(
                        value = importJsonInput,
                        onValueChange = { importJsonInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        placeholder = { Text("[{\"title\":\"Example\",\"url\":\"https://example.com\",\"folder\":\"Favorites\"}]", color = silent.textMuted, fontSize = 10.sp) },
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = silent.textPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importJsonInput.isNotBlank()) {
                            val count = viewModel.importBookmarksJson(importJsonInput)
                            showImportDialog = false
                            Toast.makeText(context, "Imported $count bookmarks into local vault", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Import Now", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun FolderChip(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val silent = MaterialTheme.silentColors
    Box(
        modifier = Modifier
            .heightIn(min = 38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) silent.chipSelectedBackground else silent.chipDefaultBackground)
            .border(
                width = 1.dp,
                color = if (isSelected) silent.chipSelectedBorder else silent.chipDefaultBorder,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isSelected) Icons.Default.FolderOpen else Icons.Default.Folder,
                contentDescription = null,
                tint = if (isSelected) silent.chipSelectedContent else silent.textMuted,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = if (isSelected) silent.chipSelectedContent else silent.chipDefaultContent,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun BookmarkCard(
    bookmark: Bookmark,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    var showMenu by remember { mutableStateOf(false) }

    CyberCard(
        borderColor = if (bookmark.isPinned) silent.badgeSuccessBorder else silent.cardBorder,
        backgroundColor = silent.cardBackground
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpen() }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (bookmark.isPinned) silent.badgeSuccessBackground else silent.chipDefaultBackground)
                    .border(1.dp, if (bookmark.isPinned) silent.accentSuccess else silent.cardBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val initial = bookmark.title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "B"
                Text(
                    text = initial,
                    color = if (bookmark.isPinned) silent.accentSuccess else silent.accentInfo,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(silent.chipDefaultBackground)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = bookmark.folder,
                            color = silent.accentInfo,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (bookmark.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        StatusBadge(text = "PINNED", color = silent.accentSuccess)
                    }

                    if (bookmark.visitCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${bookmark.visitCount} visits",
                            color = silent.accentWarning,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = bookmark.title,
                    color = silent.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = bookmark.url,
                    color = silent.textSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onTogglePin, modifier = Modifier.size(48.dp)) {
                    Icon(
                        imageVector = if (bookmark.isPinned) Icons.Default.Star else Icons.Default.PushPin,
                        contentDescription = "Pin to Quick Access",
                        tint = if (bookmark.isPinned) silent.accentSuccess else silent.textMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = silent.textMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(silent.cardBackground)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit Bookmark", color = silent.textPrimary, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp)) },
                            onClick = {
                                showMenu = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (bookmark.isPinned) "Unpin from Quick Access" else "Pin to Quick Access", color = silent.textPrimary, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp)) },
                            onClick = {
                                showMenu = false
                                onTogglePin()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Bookmark", color = silent.accentError, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = silent.accentError, modifier = Modifier.size(16.dp)) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStateView(
    paddingValues: PaddingValues,
    message: String,
    buttonText: String?,
    onButtonClick: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = silent.textMuted,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = message,
                color = silent.textSecondary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 18.sp
            )
            if (buttonText != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onButtonClick,
                    modifier = Modifier.heightIn(min = 48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(buttonText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
