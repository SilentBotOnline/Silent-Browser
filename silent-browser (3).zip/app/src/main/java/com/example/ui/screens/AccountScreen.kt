package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun AccountScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsState()
    val cloudEndpoint by viewModel.cloudEndpoint.collectAsState()

    var emailInput by remember { mutableStateOf(userEmail) }
    var passwordInput by remember { mutableStateOf("") }
    var isRegisterMode by remember { mutableStateOf(false) }

    val silent = MaterialTheme.silentColors

    fun authenticateAndPerform(actionName: String, onAuthenticated: () -> Unit) {
        val fragmentActivity = context as? FragmentActivity
        if (fragmentActivity == null) {
            onAuthenticated()
            return
        }

        val biometricManager = BiometricManager.from(context)
        val canAuthenticate = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
            onAuthenticated()
            return
        }

        val executor = ContextCompat.getMainExecutor(context)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Silent Browser Biometric Security")
            .setSubtitle("Confirm identity to authorize $actionName")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()

        val prompt = BiometricPrompt(
            fragmentActivity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Toast.makeText(context, "Identity verified successfully.", Toast.LENGTH_SHORT).show()
                    onAuthenticated()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    Toast.makeText(context, "Authentication cancelled: $errString", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(context, "Biometric unrecognized. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }
        )

        prompt.authenticate(promptInfo)
    }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = silent.screenBackground,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = silent.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "ACCOUNT & CROSS-DEVICE SYNC",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Cloud Sync, Secure Vault & Biometric Auth",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Account Card
            item {
                CyberCard(
                    borderColor = if (isLoggedIn) silent.accentSuccess else silent.cardBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (isLoggedIn) silent.accentSuccess else silent.textPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isLoggedIn) "Authenticated Account" else "Sign In or Register",
                                        color = silent.textPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isLoggedIn) userEmail else "Sync bookmarks & settings across mobile & desktop",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            StatusBadge(
                                text = if (isLoggedIn) "ACTIVE" else "OFFLINE",
                                color = if (isLoggedIn) silent.accentSuccess else silent.accentWarning
                            )
                        }

                        HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

                        if (!isLoggedIn) {
                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text("Email Address", color = silent.textMuted) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("account_email_input"),
                                textStyle = TextStyle(color = silent.textPrimary, fontFamily = FontFamily.Monospace),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = silent.chipSelectedBorder,
                                    unfocusedBorderColor = silent.cardBorder,
                                    focusedContainerColor = silent.cardBackground,
                                    unfocusedContainerColor = silent.cardBackground,
                                    focusedTextColor = silent.textPrimary,
                                    unfocusedTextColor = silent.textPrimary
                                )
                            )

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Password (min 6 chars)", color = silent.textMuted) },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth().testTag("account_password_input"),
                                textStyle = TextStyle(color = silent.textPrimary, fontFamily = FontFamily.Monospace),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = silent.chipSelectedBorder,
                                    unfocusedBorderColor = silent.cardBorder,
                                    focusedContainerColor = silent.cardBackground,
                                    unfocusedContainerColor = silent.cardBackground,
                                    focusedTextColor = silent.textPrimary,
                                    unfocusedTextColor = silent.textPrimary
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (emailInput.isNotBlank() && passwordInput.isNotBlank()) {
                                            authenticateAndPerform("Account Authentication") {
                                                if (isRegisterMode) {
                                                    viewModel.registerUser(emailInput, passwordInput, cloudEndpoint)
                                                } else {
                                                    viewModel.loginUser(emailInput, passwordInput, cloudEndpoint)
                                                }
                                            }
                                        } else {
                                            Toast.makeText(context, "Please enter email and password", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(48.dp).testTag("account_auth_submit_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = silent.primaryButtonBackground,
                                        contentColor = silent.primaryButtonContent
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isRegisterMode) "Register Account" else "Sign In",
                                        color = silent.primaryButtonContent,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }

                                OutlinedButton(
                                    onClick = { isRegisterMode = !isRegisterMode },
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = silent.secondaryButtonBackground,
                                        contentColor = silent.secondaryButtonContent
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = if (isRegisterMode) "Switch to Sign In" else "Create Account",
                                        color = silent.secondaryButtonContent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        authenticateAndPerform("Cloud Sync (Push & Pull)") {
                                            viewModel.syncAllData()
                                        }
                                    },
                                    enabled = !isSyncing,
                                    modifier = Modifier.weight(1f).height(48.dp).testTag("account_sync_now_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = silent.primaryButtonBackground,
                                        contentColor = silent.primaryButtonContent
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (isSyncing) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = silent.primaryButtonContent, strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.CloudSync, contentDescription = null, tint = silent.primaryButtonContent, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Sync Now (Biometric)", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                OutlinedButton(
                                    onClick = { viewModel.logoutUser() },
                                    modifier = Modifier.height(48.dp),
                                    border = BorderStroke(1.dp, silent.panicArmedBackground),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Sign Out", color = silent.panicArmedBackground, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        if (syncStatusMessage != null) {
                            Text(
                                text = syncStatusMessage ?: "",
                                color = silent.accentSuccess,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(silent.badgeSuccessBackground)
                                    .border(1.dp, silent.badgeSuccessBorder, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }

            // Biometric Vault & Security Status Card
            item {
                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Fingerprint, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Biometric Vault Security", color = silent.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "BiometricPrompt API integration enforces hardware fingerprint or face unlock before executing cross-device sync or accessing saved passwords.",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )

                        Button(
                            onClick = {
                                authenticateAndPerform("Vault Security Check") {
                                    Toast.makeText(context, "Biometric Vault Verified & Secure!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = silent.secondaryButtonBackground,
                                contentColor = silent.secondaryButtonContent
                            ),
                            border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.VpnKey, contentDescription = null, tint = silent.secondaryButtonContent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test Biometric Authentication", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
