package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.network.DevOpsService
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberMint
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun DevOpsScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val silent = MaterialTheme.silentColors
    val serverHealth by viewModel.serverHealth.collectAsState()
    val isPinging by viewModel.isPinging.collectAsState()
    val terminalLogs by viewModel.terminalLogs.collectAsState()

    var inputCmd by remember { mutableStateOf("") }
    val terminalListState = rememberLazyListState()

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    LaunchedEffect(terminalLogs.size) {
        if (terminalLogs.isNotEmpty()) {
            terminalListState.animateScrollToItem(terminalLogs.size - 1)
        }
    }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = silent.accentSuccess
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "NETWORK & SYNC DIAGNOSTICS",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Gateway Health, Privacy Telemetry & Self-Host Scripts",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Gateway Connectivity Card
            item {
                CyberCard(
                    borderColor = silent.accentSuccess.copy(alpha = 0.5f),
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SYNC CONNECTIVITY HEALTH",
                                color = silent.accentInfo,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            StatusBadge(
                                text = if (serverHealth?.isOnline == true) "ONLINE [200]" else "READY",
                                color = if (serverHealth?.isOnline == true) silent.accentSuccess else silent.accentWarning
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (serverHealth != null) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Latency: ${serverHealth!!.latencyMs} ms",
                                        color = silent.accentSuccess,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = serverHealth!!.message,
                                        color = silent.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            } else {
                                Text(
                                    text = "Ready to check gateway latency",
                                    color = silent.textMuted,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Button(
                                onClick = { viewModel.pingHostinger() },
                                enabled = !isPinging,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.heightIn(min = 48.dp).testTag("ping_server_button")
                            ) {
                                if (isPinging) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = silent.primaryButtonContent,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        tint = silent.primaryButtonContent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Check Health", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Sync Protocol Mapping (Zero Server URLs or Usernames Exposed)
            item {
                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "PRIVACY & SYNC PROTOCOL STATUS",
                            color = silent.accentInfo,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Sync Protocol:", color = silent.textSecondary, fontSize = 11.sp)
                            Text("HTTPS + Timestamp Conflict Guard", color = silent.accentSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Search Descriptor:", color = silent.textSecondary, fontSize = 11.sp)
                            Text("DNT: 1 + Sec-GPC: 1 Enforced", color = silent.accentInfo, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Credentials Storage:", color = silent.textSecondary, fontSize = 11.sp)
                            Text("On-Device Keystore AES-256-GCM", color = silent.accentWarning, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Diagnostics Console
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LOCAL DIAGNOSTICS CONSOLE",
                            color = silent.accentInfo,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "sandbox shell",
                            color = silent.textMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("status", "tor-check", "audit", "deploy", "backup", "clear").forEach { cmd ->
                            Box(
                                modifier = Modifier
                                    .heightIn(min = 40.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(silent.chipDefaultBackground)
                                    .border(1.dp, silent.chipDefaultBorder, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.executeTerminalCommand(cmd) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cmd,
                                    color = silent.accentInfo,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Explicit high-contrast console box so monospace colors stay crisp in Light & Dark themes
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0A111A))
                            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        LazyColumn(
                            state = terminalListState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(terminalLogs) { log ->
                                val textColor = when (log.type) {
                                    "SUCCESS" -> CyberMint
                                    "WARN" -> CyberOrange
                                    "ERROR" -> CyberRed
                                    "INPUT" -> Color(0xFF38BDF8)
                                    else -> Color(0xFFE2E8F0)
                                }
                                Text(
                                    text = log.line,
                                    color = textColor,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(silent.cardBackground)
                            .border(1.dp, silent.chipSelectedBorder, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(">_", color = silent.accentSuccess, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(8.dp))
                        BasicTextField(
                            value = inputCmd,
                            onValueChange = { inputCmd = it },
                            modifier = Modifier.weight(1f).testTag("terminal_input"),
                            singleLine = true,
                            textStyle = TextStyle(color = silent.textPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
                            cursorBrush = SolidColor(silent.accentSuccess),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (inputCmd.isNotBlank()) {
                                        viewModel.executeTerminalCommand(inputCmd)
                                        inputCmd = ""
                                    }
                                }
                            ),
                            decorationBox = { inner ->
                                if (inputCmd.isEmpty()) {
                                    Text("Enter command (status, ping, tor-check, audit)...", color = silent.textMuted, fontSize = 11.sp)
                                }
                                inner()
                            }
                        )
                        IconButton(
                            onClick = {
                                if (inputCmd.isNotBlank()) {
                                    viewModel.executeTerminalCommand(inputCmd)
                                    inputCmd = ""
                                }
                            },
                            modifier = Modifier.size(48.dp).testTag("terminal_send_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = silent.accentSuccess)
                        }
                    }
                }
            }

            // Self-Hosting Bundle Export (Sanitized Public Templates)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "SELF-HOST TEMPLATES (1-TAP EXPORT)",
                        color = silent.accentInfo,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Button(
                        onClick = {
                            val phpCode = DevOpsService.generatePhpApiScript()
                            copyToClipboard("Sync API Template (api.php)", phpCode)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("copy_php_api_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = silent.secondaryButtonContent
                        ),
                        border = BorderStroke(1.dp, silent.accentSuccess),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy Sync API Template (api.php)", color = silent.secondaryButtonContent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val sqlCode = DevOpsService.generateSqlScript()
                            copyToClipboard("SQL Schema (db.sql)", sqlCode)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("copy_sql_schema_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = silent.secondaryButtonContent
                        ),
                        border = BorderStroke(1.dp, CyberBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = CyberBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy SQL Schema Template (db.sql)", color = silent.secondaryButtonContent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val searchPhp = DevOpsService.generateSearchEnginePhpScript()
                            copyToClipboard("Search Gateway Template (search.php)", searchPhp)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("copy_search_php_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = silent.secondaryButtonContent
                        ),
                        border = BorderStroke(1.dp, silent.accentInfo),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy Search Proxy Template (search.php)", color = silent.secondaryButtonContent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val openSearch = DevOpsService.generateOpenSearchXml()
                            copyToClipboard("OpenSearch Descriptor (opensearch.xml)", openSearch)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("copy_opensearch_xml_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = silent.secondaryButtonContent
                        ),
                        border = BorderStroke(1.dp, silent.accentWarning),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = silent.accentWarning, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy OpenSearch Descriptor (opensearch.xml)", color = silent.secondaryButtonContent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
