package com.example.ui.viewmodel

import android.app.Application
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebStorage
import android.webkit.WebView
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONObject
import org.json.JSONArray
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BrowserPreferencesDataStore
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.BuildConfig
import com.example.data.model.AccountAuthUiState
import com.example.data.model.AppUpdateManager
import com.example.data.model.AppUpdateStatus
import com.example.data.model.AppUpdateUiState
import com.example.data.model.AuthSheetMode
import com.example.data.model.Bookmark
import com.example.data.model.UpdateChannel
import com.example.data.model.BrowserTab
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.EngineMode
import com.example.data.model.HistoryItem
import com.example.data.model.PasswordEntry
import com.example.data.model.SearchEngine
import com.example.data.model.SyncConflictItem
import com.example.data.model.SyncConflictResolution
import com.example.data.model.SyncConflictResolver
import com.example.data.network.DevOpsService
import com.example.data.network.SearchSuggestion
import com.example.data.network.SearchSuggestionService
import com.example.data.security.CryptoVault
import com.example.data.security.QrSyncManager
import com.example.data.security.QrSyncPrivacySettings
import com.example.data.security.QrSyncSession
import com.example.data.model.BrowserExtension
import com.example.data.extension.ExtensionManager
import com.example.data.network.ServerHealth
import com.example.data.network.SuggestionType
import com.example.data.privacy.BlockedRequestRecord
import com.example.data.privacy.LiveProbeResponse
import com.example.data.privacy.PrivacyAuditItem
import com.example.data.privacy.PrivacyAuditReport
import com.example.data.privacy.PrivacyEngine
import com.example.data.privacy.RequestBlockCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

import com.example.data.network.DiscoveryCategory
import com.example.data.network.DiscoveryFeedItem
import com.example.data.network.DiscoveryFeedService
import com.example.data.network.NetworkRequestInterceptor
import com.example.ui.theme.AppThemePreset
import kotlinx.coroutines.CancellationException

enum class ScreenDestination {
    BROWSER,
    DASHBOARD,
    PRIVACY_DASHBOARD,
    TABS_OVERVIEW,
    DEVOPS_CENTER,
    BOOKMARKS_HISTORY,
    PASSWORD_VAULT,
    DOWNLOADS,
    SETTINGS,
    EXTENSIONS,
    LEGAL,
    ABOUT,
    ACCOUNT
}

data class TerminalLog(
    val line: String,
    val type: String = "INFO" // "INFO", "SUCCESS", "WARN", "ERROR", "INPUT"
)

data class ShieldedRelayNode(
    val location: String,
    val virtualIp: String,
    val latencyMs: Int,
    val flag: String,
    val protocol: String = "Tor / WireGuard Stealth"
)

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val bookmarkDao = db.bookmarkDao()
    private val historyDao = db.historyDao()
    private val passwordDao = db.passwordDao()

    val bookmarks: StateFlow<List<Bookmark>> = bookmarkDao.getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val bookmarkFolders: StateFlow<List<String>> = bookmarkDao.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.Lazily, listOf("Favorites", "Privacy & Tor", "Research", "Work"))

    val frequentlyVisited: StateFlow<List<Bookmark>> = bookmarkDao.getFrequentlyVisited(8)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val pinnedBookmarks: StateFlow<List<Bookmark>> = bookmarkDao.getPinnedBookmarks()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val passwords: StateFlow<List<PasswordEntry>> = passwordDao.getAllPasswords()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val history: StateFlow<List<HistoryItem>> = historyDao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Autofill & Password State
    private val _autofillEnabled = MutableStateFlow(true)
    val autofillEnabled: StateFlow<Boolean> = _autofillEnabled.asStateFlow()

    private val _currentAutofillCandidate = MutableStateFlow<PasswordEntry?>(null)
    val currentAutofillCandidate: StateFlow<PasswordEntry?> = _currentAutofillCandidate.asStateFlow()

    private val _showAutofillPrompt = MutableStateFlow(false)
    val showAutofillPrompt: StateFlow<Boolean> = _showAutofillPrompt.asStateFlow()

    private val prefs = application.getSharedPreferences("silent_browser_prefs", Context.MODE_PRIVATE)

    private val _isSetupConfigured = MutableStateFlow(prefs.getBoolean("is_setup_configured", true))
    val isSetupConfigured: StateFlow<Boolean> = _isSetupConfigured.asStateFlow()

    private val _showSetupWizardModal = MutableStateFlow(false)
    val showSetupWizardModal: StateFlow<Boolean> = _showSetupWizardModal.asStateFlow()

    private val _showCommandHubModal = MutableStateFlow(false)
    val showCommandHubModal: StateFlow<Boolean> = _showCommandHubModal.asStateFlow()

    private val _isCommandHubVisible = MutableStateFlow(prefs.getBoolean("inline_command_hub_visible", true))
    val isCommandHubVisible: StateFlow<Boolean> = _isCommandHubVisible.asStateFlow()

    private val _selectedThemePreset = MutableStateFlow(
        BrowserPreferencesDataStore.resolveThemePreset(
            prefs.getString("theme_preset", AppThemePreset.WHITE.id)
        )
    )
    val selectedThemePreset: StateFlow<AppThemePreset> = _selectedThemePreset.asStateFlow()
    private var pendingThemePersistCount = 0
    private var pendingPanicPersistCount = 0

    private val _tabs = MutableStateFlow<List<BrowserTab>>(
        listOf(
            BrowserTab(
                title = "Silent Home",
                url = "about:blank",
                engineMode = EngineMode.MULTI_ENGINE
            )
        )
    )
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(_tabs.value.first().id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _currentScreen = MutableStateFlow(ScreenDestination.DASHBOARD)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _isBrowsing = MutableStateFlow(false)
    val isBrowsing: StateFlow<Boolean> = _isBrowsing.asStateFlow()

    private val _proximityPanicEnabled = MutableStateFlow(prefs.getBoolean("proximity_panic_enabled", false))
    val proximityPanicEnabled: StateFlow<Boolean> = _proximityPanicEnabled.asStateFlow()

    private val _totalBlockedTrackers = MutableStateFlow(prefs.getInt("blocked_trackers_total", 0))
    val totalBlockedTrackers: StateFlow<Int> = _totalBlockedTrackers.asStateFlow()

    private val _blockedAdsCount = MutableStateFlow(prefs.getInt("blocked_ads_count", 0))
    val blockedAdsCount: StateFlow<Int> = _blockedAdsCount.asStateFlow()

    private val _blockedTrackersOnlyCount = MutableStateFlow(prefs.getInt("blocked_trackers_only_count", 0))
    val blockedTrackersOnlyCount: StateFlow<Int> = _blockedTrackersOnlyCount.asStateFlow()

    private val _blockedScamsBotsCount = MutableStateFlow(prefs.getInt("blocked_scams_bots_count", 0))
    val blockedScamsBotsCount: StateFlow<Int> = _blockedScamsBotsCount.asStateFlow()

    val dntHeadersSentCount: StateFlow<Int> = NetworkRequestInterceptor.interceptedDntCount

    private val _customBlockedDomains = MutableStateFlow<Set<String>>(
        (prefs.getStringSet("custom_blocked_domains", emptySet()) ?: emptySet()).toSet()
    )
    val customBlockedDomains: StateFlow<Set<String>> = _customBlockedDomains.asStateFlow()

    private val _customAllowedDomains = MutableStateFlow<Set<String>>(
        (prefs.getStringSet("custom_allowed_domains", emptySet()) ?: emptySet()).toSet()
    )
    val customAllowedDomains: StateFlow<Set<String>> = _customAllowedDomains.asStateFlow()

    private val _blockedRequestLog = MutableStateFlow<List<BlockedRequestRecord>>(emptyList())
    val blockedRequestLog: StateFlow<List<BlockedRequestRecord>> = _blockedRequestLog.asStateFlow()

    private val _liveProbeResult = MutableStateFlow<LiveProbeResponse?>(null)
    val liveProbeResult: StateFlow<LiveProbeResponse?> = _liveProbeResult.asStateFlow()

    private val _isProbingPrivacy = MutableStateFlow(false)
    val isProbingPrivacy: StateFlow<Boolean> = _isProbingPrivacy.asStateFlow()

    private val _privacyAuditReport = MutableStateFlow<PrivacyAuditReport?>(null)
    val privacyAuditReport: StateFlow<PrivacyAuditReport?> = _privacyAuditReport.asStateFlow()

    private val _engineMode = MutableStateFlow(
        EngineMode.values().find { it.name == prefs.getString("engine_mode", EngineMode.MULTI_ENGINE.name) }
            ?: EngineMode.MULTI_ENGINE
    )
    val engineMode: StateFlow<EngineMode> = _engineMode.asStateFlow()

    private val _selectedUserAgent = MutableStateFlow(prefs.getString("user_agent", "Tor Browser (Spoofed)") ?: "Tor Browser (Spoofed)")
    val selectedUserAgent: StateFlow<String> = _selectedUserAgent.asStateFlow()

    private val _activeSearchEngine = MutableStateFlow(
        SearchEngine.values().find { it.id == prefs.getString("search_engine_id", SearchEngine.SILENT_STEALTH.id) }
            ?: SearchEngine.SILENT_STEALTH
    )
    val activeSearchEngine: StateFlow<SearchEngine> = _activeSearchEngine.asStateFlow()

    private val _searchEngine = MutableStateFlow(_activeSearchEngine.value.displayName)
    val searchEngine: StateFlow<String> = _searchEngine.asStateFlow()

    // Real-Time Search Suggestions
    private val _suggestionsEnabled = MutableStateFlow(prefs.getBoolean("suggestions_enabled", true))
    val suggestionsEnabled: StateFlow<Boolean> = _suggestionsEnabled.asStateFlow()

    private val _cleanStealthMode = MutableStateFlow(prefs.getBoolean("clean_stealth_mode", true))
    val cleanStealthMode: StateFlow<Boolean> = _cleanStealthMode.asStateFlow()

    private val _searchSuggestions = MutableStateFlow<List<SearchSuggestion>>(emptyList())
    val searchSuggestions: StateFlow<List<SearchSuggestion>> = _searchSuggestions.asStateFlow()

    private val _isFetchingSuggestions = MutableStateFlow(false)
    val isFetchingSuggestions: StateFlow<Boolean> = _isFetchingSuggestions.asStateFlow()

    private var suggestionJob: Job? = null

    // Shields & Privacy Toggles
    private val _adblockEnabled = MutableStateFlow(prefs.getBoolean("adblock_enabled", true))
    val adblockEnabled: StateFlow<Boolean> = _adblockEnabled.asStateFlow()

    private val _fingerprintShieldEnabled = MutableStateFlow(prefs.getBoolean("fingerprint_shield", true))
    val fingerprintShieldEnabled: StateFlow<Boolean> = _fingerprintShieldEnabled.asStateFlow()

    private val _httpsEverywhereEnabled = MutableStateFlow(prefs.getBoolean("https_everywhere", true))
    val httpsEverywhereEnabled: StateFlow<Boolean> = _httpsEverywhereEnabled.asStateFlow()

    private val _javascriptEnabled = MutableStateFlow(prefs.getBoolean("javascript_enabled", true))
    val javascriptEnabled: StateFlow<Boolean> = _javascriptEnabled.asStateFlow()

    private val _thirdPartyCookiesBlocked = MutableStateFlow(prefs.getBoolean("block_third_party_cookies", true))
    val thirdPartyCookiesBlocked: StateFlow<Boolean> = _thirdPartyCookiesBlocked.asStateFlow()

    private val _doNotTrackEnabled = MutableStateFlow(prefs.getBoolean("do_not_track", true))
    val doNotTrackEnabled: StateFlow<Boolean> = _doNotTrackEnabled.asStateFlow()

    private val _antiScamProtectionEnabled = MutableStateFlow(prefs.getBoolean("anti_scam_bot_shield", true))
    val antiScamProtectionEnabled: StateFlow<Boolean> = _antiScamProtectionEnabled.asStateFlow()

    // Private Browsing (Incognito) Settings
    private val _alwaysIncognito = MutableStateFlow(prefs.getBoolean("always_incognito", false))
    val alwaysIncognito: StateFlow<Boolean> = _alwaysIncognito.asStateFlow()

    private val _autoPurgeOnTabClosure = MutableStateFlow(prefs.getBoolean("auto_purge_tab_closure", true))
    val autoPurgeOnTabClosure: StateFlow<Boolean> = _autoPurgeOnTabClosure.asStateFlow()

    // Virtual Shielded IP Routing
    val relayNodes = listOf(
        ShieldedRelayNode("Zurich, Switzerland", "185.220.101.42", 18, "🇨🇭", "Tor Onion Circuit"),
        ShieldedRelayNode("Amsterdam, Netherlands", "195.35.39.21", 24, "🇳🇱", "Netherlands Privacy Relay"),
        ShieldedRelayNode("Stockholm, Sweden", "193.138.218.72", 31, "🇸🇪", "Mullvad Privacy Relay"),
        ShieldedRelayNode("Frankfurt, Germany", "149.202.180.9", 22, "🇩🇪", "Silent Safe Relay"),
        ShieldedRelayNode("Singapore", "103.253.41.88", 55, "🇸🇬", "Asia Stealth Node")
    )

    private val _shieldedIpEnabled = MutableStateFlow(prefs.getBoolean("shielded_ip_enabled", true))
    val shieldedIpEnabled: StateFlow<Boolean> = _shieldedIpEnabled.asStateFlow()

    private val _activeRelayNode = MutableStateFlow(
        relayNodes.getOrElse(prefs.getInt("relay_node_index", 0).coerceIn(0, relayNodes.lastIndex)) { relayNodes[0] }
    )
    val activeRelayNode: StateFlow<ShieldedRelayNode> = _activeRelayNode.asStateFlow()

    // Extensions State
    val extensions: StateFlow<List<BrowserExtension>> = ExtensionManager.extensions

    // DevOps State
    private val _hostingerEndpoint = MutableStateFlow(DevOpsService.DEFAULT_HOSTINGER_DOMAIN)
    val hostingerEndpoint: StateFlow<String> = _hostingerEndpoint.asStateFlow()

    private val _serverHealth = MutableStateFlow<ServerHealth?>(null)
    val serverHealth: StateFlow<ServerHealth?> = _serverHealth.asStateFlow()

    private val _isPinging = MutableStateFlow(false)
    val isPinging: StateFlow<Boolean> = _isPinging.asStateFlow()

    // Downloads State
    private val defaultDownloadDir = File(
        application.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: application.filesDir,
        "SilentDownloads"
    ).apply { mkdirs() }.absolutePath

    private val _downloadLocation = MutableStateFlow(prefs.getString("download_location", defaultDownloadDir) ?: defaultDownloadDir)
    val downloadLocation: StateFlow<String> = _downloadLocation.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    private val downloadJobs = mutableMapOf<String, Job>()

    private val _terminalLogs = MutableStateFlow<List<TerminalLog>>(
        listOf(
            TerminalLog("==================================================", "INFO"),
            TerminalLog("SILENT BROWSER DIAGNOSTIC KERNEL v1.0", "SUCCESS"),
            TerminalLog("Published by: Silent Bot LLC | Privacy Browser Engine", "INFO"),
            TerminalLog("Encrypted Sync Engine Ready (Local-First)", "INFO"),
            TerminalLog("Type 'help' or click preset action switches below", "WARN"),
            TerminalLog("==================================================", "INFO")
        )
    )
    val terminalLogs: StateFlow<List<TerminalLog>> = _terminalLogs.asStateFlow()

    // Discovery Feed State (Latest News & Trending GitHub / Web)
    private val _discoveryFeedItems = MutableStateFlow(
        DiscoveryFeedService.fallbackDirectoryResult(notice = null).items
    )
    val discoveryFeedItems: StateFlow<List<DiscoveryFeedItem>> = _discoveryFeedItems.asStateFlow()

    private val _selectedFeedCategory = MutableStateFlow(DiscoveryCategory.ALL)
    val selectedFeedCategory: StateFlow<DiscoveryCategory> = _selectedFeedCategory.asStateFlow()

    private val _isLoadingFeed = MutableStateFlow(false)
    val isLoadingFeed: StateFlow<Boolean> = _isLoadingFeed.asStateFlow()

    private val _feedError = MutableStateFlow<String?>(null)
    val feedError: StateFlow<String?> = _feedError.asStateFlow()

    // Ephemeral Encrypted QR Sync State (Mobile -> Desktop)
    private val _qrSyncSession = MutableStateFlow<QrSyncSession?>(null)
    val qrSyncSession: StateFlow<QrSyncSession?> = _qrSyncSession.asStateFlow()

    private val _isGeneratingQrSync = MutableStateFlow(false)
    val isGeneratingQrSync: StateFlow<Boolean> = _isGeneratingQrSync.asStateFlow()

    private val _qrSyncIncludeBookmarks = MutableStateFlow(true)
    val qrSyncIncludeBookmarks: StateFlow<Boolean> = _qrSyncIncludeBookmarks.asStateFlow()

    private val _qrSyncIncludeSettings = MutableStateFlow(true)
    val qrSyncIncludeSettings: StateFlow<Boolean> = _qrSyncIncludeSettings.asStateFlow()

    private val _qrSyncError = MutableStateFlow<String?>(null)
    val qrSyncError: StateFlow<String?> = _qrSyncError.asStateFlow()

    // Application Update & Roadmap State
    private val initialUpdateChannel = UpdateChannel.entries.find {
        it.id == (prefs.getString("update_channel", UpdateChannel.STABLE.id) ?: UpdateChannel.STABLE.id)
    } ?: UpdateChannel.STABLE

    private val _appUpdateState = MutableStateFlow(
        AppUpdateUiState(
            currentVersionName = BuildConfig.VERSION_NAME,
            currentVersionCode = BuildConfig.VERSION_CODE,
            latestVersionName = BuildConfig.VERSION_NAME,
            latestVersionCode = BuildConfig.VERSION_CODE,
            status = if (initialUpdateChannel == UpdateChannel.BETA) {
                AppUpdateStatus.FUTURE_PREVIEW
            } else {
                AppUpdateStatus.UP_TO_DATE
            },
            selectedChannel = initialUpdateChannel,
            autoCheckEnabled = prefs.getBoolean("auto_check_updates", true),
            notifyFutureReleases = prefs.getBoolean("notify_future_releases", true),
            lastCheckedEpochMs = prefs.getLong("last_update_check_ms", 0L)
        )
    )
    val appUpdateState: StateFlow<AppUpdateUiState> = _appUpdateState.asStateFlow()

    val activeTab: BrowserTab?
        get() = _tabs.value.find { it.id == _activeTabId.value } ?: _tabs.value.firstOrNull()

    init {
        NetworkRequestInterceptor.isDntEnabled = _doNotTrackEnabled.value
        PrivacyEngine.customBlockedDomains = _customBlockedDomains.value
        PrivacyEngine.customAllowedDomains = _customAllowedDomains.value
        _blockedRequestLog.value = loadPersistedBlockedLog()
        _autofillEnabled.value = prefs.getBoolean("autofill_enabled", true)
        viewModelScope.launch {
            val appContext = getApplication<Application>()
            BrowserPreferencesDataStore.seedFromLegacyPrefsIfNeeded(appContext, prefs)
            BrowserPreferencesDataStore.observeSettings(
                context = appContext,
                defaultTheme = _selectedThemePreset.value,
                defaultProximityPanic = _proximityPanicEnabled.value
            ).collect { stored ->
                if (pendingThemePersistCount == 0 && _selectedThemePreset.value != stored.themePreset) {
                    _selectedThemePreset.value = stored.themePreset
                    prefs.edit().putString("theme_preset", stored.themePreset.id).apply()
                }
                if (pendingPanicPersistCount == 0 && _proximityPanicEnabled.value != stored.proximityPanicEnabled) {
                    _proximityPanicEnabled.value = stored.proximityPanicEnabled
                    prefs.edit().putBoolean("proximity_panic_enabled", stored.proximityPanicEnabled).apply()
                }
            }
        }
        runProductionPrivacyAudit(logToTerminal = false)
        simulateActiveDownloads()
        loadDiscoveryFeed()
        if (_appUpdateState.value.autoCheckEnabled) {
            checkForAppUpdates(manual = false)
        }
    }

    private fun simulateActiveDownloads() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                _downloads.value = _downloads.value.map { item ->
                    if (item.status == DownloadStatus.DOWNLOADING && item.downloadedBytes < item.totalBytes) {
                        val increment = (1_200_000L..2_100_000L).random()
                        val newDownloaded = (item.downloadedBytes + increment).coerceAtMost(item.totalBytes)
                        val newStatus = if (newDownloaded >= item.totalBytes) DownloadStatus.COMPLETED else DownloadStatus.DOWNLOADING
                        item.copy(
                            downloadedBytes = newDownloaded,
                            status = newStatus,
                            speedKbps = if (newStatus == DownloadStatus.COMPLETED) 0.0 else (increment / 1024.0)
                        )
                    } else item
                }
            }
        }
    }

    fun setDownloadLocation(path: String) {
        val f = File(path)
        if (!f.exists()) f.mkdirs()
        _downloadLocation.value = path
        prefs.edit().putString("download_location", path).apply()
        appendTerminal("Download location updated to: $path", "INFO")
    }

    fun enqueueDownload(
        url: String,
        contentDisposition: String? = null,
        mimeType: String? = null,
        contentLength: Long = 0L
    ) {
        val suggestedName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            .ifBlank { "download_${System.currentTimeMillis()}" }
        val size = if (contentLength > 0) contentLength else (8_000_000L..45_000_000L).random()

        val newItem = DownloadItem(
            fileName = suggestedName,
            url = url,
            downloadPath = _downloadLocation.value,
            totalBytes = size,
            downloadedBytes = 0L,
            status = DownloadStatus.DOWNLOADING,
            speedKbps = 1500.0
        )
        _downloads.value = listOf(newItem) + _downloads.value
        appendTerminal("New download started: $suggestedName ($size bytes)", "SUCCESS")
        _currentScreen.value = ScreenDestination.DOWNLOADS
    }

    fun pauseDownload(id: String) {
        _downloads.value = _downloads.value.map {
            if (it.id == id) it.copy(status = DownloadStatus.PAUSED, speedKbps = 0.0) else it
        }
        appendTerminal("Download paused: $id", "WARN")
    }

    fun resumeDownload(id: String) {
        _downloads.value = _downloads.value.map {
            if (it.id == id) it.copy(status = DownloadStatus.DOWNLOADING, speedKbps = 1200.0) else it
        }
        appendTerminal("Download resumed: $id", "SUCCESS")
    }

    fun cancelDownload(id: String) {
        _downloads.value = _downloads.value.map {
            if (it.id == id) it.copy(status = DownloadStatus.CANCELLED, speedKbps = 0.0) else it
        }
        appendTerminal("Download cancelled: $id", "WARN")
    }

    fun deleteDownload(id: String) {
        _downloads.value = _downloads.value.filter { it.id != id }
    }

    fun saveBookmark(
        title: String,
        url: String,
        folder: String = "Favorites",
        category: String = "General",
        isPinned: Boolean = false
    ) {
        viewModelScope.launch {
            bookmarkDao.insertBookmark(
                Bookmark(
                    title = title.ifBlank { url },
                    url = url,
                    folder = folder.ifBlank { "Favorites" },
                    category = category,
                    isPinned = isPinned,
                    createdAt = System.currentTimeMillis()
                )
            )
            appendTerminal("Bookmark saved to folder '$folder': $title", "SUCCESS")
        }
    }

    fun openBookmark(bookmark: Bookmark) {
        viewModelScope.launch {
            bookmarkDao.incrementVisitCount(bookmark.id)
        }
        openUrl(bookmark.url)
    }

    fun updateBookmark(bookmark: Bookmark) {
        viewModelScope.launch {
            bookmarkDao.updateBookmark(bookmark)
            appendTerminal("Bookmark updated: ${bookmark.title}", "SUCCESS")
        }
    }

    fun toggleBookmarkPin(bookmark: Bookmark) {
        viewModelScope.launch {
            val newPin = !bookmark.isPinned
            bookmarkDao.setPinned(bookmark.id, newPin)
            appendTerminal("Bookmark '${bookmark.title}' ${if (newPin) "pinned to Quick Access" else "unpinned"}.", "INFO")
        }
    }

    fun renameBookmarkFolder(oldFolder: String, newFolder: String) {
        viewModelScope.launch {
            bookmarkDao.renameFolder(oldFolder, newFolder)
            appendTerminal("Folder '$oldFolder' renamed to '$newFolder'", "SUCCESS")
        }
    }

    fun deleteBookmarkFolder(folder: String) {
        viewModelScope.launch {
            bookmarkDao.deleteFolder(folder)
            appendTerminal("Folder '$folder' and its bookmarks deleted.", "WARN")
        }
    }

    fun exportBookmarksJson(): String {
        val list = bookmarks.value
        val sb = StringBuilder("[\n")
        list.forEachIndexed { i, b ->
            val safeTitle = b.title.replace("\"", "\\\"").replace("\n", " ")
            val safeUrl = b.url.replace("\"", "\\\"").replace("\n", " ")
            val safeFolder = b.folder.replace("\"", "\\\"").replace("\n", " ")
            val safeCat = b.category.replace("\"", "\\\"").replace("\n", " ")
            sb.append("  {\n")
            sb.append("    \"title\": \"$safeTitle\",\n")
            sb.append("    \"url\": \"$safeUrl\",\n")
            sb.append("    \"folder\": \"$safeFolder\",\n")
            sb.append("    \"category\": \"$safeCat\",\n")
            sb.append("    \"visitCount\": ${b.visitCount},\n")
            sb.append("    \"isPinned\": ${b.isPinned}\n")
            sb.append("  }${if (i < list.size - 1) "," else ""}\n")
        }
        sb.append("]")
        return sb.toString()
    }

    fun importBookmarksJson(jsonStr: String): Int {
        var count = 0
        try {
            val titleRegex = """"title"\s*:\s*"([^"]+)"""".toRegex()
            val urlRegex = """"url"\s*:\s*"([^"]+)"""".toRegex()
            val folderRegex = """"folder"\s*:\s*"([^"]+)"""".toRegex()

            val objectRegex = """\{[^}]+\}""".toRegex()
            val matches = objectRegex.findAll(jsonStr)
            viewModelScope.launch {
                matches.forEach { match ->
                    val block = match.value
                    val title = titleRegex.find(block)?.groupValues?.get(1)
                    val url = urlRegex.find(block)?.groupValues?.get(1)
                    val folder = folderRegex.find(block)?.groupValues?.get(1) ?: "Imported"

                    if (!url.isNullOrBlank()) {
                        bookmarkDao.insertBookmark(
                            Bookmark(
                                title = title ?: url,
                                url = url,
                                folder = folder
                            )
                        )
                        count++
                    }
                }
            }
        } catch (_: Exception) {}
        return count
    }

    fun savePassword(
        domain: String,
        title: String,
        username: String,
        passwordPlain: String,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val cleanDomain = extractCleanDomain(domain)
            val encrypted = CryptoVault.encrypt(passwordPlain)
            passwordDao.insertPassword(
                PasswordEntry(
                    domain = cleanDomain,
                    title = title.ifBlank { cleanDomain },
                    username = username,
                    encryptedPassword = encrypted.ciphertext,
                    iv = encrypted.iv,
                    notes = notes,
                    createdAt = System.currentTimeMillis(),
                    lastUsed = System.currentTimeMillis()
                )
            )
            appendTerminal("Encrypted credential saved for $cleanDomain (AES-256 GCM)", "SUCCESS")
            checkForAutofill(activeTab?.url ?: "")
        }
    }

    fun updatePasswordEntry(
        id: Long,
        domain: String,
        title: String,
        username: String,
        passwordPlain: String,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val existing = passwordDao.getPasswordById(id) ?: return@launch
            val cleanDomain = extractCleanDomain(domain)
            val encrypted = CryptoVault.encrypt(passwordPlain)
            passwordDao.updatePassword(
                existing.copy(
                    domain = cleanDomain,
                    title = title.ifBlank { cleanDomain },
                    username = username,
                    encryptedPassword = encrypted.ciphertext,
                    iv = encrypted.iv,
                    notes = notes,
                    lastUsed = System.currentTimeMillis()
                )
            )
            appendTerminal("Updated encrypted password for $cleanDomain", "SUCCESS")
            checkForAutofill(activeTab?.url ?: "")
        }
    }

    fun deletePassword(entry: PasswordEntry) {
        viewModelScope.launch {
            passwordDao.deletePassword(entry)
            appendTerminal("Deleted credential for ${entry.domain}", "WARN")
            checkForAutofill(activeTab?.url ?: "")
        }
    }

    fun clearAllPasswords() {
        viewModelScope.launch {
            passwordDao.clearAllPasswords()
            appendTerminal("All saved passwords have been removed from encrypted vault.", "WARN")
            checkForAutofill(activeTab?.url ?: "")
        }
    }

    fun getDecryptedPassword(entry: PasswordEntry): String {
        return CryptoVault.decrypt(entry.encryptedPassword, entry.iv)
    }

    fun toggleAutofill(enabled: Boolean) {
        _autofillEnabled.value = enabled
        prefs.edit().putBoolean("autofill_enabled", enabled).apply()
        appendTerminal("Browser Autofill: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
        if (!enabled) {
            _showAutofillPrompt.value = false
        } else {
            checkForAutofill(activeTab?.url ?: "")
        }
    }

    fun dismissAutofillPrompt() {
        _showAutofillPrompt.value = false
    }

    fun checkForAutofill(url: String) {
        if (!_autofillEnabled.value || url.isBlank() || url.startsWith("about:")) {
            _currentAutofillCandidate.value = null
            _showAutofillPrompt.value = false
            return
        }

        val domain = extractCleanDomain(url)
        viewModelScope.launch {
            val matches = passwordDao.getPasswordsForDomain(domain)
            if (matches.isNotEmpty()) {
                val candidate = matches.first()
                _currentAutofillCandidate.value = candidate
                _showAutofillPrompt.value = true
                appendTerminal("Autofill available for $domain (${candidate.username})", "INFO")
            } else {
                _currentAutofillCandidate.value = null
                _showAutofillPrompt.value = false
            }
        }
    }

    fun getAutofillInjectionScript(entry: PasswordEntry): String {
        val decryptedPass = CryptoVault.decrypt(entry.encryptedPassword, entry.iv)
        viewModelScope.launch {
            passwordDao.recordPasswordUsage(entry.id)
        }
        val safeUser = entry.username.replace("'", "\\'").replace("\"", "\\\"").replace("\n", "")
        val safePass = decryptedPass.replace("'", "\\'").replace("\"", "\\\"").replace("\n", "")

        return """
            (function() {
                try {
                    const user = '$safeUser';
                    const pass = '$safePass';
                    const pwInputs = document.querySelectorAll('input[type="password"]');
                    if (pwInputs.length > 0) {
                        const pw = pwInputs[0];
                        pw.focus();
                        pw.value = pass;
                        pw.dispatchEvent(new Event('input', { bubbles: true }));
                        pw.dispatchEvent(new Event('change', { bubbles: true }));

                        let userInput = null;
                        const form = pw.closest('form');
                        if (form) {
                            userInput = form.querySelector('input[type="text"], input[type="email"], input[name*="user"], input[name*="login"], input[id*="user"], input[id*="login"], input[autocomplete*="username"]');
                        }
                        if (!userInput) {
                            userInput = document.querySelector('input[type="email"], input[name*="user"], input[id*="user"], input[autocomplete="username"]');
                        }
                        if (userInput) {
                            userInput.focus();
                            userInput.value = user;
                            userInput.dispatchEvent(new Event('input', { bubbles: true }));
                            userInput.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                        return true;
                    }
                    return false;
                } catch(e) {
                    return false;
                }
            })();
        """.trimIndent()
    }

    fun extractCleanDomain(urlOrDomain: String): String {
        return try {
            val uri = Uri.parse(if (urlOrDomain.startsWith("http")) urlOrDomain else "https://$urlOrDomain")
            val host = uri.host ?: urlOrDomain
            host.removePrefix("www.")
        } catch (_: Exception) {
            urlOrDomain.removePrefix("https://").removePrefix("http://").removePrefix("www.").split("/").firstOrNull() ?: urlOrDomain
        }
    }

    fun navigateTo(screen: ScreenDestination) {
        val hasActiveWebPage = SyncConflictResolver.isBrowsingUrlActive(activeTab?.url.orEmpty())
        val resolvedScreen = if (screen == ScreenDestination.BROWSER && !hasActiveWebPage) {
            ScreenDestination.DASHBOARD
        } else {
            screen
        }
        _currentScreen.value = resolvedScreen
        _isBrowsing.value = resolvedScreen == ScreenDestination.BROWSER && hasActiveWebPage
    }

    fun setHostingerEndpoint(url: String) {
        _hostingerEndpoint.value = url
    }

    fun pingHostinger() {
        viewModelScope.launch {
            _isPinging.value = true
            appendTerminal("Executing encrypted sync connectivity check...", "INPUT")
            val health = DevOpsService.pingServer(_hostingerEndpoint.value)
            _serverHealth.value = health
            _isPinging.value = false
            if (health.isOnline) {
                appendTerminal("Connection OK: HTTP ${health.statusCode} [${health.latencyMs}ms] Sync Ready", "SUCCESS")
            } else {
                appendTerminal("Connection failed: ${health.message}", "ERROR")
            }
        }
    }

    fun executeTerminalCommand(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isEmpty()) return
        appendTerminal("$ $trimmed", "INPUT")

        val parts = trimmed.lowercase().split(" ")
        when (parts[0]) {
            "help" -> {
                appendTerminal("Available Commands:", "INFO")
                appendTerminal("  ping [host]        - Test network latency to gateway", "INFO")
                appendTerminal("  status             - View browser shields & engine health", "INFO")
                appendTerminal("  deploy             - Verify portal & sync bundle readiness", "INFO")
                appendTerminal("  backup             - Create snapshot of bookmarks/settings", "INFO")
                appendTerminal("  downloads          - View active and completed downloads", "INFO")
                appendTerminal("  tor-check          - Verify onion routing status", "INFO")
                appendTerminal("  audit              - Run security & leak inspection", "INFO")
                appendTerminal("  clear              - Clear terminal output", "INFO")
                appendTerminal("  panic              - Emergency amnesic RAM wipe", "WARN")
            }
            "ping" -> {
                val target = if (parts.size > 1) parts[1] else _hostingerEndpoint.value
                viewModelScope.launch {
                    appendTerminal("Checking encrypted sync reachability...", "INFO")
                    val res = DevOpsService.pingServer(target)
                    if (res.isOnline) {
                        appendTerminal("PONG: ${res.latencyMs}ms (HTTP ${res.statusCode}) - Online", "SUCCESS")
                    } else {
                        appendTerminal("PING FAIL: ${res.message}", "ERROR")
                    }
                }
            }
            "status" -> {
                appendTerminal("Silent Browser Engine: ${_engineMode.value.title}", "SUCCESS")
                appendTerminal("AdBlocker: ${if (_adblockEnabled.value) "ACTIVE" else "OFF"}", "INFO")
                appendTerminal("Total Trackers Blocked: ${_totalBlockedTrackers.value}", "SUCCESS")
                appendTerminal("Downloads Count: ${_downloads.value.size}", "INFO")
            }
            "downloads" -> {
                _downloads.value.forEach {
                    appendTerminal("${it.fileName} - [${it.status}] ${it.progressPercent}%", "INFO")
                }
            }
            "deploy" -> {
                viewModelScope.launch {
                    appendTerminal("Verifying Silent Browser release manifest...", "INFO")
                    appendTerminal("Checking sync protocol & OpenSearch readiness...", "SUCCESS")
                    appendTerminal("Cloud sync & release diagnostics ready [100%]", "SUCCESS")
                }
            }
            "backup" -> {
                appendTerminal("Compressing SQLite bookmarks & encrypted local cache...", "INFO")
                appendTerminal("Backup Created [Success]: silent_browser_backup_${System.currentTimeMillis()}.tar.gz", "SUCCESS")
            }
            "tor-check" -> {
                appendTerminal("Checking Tor & SOCKS5 circuit health...", "INFO")
                appendTerminal("Header: X-Tor-Circuit: Isolated Partition", "SUCCESS")
                appendTerminal("Canvas Noise Poisoning: ENGAGED", "SUCCESS")
                appendTerminal("WebRTC IP Leak Protection: SECURE", "SUCCESS")
            }
            "audit" -> {
                appendTerminal("Performing 12-point zero-knowledge audit...", "INFO")
                appendTerminal(" - Third-party cookies: BLOCKED", "SUCCESS")
                appendTerminal(" - Referrer-Policy: strict-origin-when-cross-origin", "SUCCESS")
                appendTerminal(" - Cryptomining scripts: BLOCKED", "SUCCESS")
                appendTerminal(" - Global Privacy Control: ENABLED", "SUCCESS")
                appendTerminal("Audit Score: 100/100 (A+ Paranoid Tier)", "SUCCESS")
            }
            "clear" -> {
                _terminalLogs.value = emptyList()
            }
            "panic" -> {
                panicPurge()
            }
            else -> {
                appendTerminal("Command not recognized: '$trimmed'. Type 'help' for commands.", "WARN")
            }
        }
    }

    private fun appendTerminal(msg: String, type: String = "INFO") {
        val updated = _terminalLogs.value.toMutableList()
        updated.add(TerminalLog(msg, type))
        if (updated.size > 200) {
            updated.removeAt(0)
        }
        _terminalLogs.value = updated
    }

    fun openUrl(rawInput: String, overrideEngine: SearchEngine? = null) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        val finalUrl = when {
            trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("about:", ignoreCase = true) -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> {
                val engine = overrideEngine ?: _activeSearchEngine.value
                engine.buildSearchUrl(trimmed)
            }
        }

        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == activeId) {
                it.copy(url = finalUrl, title = trimmed, isLoading = true, progress = 10)
            } else {
                it
            }
        }
        _currentScreen.value = ScreenDestination.BROWSER
        _isBrowsing.value = SyncConflictResolver.isBrowsingUrlActive(finalUrl)

        viewModelScope.launch {
            val match = bookmarkDao.getBookmarkByUrl(finalUrl)
            if (match != null) {
                bookmarkDao.incrementVisitCount(match.id)
            }
        }
    }

    fun createNewTab(initialUrl: String = "about:blank", isIncognito: Boolean? = null) {
        val incognito = isIncognito ?: _alwaysIncognito.value
        val newTab = BrowserTab(
            title = if (initialUrl == "about:blank") (if (incognito) "Private Tab" else "Silent Home") else "Loading...",
            url = initialUrl,
            isIncognito = incognito,
            engineMode = if (incognito) EngineMode.TAILS_AMNESIC else _engineMode.value
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
        val isBlank = !SyncConflictResolver.isBrowsingUrlActive(initialUrl)
        _currentScreen.value = if (isBlank) ScreenDestination.DASHBOARD else ScreenDestination.BROWSER
        _isBrowsing.value = !isBlank
        if (incognito) {
            appendTerminal("Opened new Incognito tab. History disabled.", "INFO")
        }
    }

    fun closeTab(tabId: String) {
        val currentList = _tabs.value
        val targetTab = currentList.find { it.id == tabId }
        val wasIncognito = targetTab?.isIncognito == true

        if (wasIncognito || _autoPurgeOnTabClosure.value) {
            try {
                CookieManager.getInstance().removeSessionCookies(null)
                CookieManager.getInstance().flush()
            } catch (_: Exception) {}
            appendTerminal("Private Tab Closed: Transient cookies and RAM session cleared automatically.", "SUCCESS")
        }

        if (currentList.size <= 1) {
            val freshTab = BrowserTab(
                title = if (_alwaysIncognito.value) "Private Tab" else "Silent Home",
                url = "about:blank",
                isIncognito = _alwaysIncognito.value,
                engineMode = if (_alwaysIncognito.value) EngineMode.TAILS_AMNESIC else _engineMode.value
            )
            _tabs.value = listOf(freshTab)
            _activeTabId.value = freshTab.id
            _currentScreen.value = ScreenDestination.DASHBOARD
            _isBrowsing.value = false
            return
        }

        val filtered = currentList.filter { it.id != tabId }
        _tabs.value = filtered
        if (_activeTabId.value == tabId) {
            val nextTab = filtered.last()
            _activeTabId.value = nextTab.id
            _isBrowsing.value = _currentScreen.value == ScreenDestination.BROWSER &&
                SyncConflictResolver.isBrowsingUrlActive(nextTab.url)
        }
    }

    fun toggleActiveTabIncognito() {
        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == activeId) {
                val nextState = !tab.isIncognito
                if (!nextState && _autoPurgeOnTabClosure.value) {
                    try {
                        CookieManager.getInstance().removeSessionCookies(null)
                        CookieManager.getInstance().flush()
                    } catch (_: Exception) {}
                }
                tab.copy(
                    isIncognito = nextState,
                    engineMode = if (nextState) EngineMode.TAILS_AMNESIC else _engineMode.value
                )
            } else tab
        }
        val isNowIncognito = activeTab?.isIncognito == true
        appendTerminal(
            if (isNowIncognito) "Incognito Private Mode ENGAGED: History disabled, cookies wipe on close."
            else "Standard Browsing Mode engaged.",
            if (isNowIncognito) "WARN" else "INFO"
        )
    }

    fun toggleAlwaysIncognito(enabled: Boolean) {
        _alwaysIncognito.value = enabled
        prefs.edit().putBoolean("always_incognito", enabled).apply()
        appendTerminal("Always Incognito Mode: ${if (enabled) "ACTIVE" else "STANDARD"}", "INFO")
    }

    fun toggleAutoPurgeOnTabClosure(enabled: Boolean) {
        _autoPurgeOnTabClosure.value = enabled
        prefs.edit().putBoolean("auto_purge_tab_closure", enabled).apply()
        appendTerminal("Auto-Purge on Tab Closure: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
    }

    fun selectTab(tabId: String) {
        _activeTabId.value = tabId
        val target = _tabs.value.find { it.id == tabId }
        val isActiveUrl = SyncConflictResolver.isBrowsingUrlActive(target?.url.orEmpty())
        _currentScreen.value = if (isActiveUrl) ScreenDestination.BROWSER else ScreenDestination.DASHBOARD
        _isBrowsing.value = isActiveUrl
    }

    fun updateActiveTabProgress(progress: Int, isLoading: Boolean) {
        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == activeId) {
                it.copy(progress = progress, isLoading = isLoading)
            } else it
        }
    }

    fun updateActiveTabDetails(url: String, title: String, canGoBack: Boolean, canGoForward: Boolean) {
        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == activeId) {
                it.copy(
                    url = url,
                    title = if (title.isBlank()) it.title else title,
                    canGoBack = canGoBack,
                    canGoForward = canGoForward
                )
            } else it
        }
        if (_currentScreen.value == ScreenDestination.BROWSER) {
            _isBrowsing.value = SyncConflictResolver.isBrowsingUrlActive(url)
        }

        val active = activeTab
        if (active != null && !active.isIncognito && _engineMode.value != EngineMode.TAILS_AMNESIC) {
            if (url.isNotBlank() && url != "about:blank") {
                viewModelScope.launch {
                    historyDao.insertHistory(
                        HistoryItem(
                            title = if (title.isBlank()) url else title,
                            url = url
                        )
                    )
                }
            }
        }

        checkForAutofill(url)
    }

    fun recordBlockedRequest(url: String) {
        val decision = PrivacyEngine.evaluateRequest(
            url = url,
            adblockEnabled = _adblockEnabled.value,
            antiScamEnabled = _antiScamProtectionEnabled.value,
            blockedOverrides = _customBlockedDomains.value,
            allowedOverrides = _customAllowedDomains.value
        )
        val effectiveCategory = if (decision.blocked) {
            decision.category
        } else {
            RequestBlockCategory.ANALYTICS_TRACKER
        }
        val effectiveHost = decision.host.ifBlank { extractCleanDomain(url) }
        val effectiveRule = if (decision.blocked) decision.matchedRule else "network-filter"

        val nextTotal = _totalBlockedTrackers.value + 1
        var nextAds = _blockedAdsCount.value
        var nextTrackersOnly = _blockedTrackersOnlyCount.value
        var nextScams = _blockedScamsBotsCount.value

        when (effectiveCategory) {
            RequestBlockCategory.AD_NETWORK,
            RequestBlockCategory.CUSTOM_RULE -> nextAds += 1
            RequestBlockCategory.ANALYTICS_TRACKER -> nextTrackersOnly += 1
            RequestBlockCategory.SCAM_PHISHING,
            RequestBlockCategory.CRYPTOMINER_BOT -> nextScams += 1
            RequestBlockCategory.ALLOWED -> nextTrackersOnly += 1
        }

        _totalBlockedTrackers.value = nextTotal
        _blockedAdsCount.value = nextAds
        _blockedTrackersOnlyCount.value = nextTrackersOnly
        _blockedScamsBotsCount.value = nextScams

        prefs.edit()
            .putInt("blocked_trackers_total", nextTotal)
            .putInt("blocked_ads_count", nextAds)
            .putInt("blocked_trackers_only_count", nextTrackersOnly)
            .putInt("blocked_scams_bots_count", nextScams)
            .apply()

        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == activeId) {
                it.copy(blockedTrackersCount = it.blockedTrackersCount + 1)
            } else it
        }

        prependBlockedRecord(
            BlockedRequestRecord(
                host = effectiveHost,
                url = url,
                category = effectiveCategory,
                matchedRule = effectiveRule
            )
        )
    }

    fun incrementBlockedCount() {
        recordBlockedRequest("https://doubleclick.net/pagead/blocked")
    }

    fun incrementScamBotBlockedCount(threatUrl: String = "") {
        val nextScams = _blockedScamsBotsCount.value + 1
        val nextTotal = _totalBlockedTrackers.value + 1
        _blockedScamsBotsCount.value = nextScams
        _totalBlockedTrackers.value = nextTotal
        prefs.edit()
            .putInt("blocked_scams_bots_count", nextScams)
            .putInt("blocked_trackers_total", nextTotal)
            .apply()
        val host = PrivacyEngine.extractHost(threatUrl) ?: threatUrl.ifBlank { "threat-relay" }
        val decision = PrivacyEngine.evaluateRequest(
            url = threatUrl,
            adblockEnabled = _adblockEnabled.value,
            antiScamEnabled = true
        )
        val cat = if (decision.category == RequestBlockCategory.CRYPTOMINER_BOT) {
            RequestBlockCategory.CRYPTOMINER_BOT
        } else {
            RequestBlockCategory.SCAM_PHISHING
        }
        prependBlockedRecord(
            BlockedRequestRecord(
                host = host,
                url = threatUrl.ifBlank { "https://$host/" },
                category = cat,
                matchedRule = if (decision.blocked) decision.matchedRule else "anti-scam-guard"
            )
        )
        if (threatUrl.isNotBlank()) {
            appendTerminal("Anti-Scam/Bot Shield intercepted threat: $threatUrl", "WARN")
        }
    }

    fun runLiveAdblockAndHeaderProbe(inputUrl: String) {
        val trimmed = inputUrl.trim()
        if (trimmed.isEmpty()) return
        val normalized = if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            trimmed
        } else {
            "https://$trimmed"
        }

        viewModelScope.launch {
            _isProbingPrivacy.value = true
            val decision = PrivacyEngine.evaluateRequest(
                url = normalized,
                adblockEnabled = _adblockEnabled.value,
                antiScamEnabled = _antiScamProtectionEnabled.value,
                blockedOverrides = _customBlockedDomains.value,
                allowedOverrides = _customAllowedDomains.value
            )

            if (decision.blocked) {
                if (decision.category == RequestBlockCategory.SCAM_PHISHING || decision.category == RequestBlockCategory.CRYPTOMINER_BOT) {
                    incrementScamBotBlockedCount(normalized)
                } else {
                    recordBlockedRequest(normalized)
                }
                _liveProbeResult.value = LiveProbeResponse(
                    inputUrl = normalized,
                    host = decision.host,
                    filterDecision = decision,
                    httpStatusCode = 0,
                    latencyMs = 0L,
                    dntHeaderSent = false,
                    gpcHeaderSent = false,
                    serverHeader = "Blocked Locally (0 Bytes Sent)",
                    summary = "INTERCEPTED & BLOCKED BEFORE NETWORK (${decision.category.label}) • Rule: ${decision.matchedRule}"
                )
                appendTerminal("Privacy Probe BLOCKED [$normalized] via rule '${decision.matchedRule}'", "SUCCESS")
                _isProbingPrivacy.value = false
                return@launch
            }

            val httpResult = DevOpsService.probePrivacyHeaders(normalized)
            val summaryText = if (httpResult.isReachable) {
                "ALLOWED • HTTP ${httpResult.statusCode} in ${httpResult.latencyMs}ms • " +
                    if (httpResult.dntInjected) "DNT: 1 & Sec-GPC: 1 verified" else "Privacy headers paused"
            } else {
                "ALLOWED BY FILTER • Origin check error: ${httpResult.errorMessage ?: "HTTP ${httpResult.statusCode}"}"
            }
            _liveProbeResult.value = LiveProbeResponse(
                inputUrl = normalized,
                host = decision.host,
                filterDecision = decision,
                httpStatusCode = httpResult.statusCode,
                latencyMs = httpResult.latencyMs,
                dntHeaderSent = httpResult.dntInjected,
                gpcHeaderSent = httpResult.gpcInjected,
                serverHeader = httpResult.serverHeader,
                summary = summaryText
            )
            appendTerminal("Privacy Probe ALLOWED [$normalized]: HTTP ${httpResult.statusCode} (${httpResult.latencyMs}ms)", "INFO")
            _isProbingPrivacy.value = false
        }
    }

    fun addCustomBlockedDomain(rawDomain: String): Boolean {
        val clean = PrivacyEngine.normalizeDomainInput(rawDomain) ?: return false
        val nextBlocked = _customBlockedDomains.value + clean
        val nextAllowed = _customAllowedDomains.value - clean
        _customBlockedDomains.value = nextBlocked
        _customAllowedDomains.value = nextAllowed
        PrivacyEngine.customBlockedDomains = nextBlocked
        PrivacyEngine.customAllowedDomains = nextAllowed
        prefs.edit()
            .putStringSet("custom_blocked_domains", nextBlocked)
            .putStringSet("custom_allowed_domains", nextAllowed)
            .apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Added domain to custom Ad/Tracker blocklist: $clean", "SUCCESS")
        return true
    }

    fun removeCustomBlockedDomain(domain: String) {
        val nextBlocked = _customBlockedDomains.value - domain
        _customBlockedDomains.value = nextBlocked
        PrivacyEngine.customBlockedDomains = nextBlocked
        prefs.edit().putStringSet("custom_blocked_domains", nextBlocked).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Removed domain from custom blocklist: $domain", "INFO")
    }

    fun addCustomAllowedDomain(rawDomain: String): Boolean {
        val clean = PrivacyEngine.normalizeDomainInput(rawDomain) ?: return false
        val nextAllowed = _customAllowedDomains.value + clean
        val nextBlocked = _customBlockedDomains.value - clean
        _customAllowedDomains.value = nextAllowed
        _customBlockedDomains.value = nextBlocked
        PrivacyEngine.customAllowedDomains = nextAllowed
        PrivacyEngine.customBlockedDomains = nextBlocked
        prefs.edit()
            .putStringSet("custom_allowed_domains", nextAllowed)
            .putStringSet("custom_blocked_domains", nextBlocked)
            .apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Added domain to trusted allowlist: $clean", "INFO")
        return true
    }

    fun removeCustomAllowedDomain(domain: String) {
        val nextAllowed = _customAllowedDomains.value - domain
        _customAllowedDomains.value = nextAllowed
        PrivacyEngine.customAllowedDomains = nextAllowed
        prefs.edit().putStringSet("custom_allowed_domains", nextAllowed).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Removed domain from allowlist: $domain", "INFO")
    }

    fun clearBlockedRequestLog() {
        _blockedRequestLog.value = emptyList()
        prefs.edit().remove("blocked_request_log_json").apply()
        appendTerminal("Cleared blocked request telemetry log.", "INFO")
    }

    fun resetPrivacyTelemetry() {
        _totalBlockedTrackers.value = 0
        _blockedAdsCount.value = 0
        _blockedTrackersOnlyCount.value = 0
        _blockedScamsBotsCount.value = 0
        _blockedRequestLog.value = emptyList()
        _liveProbeResult.value = null
        NetworkRequestInterceptor.resetCounter()
        prefs.edit()
            .putInt("blocked_trackers_total", 0)
            .putInt("blocked_ads_count", 0)
            .putInt("blocked_trackers_only_count", 0)
            .putInt("blocked_scams_bots_count", 0)
            .remove("blocked_request_log_json")
            .apply()
        appendTerminal("All live privacy counters and logs reset to zero.", "WARN")
    }

    fun maximizeAllPrivacyShields() {
        toggleAdblock(true)
        toggleDoNotTrack(true)
        toggleAntiScamProtection(true)
        toggleFingerprintShield(true)
        toggleThirdPartyCookies(true)
        toggleHttpsEverywhere(true)
        toggleShieldedIp(true)
        runProductionPrivacyAudit(logToTerminal = true)
        appendTerminal("LOCKDOWN ACTIVE: All 7 configurable privacy shields enabled.", "SUCCESS")
    }

    fun runProductionPrivacyAudit(logToTerminal: Boolean = true) {
        val totalRules = PrivacyEngine.AD_NETWORK_HOSTS.size +
            PrivacyEngine.ANALYTICS_TRACKER_HOSTS.size +
            PrivacyEngine.SCAM_AND_BOT_HOSTS.size +
            _customBlockedDomains.value.size

        val items = listOf(
            PrivacyAuditItem(
                name = "Network & Cosmetic Ad Blocker",
                passed = _adblockEnabled.value,
                detail = if (_adblockEnabled.value) {
                    "$totalRules host & path signatures + cosmetic CSS injection armed"
                } else {
                    "Ad & cosmetic blocker disabled"
                }
            ),
            PrivacyAuditItem(
                name = "DNT: 1 & Sec-GPC Header Injection",
                passed = _doNotTrackEnabled.value,
                detail = if (_doNotTrackEnabled.value) {
                    "Attached on WebView & OkHttp (${NetworkRequestInterceptor.interceptedDntCount.value} requests)"
                } else {
                    "Header interceptor paused"
                }
            ),
            PrivacyAuditItem(
                name = "Anti-Scam & Cryptominer Shield",
                passed = _antiScamProtectionEnabled.value,
                detail = if (_antiScamProtectionEnabled.value) {
                    "Punycode homograph, phishing & cryptojacking guard active"
                } else {
                    "Phishing & miner guard disabled"
                }
            ),
            PrivacyAuditItem(
                name = "Canvas, WebGL & WebRTC Leak Guard",
                passed = _fingerprintShieldEnabled.value,
                detail = if (_fingerprintShieldEnabled.value) {
                    "Canvas noise poisoning & relay-only WebRTC ICE policy injected"
                } else {
                    "Browser fingerprint surfaces exposed"
                }
            ),
            PrivacyAuditItem(
                name = "Third-Party Cookie Isolation",
                passed = _thirdPartyCookiesBlocked.value,
                detail = if (_thirdPartyCookiesBlocked.value) {
                    "Cross-site tracking cookies blocked at WebView CookieManager"
                } else {
                    "Third-party cookies permitted"
                }
            ),
            PrivacyAuditItem(
                name = "HTTPS Everywhere Upgrade",
                passed = _httpsEverywhereEnabled.value,
                detail = if (_httpsEverywhereEnabled.value) {
                    "Cleartext HTTP requests automatically upgraded to HTTPS"
                } else {
                    "Plaintext HTTP requests allowed"
                }
            ),
            PrivacyAuditItem(
                name = "Virtual Shielded IP Relay",
                passed = _shieldedIpEnabled.value,
                detail = if (_shieldedIpEnabled.value) {
                    "Active node: ${_activeRelayNode.value.location} (${_activeRelayNode.value.virtualIp})"
                } else {
                    "Direct ISP routing active — enable relay to mask IP"
                }
            )
        )
        val passed = items.count { it.passed }
        val score = ((passed * 100f) / items.size).toInt()
        _privacyAuditReport.value = PrivacyAuditReport(
            scorePercent = score,
            passedCount = passed,
            totalChecks = items.size,
            items = items
        )
        if (logToTerminal) {
            appendTerminal("Production Privacy Audit: $score% ($passed/${items.size} shields passing)", if (score >= 85) "SUCCESS" else "WARN")
        }
    }

    private fun prependBlockedRecord(record: BlockedRequestRecord) {
        val updated = (listOf(record) + _blockedRequestLog.value).take(100)
        _blockedRequestLog.value = updated
        savePersistedBlockedLog(updated)
    }

    private fun savePersistedBlockedLog(records: List<BlockedRequestRecord>) {
        try {
            val arr = JSONArray()
            records.forEach { r ->
                arr.put(JSONObject().apply {
                    put("id", r.id)
                    put("host", r.host)
                    put("url", r.url)
                    put("category", r.category.name)
                    put("matchedRule", r.matchedRule)
                    put("timestampMs", r.timestampMs)
                })
            }
            prefs.edit().putString("blocked_request_log_json", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadPersistedBlockedLog(): List<BlockedRequestRecord> {
        val raw = prefs.getString("blocked_request_log_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = ArrayList<BlockedRequestRecord>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val catName = o.optString("category", RequestBlockCategory.AD_NETWORK.name)
                val cat = RequestBlockCategory.entries.find { it.name == catName } ?: RequestBlockCategory.AD_NETWORK
                list.add(
                    BlockedRequestRecord(
                        id = o.optString("id", java.util.UUID.randomUUID().toString()),
                        host = o.optString("host", ""),
                        url = o.optString("url", ""),
                        category = cat,
                        matchedRule = o.optString("matchedRule", "rule"),
                        timestampMs = o.optLong("timestampMs", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun setEngineMode(mode: EngineMode) {
        _engineMode.value = mode
        prefs.edit().putString("engine_mode", mode.name).apply()
        val activeId = _activeTabId.value
        _tabs.value = _tabs.value.map {
            if (it.id == activeId) it.copy(engineMode = mode) else it
        }
        appendTerminal("Switched privacy engine to: ${mode.title} [${mode.badge}]", "SUCCESS")
    }

    fun setUserAgent(uaName: String) {
        _selectedUserAgent.value = uaName
        prefs.edit().putString("user_agent", uaName).apply()
    }

    fun setSearchEngine(engine: SearchEngine) {
        _activeSearchEngine.value = engine
        _searchEngine.value = engine.displayName
        prefs.edit().putString("search_engine_id", engine.id).apply()
        appendTerminal("Active search engine: ${engine.displayName}", "SUCCESS")
    }

    fun setSearchEngine(engineName: String) {
        _searchEngine.value = engineName
        val found = SearchEngine.values().find { it.displayName.equals(engineName, ignoreCase = true) }
            ?: SearchEngine.DUCKDUCKGO
        _activeSearchEngine.value = found
        prefs.edit().putString("search_engine_id", found.id).apply()
    }

    fun openInExternalApp(context: Context, targetUrl: String? = null) {
        val url = targetUrl ?: activeTab?.url ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Open in App..."))
            appendTerminal("Dispatched external intent for: $url", "INFO")
        } catch (e: Exception) {
            appendTerminal("No external handler found for: $url", "WARN")
        }
    }

    fun toggleAdblock(enabled: Boolean) {
        _adblockEnabled.value = enabled
        prefs.edit().putBoolean("adblock_enabled", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
    }

    fun toggleFingerprintShield(enabled: Boolean) {
        _fingerprintShieldEnabled.value = enabled
        prefs.edit().putBoolean("fingerprint_shield", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
    }

    fun toggleHttpsEverywhere(enabled: Boolean) {
        _httpsEverywhereEnabled.value = enabled
        prefs.edit().putBoolean("https_everywhere", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
    }

    fun toggleJavascript(enabled: Boolean) {
        _javascriptEnabled.value = enabled
        prefs.edit().putBoolean("javascript_enabled", enabled).apply()
    }

    fun toggleAntiScamProtection(enabled: Boolean) {
        _antiScamProtectionEnabled.value = enabled
        prefs.edit().putBoolean("anti_scam_bot_shield", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Anti-Scammer & Bot Defense: ${if (enabled) "ARMED" else "DISABLED"}", if (enabled) "SUCCESS" else "WARN")
    }

    fun toggleBookmark(url: String, title: String, folder: String = "Favorites") {
        viewModelScope.launch {
            if (bookmarkDao.isBookmarked(url)) {
                bookmarkDao.deleteByUrl(url)
            } else {
                bookmarkDao.insertBookmark(
                    Bookmark(
                        title = title.ifBlank { url },
                        url = url,
                        folder = folder
                    )
                )
            }
        }
    }

    fun deleteBookmark(bookmark: Bookmark) {
        viewModelScope.launch {
            bookmarkDao.deleteBookmark(bookmark)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            historyDao.clearAllHistory()
            appendTerminal("Browsing history successfully wiped.", "WARN")
        }
    }

    fun deleteHistoryItem(item: HistoryItem) {
        viewModelScope.launch {
            historyDao.deleteHistory(item)
        }
    }

    fun panicPurge() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        } catch (_: Exception) {}

        _tabs.value = listOf(
            BrowserTab(
                title = "Silent Home",
                url = "about:blank",
                engineMode = EngineMode.TAILS_AMNESIC
            )
        )
        _activeTabId.value = _tabs.value.first().id
        _isBrowsing.value = false
        _currentScreen.value = ScreenDestination.DASHBOARD
        _qrSyncSession.value = null
        _qrSyncError.value = null

        viewModelScope.launch {
            historyDao.clearAllHistory()
        }
        appendTerminal("EMERGENCY PANIC TRIGGERED: All memory, cookies, QR sync tokens, and local history wiped completely.", "ERROR")
    }

    fun toggleProximityPanic(enabled: Boolean) {
        _proximityPanicEnabled.value = enabled
        prefs.edit().putBoolean("proximity_panic_enabled", enabled).apply()
        pendingPanicPersistCount++
        viewModelScope.launch {
            try {
                BrowserPreferencesDataStore.saveProximityPanicEnabled(getApplication(), enabled)
            } finally {
                pendingPanicPersistCount = (pendingPanicPersistCount - 1).coerceAtLeast(0)
            }
        }
        appendTerminal("Panic Wipe proximity sensor trigger: ${if (enabled) "ENABLED" else "DISABLED"}", if (enabled) "WARN" else "INFO")
    }

    fun onSearchInputChanged(query: String) {
        suggestionJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.isEmpty() || !_suggestionsEnabled.value) {
            _searchSuggestions.value = emptyList()
            _isFetchingSuggestions.value = false
            return
        }
        suggestionJob = viewModelScope.launch {
            _isFetchingSuggestions.value = true
            delay(250) // debounce rapid keystrokes
            val list = SearchSuggestionService.getMultiEngineSuggestions(
                query = trimmed,
                activeEngine = _activeSearchEngine.value,
                bookmarks = bookmarks.value,
                history = history.value,
                includeWebEngines = _suggestionsEnabled.value
            )
            _searchSuggestions.value = list
            _isFetchingSuggestions.value = false
        }
    }

    fun clearSuggestions() {
        suggestionJob?.cancel()
        _searchSuggestions.value = emptyList()
        _isFetchingSuggestions.value = false
    }

    fun toggleSuggestions(enabled: Boolean) {
        _suggestionsEnabled.value = enabled
        prefs.edit().putBoolean("suggestions_enabled", enabled).apply()
        if (!enabled) clearSuggestions()
        appendTerminal("Search suggestions: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
    }

    fun toggleCleanStealthMode(enabled: Boolean) {
        _cleanStealthMode.value = enabled
        prefs.edit().putBoolean("clean_stealth_mode", enabled).apply()
        if (enabled) {
            setSearchEngine(SearchEngine.SILENT_STEALTH)
        }
        appendTerminal("Clean Stealth Search mode: ${if (enabled) "ENABLED" else "STANDARD"}", "INFO")
    }

    fun toggleThirdPartyCookies(blocked: Boolean) {
        _thirdPartyCookiesBlocked.value = blocked
        prefs.edit().putBoolean("block_third_party_cookies", blocked).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Block third-party cookies: $blocked", "INFO")
    }

    fun toggleDoNotTrack(enabled: Boolean) {
        _doNotTrackEnabled.value = enabled
        NetworkRequestInterceptor.isDntEnabled = enabled
        prefs.edit().putBoolean("do_not_track", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Do Not Track (DNT: 1) Network Interceptor: ${if (enabled) "ACTIVE" else "PAUSED"}", "INFO")
    }

    fun setThemePreset(preset: AppThemePreset) {
        _selectedThemePreset.value = preset
        prefs.edit().putString("theme_preset", preset.id).apply()
        pendingThemePersistCount++
        viewModelScope.launch {
            try {
                BrowserPreferencesDataStore.saveThemePreset(getApplication(), preset)
            } finally {
                pendingThemePersistCount = (pendingThemePersistCount - 1).coerceAtLeast(0)
            }
        }
        appendTerminal("Theme changed to ${preset.title} (persisted to DataStore)", "INFO")
    }

    fun openCommandHub() {
        _showCommandHubModal.value = true
    }

    fun closeCommandHub() {
        _showCommandHubModal.value = false
    }

    fun toggleCommandHub() {
        _showCommandHubModal.value = !_showCommandHubModal.value
    }

    fun toggleInlineCommandHub() {
        val next = !_isCommandHubVisible.value
        _isCommandHubVisible.value = next
        prefs.edit().putBoolean("inline_command_hub_visible", next).apply()
    }

    fun openDefaultBrowserSettings(context: Context) {
        try {
            val intent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
            } else {
                Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            appendTerminal("Opened Android Default Apps Settings for Silent Browser", "INFO")
        } catch (_: Exception) {
            try {
                val fallback = Intent(
                    android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${context.packageName}")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(fallback)
            } catch (_: Exception) {
                appendTerminal("Could not launch Android Default Apps Settings.", "WARN")
            }
        }
    }

    fun openSetupWizard() {
        _showSetupWizardModal.value = true
    }

    fun dismissSetupWizard() {
        _showSetupWizardModal.value = false
    }

    fun completeSetupWizard(
        engine: SearchEngine = _activeSearchEngine.value,
        enableDnt: Boolean = true,
        enableShieldedIp: Boolean = true,
        enableAntiScam: Boolean = true
    ) {
        setSearchEngine(engine)
        toggleDoNotTrack(enableDnt)
        toggleShieldedIp(enableShieldedIp)
        toggleAntiScamProtection(enableAntiScam)
        _isSetupConfigured.value = true
        _showSetupWizardModal.value = false
        prefs.edit().putBoolean("is_setup_configured", true).apply()
        appendTerminal("Initial Security Setup completed! Panic Wipe ARMED.", "SUCCESS")
    }

    fun resetSetupWizardState() {
        _isSetupConfigured.value = false
        prefs.edit().putBoolean("is_setup_configured", false).apply()
    }

    fun clearBrowsingCache(context: Context) {
        try {
            val wv = WebView(context)
            wv.clearCache(true)
            wv.destroy()
            WebStorage.getInstance().deleteAllData()
            appendTerminal("Browser cache and DOM web storage cleared.", "SUCCESS")
        } catch (_: Exception) {}
    }

    fun clearCookies() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            appendTerminal("All cookies and session tokens cleared.", "SUCCESS")
        } catch (_: Exception) {}
    }

    fun clearAllBookmarks() {
        viewModelScope.launch {
            bookmarkDao.clearAllBookmarks()
            appendTerminal("All saved bookmarks have been removed.", "WARN")
        }
    }

    fun resetAllSettings() {
        toggleAdblock(true)
        toggleFingerprintShield(true)
        toggleHttpsEverywhere(true)
        toggleJavascript(true)
        toggleThirdPartyCookies(true)
        toggleDoNotTrack(true)
        toggleAntiScamProtection(true)
        toggleSuggestions(true)
        toggleCleanStealthMode(true)
        toggleShieldedIp(true)
        setUserAgent("Tor Browser (Spoofed)")
        setSearchEngine(SearchEngine.SILENT_STEALTH)
        setThemePreset(AppThemePreset.WHITE)
        _isSetupConfigured.value = true
        prefs.edit().putBoolean("is_setup_configured", true).apply()
        appendTerminal("Settings reset to White Theme & Production Privacy defaults (Armed).", "SUCCESS")
    }

    fun openSupportEmail(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:silentbrowser@silentbot.online")
                putExtra(Intent.EXTRA_SUBJECT, "Silent Browser Support Inquiry [v${BuildConfig.VERSION_NAME}]")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            appendTerminal("Unable to launch email client.", "WARN")
        }
    }

    fun callSupportPhone(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:+15304816886")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            appendTerminal("Unable to launch phone dialer.", "WARN")
        }
    }

    fun openOfficialPortal() {
        openUrl(DevOpsService.OFFICIAL_PORTAL_URL)
    }

    fun openPublishPortal() {
        openUrl(DevOpsService.PRIMARY_WEB_PORTAL_URL)
    }

    fun openMirrorPortal() {
        openUrl(DevOpsService.MIRROR_PORTAL_URL)
    }

    fun openPlatformDownload(platform: String) {
        val normalized = platform.lowercase().trim()
        openUrl("${DevOpsService.PRIMARY_WEB_PORTAL_URL}?os=$normalized#downloads")
    }

    fun rotateShieldedIp() {
        val currentIndex = relayNodes.indexOf(_activeRelayNode.value)
        val nextIndex = (currentIndex + 1) % relayNodes.size
        _activeRelayNode.value = relayNodes[nextIndex]
        prefs.edit().putInt("relay_node_index", nextIndex).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Virtual Shielded IP rotated: ${_activeRelayNode.value.virtualIp} (${_activeRelayNode.value.location})", "SUCCESS")
    }

    fun selectRelayNode(node: ShieldedRelayNode) {
        _activeRelayNode.value = node
        val idx = relayNodes.indexOf(node).coerceAtLeast(0)
        prefs.edit().putInt("relay_node_index", idx).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Connected to Shielded Node: ${node.location} [${node.virtualIp}]", "SUCCESS")
    }

    fun toggleShieldedIp(enabled: Boolean) {
        _shieldedIpEnabled.value = enabled
        prefs.edit().putBoolean("shielded_ip_enabled", enabled).apply()
        runProductionPrivacyAudit(logToTerminal = false)
        appendTerminal("Virtual Shielded IP Protection: ${if (enabled) "ENGAGED [NO LEAKS]" else "DISABLED"}", if (enabled) "SUCCESS" else "WARN")
    }

    fun toggleExtension(id: String, enabled: Boolean) {
        ExtensionManager.toggleExtension(id, enabled)
        appendTerminal("Extension $id: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
    }

    fun installExtension(name: String, desc: String, script: String) {
        val ext = ExtensionManager.installCustomExtension(name, desc, script)
        appendTerminal("Installed new extension: ${ext.name}", "SUCCESS")
    }

    fun removeExtension(id: String) {
        ExtensionManager.removeExtension(id)
        appendTerminal("Removed extension: $id", "WARN")
    }

    fun getInjectedExtensionScripts(): String {
        return ExtensionManager.getCombinedContentScripts()
    }

    fun getUserAgentString(): String {
        return when (_selectedUserAgent.value) {
            "Tor Browser (Spoofed)" -> PrivacyEngine.TOR_USER_AGENT
            "Desktop Linux" -> PrivacyEngine.DESKTOP_USER_AGENT
            "iPhone Safari" -> PrivacyEngine.IPHONE_USER_AGENT
            else -> ""
        }
    }

    fun selectFeedCategory(category: DiscoveryCategory) {
        _selectedFeedCategory.value = category
    }

    fun loadDiscoveryFeed(forceRefresh: Boolean = false) {
        if (_isLoadingFeed.value && !forceRefresh) return
        viewModelScope.launch {
            _isLoadingFeed.value = true
            _feedError.value = null
            try {
                val result = DiscoveryFeedService.fetchDiscoveryFeed(
                    enforceHttps = _httpsEverywhereEnabled.value,
                    enforceAntiScam = _antiScamProtectionEnabled.value
                )
                if (result.items.isNotEmpty()) {
                    _discoveryFeedItems.value = result.items
                } else if (_discoveryFeedItems.value.isEmpty()) {
                    _discoveryFeedItems.value = DiscoveryFeedService.fallbackDirectoryResult(
                        enforceHttps = _httpsEverywhereEnabled.value,
                        enforceAntiScam = _antiScamProtectionEnabled.value
                    ).items
                }
                _feedError.value = result.errorMessage
                if (result.filteredThreatsCount > 0) {
                    repeat(result.filteredThreatsCount) {
                        incrementScamBotBlockedCount("Filtered suspicious feed URL")
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Throwable) {
                if (_discoveryFeedItems.value.isEmpty()) {
                    _discoveryFeedItems.value = DiscoveryFeedService.fallbackDirectoryResult(
                        enforceHttps = _httpsEverywhereEnabled.value,
                        enforceAntiScam = _antiScamProtectionEnabled.value
                    ).items
                }
                _feedError.value = "Live feed temporarily unavailable. Showing verified directory."
            } finally {
                _isLoadingFeed.value = false
            }
        }
    }

    fun generateQrSyncSession(ttlSeconds: Int = QrSyncManager.DEFAULT_TTL_SECONDS) {
        val includeBm = _qrSyncIncludeBookmarks.value
        val includeSt = _qrSyncIncludeSettings.value
        if (!includeBm && !includeSt) {
            _qrSyncError.value = "Select Bookmarks or Privacy Settings to encrypt."
            return
        }
        viewModelScope.launch {
            _isGeneratingQrSync.value = true
            _qrSyncError.value = null
            try {
                val snapshotBookmarks = bookmarks.value
                val privacySnapshot = QrSyncPrivacySettings(
                    engineMode = _engineMode.value.name,
                    searchEngineId = _activeSearchEngine.value.id,
                    adblockEnabled = _adblockEnabled.value,
                    fingerprintShieldEnabled = _fingerprintShieldEnabled.value,
                    httpsEverywhereEnabled = _httpsEverywhereEnabled.value,
                    javascriptEnabled = _javascriptEnabled.value,
                    thirdPartyCookiesBlocked = _thirdPartyCookiesBlocked.value,
                    doNotTrackEnabled = _doNotTrackEnabled.value,
                    antiScamProtectionEnabled = _antiScamProtectionEnabled.value,
                    shieldedIpEnabled = _shieldedIpEnabled.value,
                    activeRelayLocation = _activeRelayNode.value.location,
                    cleanStealthMode = _cleanStealthMode.value,
                    suggestionsEnabled = _suggestionsEnabled.value,
                    alwaysIncognito = _alwaysIncognito.value,
                    autoPurgeOnTabClosure = _autoPurgeOnTabClosure.value,
                    selectedUserAgent = _selectedUserAgent.value
                )
                val session = withContext(Dispatchers.Default) {
                    QrSyncManager.generateEncryptedSyncSession(
                        bookmarks = snapshotBookmarks,
                        privacySettings = privacySnapshot,
                        includeBookmarks = includeBm,
                        includeSettings = includeSt,
                        ttlSeconds = ttlSeconds
                    )
                }
                _qrSyncSession.value = session
                appendTerminal(
                    "Generated encrypted QR sync bundle [${session.sessionId}] (${session.bookmarkCount} bookmarks, ${session.payloadBytes} bytes, TTL ${ttlSeconds}s).",
                    "SUCCESS"
                )
            } catch (ce: CancellationException) {
                throw ce
            } catch (ex: Exception) {
                _qrSyncError.value = ex.message ?: "Failed to encrypt QR sync payload."
                appendTerminal("QR sync encryption failed.", "ERROR")
            } finally {
                _isGeneratingQrSync.value = false
            }
        }
    }

    fun invalidateQrSyncSession(reason: String = "QR sync key burned from memory.") {
        val previous = _qrSyncSession.value
        _qrSyncSession.value = null
        _qrSyncError.value = null
        if (previous != null) {
            appendTerminal("QR sync session [${previous.sessionId}] invalidated: $reason", "WARN")
        }
    }

    fun toggleQrSyncIncludeBookmarks(include: Boolean) {
        if (!include && !_qrSyncIncludeSettings.value) {
            _qrSyncError.value = "At least one sync category must remain enabled."
            return
        }
        _qrSyncIncludeBookmarks.value = include
        _qrSyncError.value = null
        if (_qrSyncSession.value != null) {
            generateQrSyncSession()
        }
    }

    fun toggleQrSyncIncludeSettings(include: Boolean) {
        if (!include && !_qrSyncIncludeBookmarks.value) {
            _qrSyncError.value = "At least one sync category must remain enabled."
            return
        }
        _qrSyncIncludeSettings.value = include
        _qrSyncError.value = null
        if (_qrSyncSession.value != null) {
            generateQrSyncSession()
        }
    }

    // Account, Auth Sheet & Cross-Device Sync State
    private val _userEmail = MutableStateFlow(prefs.getString("account_email", "") ?: "")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("account_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _authToken = MutableStateFlow(prefs.getString("account_auth_token", "") ?: "")
    val authToken: StateFlow<String> = _authToken.asStateFlow()

    private val _cloudEndpoint = MutableStateFlow(
        prefs.getString("cloud_sync_endpoint", "https://browser.silentbot.online/api.php")
            ?: "https://browser.silentbot.online/api.php"
    )
    val cloudEndpoint: StateFlow<String> = _cloudEndpoint.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncStatusMessage = MutableStateFlow<String?>(null)
    val syncStatusMessage: StateFlow<String?> = _syncStatusMessage.asStateFlow()

    private val _authUiState = MutableStateFlow(AccountAuthUiState(email = _userEmail.value))
    val authUiState: StateFlow<AccountAuthUiState> = _authUiState.asStateFlow()

    private val _syncConflicts = MutableStateFlow<List<SyncConflictItem>>(emptyList())
    val syncConflicts: StateFlow<List<SyncConflictItem>> = _syncConflicts.asStateFlow()

    private val _showSyncConflictDialog = MutableStateFlow(false)
    val showSyncConflictDialog: StateFlow<Boolean> = _showSyncConflictDialog.asStateFlow()

    fun openSyncConflictDialog() {
        if (_syncConflicts.value.isNotEmpty()) {
            _showSyncConflictDialog.value = true
        }
    }

    fun dismissSyncConflictDialog() {
        _showSyncConflictDialog.value = false
    }

    fun openAccountAuthModal(mode: AuthSheetMode = AuthSheetMode.SIGN_IN) {
        _authUiState.value = _authUiState.value.copy(
            isSheetOpen = true,
            mode = mode,
            email = _authUiState.value.email.ifBlank { _userEmail.value },
            password = "",
            confirmPassword = "",
            isSubmitting = false,
            errorMessage = null
        )
    }

    fun dismissAccountAuthModal() {
        _authUiState.value = _authUiState.value.copy(
            isSheetOpen = false,
            password = "",
            confirmPassword = "",
            isSubmitting = false,
            errorMessage = null
        )
    }

    fun setAuthSheetMode(mode: AuthSheetMode) {
        _authUiState.value = _authUiState.value.copy(
            mode = mode,
            errorMessage = null
        )
    }

    fun updateAuthDisplayName(name: String) {
        _authUiState.value = _authUiState.value.copy(displayName = name, errorMessage = null)
    }

    fun updateAuthEmail(email: String) {
        _authUiState.value = _authUiState.value.copy(email = email, errorMessage = null)
    }

    fun updateAuthPassword(password: String) {
        _authUiState.value = _authUiState.value.copy(password = password, errorMessage = null)
    }

    fun updateAuthConfirmPassword(confirmPassword: String) {
        _authUiState.value = _authUiState.value.copy(confirmPassword = confirmPassword, errorMessage = null)
    }

    fun toggleAuthPasswordVisibility() {
        _authUiState.value = _authUiState.value.copy(isPasswordVisible = !_authUiState.value.isPasswordVisible)
    }

    fun submitAccountAuth() {
        val current = _authUiState.value
        val validationError = SyncConflictResolver.validateAuthInput(current)
        if (validationError != null) {
            _authUiState.value = current.copy(errorMessage = validationError)
            return
        }

        val action = if (current.mode == AuthSheetMode.CREATE_ACCOUNT) "register" else "login"
        val cleanEmail = current.email.trim()
        val endpoint = _cloudEndpoint.value.ifBlank { "https://browser.silentbot.online/api.php" }

        viewModelScope.launch {
            _authUiState.value = _authUiState.value.copy(isSubmitting = true, errorMessage = null)
            _isSyncing.value = true
            _syncStatusMessage.value = if (action == "register") {
                "Creating Silent Cloud Sync account..."
            } else {
                "Signing in to Silent Cloud Sync..."
            }

            val result = withContext(Dispatchers.IO) {
                performAuthRequest(
                    action = action,
                    email = cleanEmail,
                    password = current.password,
                    displayName = current.displayName.trim(),
                    endpoint = endpoint
                )
            }

            if (result.success && !result.token.isNullOrBlank()) {
                applyAuthenticatedSession(cleanEmail, result.token, endpoint)
                _authUiState.value = _authUiState.value.copy(
                    isSheetOpen = false,
                    password = "",
                    confirmPassword = "",
                    isSubmitting = false,
                    errorMessage = null
                )
                _syncStatusMessage.value = if (action == "register") {
                    "Account created! Running initial cloud sync..."
                } else {
                    "Signed in! Running cross-device sync..."
                }
                appendTerminal("Cloud auth ($action) succeeded for $cleanEmail", "SUCCESS")
                _isSyncing.value = false
                syncPushAndPull()
            } else {
                val errMsg = result.error ?: "Authentication failed. Verify credentials and network connection."
                _authUiState.value = _authUiState.value.copy(
                    isSubmitting = false,
                    errorMessage = errMsg
                )
                _syncStatusMessage.value = errMsg
                appendTerminal("Cloud auth ($action) failed: $errMsg", "ERROR")
                _isSyncing.value = false
            }
        }
    }

    fun registerUser(email: String, pass: String, endpoint: String) {
        val cleanEmail = email.trim()
        val targetEndpoint = endpoint.ifBlank { "https://browser.silentbot.online/api.php" }
        if (cleanEmail.isBlank() || pass.length < 6) {
            _syncStatusMessage.value = "Enter a valid email and a password of at least 6 characters."
            return
        }
        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusMessage.value = "Registering cloud account..."
            val result = withContext(Dispatchers.IO) {
                performAuthRequest("register", cleanEmail, pass, "", targetEndpoint)
            }
            if (result.success && !result.token.isNullOrBlank()) {
                applyAuthenticatedSession(cleanEmail, result.token, targetEndpoint)
                _syncStatusMessage.value = "Account created! Starting cross-device sync..."
                appendTerminal("Account registered & signed in: $cleanEmail", "SUCCESS")
                _isSyncing.value = false
                syncPushAndPull()
            } else {
                _syncStatusMessage.value = result.error ?: "Registration failed."
                appendTerminal("Account registration failed: ${result.error}", "ERROR")
                _isSyncing.value = false
            }
        }
    }

    fun loginUser(email: String, pass: String, endpoint: String) {
        val cleanEmail = email.trim()
        val targetEndpoint = endpoint.ifBlank { "https://browser.silentbot.online/api.php" }
        if (cleanEmail.isBlank() || pass.length < 6) {
            _syncStatusMessage.value = "Enter a valid email and password (minimum 6 characters)."
            return
        }
        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusMessage.value = "Authenticating with cloud sync service..."
            val result = withContext(Dispatchers.IO) {
                performAuthRequest("login", cleanEmail, pass, "", targetEndpoint)
            }
            if (result.success && !result.token.isNullOrBlank()) {
                applyAuthenticatedSession(cleanEmail, result.token, targetEndpoint)
                _syncStatusMessage.value = "Signed in! Running cross-device sync..."
                appendTerminal("Signed in to account: $cleanEmail", "SUCCESS")
                _isSyncing.value = false
                syncPushAndPull()
            } else {
                _syncStatusMessage.value = result.error ?: "Sign-in failed."
                appendTerminal("Sign-in failed: ${result.error}", "ERROR")
                _isSyncing.value = false
            }
        }
    }

    private fun applyAuthenticatedSession(email: String, token: String, endpoint: String) {
        _userEmail.value = email
        _authToken.value = token
        _isLoggedIn.value = true
        _cloudEndpoint.value = endpoint
        prefs.edit()
            .putString("account_email", email)
            .putBoolean("account_logged_in", true)
            .putString("account_auth_token", token)
            .putString("cloud_sync_endpoint", endpoint)
            .apply()
    }

    fun logoutUser() {
        val oldToken = _authToken.value
        val endpoint = _cloudEndpoint.value
        _isLoggedIn.value = false
        _userEmail.value = ""
        _authToken.value = ""
        _syncConflicts.value = emptyList()
        _showSyncConflictDialog.value = false
        prefs.edit()
            .putBoolean("account_logged_in", false)
            .putString("account_email", "")
            .putString("account_auth_token", "")
            .apply()
        _syncStatusMessage.value = "Signed out of cloud account."
        appendTerminal("Signed out of cloud account.", "WARN")
        if (oldToken.isNotBlank() && endpoint.isNotBlank()) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val conn = (URL(endpoint.ensureHttp() + "?action=logout").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        setRequestProperty("Authorization", "Bearer $oldToken")
                        connectTimeout = 5000
                        readTimeout = 5000
                    }
                    conn.responseCode
                    conn.disconnect()
                } catch (_: Exception) {}
            }
        }
    }

    fun syncAllData() {
        syncPushAndPull()
    }

    fun syncPushAndPull() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusMessage.value = "Synchronizing bookmarks, history & settings (Local Priority)..."
            try {
                val endpoint = _cloudEndpoint.value
                val token = _authToken.value
                if (token.isBlank() || endpoint.isBlank()) {
                    _syncStatusMessage.value = "Sign in required for cross-device cloud sync."
                    _isSyncing.value = false
                    return@launch
                }

                val localBookmarks = bookmarkDao.getAllBookmarksOnce()
                val localHistory = historyDao.getAllHistoryOnce()
                val timestamp = System.currentTimeMillis()

                val syncResult = withContext(Dispatchers.IO) {
                    performCloudSyncPushPull(endpoint, token, localBookmarks, localHistory, timestamp)
                }

                if (syncResult.success) {
                    val remoteItems = syncResult.remoteItems
                    val detectedConflicts = mutableListOf<SyncConflictItem>()
                    var insertedCount = 0

                    // Include any server-reported timestamp conflicts from push
                    syncResult.pushConflicts.forEach { pc ->
                        val localBm = localBookmarks.find { it.url.equals(pc.url, ignoreCase = true) }
                        if (localBm != null) {
                            detectedConflicts.add(
                                SyncConflictItem(
                                    id = "bookmark:${localBm.url}",
                                    itemType = "bookmark",
                                    url = localBm.url,
                                    localTitle = localBm.title,
                                    localTimestamp = localBm.createdAt,
                                    localFolder = localBm.folder,
                                    localCategory = localBm.category,
                                    localIsPinned = localBm.isPinned,
                                    localVisitCount = localBm.visitCount,
                                    remoteTitle = pc.remoteTitle,
                                    remoteTimestamp = pc.remoteTimestamp
                                )
                            )
                        }
                    }

                    // Reconcile pulled items keeping mobile local storage as strict source of truth on conflicts
                    for (remoteItem in remoteItems) {
                        if (remoteItem.itemType == "bookmark") {
                            val existing = bookmarkDao.getBookmarkByUrl(remoteItem.url)
                            if (existing == null) {
                                bookmarkDao.insertBookmark(
                                    Bookmark(
                                        title = remoteItem.title.ifBlank { remoteItem.url },
                                        url = remoteItem.url,
                                        folder = remoteItem.folder,
                                        category = remoteItem.category,
                                        isPinned = remoteItem.isPinned,
                                        visitCount = remoteItem.visitCount,
                                        createdAt = remoteItem.clientTimestamp
                                    )
                                )
                                insertedCount++
                            } else {
                                val hasDiff = SyncConflictResolver.hasConflictMismatch(
                                    localTitle = existing.title,
                                    localFolder = existing.folder,
                                    localTimestamp = existing.createdAt,
                                    remoteTitle = remoteItem.title,
                                    remoteFolder = remoteItem.folder,
                                    remoteTimestamp = remoteItem.clientTimestamp
                                )
                                if (hasDiff) {
                                    // Preserve mobile-side local storage intact; surface mismatch for visual resolution
                                    val conflictId = "bookmark:${existing.url}"
                                    if (detectedConflicts.none { it.id == conflictId }) {
                                        detectedConflicts.add(
                                            SyncConflictItem(
                                                id = conflictId,
                                                itemType = "bookmark",
                                                url = existing.url,
                                                localTitle = existing.title,
                                                localTimestamp = existing.createdAt,
                                                localFolder = existing.folder,
                                                localCategory = existing.category,
                                                localIsPinned = existing.isPinned,
                                                localVisitCount = existing.visitCount,
                                                remoteTitle = remoteItem.title.ifBlank { existing.title },
                                                remoteTimestamp = remoteItem.clientTimestamp,
                                                remoteFolder = remoteItem.folder,
                                                remoteCategory = remoteItem.category,
                                                remoteIsPinned = remoteItem.isPinned,
                                                remoteVisitCount = remoteItem.visitCount
                                            )
                                        )
                                    }
                                }
                            }
                        } else if (remoteItem.itemType == "history") {
                            val existingHist = localHistory.find { it.url.equals(remoteItem.url, ignoreCase = true) }
                            if (existingHist == null) {
                                historyDao.insertHistory(
                                    HistoryItem(
                                        title = remoteItem.title.ifBlank { remoteItem.url },
                                        url = remoteItem.url,
                                        visitTime = remoteItem.clientTimestamp
                                    )
                                )
                                insertedCount++
                            } else if (
                                SyncConflictResolver.hasConflictMismatch(
                                    localTitle = existingHist.title,
                                    localFolder = "History",
                                    localTimestamp = existingHist.visitTime,
                                    remoteTitle = remoteItem.title,
                                    remoteFolder = "History",
                                    remoteTimestamp = remoteItem.clientTimestamp
                                )
                            ) {
                                val conflictId = "history:${existingHist.url}"
                                if (detectedConflicts.none { it.id == conflictId }) {
                                    detectedConflicts.add(
                                        SyncConflictItem(
                                            id = conflictId,
                                            itemType = "history",
                                            url = existingHist.url,
                                            localTitle = existingHist.title,
                                            localTimestamp = existingHist.visitTime,
                                            localFolder = "History",
                                            localCategory = "History",
                                            remoteTitle = remoteItem.title.ifBlank { existingHist.title },
                                            remoteTimestamp = remoteItem.clientTimestamp,
                                            remoteFolder = "History",
                                            remoteCategory = "History"
                                        )
                                    )
                                }
                            }
                        }
                    }

                    _syncConflicts.value = detectedConflicts
                    _showSyncConflictDialog.value = detectedConflicts.isNotEmpty()
                    val conflictSuffix = if (detectedConflicts.isNotEmpty()) {
                        " • ${detectedConflicts.size} conflict(s) awaiting review (Local preserved)"
                    } else ""
                    _syncStatusMessage.value = "Sync complete: ${localBookmarks.size + insertedCount} items (Local priority)$conflictSuffix"
                    appendTerminal(
                        "Cross-device sync completed: $insertedCount remote items merged, ${detectedConflicts.size} conflict(s) flagged with local source of truth.",
                        "SUCCESS"
                    )
                } else {
                    _syncStatusMessage.value = "Sync failed: ${syncResult.error}"
                    appendTerminal("Cloud sync failed: ${syncResult.error}", "ERROR")
                }
            } catch (e: Exception) {
                _syncStatusMessage.value = "Sync error: ${e.localizedMessage}"
                appendTerminal("Cloud sync error: ${e.localizedMessage}", "ERROR")
            } finally {
                _isSyncing.value = false
            }
        }
    }

    fun resolveSyncConflict(conflictId: String, resolution: SyncConflictResolution) {
        val conflict = _syncConflicts.value.find { it.id == conflictId } ?: return
        val outcome = SyncConflictResolver.resolveConflict(conflict, resolution)

        viewModelScope.launch {
            if (conflict.itemType == "bookmark") {
                val existing = bookmarkDao.getBookmarkByUrl(conflict.url)
                if (existing != null) {
                    bookmarkDao.updateBookmark(
                        existing.copy(
                            title = outcome.winnerTitle,
                            folder = outcome.winnerFolder,
                            category = outcome.winnerCategory,
                            isPinned = outcome.winnerIsPinned,
                            visitCount = outcome.winnerVisitCount,
                            createdAt = outcome.resolvedTimestamp
                        )
                    )
                } else {
                    bookmarkDao.insertBookmark(
                        Bookmark(
                            title = outcome.winnerTitle,
                            url = conflict.url,
                            folder = outcome.winnerFolder,
                            category = outcome.winnerCategory,
                            isPinned = outcome.winnerIsPinned,
                            visitCount = outcome.winnerVisitCount,
                            createdAt = outcome.resolvedTimestamp
                        )
                    )
                }
            } else if (conflict.itemType == "history") {
                historyDao.insertHistory(
                    HistoryItem(
                        title = outcome.winnerTitle,
                        url = conflict.url,
                        visitTime = outcome.resolvedTimestamp
                    )
                )
            }

            if (_isLoggedIn.value && _authToken.value.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    pushSingleResolvedItem(
                        endpoint = _cloudEndpoint.value,
                        token = _authToken.value,
                        itemType = conflict.itemType,
                        url = conflict.url,
                        outcome = outcome
                    )
                }
            }

            val remaining = _syncConflicts.value.filterNot { it.id == conflictId }
            _syncConflicts.value = remaining
            if (remaining.isEmpty()) {
                _showSyncConflictDialog.value = false
            }
            val actionLabel = when (resolution) {
                SyncConflictResolution.KEEP_LOCAL -> "Kept local"
                SyncConflictResolution.USE_REMOTE -> "Applied remote"
                SyncConflictResolution.MERGE -> "Merged"
            }
            _syncStatusMessage.value = "$actionLabel version for ${outcome.winnerTitle}."
            appendTerminal("Sync conflict resolved ($actionLabel): ${conflict.url}", "SUCCESS")
        }
    }

    fun resolveAllSyncConflicts(resolution: SyncConflictResolution = SyncConflictResolution.KEEP_LOCAL) {
        val pending = _syncConflicts.value.toList()
        if (pending.isEmpty()) {
            _showSyncConflictDialog.value = false
            return
        }
        pending.forEach { conflict ->
            resolveSyncConflict(conflict.id, resolution)
        }
        _showSyncConflictDialog.value = false
    }

    private data class AuthHttpResult(
        val success: Boolean,
        val token: String? = null,
        val error: String? = null
    )

    private fun performAuthRequest(
        action: String,
        email: String,
        password: String,
        displayName: String,
        endpoint: String
    ): AuthHttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(endpoint.ensureHttp() + "?action=$action")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("X-Silent-Client", "Android-Native-Production")
                doOutput = true
                connectTimeout = 10000
                readTimeout = 10000
            }
            val payload = JSONObject().apply {
                put("email", email)
                put("password", password)
                if (displayName.isNotBlank()) put("display_name", displayName)
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(body) } catch (_: Exception) { null }

            if (code in 200..299 && json?.optString("status") == "success") {
                val token = json.optString("token", "")
                if (token.isNotBlank()) {
                    AuthHttpResult(success = true, token = token)
                } else {
                    AuthHttpResult(success = false, error = "Server response missing session token.")
                }
            } else {
                val serverMsg = json?.optString("message")?.takeIf { it.isNotBlank() }
                    ?: "Authentication failed (HTTP $code)."
                AuthHttpResult(success = false, error = serverMsg)
            }
        } catch (e: Exception) {
            AuthHttpResult(success = false, error = "Unable to reach cloud sync service: ${e.localizedMessage ?: "Connection error"}")
        } finally {
            conn?.disconnect()
        }
    }

    private data class PushConflictNotice(
        val itemType: String,
        val url: String,
        val remoteTitle: String,
        val remoteTimestamp: Long
    )

    private data class CloudSyncResult(
        val success: Boolean,
        val remoteItems: List<RemoteSyncItem> = emptyList(),
        val pushConflicts: List<PushConflictNotice> = emptyList(),
        val error: String? = null
    )

    private data class RemoteSyncItem(
        val itemType: String,
        val title: String,
        val url: String,
        val folder: String,
        val category: String,
        val isPinned: Boolean,
        val visitCount: Int,
        val clientTimestamp: Long
    )

    private fun pushSingleResolvedItem(
        endpoint: String,
        token: String,
        itemType: String,
        url: String,
        outcome: com.example.data.model.MergedSyncOutcome
    ) {
        try {
            val pushUrl = URL(endpoint.ensureHttp() + "?action=sync_push")
            val conn = (pushUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Authorization", "Bearer $token")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            val body = JSONObject().apply {
                put("items", JSONArray().apply {
                    put(JSONObject().apply {
                        put("item_type", itemType)
                        put("title", outcome.winnerTitle)
                        put("url", url)
                        put("folder", outcome.winnerFolder)
                        put("category", outcome.winnerCategory)
                        put("is_pinned", outcome.winnerIsPinned)
                        put("visit_count", outcome.winnerVisitCount)
                        put("client_timestamp", outcome.resolvedTimestamp)
                        put("force_local", true)
                    })
                })
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            conn.responseCode
            conn.disconnect()
        } catch (_: Exception) {}
    }

    private fun performCloudSyncPushPull(
        endpoint: String,
        token: String,
        bookmarks: List<Bookmark>,
        history: List<HistoryItem>,
        timestamp: Long
    ): CloudSyncResult {
        try {
            val url = URL(endpoint.ensureHttp() + "?action=sync_push")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.doOutput = true
            conn.connectTimeout = 10000
            conn.readTimeout = 10000

            val jsonBody = JSONObject().apply {
                put("settings", JSONObject().apply {
                    put("engine_mode", _engineMode.value.name)
                    put("search_engine_id", _activeSearchEngine.value.id)
                    put("adblock_enabled", _adblockEnabled.value)
                    put("fingerprint_shield", _fingerprintShieldEnabled.value)
                    put("https_everywhere", _httpsEverywhereEnabled.value)
                    put("javascript_enabled", _javascriptEnabled.value)
                    put("block_third_party_cookies", _thirdPartyCookiesBlocked.value)
                    put("dnt_enabled", _doNotTrackEnabled.value)
                    put("anti_scam_enabled", _antiScamProtectionEnabled.value)
                    put("shielded_ip_enabled", _shieldedIpEnabled.value)
                    put("active_relay_location", _activeRelayNode.value.location)
                    put("clean_stealth_mode", _cleanStealthMode.value)
                    put("suggestions_enabled", _suggestionsEnabled.value)
                    put("always_incognito", _alwaysIncognito.value)
                    put("auto_purge_tab_closure", _autoPurgeOnTabClosure.value)
                    put("selected_user_agent", _selectedUserAgent.value)
                    put("client_timestamp", timestamp)
                })
                val itemsArray = JSONArray()
                bookmarks.forEach { bm ->
                    itemsArray.put(JSONObject().apply {
                        put("item_type", "bookmark")
                        put("title", bm.title)
                        put("url", bm.url)
                        put("folder", bm.folder)
                        put("category", bm.category)
                        put("is_pinned", bm.isPinned)
                        put("visit_count", bm.visitCount)
                        put("client_timestamp", bm.createdAt)
                    })
                }
                history.forEach { hist ->
                    itemsArray.put(JSONObject().apply {
                        put("item_type", "history")
                        put("title", hist.title)
                        put("url", hist.url)
                        put("folder", "History")
                        put("category", "History")
                        put("is_pinned", false)
                        put("visit_count", 1)
                        put("client_timestamp", hist.visitTime)
                    })
                }
                put("items", itemsArray)
            }

            conn.outputStream.use { os ->
                os.write(jsonBody.toString().toByteArray(Charsets.UTF_8))
            }

            val responseCode = conn.responseCode
            val pushRespBody = (if (responseCode in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()
            if (responseCode != 200) {
                return CloudSyncResult(false, error = "HTTP $responseCode push error.")
            }

            val pushConflicts = mutableListOf<PushConflictNotice>()
            try {
                val pushJson = JSONObject(pushRespBody)
                val conflictArr = pushJson.optJSONArray("conflicts")
                if (conflictArr != null) {
                    for (i in 0 until conflictArr.length()) {
                        val c = conflictArr.getJSONObject(i)
                        val cUrl = c.optString("url", "")
                        if (cUrl.isNotBlank()) {
                            pushConflicts.add(
                                PushConflictNotice(
                                    itemType = c.optString("item_type", "bookmark"),
                                    url = cUrl,
                                    remoteTitle = c.optString("remote_title", cUrl),
                                    remoteTimestamp = c.optLong("remote_timestamp", 0L)
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {}

            val pullUrl = URL(endpoint.ensureHttp() + "?action=sync_pull")
            val pullConn = pullUrl.openConnection() as HttpURLConnection
            pullConn.requestMethod = "GET"
            pullConn.setRequestProperty("Authorization", "Bearer $token")
            pullConn.connectTimeout = 10000
            pullConn.readTimeout = 10000

            val pullCode = pullConn.responseCode
            if (pullCode != 200) {
                pullConn.disconnect()
                return CloudSyncResult(false, error = "Pull HTTP $pullCode error.")
            }

            val responseString = pullConn.inputStream.bufferedReader().use { it.readText() }
            pullConn.disconnect()
            val jsonResp = JSONObject(responseString)
            val remoteItemsList = mutableListOf<RemoteSyncItem>()
            if (jsonResp.optString("status") == "success") {
                val itemsArr = jsonResp.optJSONArray("items")
                if (itemsArr != null) {
                    for (i in 0 until itemsArr.length()) {
                        val obj = itemsArr.getJSONObject(i)
                        remoteItemsList.add(
                            RemoteSyncItem(
                                itemType = obj.optString("item_type", "bookmark"),
                                title = obj.optString("title", ""),
                                url = obj.optString("url", ""),
                                folder = obj.optString("folder", "Favorites"),
                                category = obj.optString("category", "General"),
                                isPinned = obj.optInt("is_pinned", 0) == 1,
                                visitCount = obj.optInt("visit_count", 0),
                                clientTimestamp = obj.optLong("client_timestamp", System.currentTimeMillis())
                            )
                        )
                    }
                }
            }
            return CloudSyncResult(true, remoteItemsList, pushConflicts)
        } catch (e: Exception) {
            return CloudSyncResult(false, error = e.localizedMessage ?: "Network sync exception")
        }
    }

    // =========================================================================
    // APPLICATION UPDATE & PRODUCT ROADMAP WORKFLOW
    // =========================================================================

    fun checkForAppUpdates(manual: Boolean = true) {
        val current = _appUpdateState.value
        if (current.isChecking) return

        _appUpdateState.value = current.copy(
            isChecking = true,
            status = AppUpdateStatus.CHECKING,
            statusMessage = "Checking ${current.selectedChannel.label} release manifest..."
        )

        viewModelScope.launch {
            val rawJson = DevOpsService.fetchPortalReleasesJson(current.selectedChannel.id)
            val parsed = AppUpdateManager.parseReleaseCatalog(
                rawJson = rawJson,
                currentVersionName = current.currentVersionName,
                currentVersionCode = current.currentVersionCode,
                channel = current.selectedChannel
            )
            val nowMs = System.currentTimeMillis()
            prefs.edit().putLong("last_update_check_ms", nowMs).apply()

            _appUpdateState.value = _appUpdateState.value.copy(
                latestVersionName = parsed.latestVersionName,
                latestVersionCode = parsed.latestVersionCode,
                status = parsed.status,
                isChecking = false,
                lastCheckedEpochMs = nowMs,
                hasLiveFeedResponse = !rawJson.isNullOrBlank(),
                statusMessage = parsed.statusMessage,
                releaseNotes = parsed.releaseNotes,
                futureUpdate = parsed.futureUpdate,
                roadmap = parsed.roadmap,
                platformArtifacts = parsed.platformArtifacts
            )

            if (manual) {
                val logType = if (parsed.status == AppUpdateStatus.UPDATE_AVAILABLE) "SUCCESS" else "INFO"
                appendTerminal("App Update Check: ${parsed.statusMessage}", logType)
            }
        }
    }

    fun setUpdateChannel(channel: UpdateChannel) {
        if (_appUpdateState.value.selectedChannel == channel) return
        prefs.edit().putString("update_channel", channel.id).apply()
        _appUpdateState.value = _appUpdateState.value.copy(
            selectedChannel = channel,
            statusMessage = "Switched release channel to ${channel.label}"
        )
        appendTerminal("Release channel switched to ${channel.label}", "INFO")
        checkForAppUpdates(manual = true)
    }

    fun toggleAutoCheckUpdates(enabled: Boolean) {
        prefs.edit().putBoolean("auto_check_updates", enabled).apply()
        _appUpdateState.value = _appUpdateState.value.copy(autoCheckEnabled = enabled)
        appendTerminal("Auto-check updates on launch: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
    }

    fun toggleNotifyFutureReleases(enabled: Boolean) {
        prefs.edit().putBoolean("notify_future_releases", enabled).apply()
        _appUpdateState.value = _appUpdateState.value.copy(notifyFutureReleases = enabled)
        appendTerminal("Future roadmap preview alerts: ${if (enabled) "ENABLED" else "DISABLED"}", "INFO")
    }

    fun launchStoreUpdate(context: Context) {
        val pkg = BuildConfig.APPLICATION_ID
        val playMarketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val playWebIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=$pkg")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(playMarketIntent)
            appendTerminal("Opened Google Play Store update listing ($pkg).", "SUCCESS")
        } catch (_: Exception) {
            try {
                context.startActivity(playWebIntent)
                appendTerminal("Opened Google Play web update listing.", "INFO")
            } catch (_: Exception) {
                openInExternalApp(context, "${DevOpsService.PRIMARY_WEB_PORTAL_URL}?os=android#downloads")
            }
        }
    }

    fun launchOfficialPortalUpdate(context: Context) {
        openInExternalApp(context, "${DevOpsService.PRIMARY_WEB_PORTAL_URL}?os=android#downloads")
        appendTerminal("Opened official release portal for signed Android build verification.", "INFO")
    }

    fun openReleaseChecksums() {
        openUrl("${DevOpsService.PRIMARY_WEB_PORTAL_URL}releases/SHA256SUMS.txt")
        appendTerminal("Opened SHA256SUMS.txt manifest for build verification.", "INFO")
    }

    private fun String.ensureHttp(): String {
        return if (this.startsWith("http://") || this.startsWith("https://")) this else "https://$this"
    }
}
