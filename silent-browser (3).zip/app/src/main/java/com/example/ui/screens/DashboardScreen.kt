package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Article
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.example.BuildConfig
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import coil.compose.AsyncImage
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.EngineMode
import com.example.data.model.SearchEngine
import com.example.data.network.DiscoveryCategory
import com.example.ui.components.BrowserBottomBar
import com.example.ui.components.CommandHubModal
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun DashboardScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val engineMode by viewModel.engineMode.collectAsState()
    val totalBlocked by viewModel.totalBlockedTrackers.collectAsState()
    val dntHeadersSent by viewModel.dntHeadersSentCount.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val activeTab = viewModel.activeTab
    val activeSearchEngine by viewModel.activeSearchEngine.collectAsState()
    val searchSuggestions by viewModel.searchSuggestions.collectAsState()
    val isFetchingSuggestions by viewModel.isFetchingSuggestions.collectAsState()
    val cleanStealthMode by viewModel.cleanStealthMode.collectAsState()
    val shieldedIpEnabled by viewModel.shieldedIpEnabled.collectAsState()
    val extensions by viewModel.extensions.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val frequentlyVisited by viewModel.frequentlyVisited.collectAsState()
    val pinnedBookmarks by viewModel.pinnedBookmarks.collectAsState()
    val passwords by viewModel.passwords.collectAsState()
    val doNotTrackEnabled by viewModel.doNotTrackEnabled.collectAsState()
    val antiScamEnabled by viewModel.antiScamProtectionEnabled.collectAsState()
    val discoveryFeedItems by viewModel.discoveryFeedItems.collectAsState()
    val selectedFeedCategory by viewModel.selectedFeedCategory.collectAsState()
    val isLoadingFeed by viewModel.isLoadingFeed.collectAsState()
    val feedError by viewModel.feedError.collectAsState()
    val showCommandHubModal by viewModel.showCommandHubModal.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var isEngineAccordionExpanded by remember { mutableStateOf(false) }
    val chevronRotation by animateFloatAsState(
        targetValue = if (isEngineAccordionExpanded) 180f else 0f,
        label = "engine_accordion_chevron"
    )

    val focusManager = LocalFocusManager.current
    val silent = MaterialTheme.silentColors

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = silent.screenBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            BrowserBottomBar(
                openTabsCount = tabs.size,
                isHomeSelected = true,
                isAccountSelected = false,
                onHome = { /* Already on Default Home */ },
                onBookmarks = { viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY) },
                onTabs = { viewModel.navigateTo(ScreenDestination.TABS_OVERVIEW) },
                onAccount = { viewModel.navigateTo(ScreenDestination.ACCOUNT) }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Sticky Header Row + Search / Omnibox + Engine & Action Chips
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header row: Brand + Privacy, Command Hub & Settings quick actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.silent_browser_logo),
                            contentDescription = "Silent Browser Logo",
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .border(1.dp, silent.cardBorder, RoundedCornerShape(9.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "SILENT BROWSER",
                                color = silent.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "v${BuildConfig.VERSION_NAME} · ${engineMode.badge}",
                                color = silent.accentSuccess,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) },
                            modifier = Modifier.size(48.dp).testTag("top_privacy_dashboard_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Shield Status & Privacy Dashboard",
                                tint = if (antiScamEnabled && doNotTrackEnabled) silent.accentSuccess else silent.accentWarning,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (showCommandHubModal) silent.chipSelectedBackground
                                    else silent.chipDefaultBackground
                                )
                                .border(
                                    1.dp,
                                    if (showCommandHubModal) silent.chipSelectedBorder
                                    else silent.chipDefaultBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.toggleCommandHub() }
                                .padding(horizontal = 10.dp, vertical = 10.dp)
                                .testTag("top_command_hub_btn"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Apps,
                                contentDescription = if (showCommandHubModal) "Hide Command Hub" else "Open Command Hub",
                                tint = if (showCommandHubModal) silent.chipSelectedContent else silent.textPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showCommandHubModal) "Hide Hub" else "Hub",
                                color = if (showCommandHubModal) silent.chipSelectedContent else silent.textPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenDestination.SETTINGS) },
                            modifier = Modifier.size(48.dp).testTag("top_browser_settings_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Browser Settings",
                                tint = silent.textPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Pinned Multi-Engine Web Search Bar
                val searchPlaceholder = if (cleanStealthMode && activeSearchEngine.isStealthPrivate) {
                    "Search privately with Silent Search..."
                } else {
                    "Search with ${activeSearchEngine.displayName} or enter URL..."
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        viewModel.onSearchInputChanged(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_search_input"),
                    placeholder = {
                        Text(searchPlaceholder, color = silent.textMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    singleLine = true,
                    textStyle = TextStyle(
                        color = silent.textPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = if (activeTab?.isIncognito == true) CyberPurple else silent.textSecondary
                        )
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isFetchingSuggestions) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = silent.accentSuccess,
                                    strokeWidth = 1.5.dp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        searchQuery = ""
                                        viewModel.clearSuggestions()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = silent.textMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            if (searchQuery.isNotBlank()) {
                                Button(
                                    onClick = {
                                        focusManager.clearFocus()
                                        viewModel.clearSuggestions()
                                        viewModel.openUrl(searchQuery, activeSearchEngine)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (activeTab?.isIncognito == true) CyberPurple else silent.primaryButtonBackground,
                                        contentColor = silent.primaryButtonContent
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .height(34.dp)
                                        .testTag("dashboard_search_go_button")
                                ) {
                                    Text(
                                        "Go",
                                        color = silent.primaryButtonContent,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            if (searchQuery.isNotBlank()) {
                                focusManager.clearFocus()
                                viewModel.clearSuggestions()
                                viewModel.openUrl(searchQuery, activeSearchEngine)
                            }
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (activeTab?.isIncognito == true) CyberPurple else silent.chipSelectedBorder,
                        unfocusedBorderColor = silent.cardBorder,
                        focusedContainerColor = silent.cardBackground,
                        unfocusedContainerColor = silent.cardBackground,
                        focusedTextColor = silent.textPrimary,
                        unfocusedTextColor = silent.textPrimary
                    )
                )

                // Suggestions Dropdown cleanly anchored below top Search bar
                if (searchQuery.isNotBlank() && searchSuggestions.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(silent.cardBackground)
                            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                            .padding(vertical = 4.dp)
                    ) {
                        searchSuggestions.take(5).forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        focusManager.clearFocus()
                                        viewModel.clearSuggestions()
                                        viewModel.openUrl(item.url ?: item.text, activeSearchEngine)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (item.type) {
                                        com.example.data.network.SuggestionType.DIRECT_URL -> Icons.Default.Language
                                        com.example.data.network.SuggestionType.BOOKMARK -> Icons.Default.Bookmark
                                        com.example.data.network.SuggestionType.HISTORY -> Icons.Default.History
                                        else -> Icons.Default.Search
                                    },
                                    contentDescription = null,
                                    tint = silent.accentSuccess,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = item.text,
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = item.sourceEngine,
                                    color = silent.textMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Engine Selection Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SearchEngine.values().forEach { engine ->
                        val isSelected = engine == activeSearchEngine
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) silent.chipSelectedBackground else silent.chipDefaultBackground)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) silent.chipSelectedBorder else silent.chipDefaultBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    viewModel.setSearchEngine(engine)
                                    if (searchQuery.isNotBlank()) {
                                        viewModel.openUrl(searchQuery, engine)
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(engine.iconLetter, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = engine.displayName,
                                    color = if (isSelected) silent.chipSelectedContent else silent.textPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Compact Quick-Action Strip (Back, Forward, Settings, Command Hub & Shortcuts)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .testTag("top_quick_action_strip"),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val hasBrowserHistory = activeTab != null && activeTab.url != "about:blank"
                    if (hasBrowserHistory) {
                        QuickActionPill(
                            label = "Back to Web",
                            icon = Icons.AutoMirrored.Filled.ArrowBack,
                            tint = silent.textSecondary,
                            onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                            modifier = Modifier.testTag("quick_action_back")
                        )
                    }
                    QuickActionPill(
                        label = "Tabs (${tabs.size})",
                        icon = Icons.Default.Tab,
                        tint = silent.textSecondary,
                        onClick = { viewModel.navigateTo(ScreenDestination.TABS_OVERVIEW) },
                        modifier = Modifier.testTag("quick_action_tabs")
                    )
                    QuickActionPill(
                        label = "Private Tab",
                        icon = Icons.Default.VisibilityOff,
                        tint = CyberPurple,
                        onClick = { viewModel.createNewTab(isIncognito = true) },
                        modifier = Modifier.testTag("quick_action_private_tab")
                    )
                    QuickActionPill(
                        label = "Vault (${passwords.size})",
                        icon = Icons.Default.VpnKey,
                        tint = silent.textSecondary,
                        onClick = { viewModel.navigateTo(ScreenDestination.PASSWORD_VAULT) },
                        modifier = Modifier.testTag("quick_action_vault")
                    )
                    QuickActionPill(
                        label = "Extensions (${extensions.count { it.isEnabled }})",
                        icon = Icons.Default.Extension,
                        tint = silent.accentWarning,
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTENSIONS) },
                        modifier = Modifier.testTag("quick_action_extensions")
                    )
                    QuickActionPill(
                        label = "Sync & Net",
                        icon = Icons.Default.Terminal,
                        tint = silent.accentSuccess,
                        onClick = { viewModel.navigateTo(ScreenDestination.DEVOPS_CENTER) },
                        modifier = Modifier.testTag("quick_action_devops")
                    )
                }

                HorizontalDivider(color = silent.barDivider, thickness = 1.dp)
            }

            // Single Bounded Scrollable Feed & Dashboard Area above Bottom Navigation Bar
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. User's Personal Bookmarked Shortcuts & Frequently Visited URLs
                val displayShortcuts = (pinnedBookmarks + frequentlyVisited + bookmarks).distinctBy { it.id }.take(10)
                if (displayShortcuts.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PINNED & FREQUENT (${displayShortcuts.size})",
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Manage Bookmarks",
                                color = silent.accentSuccess,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.clickable { viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY) }
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(displayShortcuts, key = { it.id }) { bookmark ->
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(silent.cardBackground)
                                        .border(
                                            1.dp,
                                            if (bookmark.isPinned) silent.accentSuccess else silent.cardBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.openBookmark(bookmark) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(if (bookmark.isPinned) silent.badgeSuccessBackground else silent.chipDefaultBackground),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = bookmark.title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "B",
                                            color = if (bookmark.isPinned) silent.accentSuccess else silent.textPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = bookmark.title,
                                                color = silent.textPrimary,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1
                                            )
                                            if (bookmark.isPinned) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("★", color = silent.accentSuccess, fontSize = 10.sp)
                                            }
                                        }
                                        Text(
                                            text = bookmark.folder,
                                            color = silent.textMuted,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Latest News & Trending / Viral GitHub & Web Feed
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LATEST NEWS & TRENDING GITHUB",
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = buildString {
                                        append(if (doNotTrackEnabled) "DNT: 1 Enforced" else "Direct Mode")
                                        append(" · ")
                                        append(if (antiScamEnabled) "Anti-Scam Filtered" else "Unfiltered")
                                    },
                                    color = silent.accentSuccess,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(silent.chipDefaultBackground)
                                    .border(1.dp, silent.chipDefaultBorder, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.loadDiscoveryFeed(forceRefresh = true) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("refresh_discovery_feed_btn"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh Feed",
                                    tint = silent.textPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isLoadingFeed) "Syncing..." else "Refresh",
                                    color = silent.textPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Filter Pills
                        FeedFilterChipRow(
                            filters = DiscoveryCategory.values().map { it.label },
                            selectedFilter = selectedFeedCategory.label,
                            onSelectFilter = { selectedLabel ->
                                val category = DiscoveryCategory.values().firstOrNull { it.label == selectedLabel }
                                if (category != null) {
                                    viewModel.selectFeedCategory(category)
                                }
                            },
                            contentPadding = PaddingValues(0.dp)
                        )
                    }
                }

                val visibleFeedItems = if (selectedFeedCategory == DiscoveryCategory.ALL) {
                    discoveryFeedItems
                } else {
                    discoveryFeedItems.filter { it.category == selectedFeedCategory }
                }

                if (!feedError.isNullOrBlank()) {
                    item {
                        CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = feedError ?: "",
                                    color = silent.textSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Retry",
                                    color = silent.accentSuccess,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier
                                        .clickable { viewModel.loadDiscoveryFeed(forceRefresh = true) }
                                        .padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                if (isLoadingFeed && visibleFeedItems.isEmpty()) {
                    item {
                        CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = silent.accentSuccess,
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "Fetching trending GitHub repos & latest tech/privacy news with DNT: 1...",
                                    color = silent.textSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                } else if (visibleFeedItems.isEmpty()) {
                    item {
                        CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = feedError ?: "No items available for ${selectedFeedCategory.label}.",
                                    color = silent.textSecondary,
                                    fontSize = 12.sp
                                )
                                Button(
                                    onClick = { viewModel.loadDiscoveryFeed(forceRefresh = true) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = silent.secondaryButtonBackground,
                                        contentColor = silent.secondaryButtonContent
                                    ),
                                    border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = silent.secondaryButtonContent, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Retry Live Feed", color = silent.secondaryButtonContent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(visibleFeedItems, key = { "${it.category.name}_${it.id}" }) { item ->
                        CyberFeedCard(
                            categoryLabel = item.source,
                            badgeText = item.metricBadge,
                            title = item.title,
                            subtitleOrSnippet = item.subtitle,
                            imageUrl = item.imageUrl,
                            onCardClick = { viewModel.openUrl(item.url) },
                            modifier = Modifier.testTag("discovery_feed_item_${item.id}")
                        )
                    }
                }

                // 3. Live Shield Stats Banner (Tappable to open Privacy Dashboard)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) }
                            .testTag("dashboard_shield_stats_row"),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CyberCard(
                            modifier = Modifier.weight(1f),
                            borderColor = silent.cardBorder,
                            backgroundColor = silent.cardBackground
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("TRACKERS INTERCEPTED", color = silent.textMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$totalBlocked",
                                    color = silent.accentSuccess,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text("Tap for Privacy Dashboard", color = silent.textSecondary, fontSize = 11.sp)
                            }
                        }

                        CyberCard(
                            modifier = Modifier.weight(1f),
                            borderColor = silent.cardBorder,
                            backgroundColor = silent.cardBackground
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("DNT: 1 + PROXY SHIELD", color = silent.textMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (shieldedIpEnabled) "SECURE" else "DIRECT",
                                    color = if (shieldedIpEnabled) silent.accentInfo else silent.accentWarning,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text("DNT headers: $dntHeadersSent", color = silent.textSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // 4. Collapsible Accordion Privacy Engine Profiles
                item {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { isEngineAccordionExpanded = !isEngineAccordionExpanded }
                                .padding(vertical = 4.dp)
                                .testTag("engine_accordion_toggle"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PRIVACY ENGINE PROFILES",
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isEngineAccordionExpanded) "Hide Profiles" else "Switch Profile",
                                    color = silent.accentSuccess,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ExpandMore,
                                    contentDescription = "Expand or Collapse Privacy Engine Profiles",
                                    tint = silent.textSecondary,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .rotate(chevronRotation)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(silent.cardBackground)
                                .border(1.5.dp, silent.chipSelectedBorder, RoundedCornerShape(12.dp))
                                .clickable { isEngineAccordionExpanded = !isEngineAccordionExpanded }
                                .padding(14.dp)
                                .testTag("active_engine_profile_card"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(silent.accentSuccess)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = engineMode.title,
                                        color = silent.textPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    StatusBadge(text = engineMode.badge, color = silent.accentSuccess)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = engineMode.description,
                                    color = silent.textSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = silent.textSecondary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(chevronRotation)
                            )
                        }

                        AnimatedVisibility(
                            visible = isEngineAccordionExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(
                                modifier = Modifier.padding(top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                EngineMode.values().filter { it != engineMode }.forEach { mode ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(silent.cardBackground)
                                            .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
                                            .clickable {
                                                viewModel.setEngineMode(mode)
                                                isEngineAccordionExpanded = false
                                            }
                                            .padding(12.dp)
                                            .testTag("engine_accordion_option_${mode.name}"),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(silent.cardBorder)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = mode.title,
                                                    color = silent.textPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = mode.badge,
                                                    color = silent.textMuted,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                            Text(
                                                text = mode.description,
                                                color = silent.textSecondary,
                                                fontSize = 11.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. Armed Panic Wipe Button (Production Default)
                item {
                    Button(
                        onClick = { viewModel.panicPurge() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("panic_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.panicArmedBackground,
                            contentColor = silent.panicArmedContent
                        ),
                        border = BorderStroke(1.dp, silent.panicArmedBackground),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Panic Purge",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PANIC WIPE (ARMED • AMNESIC PURGE)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = silent.panicArmedContent
                        )
                    }
                }
            }
        }
    }

    if (showCommandHubModal) {
        CommandHubModal(
            viewModel = viewModel,
            onDismiss = { viewModel.closeCommandHub() }
        )
    }
}

@Composable
private fun QuickActionPill(
    label: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(silent.chipDefaultBackground)
            .border(1.dp, silent.chipDefaultBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(13.dp))
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = silent.textPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CyberFeedCard(
    categoryLabel: String,
    badgeText: String,
    title: String,
    subtitleOrSnippet: String,
    imageUrl: String? = null,
    onCardClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    var imageFailed by remember(imageUrl) { mutableStateOf(false) }

    Surface(
        onClick = onCardClick,
        shape = RoundedCornerShape(14.dp),
        color = silent.cardBackground,
        border = BorderStroke(1.dp, silent.cardBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Article,
                        contentDescription = null,
                        tint = silent.accentWarning,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = categoryLabel.uppercase(),
                        color = silent.accentWarning,
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 0.8.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = silent.badgeSuccessBackground,
                        border = BorderStroke(1.dp, silent.badgeSuccessBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(silent.accentSuccess)
                            )
                            Text(
                                text = badgeText.uppercase(),
                                color = silent.accentSuccess,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.6.sp
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                        contentDescription = "Open link",
                        tint = silent.textMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = title,
                        color = silent.textPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 22.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = subtitleOrSnippet,
                        color = silent.textSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (!imageUrl.isNullOrBlank() && !imageFailed) {
                    Box(
                        modifier = Modifier
                            .size(width = 88.dp, height = 66.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(silent.chipDefaultBackground)
                            .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
                    ) {
                        AsyncImage(
                            model = imageUrl,
                            contentDescription = "$title preview",
                            contentScale = ContentScale.Crop,
                            onError = { imageFailed = true },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeedFilterChipRow(
    filters: List<String>,
    selectedFilter: String,
    onSelectFilter: (String) -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp)
) {
    val silent = MaterialTheme.silentColors
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = contentPadding
    ) {
        items(filters, key = { it }) { filter ->
            val isSelected = filter == selectedFilter
            Surface(
                onClick = { onSelectFilter(filter) },
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) silent.chipSelectedBackground else silent.chipDefaultBackground,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isSelected) silent.chipSelectedBorder else silent.chipDefaultBorder
                ),
                modifier = Modifier
                    .heightIn(min = 40.dp)
                    .testTag("feed_filter_$filter")
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = filter,
                        color = if (isSelected) silent.chipSelectedContent else silent.chipDefaultContent,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}
