package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.network.NetworkRequestInterceptor
import com.example.data.privacy.PrivacyEngine
import java.io.ByteArrayInputStream

/**
 * Reusable BrowserWebView component that wraps Android's native WebView,
 * providing URL loading with DNT: 1 header injection, JavaScript execution,
 * tracker/ad & anti-scam/bot interception, fingerprint spoofing injection,
 * third-party cookie isolation, and download handling.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserWebView(
    url: String,
    javascriptEnabled: Boolean = true,
    adblockEnabled: Boolean = true,
    fingerprintEnabled: Boolean = true,
    doNotTrackEnabled: Boolean = true,
    httpsEverywhereEnabled: Boolean = true,
    thirdPartyCookiesBlocked: Boolean = true,
    antiScamEnabled: Boolean = true,
    extensionScripts: String = "",
    userAgent: String = "",
    onProgressChanged: (progress: Int, isLoading: Boolean) -> Unit = { _, _ -> },
    onPageFinished: (url: String, title: String, canGoBack: Boolean, canGoForward: Boolean) -> Unit = { _, _, _, _ -> },
    onBlockedTracker: (String) -> Unit = {},
    onBlockedThreat: (String) -> Unit = {},
    onDntHeaderAttached: () -> Unit = {},
    onDownloadRequested: (url: String, userAgent: String?, contentDisposition: String?, mimeType: String?, contentLength: Long) -> Unit = { _, _, _, _, _ -> },
    onWebViewCreated: (WebView) -> Unit = {},
    backgroundColor: Int = android.graphics.Color.WHITE,
    modifier: Modifier = Modifier
) {
    fun normalizeUrl(rawUrl: String): String {
        return if (httpsEverywhereEnabled && rawUrl.startsWith("http://", ignoreCase = true)) {
            "https://" + rawUrl.substring(7)
        } else {
            rawUrl
        }
    }

    AndroidView(
        modifier = modifier.testTag("browser_webview"),
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(backgroundColor)

                CookieManager.getInstance().setAcceptThirdPartyCookies(this, !thirdPartyCookiesBlocked)

                settings.apply {
                    this.javaScriptEnabled = javascriptEnabled
                    domStorageEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    cacheMode = WebSettings.LOAD_DEFAULT
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        safeBrowsingEnabled = true
                    }

                    if (userAgent.isNotBlank()) {
                        userAgentString = userAgent
                    }
                }

                setDownloadListener { downloadUrl, ua, contentDisposition, mimetype, contentLength ->
                    onDownloadRequested(downloadUrl, ua, contentDisposition, mimetype, contentLength)
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val reqUrl = request?.url?.toString()
                        val decision = PrivacyEngine.evaluateRequest(
                            url = reqUrl,
                            adblockEnabled = adblockEnabled,
                            antiScamEnabled = antiScamEnabled
                        )
                        if (decision.blocked && (
                                decision.category == com.example.data.privacy.RequestBlockCategory.SCAM_PHISHING ||
                                decision.category == com.example.data.privacy.RequestBlockCategory.CRYPTOMINER_BOT
                            )
                        ) {
                            onBlockedThreat(reqUrl ?: decision.host)
                            return WebResourceResponse(
                                "text/html",
                                "UTF-8",
                                ByteArrayInputStream(
                                    "<html><body style='background:#FFFFFF;color:#17231C;font-family:sans-serif;padding:24px;'><div style='border:1px solid #E5EAE7;border-radius:12px;padding:20px;background:#F5F7F6;'><h2 style='color:#B42318;margin-top:0;'>Silent Shield Blocked Threat</h2><p>Intercepted <strong>${decision.category.label}</strong> on host <code>${decision.host}</code>.</p><p style='color:#667085;font-size:13px;'>Rule: ${decision.matchedRule}</p></div></body></html>".toByteArray()
                                )
                            )
                        }
                        if (decision.blocked) {
                            onBlockedTracker(reqUrl ?: decision.host)
                            return WebResourceResponse(
                                "text/plain",
                                "UTF-8",
                                ByteArrayInputStream(ByteArray(0))
                            )
                        }
                        if (doNotTrackEnabled && reqUrl != null && reqUrl.startsWith("http")) {
                            NetworkRequestInterceptor.recordWebViewDntRequest()
                            onDntHeaderAttached()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageStarted(view: WebView?, pageUrl: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, pageUrl, favicon)
                        onProgressChanged(15, true)
                        if (adblockEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.AD_BLOCK_COSMETIC_JS, null)
                        }
                        if (doNotTrackEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.DNT_NETWORK_INTERCEPTOR_JS, null)
                        }
                        if (fingerprintEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.FINGERPRINT_SHIELD_JS, null)
                        }
                        if (extensionScripts.isNotBlank()) {
                            view?.evaluateJavascript(extensionScripts, null)
                        }
                    }

                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        super.onPageFinished(view, pageUrl)
                        onProgressChanged(100, false)
                        onPageFinished(
                            pageUrl ?: "",
                            view?.title ?: "",
                            view?.canGoBack() ?: false,
                            view?.canGoForward() ?: false
                        )
                        if (adblockEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.AD_BLOCK_COSMETIC_JS, null)
                        }
                        if (doNotTrackEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.DNT_NETWORK_INTERCEPTOR_JS, null)
                        }
                        if (fingerprintEnabled) {
                            view?.evaluateJavascript(PrivacyEngine.FINGERPRINT_SHIELD_JS, null)
                        }
                        if (extensionScripts.isNotBlank()) {
                            view?.evaluateJavascript(extensionScripts, null)
                        }
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val urlStr = request?.url?.toString() ?: return false
                        if (antiScamEnabled && PrivacyEngine.isScamOrBotThreat(urlStr)) {
                            onBlockedThreat(urlStr)
                            return true
                        }
                        if (urlStr.startsWith("http://") || urlStr.startsWith("https://")) {
                            val target = normalizeUrl(urlStr)
                            if (doNotTrackEnabled) {
                                val headers = PrivacyEngine.buildPrivacyHeaders(true)
                                NetworkRequestInterceptor.recordWebViewDntRequest()
                                onDntHeaderAttached()
                                view?.loadUrl(target, headers)
                                return true
                            } else if (target != urlStr) {
                                view?.loadUrl(target)
                                return true
                            }
                            return false
                        }
                        if (urlStr.startsWith("about:")) {
                            return false
                        }
                        return try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlStr))
                            ctx.startActivity(intent)
                            true
                        } catch (_: Exception) {
                            true
                        }
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        super.onProgressChanged(view, newProgress)
                        onProgressChanged(newProgress, newProgress < 100)
                    }

                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        super.onReceivedTitle(view, title)
                        if (!title.isNullOrBlank()) {
                            onPageFinished(
                                view?.url ?: "",
                                title,
                                view?.canGoBack() ?: false,
                                view?.canGoForward() ?: false
                            )
                        }
                    }
                }

                onWebViewCreated(this)
                if (url.isNotBlank() && url != "about:blank") {
                    val target = normalizeUrl(url)
                    val headers = PrivacyEngine.buildPrivacyHeaders(doNotTrackEnabled)
                    if (headers.isNotEmpty()) {
                        NetworkRequestInterceptor.recordWebViewDntRequest()
                        onDntHeaderAttached()
                        loadUrl(target, headers)
                    } else {
                        loadUrl(target)
                    }
                }
            }
        },
        update = { webView ->
            onWebViewCreated(webView)
            webView.setBackgroundColor(backgroundColor)
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, !thirdPartyCookiesBlocked)

            if (userAgent.isNotBlank() && webView.settings.userAgentString != userAgent) {
                webView.settings.userAgentString = userAgent
            }
            if (webView.settings.javaScriptEnabled != javascriptEnabled) {
                webView.settings.javaScriptEnabled = javascriptEnabled
            }

            if (url.isNotBlank() && url != webView.url && url != "about:blank") {
                val target = normalizeUrl(url)
                if (target != webView.url) {
                    val headers = PrivacyEngine.buildPrivacyHeaders(doNotTrackEnabled)
                    if (headers.isNotEmpty()) {
                        NetworkRequestInterceptor.recordWebViewDntRequest()
                        onDntHeaderAttached()
                        webView.loadUrl(target, headers)
                    } else {
                        webView.loadUrl(target)
                    }
                }
            }
        }
    )
}
