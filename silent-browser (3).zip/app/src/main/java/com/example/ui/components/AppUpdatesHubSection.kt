package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppUpdateStatus
import com.example.data.model.AppUpdateUiState
import com.example.data.model.ReleasePlatformArtifact
import com.example.data.model.RoadmapMilestone
import com.example.data.model.RoadmapMilestoneStatus
import com.example.data.model.UpdateChannel
import com.example.ui.theme.silentColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class RoadmapFilter(val label: String) {
    ALL("All"),
    SHIPPED("Shipped"),
    IN_PROGRESS("In Progress"),
    UPCOMING("Planned")
}

@Composable
fun CommandHubUpdateSummaryCard(
    updateState: AppUpdateUiState,
    onCheckUpdates: () -> Unit,
    onOpenUpdateCenter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    val badgeColors = resolveUpdateBadgeColors(updateState.status)

    Surface(
        color = silent.cardBackground,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (updateState.isUpdateAvailable) silent.primaryButtonBackground else silent.cardBorder
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("hub_app_update_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = null,
                        tint = if (updateState.isUpdateAvailable) silent.primaryButtonBackground else silent.accentInfo,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "APPLICATION UPDATES & ROADMAP",
                            color = silent.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Installed v${updateState.currentVersionName} (Build ${updateState.currentVersionCode}) • ${updateState.selectedChannel.label}",
                            color = silent.textSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeColors.background)
                        .border(1.dp, badgeColors.border, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = updateState.status.badgeLabel,
                        color = badgeColors.text,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Future Update Available Preview Strip
            Surface(
                color = silent.badgeInfoBackground,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, silent.badgeInfoBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenUpdateCenter() }
                    .testTag("hub_future_update_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = silent.accentInfo,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "FUTURE UPDATE: ${updateState.futureUpdate.versionTag} (${updateState.futureUpdate.readinessPercent}% Ready)",
                                color = silent.accentInfo,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = updateState.futureUpdate.title,
                                color = silent.textPrimary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Open Application Updates and Roadmap",
                        tint = silent.accentInfo,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(
                text = updateState.statusMessage,
                color = silent.textSecondary,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCheckUpdates,
                    enabled = !updateState.isChecking,
                    border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = silent.secondaryButtonBackground,
                        contentColor = silent.secondaryButtonContent
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("hub_quick_check_updates_button")
                ) {
                    if (updateState.isChecking) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = silent.primaryButtonBackground
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Checking...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Check Updates", fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                    }
                }

                Button(
                    onClick = onOpenUpdateCenter,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .heightIn(min = 48.dp)
                        .testTag("hub_open_updates_screen_button")
                ) {
                    Icon(
                        imageVector = if (updateState.isUpdateAvailable) Icons.Default.Download else Icons.Default.RocketLaunch,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (updateState.isUpdateAvailable) "Update Now" else "Updates & Roadmap",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun AppUpdatesHubView(
    updateState: AppUpdateUiState,
    onBack: () -> Unit,
    onClose: () -> Unit,
    onCheckUpdates: () -> Unit,
    onSelectChannel: (UpdateChannel) -> Unit,
    onToggleAutoCheck: (Boolean) -> Unit,
    onToggleFutureAlerts: (Boolean) -> Unit,
    onUpdateViaPlayStore: () -> Unit,
    onUpdateViaOfficialPortal: () -> Unit,
    onVerifyChecksums: () -> Unit,
    onOpenPlatformArtifact: (ReleasePlatformArtifact) -> Unit
) {
    val silent = MaterialTheme.silentColors
    val badgeColors = resolveUpdateBadgeColors(updateState.status)
    var selectedFilter by remember { mutableStateOf(RoadmapFilter.ALL) }
    val filteredMilestones = remember(updateState.roadmap, selectedFilter) {
        when (selectedFilter) {
            RoadmapFilter.ALL -> updateState.roadmap
            RoadmapFilter.SHIPPED -> updateState.roadmap.filter { it.status == RoadmapMilestoneStatus.SHIPPED }
            RoadmapFilter.IN_PROGRESS -> updateState.roadmap.filter { it.status == RoadmapMilestoneStatus.IN_PROGRESS }
            RoadmapFilter.UPCOMING -> updateState.roadmap.filter { it.status == RoadmapMilestoneStatus.UPCOMING }
        }
    }
    val fmt = remember { SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()) }
    val lastCheckedLabel = if (updateState.lastCheckedEpochMs > 0L) {
        fmt.format(Date(updateState.lastCheckedEpochMs))
    } else {
        "Just now"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp)
            .navigationBarsPadding()
            .testTag("app_updates_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("app_updates_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Command Hub",
                        tint = silent.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "APPLICATION UPDATES",
                            color = silent.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeColors.background)
                                .border(1.dp, badgeColors.border, RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = updateState.status.badgeLabel,
                                color = badgeColors.text,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "Release workflow, store updates & product roadmap",
                        color = silent.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("command_hub_close_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close Command Hub", tint = silent.textMuted)
            }
        }

        HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 240.dp, max = 540.dp)
                .testTag("app_updates_lazy_list"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            // 1. Installed Build & Live Update Workflow Card
            item(key = "update_status_card") {
                Surface(
                    color = silent.cardBackground,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (updateState.isUpdateAvailable) silent.primaryButtonBackground else silent.cardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("INSTALLED VERSION", color = silent.textMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = "v${updateState.currentVersionName} (Build ${updateState.currentVersionCode})",
                                    color = silent.textPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("CHANNEL LATEST", color = silent.textMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = "v${updateState.latestVersionName} (Build ${updateState.latestVersionCode})",
                                    color = if (updateState.isUpdateAvailable) silent.accentWarning else silent.accentSuccess,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Last Checked: $lastCheckedLabel",
                                color = silent.textSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = if (updateState.hasLiveFeedResponse) "Live Catalog Synced" else "Local Catalog",
                                color = if (updateState.hasLiveFeedResponse) silent.accentSuccess else silent.textMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = updateState.statusMessage,
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onUpdateViaPlayStore,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .heightIn(min = 48.dp)
                                    .testTag("updates_google_play_button")
                            ) {
                                Icon(Icons.Default.Shop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Update on Play Store", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }

                            OutlinedButton(
                                onClick = onCheckUpdates,
                                enabled = !updateState.isChecking,
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(0.9f)
                                    .heightIn(min = 48.dp)
                                    .testTag("updates_check_now_button")
                            ) {
                                if (updateState.isChecking) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = silent.primaryButtonBackground
                                    )
                                } else {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Check Now", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onUpdateViaOfficialPortal,
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.screenBackground,
                                    contentColor = silent.textPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("updates_official_portal_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Official Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }

                            OutlinedButton(
                                onClick = onVerifyChecksums,
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.screenBackground,
                                    contentColor = silent.textPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("updates_checksum_button")
                            ) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("SHA-256 Sums", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // 2. Future Update Available Preview Card
            item(key = "future_update_preview") {
                val future = updateState.futureUpdate
                Surface(
                    color = silent.badgeInfoBackground,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, silent.badgeInfoBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("updates_future_preview_card")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NewReleases, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "FUTURE UPDATE AVAILABLE • ${future.versionTag}",
                                    color = silent.accentInfo,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "${future.readinessPercent}% Ready",
                                color = silent.accentInfo,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = future.title,
                            color = silent.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = future.summary,
                            color = silent.textSecondary,
                            fontSize = 12.sp
                        )

                        LinearProgressIndicator(
                            progress = { (future.readinessPercent / 100f).coerceIn(0f, 1f) },
                            color = silent.accentInfo,
                            trackColor = silent.cardBackground,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            future.highlights.forEach { bullet ->
                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = silent.accentInfo,
                                        modifier = Modifier.padding(top = 2.dp).size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = bullet, color = silent.textPrimary, fontSize = 11.sp)
                                }
                            }
                        }

                        val isBeta = updateState.selectedChannel == UpdateChannel.BETA
                        Button(
                            onClick = {
                                onSelectChannel(if (isBeta) UpdateChannel.STABLE else UpdateChannel.BETA)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isBeta) silent.accentSuccess else silent.primaryButtonBackground,
                                contentColor = silent.primaryButtonContent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("updates_enroll_beta_button")
                        ) {
                            Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBeta) {
                                    "Enrolled in Early Access Beta (${future.versionTag})"
                                } else {
                                    "Opt Into Early Access Channel (${future.versionTag})"
                                },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 3. Release Channel & Update Automation Controls
            item(key = "channel_and_preferences") {
                Surface(
                    color = silent.cardBackground,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, silent.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "RELEASE CHANNEL & WORKFLOW",
                            color = silent.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            UpdateChannel.entries.forEach { channel ->
                                val selected = updateState.selectedChannel == channel
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) silent.chipSelectedBackground else silent.screenBackground)
                                        .border(
                                            1.dp,
                                            if (selected) silent.chipSelectedBorder else silent.cardBorder,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { onSelectChannel(channel) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                        .testTag("updates_channel_${channel.id}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = channel.label,
                                            color = if (selected) silent.chipSelectedContent else silent.textPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = channel.description,
                                            color = silent.textMuted,
                                            fontSize = 9.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Check on Launch", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("Query release manifest when app starts", color = silent.textSecondary, fontSize = 10.sp)
                            }
                            Switch(
                                checked = updateState.autoCheckEnabled,
                                onCheckedChange = onToggleAutoCheck,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = silent.primaryButtonContent,
                                    checkedTrackColor = silent.accentSuccess
                                ),
                                modifier = Modifier.testTag("updates_auto_check_switch")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Future Release Alerts", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("Show upcoming roadmap versions inside Command Hub", color = silent.textSecondary, fontSize = 10.sp)
                            }
                            Switch(
                                checked = updateState.notifyFutureReleases,
                                onCheckedChange = onToggleFutureAlerts,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = silent.primaryButtonContent,
                                    checkedTrackColor = silent.accentInfo
                                ),
                                modifier = Modifier.testTag("updates_future_alerts_switch")
                            )
                        }
                    }
                }
            }

            // 4. Current Production Release Notes
            item(key = "current_release_notes") {
                Surface(
                    color = silent.cardBackground,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, silent.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "RELEASE NOTES • v${updateState.currentVersionName}",
                            color = silent.accentSuccess,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        updateState.releaseNotes.forEach { note ->
                            Row(verticalAlignment = Alignment.Top) {
                                Text("•", color = silent.accentSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(note, color = silent.textSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 5. Product Roadmap Header + Filter Chips
            item(key = "roadmap_header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("updates_roadmap_section"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "PRODUCT ROADMAP",
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoadmapFilter.entries.forEach { filter ->
                            val selected = selectedFilter == filter
                            Box(
                                modifier = Modifier
                                    .heightIn(min = 40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) silent.chipSelectedBackground else silent.cardBackground)
                                    .border(
                                        1.dp,
                                        if (selected) silent.chipSelectedBorder else silent.cardBorder,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedFilter = filter }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("roadmap_filter_${filter.name.lowercase(Locale.US)}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = filter.label,
                                    color = if (selected) silent.chipSelectedContent else silent.textSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 6. Roadmap Milestone Cards
            itemsIndexed(
                items = filteredMilestones,
                key = { _, item -> item.id }
            ) { index, milestone ->
                RoadmapMilestoneCard(milestone = milestone, index = index)
            }

            // 7. Cross-Platform Downloads Row
            item(key = "platform_artifacts") {
                Surface(
                    color = silent.cardBackground,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, silent.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "CROSS-PLATFORM RELEASES",
                            color = silent.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            updateState.platformArtifacts.forEach { artifact ->
                                Box(
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(silent.screenBackground)
                                        .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                                        .clickable { onOpenPlatformArtifact(artifact) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column {
                                        Text(
                                            text = artifact.displayName,
                                            color = silent.textPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = artifact.sizeLabel,
                                            color = silent.textMuted,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoadmapMilestoneCard(
    milestone: RoadmapMilestone,
    index: Int
) {
    val silent = MaterialTheme.silentColors
    val (accent, badgeBg, badgeBorder) = when (milestone.status) {
        RoadmapMilestoneStatus.SHIPPED -> Triple(silent.accentSuccess, silent.badgeSuccessBackground, silent.badgeSuccessBorder)
        RoadmapMilestoneStatus.IN_PROGRESS -> Triple(silent.accentInfo, silent.badgeInfoBackground, silent.badgeInfoBorder)
        RoadmapMilestoneStatus.UPCOMING -> Triple(silent.accentWarning, silent.badgeWarningBackground, silent.badgeWarningBorder)
    }

    Surface(
        color = silent.cardBackground,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, badgeBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("roadmap_milestone_$index")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeBg)
                            .border(1.dp, badgeBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = milestone.versionTag,
                            color = accent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = milestone.targetWindow,
                        color = silent.textMuted,
                        fontSize = 10.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(badgeBg)
                        .border(1.dp, badgeBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = milestone.status.label,
                        color = accent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Text(
                text = milestone.title,
                color = silent.textPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = milestone.summary,
                color = silent.textSecondary,
                fontSize = 11.sp
            )

            LinearProgressIndicator(
                progress = { (milestone.progressPercent / 100f).coerceIn(0f, 1f) },
                color = accent,
                trackColor = silent.screenBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            if (milestone.highlights.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    milestone.highlights.forEach { h ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(h, color = silent.textSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

private data class UpdateBadgePalette(
    val background: Color,
    val border: Color,
    val text: Color
)

@Composable
private fun resolveUpdateBadgeColors(status: AppUpdateStatus): UpdateBadgePalette {
    val silent = MaterialTheme.silentColors
    return when (status) {
        AppUpdateStatus.UP_TO_DATE -> UpdateBadgePalette(
            background = silent.badgeSuccessBackground,
            border = silent.badgeSuccessBorder,
            text = silent.accentSuccess
        )
        AppUpdateStatus.UPDATE_AVAILABLE -> UpdateBadgePalette(
            background = silent.badgeWarningBackground,
            border = silent.badgeWarningBorder,
            text = silent.accentWarning
        )
        AppUpdateStatus.FUTURE_PREVIEW, AppUpdateStatus.CHECKING -> UpdateBadgePalette(
            background = silent.badgeInfoBackground,
            border = silent.badgeInfoBorder,
            text = silent.accentInfo
        )
        AppUpdateStatus.CHECK_FAILED -> UpdateBadgePalette(
            background = silent.chipDefaultBackground,
            border = silent.cardBorder,
            text = silent.textMuted
        )
    }
}
