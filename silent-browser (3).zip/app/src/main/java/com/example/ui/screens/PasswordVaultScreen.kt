package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PasswordEntry
import com.example.data.security.CryptoVault
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordVaultScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val passwords by viewModel.passwords.collectAsState()
    val autofillEnabled by viewModel.autofillEnabled.collectAsState()
    val activeTab = viewModel.activeTab

    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var entryToEdit by remember { mutableStateOf<PasswordEntry?>(null) }
    var showGeneratorDialog by remember { mutableStateOf(false) }
    var showClearVaultDialog by remember { mutableStateOf(false) }

    // Add Form Fields
    var addDomain by remember { mutableStateOf("") }
    var addTitle by remember { mutableStateOf("") }
    var addUsername by remember { mutableStateOf("") }
    var addPassword by remember { mutableStateOf("") }
    var addNotes by remember { mutableStateOf("") }

    // Password Generator State
    var genLength by remember { mutableFloatStateOf(18f) }
    val genUpper = true
    val genLower = true
    var genDigits by remember { mutableStateOf(true) }
    var genSymbols by remember { mutableStateOf(true) }
    var generatedPassword by remember {
        mutableStateOf(CryptoVault.generateStrongPassword(18, true, true, true, true))
    }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = silent.accentSuccess
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "ENCRYPTED PASSWORD VAULT",
                            color = silent.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "AES-256 GCM • Hardware Protected",
                            color = silent.accentSuccess,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                generatedPassword = CryptoVault.generateStrongPassword(
                                    genLength.toInt(), genUpper, genLower, genDigits, genSymbols
                                )
                                showGeneratorDialog = true
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.Casino, contentDescription = "Password Generator", tint = CyberPurple)
                        }

                        IconButton(
                            onClick = {
                                val currentUrl = activeTab?.url ?: ""
                                addDomain = if (currentUrl != "about:blank" && currentUrl.isNotBlank()) {
                                    viewModel.extractCleanDomain(currentUrl)
                                } else ""
                                addTitle = if (addDomain.isNotBlank()) "$addDomain Account" else ""
                                addUsername = ""
                                addPassword = ""
                                addNotes = ""
                                showAddDialog = true
                            },
                            modifier = Modifier.size(48.dp).testTag("add_password_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Password", tint = silent.accentSuccess)
                        }
                    }
                }

                CyberCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    borderColor = silent.cardBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Browser Auto-Fill Engine", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Injects credentials into login forms", color = silent.textMuted, fontSize = 10.sp)
                                }
                            }
                            Switch(
                                checked = autofillEnabled,
                                onCheckedChange = { viewModel.toggleAutofill(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = silent.primaryButtonContent,
                                    checkedTrackColor = silent.accentSuccess,
                                    uncheckedThumbColor = silent.textMuted,
                                    uncheckedTrackColor = silent.chipDefaultBackground
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(text = "${passwords.size} STORED VAULT LOGINS", color = silent.accentSuccess)
                            StatusBadge(text = "ZERO PLAINTEXT LEAKS", color = CyberPurple)
                        }
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("vault_search_input"),
                    placeholder = { Text("Search by domain, username, or account...", color = silent.textMuted, fontSize = 12.sp) },
                    singleLine = true,
                    textStyle = TextStyle(color = silent.textPrimary, fontSize = 13.sp),
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(16.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = silent.textMuted, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = silent.accentSuccess,
                        unfocusedBorderColor = silent.cardBorder,
                        focusedContainerColor = silent.cardBackground,
                        unfocusedContainerColor = silent.cardBackground
                    )
                )
            }
        }
    ) { paddingValues ->
        val filteredPasswords = passwords.filter {
            it.domain.contains(searchQuery, ignoreCase = true) ||
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.username.contains(searchQuery, ignoreCase = true)
        }

        if (filteredPasswords.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .navigationBarsPadding()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = silent.textMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No credentials matching '$searchQuery'"
                        else "No passwords stored in encrypted vault.\nAdd accounts here to enable 1-tap browser auto-fill.",
                        color = silent.textSecondary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val currentUrl = activeTab?.url ?: ""
                            addDomain = if (currentUrl != "about:blank" && currentUrl.isNotBlank()) {
                                viewModel.extractCleanDomain(currentUrl)
                            } else ""
                            addTitle = if (addDomain.isNotBlank()) "$addDomain Account" else ""
                            addUsername = ""
                            addPassword = ""
                            addNotes = ""
                            showAddDialog = true
                        },
                        modifier = Modifier.heightIn(min = 48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.primaryButtonBackground,
                            contentColor = silent.primaryButtonContent
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save New Login", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredPasswords, key = { it.id }) { entry ->
                    CredentialCard(
                        entry = entry,
                        viewModel = viewModel,
                        context = context,
                        onEdit = {
                            entryToEdit = entry
                            showEditDialog = true
                        },
                        onDelete = { viewModel.deletePassword(entry) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { showClearVaultDialog = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = silent.accentError),
                        border = BorderStroke(1.dp, silent.accentError.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = silent.accentError, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Purge Entire Password Vault", color = silent.accentError, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // 1. ADD CREDENTIAL DIALOG
    if (showAddDialog) {
        var isPasswordVisible by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("SAVE ENCRYPTED LOGIN", color = silent.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = addDomain,
                        onValueChange = { addDomain = it },
                        label = { Text("Domain / Website (e.g. github.com)", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = addTitle,
                        onValueChange = { addTitle = it },
                        label = { Text("Account Label", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = addUsername,
                        onValueChange = { addUsername = it },
                        label = { Text("Username or Email", color = silent.textSecondary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = addPassword,
                        onValueChange = { addPassword = it },
                        label = { Text("Password", color = silent.textSecondary) },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle Visibility",
                                        tint = silent.textMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(onClick = {
                                    addPassword = CryptoVault.generateStrongPassword(16, true, true, true, true)
                                }) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = "Generate", tint = CyberPurple, modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = addNotes,
                        onValueChange = { addNotes = it },
                        label = { Text("Notes (Optional: 2FA, Security Questions)", color = silent.textSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (addDomain.isNotBlank() && addPassword.isNotBlank()) {
                            viewModel.savePassword(
                                domain = addDomain,
                                title = addTitle.ifBlank { addDomain },
                                username = addUsername,
                                passwordPlain = addPassword,
                                notes = addNotes
                            )
                            showAddDialog = false
                            Toast.makeText(context, "Encrypted & saved for $addDomain", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Domain and Password are required", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Save & Encrypt", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // 2. EDIT CREDENTIAL DIALOG
    entryToEdit?.let { entry ->
        if (showEditDialog) {
            var editDomain by remember { mutableStateOf(entry.domain) }
            var editTitle by remember { mutableStateOf(entry.title) }
            var editUsername by remember { mutableStateOf(entry.username) }
            var editPassword by remember { mutableStateOf(viewModel.getDecryptedPassword(entry)) }
            var editNotes by remember { mutableStateOf(entry.notes) }
            var isPassVisible by remember { mutableStateOf(false) }

            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                containerColor = silent.cardBackground,
                title = {
                    Text("EDIT CREDENTIAL", color = silent.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = editDomain,
                            onValueChange = { editDomain = it },
                            label = { Text("Domain", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editTitle,
                            onValueChange = { editTitle = it },
                            label = { Text("Title", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editUsername,
                            onValueChange = { editUsername = it },
                            label = { Text("Username / Email", color = silent.textSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editPassword,
                            onValueChange = { editPassword = it },
                            label = { Text("Password", color = silent.textSecondary) },
                            singleLine = true,
                            visualTransformation = if (isPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { isPassVisible = !isPassVisible }) {
                                    Icon(
                                        imageVector = if (isPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle",
                                        tint = silent.textMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )

                        OutlinedTextField(
                            value = editNotes,
                            onValueChange = { editNotes = it },
                            label = { Text("Notes", color = silent.textSecondary) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = silent.accentSuccess,
                                unfocusedBorderColor = silent.cardBorder,
                                focusedContainerColor = silent.screenBackground,
                                unfocusedContainerColor = silent.screenBackground
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.updatePasswordEntry(
                                id = entry.id,
                                domain = editDomain,
                                title = editTitle,
                                username = editUsername,
                                passwordPlain = editPassword,
                                notes = editNotes
                            )
                            showEditDialog = false
                            Toast.makeText(context, "Credential updated", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.primaryButtonBackground,
                            contentColor = silent.primaryButtonContent
                        )
                    ) {
                        Text("Update", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDialog = false }) {
                        Text("Cancel", color = silent.textSecondary)
                    }
                }
            )
        }
    }

    // 3. SECURE PASSWORD GENERATOR DIALOG
    if (showGeneratorDialog) {
        AlertDialog(
            onDismissRequest = { showGeneratorDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Casino, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PASSWORD GENERATOR", color = CyberPurple, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(silent.screenBackground)
                            .border(1.dp, CyberPurple, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = generatedPassword,
                            color = silent.accentSuccess,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    val entropy = CryptoVault.calculateEntropyScore(generatedPassword)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Security Strength:", color = silent.textSecondary, fontSize = 11.sp)
                        Text(
                            text = if (entropy >= 80) "EXTREME ($entropy/100)" else "MODERATE ($entropy/100)",
                            color = if (entropy >= 80) silent.accentSuccess else silent.accentWarning,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text("Length: ${genLength.toInt()} characters", color = silent.textPrimary, fontSize = 12.sp)
                    Slider(
                        value = genLength,
                        onValueChange = {
                            genLength = it
                            generatedPassword = CryptoVault.generateStrongPassword(it.toInt(), genUpper, genLower, genDigits, genSymbols)
                        },
                        valueRange = 8f..32f,
                        steps = 24,
                        colors = SliderDefaults.colors(thumbColor = CyberPurple, activeTrackColor = CyberPurple)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Include Symbols (!@#$)", color = silent.textSecondary, fontSize = 11.sp)
                        Switch(
                            checked = genSymbols,
                            onCheckedChange = {
                                genSymbols = it
                                generatedPassword = CryptoVault.generateStrongPassword(genLength.toInt(), genUpper, genLower, genDigits, it)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = CyberPurple)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Include Numbers (0-9)", color = silent.textSecondary, fontSize = 11.sp)
                        Switch(
                            checked = genDigits,
                            onCheckedChange = {
                                genDigits = it
                                generatedPassword = CryptoVault.generateStrongPassword(genLength.toInt(), genUpper, genLower, it, genSymbols)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = CyberPurple)
                        )
                    }

                    Button(
                        onClick = {
                            generatedPassword = CryptoVault.generateStrongPassword(genLength.toInt(), genUpper, genLower, genDigits, genSymbols)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.secondaryButtonBackground,
                            contentColor = CyberPurple
                        ),
                        border = BorderStroke(1.dp, CyberPurple)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = CyberPurple, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Regenerate", color = CyberPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Generated Password", generatedPassword))
                        showGeneratorDialog = false
                        Toast.makeText(context, "Generated password copied to clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPurple, contentColor = Color.White)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy Password", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGeneratorDialog = false }) {
                    Text("Close", color = silent.textSecondary)
                }
            }
        )
    }

    // 4. CLEAR ALL PASSWORDS DIALOG
    if (showClearVaultDialog) {
        AlertDialog(
            onDismissRequest = { showClearVaultDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text("PURGE ALL PASSWORDS?", color = silent.accentError, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            },
            text = {
                Text("This will permanently remove all encrypted credentials from your device. This cannot be undone.", color = silent.textSecondary, fontSize = 12.sp)
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllPasswords()
                        showClearVaultDialog = false
                        Toast.makeText(context, "Password vault purged completely.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.panicArmedBackground,
                        contentColor = silent.panicArmedContent
                    )
                ) {
                    Text("Purge All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearVaultDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun CredentialCard(
    entry: PasswordEntry,
    viewModel: BrowserViewModel,
    context: Context,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    var isRevealed by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(silent.badgeSuccessBackground)
                            .border(1.dp, silent.badgeSuccessBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val initial = entry.domain.firstOrNull()?.uppercaseChar()?.toString() ?: "P"
                        Text(
                            text = initial,
                            color = silent.accentSuccess,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = entry.title,
                            color = silent.textPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = entry.domain,
                            color = silent.accentInfo,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.openUrl(entry.domain) }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Launch", tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                    }

                    Box {
                        IconButton(onClick = { showMenu = true }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = silent.textMuted, modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(silent.cardBackground)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Edit Credential", color = silent.textPrimary, fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(16.dp)) },
                                onClick = {
                                    showMenu = false
                                    onEdit()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Credential", color = silent.accentError, fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = silent.accentError, modifier = Modifier.size(16.dp)) },
                                onClick = {
                                    showMenu = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Username Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(silent.screenBackground)
                    .border(1.dp, silent.cardBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("USERNAME", color = silent.textMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = entry.username.ifBlank { "No username" },
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Username", entry.username))
                        Toast.makeText(context, "Username copied!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Username", tint = silent.accentInfo, modifier = Modifier.size(15.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Password Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(silent.screenBackground)
                    .border(1.dp, silent.cardBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("PASSWORD (ENCRYPTED)", color = silent.textMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = if (isRevealed) viewModel.getDecryptedPassword(entry) else "••••••••••••",
                        color = if (isRevealed) silent.accentSuccess else silent.textPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { isRevealed = !isRevealed }, modifier = Modifier.size(48.dp)) {
                        Icon(
                            imageVector = if (isRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Visibility",
                            tint = if (isRevealed) silent.accentSuccess else silent.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            val decrypted = viewModel.getDecryptedPassword(entry)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Password", decrypted))
                            Toast.makeText(context, "Password copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Password", tint = silent.accentSuccess, modifier = Modifier.size(15.dp))
                    }
                }
            }

            if (entry.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Notes: ${entry.notes}",
                    color = silent.textMuted,
                    fontSize = 10.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
