package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NorthWest
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrowserTab
import com.example.data.model.SearchEngine
import com.example.data.network.SearchSuggestion
import com.example.data.network.SuggestionType
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.silentColors

@Composable
fun Omnibox(
    activeTab: BrowserTab?,
    openTabsCount: Int,
    currentSearchEngine: SearchEngine,
    suggestions: List<SearchSuggestion>,
    isFetchingSuggestions: Boolean,
    isIncognito: Boolean = false,
    cleanStealthMode: Boolean = true,
    onToggleIncognito: () -> Unit = {},
    onSearchEngineSelected: (SearchEngine) -> Unit,
    onUrlSubmit: (String) -> Unit,
    onSearchWithEngine: (query: String, engine: SearchEngine) -> Unit,
    onQueryChanged: (String) -> Unit,
    onClearSuggestions: () -> Unit,
    onReload: () -> Unit,
    onOpenDashboard: () -> Unit,
    onOpenTabsOverview: () -> Unit,
    onOpenMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val silent = MaterialTheme.silentColors
    var textInput by remember { mutableStateOf(activeTab?.url ?: "") }
    var isFocused by remember { mutableStateOf(false) }
    var showEngineMenu by remember { mutableStateOf(false) }

    LaunchedEffect(activeTab?.url) {
        if (!isFocused) {
            textInput = activeTab?.url ?: ""
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(silent.topBarSurface)
    ) {
        // Incognito Banner
        if (isIncognito) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberPurple.copy(alpha = 0.2f))
                    .padding(horizontal = 12.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VisibilityOff,
                        contentDescription = null,
                        tint = CyberPurple,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "INCOGNITO MODE (Zero History • Auto-Purge Cookies on Close)",
                        color = CyberPurple,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "AMNESIC",
                    color = silent.accentSuccess,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Dashboard Shortcut button
            IconButton(
                onClick = onOpenDashboard,
                modifier = Modifier
                    .size(42.dp)
                    .testTag("dashboard_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Dashboard,
                    contentDescription = "Silent Dashboard",
                    tint = silent.primaryButtonBackground,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Incognito Quick Toggle Button
            IconButton(
                onClick = onToggleIncognito,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isIncognito) CyberPurple.copy(alpha = 0.2f) else Color.Transparent)
                    .border(
                        width = 1.dp,
                        color = if (isIncognito) CyberPurple else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .testTag("incognito_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Incognito Private Mode",
                    tint = if (isIncognito) CyberPurple else silent.textMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Center Omnibox Search/URL Bar
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(silent.cardBackground)
                    .border(
                        width = 1.dp,
                        color = if (isFocused) (if (isIncognito) CyberPurple else silent.primaryButtonBackground) else (if (isIncognito) CyberPurple.copy(alpha = 0.6f) else silent.cardBorder),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Search Engine Picker Pill
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(currentSearchEngine.brandColorHex).copy(alpha = 0.16f))
                            .clickable { showEngineMenu = true }
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentSearchEngine.iconLetter,
                            color = Color(currentSearchEngine.brandColorHex),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Switch Engine",
                            tint = Color(currentSearchEngine.brandColorHex),
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showEngineMenu,
                        onDismissRequest = { showEngineMenu = false },
                        modifier = Modifier.background(silent.topBarSurface)
                    ) {
                        SearchEngine.values().forEach { engine ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(engine.iconLetter, fontSize = 14.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = engine.displayName,
                                            color = if (engine == currentSearchEngine) silent.primaryButtonBackground else silent.textPrimary,
                                            fontWeight = if (engine == currentSearchEngine) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                },
                                onClick = {
                                    onSearchEngineSelected(engine)
                                    showEngineMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Text Field Input
                BasicTextField(
                    value = textInput,
                    onValueChange = {
                        textInput = it
                        onQueryChanged(it)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { focusState ->
                            isFocused = focusState.isFocused
                            if (focusState.isFocused) {
                                onQueryChanged(textInput)
                            } else {
                                onClearSuggestions()
                            }
                        }
                        .testTag("omnibox_input"),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = silent.textPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    cursorBrush = SolidColor(silent.primaryButtonBackground),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            focusManager.clearFocus()
                            onClearSuggestions()
                            onUrlSubmit(textInput)
                        }
                    ),
                    decorationBox = { innerTextField ->
                        if (textInput.isEmpty()) {
                            val placeholderText = if (isIncognito) {
                                "Private Incognito Search..."
                            } else if (cleanStealthMode && currentSearchEngine == SearchEngine.SILENT_STEALTH) {
                                "Search privately with Silent Search..."
                            } else {
                                "Search with ${currentSearchEngine.displayName}..."
                            }
                            Text(
                                text = placeholderText,
                                color = silent.textMuted,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        innerTextField()
                    }
                )

                if (isFetchingSuggestions) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = silent.primaryButtonBackground,
                        strokeWidth = 1.5.dp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }

                if (isFocused && textInput.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            textInput = ""
                            onQueryChanged("")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = silent.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = onReload,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload",
                            tint = silent.primaryButtonBackground,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Tab count button
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(silent.cardBackground)
                    .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                    .clickable { onOpenTabsOverview() }
                    .testTag("tabs_overview_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$openTabsCount",
                    color = silent.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Menu button
            IconButton(
                onClick = onOpenMenu,
                modifier = Modifier
                    .size(42.dp)
                    .testTag("browser_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Browser Menu",
                    tint = silent.textPrimary
                )
            }
        }

        // Fast Multi-Engine Search Row
        AnimatedVisibility(
            visible = isFocused && textInput.isNotBlank(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.cardBackground)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Search in:", color = silent.textMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                    SearchEngine.values().forEach { engine ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(engine.brandColorHex).copy(alpha = 0.16f))
                                .border(1.dp, Color(engine.brandColorHex).copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                                .clickable {
                                    focusManager.clearFocus()
                                    onClearSuggestions()
                                    onSearchWithEngine(textInput, engine)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(engine.iconLetter, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = engine.displayName,
                                    color = Color(engine.brandColorHex),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Real-Time Search Suggestions Overlay Card
        AnimatedVisibility(
            visible = isFocused && suggestions.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.screenBackground)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                CyberCard(
                    borderColor = silent.cardBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REAL-TIME SUGGESTIONS",
                                color = silent.primaryButtonBackground,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${suggestions.size} matches",
                                color = silent.textMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        HorizontalDivider(color = silent.barDivider, thickness = 0.5.dp)

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp)
                        ) {
                            itemsIndexed(suggestions) { index, item ->
                                val (icon, iconTint) = when (item.type) {
                                    SuggestionType.DIRECT_URL -> Pair(Icons.Default.Language, silent.accentInfo)
                                    SuggestionType.BOOKMARK -> Pair(Icons.Default.Bookmark, silent.accentSuccess)
                                    SuggestionType.HISTORY -> Pair(Icons.Default.History, CyberBlue)
                                    SuggestionType.QUERY -> Pair(Icons.Default.Search, silent.textSecondary)
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            focusManager.clearFocus()
                                            onClearSuggestions()
                                            onUrlSubmit(item.url ?: item.text)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("suggestion_item_$index"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = iconTint,
                                        modifier = Modifier.size(16.dp)
                                    )

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.text,
                                            color = silent.textPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = if (item.type == SuggestionType.QUERY) FontWeight.Normal else FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (item.url != null && item.url != item.text) {
                                            Text(
                                                text = item.url,
                                                color = silent.textMuted,
                                                fontSize = 10.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    StatusBadge(
                                        text = item.sourceEngine,
                                        color = when (item.type) {
                                            SuggestionType.BOOKMARK -> silent.accentSuccess
                                            SuggestionType.HISTORY -> CyberBlue
                                            SuggestionType.DIRECT_URL -> silent.accentInfo
                                            SuggestionType.QUERY -> CyberOrange
                                        }
                                    )

                                    Spacer(modifier = Modifier.width(6.dp))

                                    IconButton(
                                        onClick = {
                                            textInput = item.text
                                            onQueryChanged(item.text)
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.NorthWest,
                                            contentDescription = "Refine Query",
                                            tint = silent.textMuted,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
