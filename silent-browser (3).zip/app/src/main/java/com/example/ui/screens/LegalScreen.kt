package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

private data class LegalClause(
    val number: String,
    val title: String,
    val body: String,
    val highlightTag: String? = null
)

private object LocalLegalDocumentStore {
    val termsOfService = listOf(
        LegalClause(
            number = "01",
            title = "Acceptance of Production Terms",
            body = "By accessing or using Silent Browser (Release v1.0.0), published by Silent Bot LLC (Silentbot.online), you agree to be bound by these Terms of Service. Silent Browser is engineered as a privacy-focused user agent designed to minimize tracking, manage local credentials, and support user-controlled network privacy settings.",
            highlightTag = "EFFECTIVE 2026"
        ),
        LegalClause(
            number = "02",
            title = "Authorized Use & Security Boundaries",
            body = "You agree to use Silent Browser strictly for lawful internet browsing, security research, and private communications. Automated abuse, credential stuffing, unauthorized intrusion testing, or redistribution of malicious payloads is strictly prohibited."
        ),
        LegalClause(
            number = "03",
            title = "Local Encrypted Vault Responsibility",
            body = "Credentials stored inside the Silent Password Vault are encrypted on-device using AES-256-GCM authenticated encryption. Silent Bot LLC never transmits, stores, or holds recovery keys for your encrypted passwords. You remain solely responsible for maintaining device security and backups.",
            highlightTag = "AES-256 LOCAL"
        ),
        LegalClause(
            number = "04",
            title = "WebExtensions & Third-Party Content",
            body = "Silent Browser allows execution of compatible content scripts and extensions as well as navigation to external websites. Third-party sites and user-installed scripts operate independently under their own respective terms. Silent Shield blocks known trackers and phishing patterns on a best-effort basis."
        ),
        LegalClause(
            number = "05",
            title = "Warranty Disclaimer & Support",
            body = "Silent Browser is provided 'AS IS' under the GPL-3.0 Core open-source architecture without express or implied warranties of uninterrupted uptime across third-party relay endpoints. Official support is available via silentbrowser@silentbot.online."
        )
    )

    val privacyPolicy = listOf(
        LegalClause(
            number = "01",
            title = "No First-Party Behavioral Ad Telemetry",
            body = "Silent Browser does not collect behavioral advertising analytics or sell browsing histories. Search queries go only to your chosen search engine, and optional Cloud Sync or AI privacy checks transmit data only when you explicitly invoke them.",
            highlightTag = "MINIMAL DATA"
        ),
        LegalClause(
            number = "02",
            title = "Automatic Do Not Track (DNT: 1) & Sec-GPC",
            body = "Our built-in Network Request Interceptor appends 'DNT: 1' and 'Sec-GPC: 1' headers to outgoing browser requests when enabled, signaling privacy opt-out preferences to web servers.",
            highlightTag = "DNT: 1 ACTIVE"
        ),
        LegalClause(
            number = "03",
            title = "Incognito Mode & Best-Effort Panic Wipe",
            body = "Tabs opened in Private (Incognito) mode avoid persisting browsing history to the local Room database and purge session cookies upon tab closure. Engaging Panic Wipe immediately clears active tabs, WebStorage, cookies, and history.",
        ),
        LegalClause(
            number = "04",
            title = "Anti-Scam, Phishing & Script Defense",
            body = "URL evaluation for anti-scam, homograph (punycode), cryptojacking, and tracker domain rules runs locally on your device against embedded and custom rules without uploading visited URLs to external inspection APIs.",
            highlightTag = "ON-DEVICE GUARD"
        ),
        LegalClause(
            number = "05",
            title = "Contact & Data Protection Officer",
            body = "Questions regarding privacy compliance, GDPR/CCPA rights, or security disclosures may be sent to Silent Bot LLC at silentbrowser@silentbot.online or via our portal at browser.silentbot.online."
        )
    )

    val securityCompliance = listOf(
        LegalClause(
            number = "A1",
            title = "Network Header Enforcement (DNT: 1)",
            body = "Every HTTP/HTTPS request triggered through the browser engine and internal networking stack enforces Do Not Track ('DNT: 1') and Global Privacy Control ('Sec-GPC: 1') when configured in Settings."
        ),
        LegalClause(
            number = "A2",
            title = "Scammer & Automated Bot Defense Architecture",
            body = "Silent Browser integrates multi-layered defense: (1) Canvas & WebGL fingerprint noise injection, (2) WebRTC ICE relay enforcement preventing real IP leaks, (3) Local phishing & homograph URL blocking, and (4) Third-party cookie partitioning."
        ),
        LegalClause(
            number = "A3",
            title = "Production Sync & Conflict Protection",
            body = "When optional Account Cloud Sync is enabled, bookmarks and history conflicts are resolved by timestamp while keeping your mobile device's local storage as the authoritative source of truth until you explicitly confirm otherwise."
        )
    )
}

@Composable
fun LegalScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val silent = MaterialTheme.silentColors
    var selectedTab by remember { mutableIntStateOf(0) }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.SETTINGS)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.SETTINGS) },
                    modifier = Modifier.size(48.dp).testTag("legal_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Settings",
                        tint = silent.accentSuccess
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "LEGAL & PRIVACY GOVERNANCE",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Terms of Service, Privacy Policy & Security Compliance",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    ) { paddingValues ->
        val activeList = when (selectedTab) {
            0 -> LocalLegalDocumentStore.termsOfService
            1 -> LocalLegalDocumentStore.privacyPolicy
            else -> LocalLegalDocumentStore.securityCompliance
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Governance Card
            item {
                CyberCard(
                    borderColor = silent.accentSuccess.copy(alpha = 0.55f),
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = silent.accentSuccess,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SILENT BOT LLC PRODUCTION LEGAL",
                                    color = silent.accentSuccess,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            StatusBadge(text = "v1.0.0 PROD", color = silent.accentInfo)
                        }

                        Text(
                            text = "Transparent terms and verifiable on-device privacy controls engineered for user protection against scammers, trackers, and automated bots.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = silent.textSecondary,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            // Modern Segmented Tab Selector
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(silent.cardBackground)
                        .border(1.dp, silent.cardBorder, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf(
                        Triple(0, "Terms", Icons.Default.Gavel),
                        Triple(1, "Privacy Policy", Icons.Default.Policy),
                        Triple(2, "Security", Icons.Default.Security)
                    )
                    tabs.forEach { (idx, label, icon) ->
                        val selected = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(
                                    if (selected) silent.chipSelectedBackground
                                    else Color.Transparent
                                )
                                .border(
                                    width = if (selected) 1.dp else 0.dp,
                                    color = if (selected) silent.chipSelectedBorder else Color.Transparent,
                                    shape = RoundedCornerShape(9.dp)
                                )
                                .clickable { selectedTab = idx }
                                .padding(vertical = 10.dp, horizontal = 6.dp)
                                .testTag("legal_tab_$idx"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = if (selected) silent.chipSelectedContent else silent.textMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = label,
                                    color = if (selected) silent.chipSelectedContent else silent.textSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Document Clauses in Modern Readable Typography
            items(activeList, key = { "${selectedTab}_${it.number}" }) { clause ->
                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(silent.chipDefaultBackground)
                                        .border(1.dp, silent.cardBorder, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = clause.number,
                                        color = silent.accentSuccess,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = clause.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = silent.textPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }

                            if (clause.highlightTag != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                                StatusBadge(
                                    text = clause.highlightTag,
                                    color = CyberPurple,
                                    isPulsing = false
                                )
                            }
                        }

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Text(
                            text = clause.body,
                            style = MaterialTheme.typography.bodyMedium,
                            color = silent.textSecondary,
                            fontSize = 13.5.sp,
                            lineHeight = 21.sp
                        )
                    }
                }
            }

            // Footer signature
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Silent Bot LLC • browser.silentbot.online",
                        color = silent.textMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Support: silentbrowser@silentbot.online | +1 (530) 481-6886",
                        color = silent.textMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
