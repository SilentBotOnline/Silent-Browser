package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

enum class TabFilter {
    ALL,
    STANDARD,
    INCOGNITO
}

@Composable
fun TabsOverviewScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    var selectedFilter by remember { mutableStateOf(TabFilter.ALL) }

    val filteredTabs = when (selectedFilter) {
        TabFilter.ALL -> tabs
        TabFilter.STANDARD -> tabs.filter { !it.isIncognito }
        TabFilter.INCOGNITO -> tabs.filter { it.isIncognito }
    }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Browser",
                            tint = silent.accentSuccess
                        )
                    }

                    Text(
                        text = "MULTI-TAB MANAGER (${tabs.size})",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    IconButton(
                        onClick = { viewModel.panicPurge() },
                        modifier = Modifier.size(48.dp).testTag("purge_all_tabs_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Close All Tabs",
                            tint = silent.accentError
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Filter Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val incognitoCount = tabs.count { it.isIncognito }
                    val standardCount = tabs.size - incognitoCount

                    TabFilterChip(
                        title = "All (${tabs.size})",
                        isSelected = selectedFilter == TabFilter.ALL,
                        selectedColor = silent.accentInfo,
                        onClick = { selectedFilter = TabFilter.ALL },
                        modifier = Modifier.weight(1f)
                    )

                    TabFilterChip(
                        title = "Standard ($standardCount)",
                        isSelected = selectedFilter == TabFilter.STANDARD,
                        selectedColor = silent.accentSuccess,
                        onClick = { selectedFilter = TabFilter.STANDARD },
                        modifier = Modifier.weight(1f)
                    )

                    TabFilterChip(
                        title = "Private ($incognitoCount)",
                        isSelected = selectedFilter == TabFilter.INCOGNITO,
                        selectedColor = CyberPurple,
                        onClick = { selectedFilter = TabFilter.INCOGNITO },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        floatingActionButton = {
            Row(
                modifier = Modifier.navigationBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FloatingActionButton(
                    onClick = { viewModel.createNewTab(isIncognito = true) },
                    containerColor = CyberPurple,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("create_incognito_tab_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = "New Private Tab", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ Private", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                FloatingActionButton(
                    onClick = { viewModel.createNewTab(isIncognito = false) },
                    containerColor = silent.primaryButtonBackground,
                    contentColor = silent.primaryButtonContent,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("create_tab_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "New Tab", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ Tab", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    ) { paddingValues ->
        if (filteredTabs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .navigationBarsPadding(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (selectedFilter == TabFilter.INCOGNITO) Icons.Default.Security else Icons.Default.Lock,
                        contentDescription = null,
                        tint = silent.textMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (selectedFilter == TabFilter.INCOGNITO) "No active Private tabs" else "No open tabs in this view",
                        color = silent.textSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (selectedFilter == TabFilter.INCOGNITO) viewModel.createNewTab(isIncognito = true)
                            else viewModel.createNewTab(isIncognito = false)
                        },
                        modifier = Modifier.heightIn(min = 48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedFilter == TabFilter.INCOGNITO) CyberPurple else silent.primaryButtonBackground,
                            contentColor = if (selectedFilter == TabFilter.INCOGNITO) Color.White else silent.primaryButtonContent
                        )
                    ) {
                        Text(
                            text = if (selectedFilter == TabFilter.INCOGNITO) "Open Private Tab" else "Open New Tab"
                        )
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 84.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTabs, key = { it.id }) { tab ->
                    val isSelected = tab.id == activeTabId
                    val borderColor = when {
                        isSelected && tab.isIncognito -> CyberPurple
                        isSelected -> silent.chipSelectedBorder
                        tab.isIncognito -> CyberPurple.copy(alpha = 0.5f)
                        else -> silent.cardBorder
                    }

                    Box(
                        modifier = Modifier
                            .height(165.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) silent.chipSelectedBackground else silent.cardBackground)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = borderColor,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.selectTab(tab.id) }
                            .padding(10.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (tab.isIncognito) CyberPurple.copy(alpha = 0.2f)
                                                else silent.badgeSuccessBackground
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (tab.isIncognito) Icons.Default.Security else Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = if (tab.isIncognito) CyberPurple else silent.accentSuccess,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = tab.title,
                                        color = if (isSelected) {
                                            if (tab.isIncognito) CyberPurple else silent.chipSelectedContent
                                        } else silent.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.closeTab(tab.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close Tab",
                                        tint = silent.textMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = tab.url,
                                color = silent.textSecondary,
                                fontSize = 10.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.weight(1f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${tab.blockedTrackersCount} shields",
                                    color = silent.accentSuccess,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                if (tab.isIncognito) {
                                    StatusBadge(text = "PRIVATE", color = CyberPurple)
                                } else {
                                    Text(
                                        text = tab.engineMode.badge,
                                        color = silent.accentInfo,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabFilterChip(
    title: String,
    isSelected: Boolean,
    selectedColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Box(
        modifier = modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) selectedColor.copy(alpha = 0.16f) else silent.chipDefaultBackground)
            .border(1.dp, if (isSelected) selectedColor else silent.chipDefaultBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (isSelected) selectedColor else silent.chipDefaultContent,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
