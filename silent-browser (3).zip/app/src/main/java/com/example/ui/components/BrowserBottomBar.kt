package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.silentColors

/**
 * Single-row bottom navigation bar containing strictly four items:
 * Home, Bookmarks, Tabs (with active tab count), and Account.
 * Adapts cleanly to Black Theme, White Theme, and Midnight Theme.
 */
@Composable
fun BrowserBottomBar(
    openTabsCount: Int,
    isHomeSelected: Boolean = false,
    isBookmarksSelected: Boolean = false,
    isTabsSelected: Boolean = false,
    isAccountSelected: Boolean = false,
    onHome: () -> Unit,
    onBookmarks: () -> Unit,
    onTabs: () -> Unit,
    onAccount: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = silent.barDivider),
        color = silent.bottomBarSurface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Home
            BottomBarItem(
                label = "Home",
                selected = isHomeSelected,
                selectedTint = silent.accentSuccess,
                defaultTint = silent.textSecondary,
                onClick = onHome,
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_home_button")
            ) { tint ->
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Home",
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
            }

            // 2. Bookmarks
            BottomBarItem(
                label = "Bookmarks",
                selected = isBookmarksSelected,
                selectedTint = silent.accentSuccess,
                defaultTint = silent.textSecondary,
                onClick = onBookmarks,
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_bookmark_button")
            ) { tint ->
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = "Bookmarks",
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
            }

            // 3. Tabs (with active tab count badge)
            BottomBarItem(
                label = "Tabs",
                selected = isTabsSelected,
                selectedTint = silent.accentSuccess,
                defaultTint = silent.textSecondary,
                onClick = onTabs,
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_tabs_button")
            ) { tint ->
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(tint.copy(alpha = 0.12f))
                        .border(1.5.dp, tint, RoundedCornerShape(5.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = openTabsCount.coerceAtLeast(1).let { if (it > 99) "99" else "$it" },
                        color = tint,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            // 4. Account & Cross-Device Sync
            BottomBarItem(
                label = "Account",
                selected = isAccountSelected,
                selectedTint = silent.accentSuccess,
                defaultTint = silent.textSecondary,
                onClick = onAccount,
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_account_button")
            ) { tint ->
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Account and Sync",
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun BottomBarItem(
    label: String,
    selected: Boolean,
    selectedTint: Color,
    defaultTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconContent: @Composable (tint: Color) -> Unit
) {
    val tint = if (selected) selectedTint else defaultTint
    Column(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        iconContent(tint)
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = if (selected) selectedTint else MaterialTheme.silentColors.textSecondary,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}
