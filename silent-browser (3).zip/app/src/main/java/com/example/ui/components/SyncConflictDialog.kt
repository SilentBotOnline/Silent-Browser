package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MergeType
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ConflictTimestampRelation
import com.example.data.model.SyncConflictItem
import com.example.data.model.SyncConflictResolution
import com.example.data.model.SyncConflictResolver
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SyncConflictDialog(
    viewModel: BrowserViewModel,
    onDismiss: () -> Unit
) {
    val conflicts by viewModel.syncConflicts.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsState()

    if (conflicts.isEmpty()) return

    SyncConflictDialog(
        conflicts = conflicts,
        isSyncing = isSyncing,
        syncStatusMessage = syncStatusMessage,
        onResolveConflict = { id, resolution -> viewModel.resolveSyncConflict(id, resolution) },
        onResolveAllKeepLocal = {
            viewModel.resolveAllSyncConflicts(SyncConflictResolution.KEEP_LOCAL)
            onDismiss()
        },
        onDismiss = onDismiss
    )
}

@Composable
fun SyncConflictDialog(
    conflicts: List<SyncConflictItem>,
    isSyncing: Boolean,
    syncStatusMessage: String?,
    onResolveConflict: (String, SyncConflictResolution) -> Unit,
    onResolveAllKeepLocal: () -> Unit,
    onDismiss: () -> Unit
) {
    val silent = MaterialTheme.silentColors

    Dialog(
        onDismissRequest = { if (!isSyncing) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = silent.topBarSurface,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, silent.cardBorder),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 560.dp)
                .testTag("sync_conflict_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SyncProblem,
                            contentDescription = null,
                            tint = silent.accentWarning,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "SYNC CONFLICTS",
                                    color = silent.textPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(silent.badgeWarningBackground)
                                        .border(1.dp, silent.badgeWarningBorder, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${conflicts.size}",
                                        color = silent.accentWarning,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                            Text(
                                text = "Timestamp mismatch review • Local device stays authoritative",
                                color = silent.textSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSyncing,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("sync_conflict_dialog_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Sync Conflict Dialog",
                            tint = silent.textMuted
                        )
                    }
                }

                // Local Device Authority Banner
                Surface(
                    color = silent.badgeSuccessBackground,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, silent.badgeSuccessBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sync_dialog_local_authority_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = silent.accentSuccess,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "LOCAL DEVICE AUTHORITY ACTIVE",
                                color = silent.accentSuccess,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "On-device records were preserved intact and win ties unless you choose Use Remote or Merge.",
                                color = silent.textPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (!syncStatusMessage.isNullOrBlank()) {
                    Text(
                        text = syncStatusMessage,
                        color = silent.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

                // Conflict Entries List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 380.dp)
                        .testTag("sync_dialog_conflict_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    itemsIndexed(
                        items = conflicts,
                        key = { _, item -> item.id }
                    ) { index, conflict ->
                        SyncConflictDialogEntryCard(
                            conflict = conflict,
                            index = index,
                            onResolve = { resolution -> onResolveConflict(conflict.id, resolution) }
                        )
                    }
                }

                HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

                // Footer Actions (Local Authority First)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSyncing,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("sync_dialog_dismiss_button")
                    ) {
                        Text(
                            text = "Keep Local & Close",
                            color = silent.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = onResolveAllKeepLocal,
                        enabled = !isSyncing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = silent.primaryButtonBackground,
                            contentColor = silent.primaryButtonContent
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("sync_dialog_keep_all_local_button")
                    ) {
                        Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Keep All Local",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncConflictDialogEntryCard(
    conflict: SyncConflictItem,
    index: Int,
    onResolve: (SyncConflictResolution) -> Unit
) {
    val silent = MaterialTheme.silentColors
    val fmt = remember { SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault()) }
    val localTimeLabel = fmt.format(Date(conflict.localTimestamp))
    val remoteTimeLabel = fmt.format(Date(conflict.remoteTimestamp))
    val relation = SyncConflictResolver.classifyTimestampMismatch(
        localTimestamp = conflict.localTimestamp,
        remoteTimestamp = conflict.remoteTimestamp
    )
    val localIsAuthoritative = relation != ConflictTimestampRelation.REMOTE_NEWER

    Surface(
        color = silent.cardBackground,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, silent.badgeWarningBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sync_dialog_entry_$index")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(silent.badgeWarningBackground)
                            .border(1.dp, silent.badgeWarningBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = conflict.itemType.uppercase(Locale.US),
                            color = silent.accentWarning,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(silent.badgeSuccessBackground)
                            .border(1.dp, silent.badgeSuccessBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (localIsAuthoritative) relation.badgeLabel else "LOCAL AUTHORITATIVE",
                            color = silent.accentSuccess,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Text(
                text = conflict.url,
                color = silent.textMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Primary On-Device Record
            Surface(
                color = silent.badgeSuccessBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, silent.badgeSuccessBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "THIS DEVICE (AUTHORITY)",
                            color = silent.accentSuccess,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = localTimeLabel,
                            color = silent.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = conflict.localTitle.ifBlank { conflict.url },
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (conflict.itemType == "bookmark") {
                        Text(
                            text = "Folder: ${conflict.localFolder} • Visits: ${conflict.localVisitCount}",
                            color = silent.textMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Cloud Remote Record
            Surface(
                color = silent.screenBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, silent.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CLOUD REMOTE",
                            color = silent.accentInfo,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = remoteTimeLabel,
                            color = silent.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = conflict.remoteTitle.ifBlank { conflict.url },
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (conflict.itemType == "bookmark") {
                        Text(
                            text = "Folder: ${conflict.remoteFolder} • Visits: ${conflict.remoteVisitCount}",
                            color = silent.textMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Explicit Keep Local / Use Remote / Merge Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { onResolve(SyncConflictResolution.KEEP_LOCAL) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(1.05f)
                        .heightIn(min = 48.dp)
                        .testTag("sync_dialog_keep_local_$index")
                ) {
                    Text("Keep Local", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { onResolve(SyncConflictResolution.USE_REMOTE) },
                    border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = silent.secondaryButtonBackground,
                        contentColor = silent.secondaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("sync_dialog_use_remote_$index")
                ) {
                    Text("Use Remote", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { onResolve(SyncConflictResolution.MERGE) },
                    border = BorderStroke(1.dp, silent.chipSelectedBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = silent.chipSelectedBackground,
                        contentColor = silent.chipSelectedContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(0.95f)
                        .heightIn(min = 48.dp)
                        .testTag("sync_dialog_merge_$index")
                ) {
                    Icon(Icons.AutoMirrored.Filled.MergeType, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Merge", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}
