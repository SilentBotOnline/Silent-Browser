package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun DownloadsScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val downloads by viewModel.downloads.collectAsState()
    val downloadLocation by viewModel.downloadLocation.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var newLocationInput by remember { mutableStateOf(downloadLocation) }
    var newDownloadUrl by remember { mutableStateOf("") }

    val activeDownloads = downloads.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED }
    val completedDownloads = downloads.filter { it.status == DownloadStatus.COMPLETED || it.status == DownloadStatus.CANCELLED || it.status == DownloadStatus.FAILED }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Column(modifier = Modifier.background(silent.topBarSurface).statusBarsPadding()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = silent.accentSuccess
                        )
                    }

                    Text(
                        text = "DOWNLOAD MANAGER",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    IconButton(
                        onClick = {
                            viewModel.enqueueDownload(
                                url = "https://browser.silentbot.online/releases/silent-browser-v1.0.0-android.apk",
                                contentLength = 28_400_000L
                            )
                        },
                        modifier = Modifier.size(48.dp).testTag("test_download_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Trigger Test Download",
                            tint = silent.accentSuccess
                        )
                    }
                }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = silent.topBarSurface,
                    contentColor = silent.accentSuccess,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = silent.accentSuccess
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Text("Active (${activeDownloads.size})", fontWeight = FontWeight.SemiBold)
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Text("Completed (${completedDownloads.size})", fontWeight = FontWeight.SemiBold)
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        selectedContentColor = silent.accentSuccess,
                        unselectedContentColor = silent.textSecondary,
                        text = {
                            Text("Storage Location", fontWeight = FontWeight.SemiBold)
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        when (selectedTab) {
            0 -> {
                if (activeDownloads.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No active downloads", color = silent.textMuted, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Downloads started via web pages will stream here", color = silent.textSecondary, fontSize = 11.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(activeDownloads, key = { it.id }) { item ->
                            DownloadItemCard(
                                item = item,
                                onPause = { viewModel.pauseDownload(item.id) },
                                onResume = { viewModel.resumeDownload(item.id) },
                                onCancel = { viewModel.cancelDownload(item.id) },
                                onDelete = { viewModel.deleteDownload(item.id) }
                            )
                        }
                    }
                }
            }
            1 -> {
                if (completedDownloads.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No completed downloads yet", color = silent.textMuted, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(completedDownloads, key = { it.id }) { item ->
                            DownloadItemCard(
                                item = item,
                                onPause = {},
                                onResume = {},
                                onCancel = {},
                                onDelete = { viewModel.deleteDownload(item.id) },
                                onOpen = {
                                    Toast.makeText(context, "Opening ${item.fileName}...", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
            2 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .navigationBarsPadding()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    CyberCard(borderColor = silent.accentSuccess, backgroundColor = silent.cardBackground) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = silent.accentSuccess)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CURRENT DOWNLOAD LOCATION",
                                    color = silent.accentSuccess,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = downloadLocation,
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "SPECIFY NEW DOWNLOAD DIRECTORY",
                                color = silent.accentInfo,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = newLocationInput,
                                onValueChange = { newLocationInput = it },
                                modifier = Modifier.fillMaxWidth().testTag("download_location_input"),
                                label = { Text("Directory Path", color = silent.textSecondary) },
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = silent.accentSuccess,
                                    unfocusedBorderColor = silent.cardBorder,
                                    focusedContainerColor = silent.screenBackground,
                                    unfocusedContainerColor = silent.screenBackground
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    if (newLocationInput.isNotBlank()) {
                                        viewModel.setDownloadLocation(newLocationInput)
                                        Toast.makeText(context, "Location saved successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("save_download_location_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Update Download Path", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "DOWNLOAD FROM URL",
                                color = silent.accentInfo,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = newDownloadUrl,
                                onValueChange = { newDownloadUrl = it },
                                modifier = Modifier.fillMaxWidth().testTag("direct_download_url_input"),
                                placeholder = { Text("https://example.com/file.zip", color = silent.textMuted) },
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = silent.accentSuccess,
                                    unfocusedBorderColor = silent.cardBorder,
                                    focusedContainerColor = silent.screenBackground,
                                    unfocusedContainerColor = silent.screenBackground
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (newDownloadUrl.isNotBlank()) {
                                        viewModel.enqueueDownload(url = newDownloadUrl)
                                        newDownloadUrl = ""
                                        selectedTab = 0
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("start_direct_download_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Start Download", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadItemCard(
    item: DownloadItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onOpen: (() -> Unit)? = null
) {
    val silent = MaterialTheme.silentColors
    val downloadedMb = item.downloadedBytes / (1024f * 1024f)
    val totalMb = item.totalBytes / (1024f * 1024f)
    val statusColor = when (item.status) {
        DownloadStatus.DOWNLOADING -> silent.accentInfo
        DownloadStatus.COMPLETED -> silent.accentSuccess
        DownloadStatus.PAUSED -> silent.accentWarning
        else -> silent.accentError
    }

    CyberCard(
        borderColor = statusColor,
        backgroundColor = silent.cardBackground
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        color = silent.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = item.downloadPath,
                        color = silent.textMuted,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace
                    )
                }

                StatusBadge(
                    text = item.status.name,
                    color = statusColor,
                    isPulsing = item.status == DownloadStatus.DOWNLOADING
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { item.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = statusColor,
                trackColor = silent.barDivider
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format("%.1f MB / %.1f MB (%d%%)", downloadedMb, totalMb, item.progressPercent),
                    color = silent.textSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                if (item.status == DownloadStatus.DOWNLOADING) {
                    Text(
                        text = String.format("%.0f KB/s", item.speedKbps),
                        color = silent.accentInfo,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (item.status) {
                        DownloadStatus.DOWNLOADING -> {
                            IconButton(onClick = onPause, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Pause, contentDescription = "Pause", tint = silent.accentWarning, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = onCancel, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = silent.accentError, modifier = Modifier.size(18.dp))
                            }
                        }
                        DownloadStatus.PAUSED -> {
                            IconButton(onClick = onResume, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Resume", tint = silent.accentInfo, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = onCancel, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = silent.accentError, modifier = Modifier.size(18.dp))
                            }
                        }
                        DownloadStatus.COMPLETED -> {
                            if (onOpen != null) {
                                IconButton(onClick = onOpen, modifier = Modifier.size(48.dp)) {
                                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Open", tint = silent.accentSuccess, modifier = Modifier.size(18.dp))
                                }
                            }
                            IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = silent.textMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                        else -> {
                            IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = silent.textMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
