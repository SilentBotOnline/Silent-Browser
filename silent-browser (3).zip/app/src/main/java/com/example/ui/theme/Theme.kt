package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class AppThemePreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val mode: BrowserThemeMode,
    val primaryColor: Color,
    val secondaryColor: Color,
    val backgroundTop: Color,
    val backgroundBottom: Color
) {
    BLACK(
        id = "black",
        title = "Black Theme",
        subtitle = "Pure OLED black with high-contrast monochrome & emerald",
        mode = BrowserThemeMode.BLACK,
        primaryColor = Color(0xFF22C55E),
        secondaryColor = Color(0xFFFFFFFF),
        backgroundTop = Color(0xFF000000),
        backgroundBottom = Color(0xFF070707)
    ),
    WHITE(
        id = "white",
        title = "White Theme",
        subtitle = "Crisp white canvas with clean slate surfaces & emerald brand",
        mode = BrowserThemeMode.WHITE,
        primaryColor = Color(0xFF08783A),
        secondaryColor = Color(0xFF0A9650),
        backgroundTop = Color(0xFFFFFFFF),
        backgroundBottom = Color(0xFFF5F7F6)
    ),
    MIDNIGHT(
        id = "midnight",
        title = "Midnight Theme",
        subtitle = "Deep midnight navy-slate matrix with cyber teal telemetry",
        mode = BrowserThemeMode.MIDNIGHT,
        primaryColor = Color(0xFF14B8A6),
        secondaryColor = Color(0xFF00E5FF),
        backgroundTop = Color(0xFF060D16),
        backgroundBottom = Color(0xFF0A1524)
    ),
    OBSIDIAN_MINT(
        id = "obsidian_mint",
        title = "Obsidian Stealth",
        subtitle = "Ultra-dark carbon with encrypted mint telemetry",
        mode = BrowserThemeMode.BLACK,
        primaryColor = Color(0xFF00E676),
        secondaryColor = Color(0xFF00E5FF),
        backgroundTop = Color(0xFF071612),
        backgroundBottom = Color(0xFF040708)
    ),
    QUANTUM_VIOLET(
        id = "quantum_violet",
        title = "Quantum Amnesic",
        subtitle = "Nocturnal indigo-violet tailored for private tabs",
        mode = BrowserThemeMode.MIDNIGHT,
        primaryColor = Color(0xFFB388FF),
        secondaryColor = Color(0xFF00E5FF),
        backgroundTop = Color(0xFF120B24),
        backgroundBottom = Color(0xFF06040D)
    );

    companion object {
        // Legacy compatibility alias
        val CYBER_MIDNIGHT = MIDNIGHT
    }
}

fun cyberAtmosphericBrush(preset: AppThemePreset = AppThemePreset.WHITE): Brush {
    return Brush.verticalGradient(
        colors = listOf(
            preset.backgroundTop,
            preset.backgroundTop,
            preset.backgroundBottom
        )
    )
}

private fun buildColorScheme(preset: AppThemePreset): ColorScheme {
    val ext = when (preset.mode) {
        BrowserThemeMode.BLACK -> SilentColors.BlackExtended
        BrowserThemeMode.WHITE -> SilentColors.WhiteExtended
        BrowserThemeMode.MIDNIGHT -> SilentColors.MidnightExtended
    }

    return if (!ext.isDark) {
        lightColorScheme(
            primary = ext.primaryButtonBackground,
            onPrimary = ext.primaryButtonContent,
            primaryContainer = ext.chipSelectedBackground,
            onPrimaryContainer = ext.chipSelectedContent,
            secondary = Color(0xFF0A9650),
            onSecondary = Color(0xFFFFFFFF),
            secondaryContainer = ext.chipDefaultBackground,
            onSecondaryContainer = ext.textPrimary,
            tertiary = ext.accentSuccess,
            onTertiary = Color(0xFFFFFFFF),
            background = ext.screenBackground,
            onBackground = ext.textPrimary,
            surface = ext.cardBackground,
            onSurface = ext.textPrimary,
            surfaceVariant = ext.chipDefaultBackground,
            onSurfaceVariant = ext.textSecondary,
            error = ext.panicArmedBackground,
            onError = ext.panicArmedContent,
            outline = ext.cardBorder,
            outlineVariant = ext.barDivider
        )
    } else {
        darkColorScheme(
            primary = preset.primaryColor,
            onPrimary = ext.primaryButtonContent,
            primaryContainer = ext.chipSelectedBackground,
            onPrimaryContainer = ext.chipSelectedContent,
            secondary = preset.secondaryColor,
            onSecondary = ext.screenBackground,
            secondaryContainer = ext.chipDefaultBackground,
            onSecondaryContainer = ext.textPrimary,
            tertiary = ext.accentSuccess,
            onTertiary = ext.screenBackground,
            background = ext.screenBackground,
            onBackground = ext.textPrimary,
            surface = ext.cardBackground,
            onSurface = ext.textPrimary,
            surfaceVariant = ext.chipDefaultBackground,
            onSurfaceVariant = ext.textSecondary,
            error = ext.panicArmedBackground,
            onError = ext.panicArmedContent,
            outline = ext.cardBorder,
            outlineVariant = ext.barDivider
        )
    }
}

@Composable
fun MyApplicationTheme(
    themePreset: AppThemePreset = AppThemePreset.WHITE,
    content: @Composable () -> Unit
) {
    val extendedColors = when (themePreset.mode) {
        BrowserThemeMode.BLACK -> SilentColors.BlackExtended
        BrowserThemeMode.WHITE -> SilentColors.WhiteExtended
        BrowserThemeMode.MIDNIGHT -> SilentColors.MidnightExtended
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !extendedColors.isDark
                controller.isAppearanceLightNavigationBars = !extendedColors.isDark
            }
        }
    }

    CompositionLocalProvider(LocalSilentColors provides extendedColors) {
        MaterialTheme(
            colorScheme = buildColorScheme(themePreset),
            typography = Typography,
            content = content
        )
    }
}
