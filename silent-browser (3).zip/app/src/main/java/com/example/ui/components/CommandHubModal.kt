package com.example.ui.components

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.MergeType
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuthSheetMode
import com.example.data.model.ConflictTimestampRelation
import com.example.data.model.SearchEngine
import com.example.data.model.SyncConflictItem
import com.example.data.model.SyncConflictResolution
import com.example.data.model.SyncConflictResolver
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class CommandHubSubScreen {
    MAIN,
    SYNC_CONFLICTS,
    APPLICATION_UPDATES
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandHubModal(
    viewModel: BrowserViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val tabs by viewModel.tabs.collectAsState()
    val extensions by viewModel.extensions.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val passwords by viewModel.passwords.collectAsState()
    val downloads by viewModel.downloads.collectAsState()

    val shieldedIpEnabled by viewModel.shieldedIpEnabled.collectAsState()
    val activeRelayNode by viewModel.activeRelayNode.collectAsState()
    val doNotTrackEnabled by viewModel.doNotTrackEnabled.collectAsState()
    val adblockEnabled by viewModel.adblockEnabled.collectAsState()
    val antiScamEnabled by viewModel.antiScamProtectionEnabled.collectAsState()

    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsState()
    val syncConflicts by viewModel.syncConflicts.collectAsState()
    val appUpdateState by viewModel.appUpdateState.collectAsState()
    var currentSubScreen by remember { mutableStateOf(CommandHubSubScreen.MAIN) }

    BackHandler(enabled = currentSubScreen != CommandHubSubScreen.MAIN) {
        currentSubScreen = CommandHubSubScreen.MAIN
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = silent.topBarSurface,
        contentColor = silent.textPrimary,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        if (currentSubScreen == CommandHubSubScreen.SYNC_CONFLICTS) {
            SyncConflictsHubView(
                syncConflicts = syncConflicts,
                isLoggedIn = isLoggedIn,
                isSyncing = isSyncing,
                syncStatusMessage = syncStatusMessage,
                onBack = { currentSubScreen = CommandHubSubScreen.MAIN },
                onClose = onDismiss,
                onRefreshSync = { viewModel.syncAllData() },
                onOpenSignIn = {
                    onDismiss()
                    viewModel.openAccountAuthModal(AuthSheetMode.SIGN_IN)
                },
                onResolveConflict = { conflictId, resolution ->
                    viewModel.resolveSyncConflict(conflictId, resolution)
                },
                onResolveAllKeepLocal = {
                    viewModel.resolveAllSyncConflicts(SyncConflictResolution.KEEP_LOCAL)
                }
            )
            return@ModalBottomSheet
        }

        if (currentSubScreen == CommandHubSubScreen.APPLICATION_UPDATES) {
            AppUpdatesHubView(
                updateState = appUpdateState,
                onBack = { currentSubScreen = CommandHubSubScreen.MAIN },
                onClose = onDismiss,
                onCheckUpdates = { viewModel.checkForAppUpdates(manual = true) },
                onSelectChannel = { channel -> viewModel.setUpdateChannel(channel) },
                onToggleAutoCheck = { enabled -> viewModel.toggleAutoCheckUpdates(enabled) },
                onToggleFutureAlerts = { enabled -> viewModel.toggleNotifyFutureReleases(enabled) },
                onUpdateViaPlayStore = { viewModel.launchStoreUpdate(context) },
                onUpdateViaOfficialPortal = { viewModel.launchOfficialPortalUpdate(context) },
                onVerifyChecksums = {
                    onDismiss()
                    viewModel.openReleaseChecksums()
                },
                onOpenPlatformArtifact = { artifact ->
                    onDismiss()
                    viewModel.openPlatformDownload(artifact.platformKey)
                }
            )
            return@ModalBottomSheet
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = null,
                        tint = silent.primaryButtonBackground,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "COMMAND HUB",
                            color = silent.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Account sync, shielded IP & all system modules",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("command_hub_close_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Command Hub", tint = silent.textMuted)
                }
            }

            // Quick Live Privacy Toggles Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickTogglePill(
                    modifier = Modifier.weight(1f).testTag("hub_quick_dnt"),
                    label = "DNT: 1",
                    active = doNotTrackEnabled,
                    activeTint = silent.accentSuccess,
                    onClick = { viewModel.toggleDoNotTrack(!doNotTrackEnabled) }
                )
                QuickTogglePill(
                    modifier = Modifier.weight(1f).testTag("hub_quick_shield_ip"),
                    label = "Shield IP",
                    active = shieldedIpEnabled,
                    activeTint = silent.primaryButtonBackground,
                    onClick = { viewModel.toggleShieldedIp(!shieldedIpEnabled) }
                )
                QuickTogglePill(
                    modifier = Modifier.weight(1f).testTag("hub_quick_adblock"),
                    label = "AdBlock",
                    active = adblockEnabled,
                    activeTint = CyberOrange,
                    onClick = { viewModel.toggleAdblock(!adblockEnabled) }
                )
                QuickTogglePill(
                    modifier = Modifier.weight(1f).testTag("hub_quick_antiscam"),
                    label = "Anti-Scam",
                    active = antiScamEnabled,
                    activeTint = CyberPurple,
                    onClick = { viewModel.toggleAntiScamProtection(!antiScamEnabled) }
                )
            }

            HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

            // =========================================================================
            // 1. ACCOUNT & CLOUD SYNC SECTION (+ Visual Conflict Resolution UI)
            // =========================================================================
            Surface(
                color = silent.cardBackground,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, silent.cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hub_account_sync_card")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (isLoggedIn) Icons.Default.CloudDone else Icons.Default.AccountCircle,
                                contentDescription = null,
                                tint = if (isLoggedIn) silent.accentSuccess else silent.primaryButtonBackground,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "ACCOUNT & CLOUD SYNC",
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = if (isLoggedIn) userEmail else "Sign in or create an account to sync devices",
                                    color = silent.textSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isLoggedIn) silent.badgeSuccessBackground else silent.chipDefaultBackground)
                                .border(
                                    1.dp,
                                    if (isLoggedIn) silent.badgeSuccessBorder else silent.cardBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isLoggedIn) "CONNECTED" else "LOCAL ONLY",
                                color = if (isLoggedIn) silent.accentSuccess else silent.textMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    if (!syncStatusMessage.isNullOrBlank()) {
                        Text(
                            text = syncStatusMessage ?: "",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                    }

                    if (!isLoggedIn) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onDismiss()
                                    viewModel.openAccountAuthModal(AuthSheetMode.SIGN_IN)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hub_open_signin_button")
                            ) {
                                Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    viewModel.openAccountAuthModal(AuthSheetMode.CREATE_ACCOUNT)
                                },
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = silent.secondaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hub_open_create_account_button")
                            ) {
                                Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.syncAllData() },
                                enabled = !isSyncing,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1.3f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hub_sync_now_button")
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = silent.primaryButtonContent
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Syncing...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sync Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                            OutlinedButton(
                                onClick = { viewModel.logoutUser() },
                                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = silent.secondaryButtonBackground,
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(0.9f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hub_sign_out_button")
                            ) {
                                Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    // Sync Conflicts Screen Entry Row
                    val hasConflicts = syncConflicts.isNotEmpty()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (hasConflicts) silent.badgeWarningBackground
                                else silent.screenBackground
                            )
                            .border(
                                1.dp,
                                if (hasConflicts) silent.badgeWarningBorder else silent.cardBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { currentSubScreen = CommandHubSubScreen.SYNC_CONFLICTS }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("hub_open_sync_conflicts_button"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (hasConflicts) Icons.Default.Warning else Icons.Default.SyncProblem,
                                contentDescription = null,
                                tint = if (hasConflicts) silent.accentWarning else silent.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (hasConflicts) {
                                        "Sync Conflicts (${syncConflicts.size})"
                                    } else {
                                        "Sync Conflicts (0)"
                                    },
                                    color = if (hasConflicts) silent.accentWarning else silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (hasConflicts) {
                                        "Timestamp mismatches detected • Local prioritized"
                                    } else {
                                        "Inspect & resolve cross-device timestamp mismatches"
                                    },
                                    color = silent.textSecondary,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (hasConflicts) "Resolve" else "View",
                                color = if (hasConflicts) silent.accentWarning else silent.primaryButtonBackground,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Open Sync Conflicts screen",
                                tint = if (hasConflicts) silent.accentWarning else silent.primaryButtonBackground,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // 2. VIRTUAL SHIELDED IP SETUP SECTION (ON/OFF + Nodes + DNT/GPC + Rotate)
            // =========================================================================
            Surface(
                color = silent.cardBackground,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    1.dp,
                    if (shieldedIpEnabled) silent.badgeSuccessBorder else silent.cardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hub_shielded_ip_card")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.VpnLock,
                                contentDescription = null,
                                tint = if (shieldedIpEnabled) silent.accentSuccess else silent.textMuted,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "VIRTUAL SHIELDED IP SETUP",
                                    color = silent.textPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = if (shieldedIpEnabled) {
                                        "${activeRelayNode.flag} ${activeRelayNode.location} • ${activeRelayNode.virtualIp}"
                                    } else {
                                        "Direct ISP routing (Virtual Shield OFF)"
                                    },
                                    color = if (shieldedIpEnabled) silent.accentSuccess else silent.textSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = shieldedIpEnabled,
                            onCheckedChange = { viewModel.toggleShieldedIp(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = silent.primaryButtonContent,
                                checkedTrackColor = silent.accentSuccess,
                                uncheckedThumbColor = silent.textMuted,
                                uncheckedTrackColor = silent.screenBackground
                            ),
                            modifier = Modifier.testTag("hub_shielded_ip_switch")
                        )
                    }

                    // Protection Status Row & 1-Tap Rotate IP
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Protocol: ${activeRelayNode.protocol}",
                                color = silent.textSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Headers: ${if (doNotTrackEnabled) "DNT: 1 • Sec-GPC: 1 Active" else "DNT / GPC Paused"}",
                                color = if (doNotTrackEnabled) silent.accentInfo else silent.textMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Button(
                            onClick = { viewModel.rotateShieldedIp() },
                            enabled = shieldedIpEnabled,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = silent.primaryButtonBackground,
                                contentColor = silent.primaryButtonContent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("hub_rotate_ip_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rotate IP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // Quick Relay Node Switcher Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        viewModel.relayNodes.forEach { node ->
                            val isSelected = node.location == activeRelayNode.location
                            Box(
                                modifier = Modifier
                                    .heightIn(min = 40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected && shieldedIpEnabled) silent.chipSelectedBackground
                                        else silent.screenBackground
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected && shieldedIpEnabled) silent.chipSelectedBorder else silent.cardBorder,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        if (!shieldedIpEnabled) viewModel.toggleShieldedIp(true)
                                        viewModel.selectRelayNode(node)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${node.flag} ${node.location.substringBefore(",")} (${node.latencyMs}ms)",
                                    color = if (isSelected && shieldedIpEnabled) silent.chipSelectedContent else silent.textSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 3. APPLICATION UPDATE & FUTURE ROADMAP SECTION
            // =========================================================================
            CommandHubUpdateSummaryCard(
                updateState = appUpdateState,
                onCheckUpdates = { viewModel.checkForAppUpdates(manual = true) },
                onOpenUpdateCenter = { currentSubScreen = CommandHubSubScreen.APPLICATION_UPDATES }
            )

            HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

            // =========================================================================
            // 3. ALL 12 SYSTEM MODULES & DESTINATIONS
            // =========================================================================
            Text(
                text = "ALL 12 SYSTEM MODULES & DESTINATIONS",
                color = silent.textSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_dashboard"),
                    icon = Icons.Default.Home,
                    title = "Home Dashboard",
                    subtitle = "Search & tech feed",
                    accent = silent.primaryButtonBackground,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.DASHBOARD)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_browser"),
                    icon = Icons.Default.Dashboard,
                    title = "Active Browser",
                    subtitle = "Return to web viewport",
                    accent = silent.accentInfo,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.BROWSER)
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_privacy_dashboard"),
                    icon = Icons.Default.PrivacyTip,
                    title = "Privacy Dashboard",
                    subtitle = "Tracker & ad metrics",
                    accent = silent.accentSuccess,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_settings"),
                    icon = Icons.Default.Settings,
                    title = "Browser Settings",
                    subtitle = "Engines & themes",
                    accent = CyberBlue,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.SETTINGS)
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_tabs"),
                    icon = Icons.Default.Tab,
                    title = "Tabs (${tabs.size})",
                    subtitle = "Manage open sessions",
                    accent = CyberCyan,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.TABS_OVERVIEW)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_account"),
                    icon = Icons.Default.AccountCircle,
                    title = "Account & Sync",
                    subtitle = if (isLoggedIn) userEmail else "Cloud sync & profile",
                    accent = silent.primaryButtonBackground,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.ACCOUNT)
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_vault"),
                    icon = Icons.Default.VpnKey,
                    title = "Password Vault",
                    subtitle = "${passwords.size} AES-256 logins",
                    accent = CyberCyan,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.PASSWORD_VAULT)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_bookmarks"),
                    icon = Icons.Default.Bookmark,
                    title = "Bookmarks & History",
                    subtitle = "${bookmarks.size} saved URLs",
                    accent = silent.accentSuccess,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY)
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_extensions"),
                    icon = Icons.Default.Extension,
                    title = "Extensions",
                    subtitle = "${extensions.count { it.isEnabled }} active scripts",
                    accent = CyberOrange,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.EXTENSIONS)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_downloads"),
                    icon = Icons.Default.Download,
                    title = "Downloads (${downloads.size})",
                    subtitle = "File storage vault",
                    accent = CyberBlue,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.DOWNLOADS)
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_devops"),
                    icon = Icons.Default.NetworkCheck,
                    title = "Sync Diagnostics",
                    subtitle = "Gateway health & checks",
                    accent = silent.accentInfo,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.DEVOPS_CENTER)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_legal"),
                    icon = Icons.Default.Gavel,
                    title = "Legal & Privacy",
                    subtitle = "Terms & zero-log policy",
                    accent = CyberPurple,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.LEGAL)
                    }
                )
            }

            // Bonus Quick Actions: Private Tab & About / OS Releases
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_private_tab"),
                    icon = Icons.Default.VisibilityOff,
                    title = "New Private Tab",
                    subtitle = "Auto-purge on close",
                    accent = CyberPurple,
                    onClick = {
                        onDismiss()
                        viewModel.createNewTab(isIncognito = true)
                    }
                )
                CommandModalTile(
                    modifier = Modifier.weight(1f).testTag("hub_modal_releases"),
                    icon = Icons.Default.Info,
                    title = "About & OS Releases",
                    subtitle = "Android, Win, iOS, Mac",
                    accent = silent.accentSuccess,
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(ScreenDestination.ABOUT)
                    }
                )
            }

            CommandModalTile(
                modifier = Modifier.fillMaxWidth().testTag("hub_modal_public_site"),
                icon = Icons.Default.Public,
                title = "Open Silent Browser Web Portal",
                subtitle = "https://browser.silentbot.online/",
                accent = silent.primaryButtonBackground,
                onClick = {
                    onDismiss()
                    viewModel.openPublishPortal()
                }
            )

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SyncConflictsHubView(
    syncConflicts: List<SyncConflictItem>,
    isLoggedIn: Boolean,
    isSyncing: Boolean,
    syncStatusMessage: String?,
    onBack: () -> Unit,
    onClose: () -> Unit,
    onRefreshSync: () -> Unit,
    onOpenSignIn: () -> Unit,
    onResolveConflict: (String, SyncConflictResolution) -> Unit,
    onResolveAllKeepLocal: () -> Unit
) {
    val silent = MaterialTheme.silentColors

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp)
            .navigationBarsPadding()
            .testTag("sync_conflicts_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("sync_conflicts_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Command Hub",
                        tint = silent.textPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SYNC CONFLICTS",
                            color = silent.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (syncConflicts.isNotEmpty()) silent.badgeWarningBackground
                                    else silent.badgeSuccessBackground
                                )
                                .border(
                                    1.dp,
                                    if (syncConflicts.isNotEmpty()) silent.badgeWarningBorder else silent.badgeSuccessBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${syncConflicts.size}",
                                color = if (syncConflicts.isNotEmpty()) silent.accentWarning else silent.accentSuccess,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "Timestamp mismatches • Mobile local storage prioritized",
                        color = silent.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("command_hub_close_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close Command Hub", tint = silent.textMuted)
            }
        }

        // Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = if (isLoggedIn) onRefreshSync else onOpenSignIn,
                enabled = !isSyncing,
                border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = silent.secondaryButtonBackground,
                    contentColor = silent.secondaryButtonContent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .testTag("sync_conflicts_refresh_button")
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = silent.primaryButtonBackground
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Checking...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = if (isLoggedIn) Icons.Default.Refresh else Icons.Default.AccountCircle,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isLoggedIn) "Refresh Sync" else "Sign In to Sync",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (syncConflicts.isNotEmpty()) {
                Button(
                    onClick = onResolveAllKeepLocal,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("sync_conflicts_keep_all_local_button")
                ) {
                    Text("Keep All Local", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }

        if (!syncStatusMessage.isNullOrBlank()) {
            Text(
                text = syncStatusMessage,
                color = silent.textSecondary,
                fontSize = 11.sp
            )
        }

        HorizontalDivider(color = silent.barDivider, thickness = 1.dp)

        // Granular Sync Conflict List (LazyColumn)
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp, max = 520.dp)
                .testTag("sync_conflicts_lazy_list"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            if (syncConflicts.isEmpty()) {
                item(key = "sync_conflicts_empty") {
                    Surface(
                        color = silent.cardBackground,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, silent.badgeSuccessBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sync_conflicts_empty_state")
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = silent.accentSuccess,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "All Items In Sync",
                                color = silent.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "No bookmark or history timestamp mismatches are pending. When a cross-device conflict is flagged during cloud sync, each entry will appear here with Keep Local, Use Remote, and Merge controls.",
                                color = silent.textSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(
                    items = syncConflicts,
                    key = { _, conflict -> conflict.id }
                ) { index, conflict ->
                    ConflictResolutionItemCard(
                        conflict = conflict,
                        index = index,
                        onResolve = { resolution -> onResolveConflict(conflict.id, resolution) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ConflictResolutionItemCard(
    conflict: SyncConflictItem,
    index: Int,
    onResolve: (SyncConflictResolution) -> Unit
) {
    val silent = MaterialTheme.silentColors
    val fmt = remember { SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault()) }
    val localTimeLabel = fmt.format(Date(conflict.localTimestamp))
    val remoteTimeLabel = fmt.format(Date(conflict.remoteTimestamp))
    val relation = SyncConflictResolver.classifyTimestampMismatch(
        localTimestamp = conflict.localTimestamp,
        remoteTimestamp = conflict.remoteTimestamp
    )
    val timestampDelta = SyncConflictResolver.formatTimestampDelta(
        localTimestamp = conflict.localTimestamp,
        remoteTimestamp = conflict.remoteTimestamp
    )
    val localWinsPriority = relation != ConflictTimestampRelation.REMOTE_NEWER

    Surface(
        color = silent.cardBackground,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, silent.badgeWarningBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sync_conflict_card_$index")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(silent.badgeWarningBackground)
                            .border(1.dp, silent.badgeWarningBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = conflict.itemType.uppercase(Locale.US),
                            color = silent.accentWarning,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (localWinsPriority) silent.badgeSuccessBackground else silent.badgeInfoBackground
                            )
                            .border(
                                1.dp,
                                if (localWinsPriority) silent.badgeSuccessBorder else silent.badgeInfoBorder,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = relation.badgeLabel,
                            color = if (localWinsPriority) silent.accentSuccess else silent.accentInfo,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Text(
                    text = timestampDelta,
                    color = silent.textSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = conflict.url,
                color = silent.textMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Local vs Remote Timestamp Comparison
            Surface(
                color = if (localWinsPriority) silent.badgeSuccessBackground else silent.screenBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(
                    1.dp,
                    if (localWinsPriority) silent.badgeSuccessBorder else silent.cardBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "MOBILE LOCAL",
                            color = silent.accentSuccess,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = localTimeLabel,
                            color = silent.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = conflict.localTitle.ifBlank { conflict.url },
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (conflict.itemType == "bookmark") {
                        Text(
                            text = "Folder: ${conflict.localFolder} • Visits: ${conflict.localVisitCount}",
                            color = silent.textMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Surface(
                color = silent.screenBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, silent.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CLOUD REMOTE",
                            color = silent.accentInfo,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = remoteTimeLabel,
                            color = silent.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = conflict.remoteTitle.ifBlank { conflict.url },
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (conflict.itemType == "bookmark") {
                        Text(
                            text = "Folder: ${conflict.remoteFolder} • Visits: ${conflict.remoteVisitCount}",
                            color = silent.textMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { onResolve(SyncConflictResolution.KEEP_LOCAL) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("conflict_keep_local_$index")
                ) {
                    Text("Keep Local", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { onResolve(SyncConflictResolution.USE_REMOTE) },
                    border = BorderStroke(1.dp, silent.secondaryButtonBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = silent.secondaryButtonBackground,
                        contentColor = silent.secondaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("conflict_use_remote_$index")
                ) {
                    Text("Use Remote", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { onResolve(SyncConflictResolution.MERGE) },
                    border = BorderStroke(1.dp, silent.chipSelectedBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = silent.chipSelectedBackground,
                        contentColor = silent.chipSelectedContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(0.95f)
                        .heightIn(min = 48.dp)
                        .testTag("conflict_merge_$index")
                ) {
                    Icon(Icons.AutoMirrored.Filled.MergeType, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Merge", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun QuickTogglePill(
    label: String,
    active: Boolean,
    activeTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) silent.chipSelectedBackground else silent.chipDefaultBackground)
            .border(
                1.dp,
                if (active) activeTint else silent.chipDefaultBorder,
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (active) activeTint else silent.chipDefaultContent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun CommandModalTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = modifier
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(silent.cardBackground)
            .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = silent.textPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = silent.textMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SecuritySetupWizardDialog(
    viewModel: BrowserViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val currentEngine by viewModel.activeSearchEngine.collectAsState()
    val currentDnt by viewModel.doNotTrackEnabled.collectAsState()
    val currentShieldIp by viewModel.shieldedIpEnabled.collectAsState()
    val currentAntiScam by viewModel.antiScamProtectionEnabled.collectAsState()
    var selectedEngine by remember { mutableStateOf(currentEngine) }
    var enableDnt by remember { mutableStateOf(currentDnt) }
    var enableShieldIp by remember { mutableStateOf(currentShieldIp) }
    var enableAntiScam by remember { mutableStateOf(currentAntiScam) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = silent.topBarSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = silent.primaryButtonBackground)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Production Security Profile",
                    color = silent.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Silent Browser ships pre-armed with production privacy protections. Customize or restore your default search and network shields below.",
                    color = silent.textSecondary,
                    fontSize = 12.sp
                )

                Text(
                    text = "Default Search Gateway:",
                    color = silent.textPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(SearchEngine.SILENT_STEALTH, SearchEngine.DUCKDUCKGO, SearchEngine.BRAVE).forEach { eng ->
                        val isSel = selectedEngine == eng
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) silent.chipSelectedBackground else silent.chipDefaultBackground)
                                .border(
                                    1.dp,
                                    if (isSel) silent.chipSelectedBorder else silent.chipDefaultBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedEngine = eng }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = eng.displayName.substringBefore(" "),
                                color = if (isSel) silent.chipSelectedContent else silent.chipDefaultContent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                WizardCheckRow("Enforce DNT: 1 Network Interceptor", enableDnt) { enableDnt = it }
                WizardCheckRow("Enable Virtual Shielded IP Relay", enableShieldIp) { enableShieldIp = it }
                WizardCheckRow("Arm Anti-Scammer & Bot Attack Guard", enableAntiScam) { enableAntiScam = it }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.completeSetupWizard(
                        engine = selectedEngine,
                        enableDnt = enableDnt,
                        enableShieldedIp = enableShieldIp,
                        enableAntiScam = enableAntiScam
                    )
                    Toast.makeText(context, "Production Security Profile Applied!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = silent.primaryButtonBackground,
                    contentColor = silent.primaryButtonContent
                ),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("wizard_complete_button")
            ) {
                Text("Apply Production Profile", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("Close", color = silent.textSecondary)
            }
        }
    )
}

@Composable
private fun WizardCheckRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = silent.accentSuccess,
                uncheckedColor = silent.textMuted
            )
        )
        Text(label, color = silent.textPrimary, fontSize = 12.sp)
    }
}
