package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class BrowserThemeMode(val displayName: String) {
    BLACK("Black Theme"),
    WHITE("White Theme"),
    MIDNIGHT("Midnight Theme")
}

data class SilentExtendedColors(
    val isDark: Boolean,
    val screenBackground: Color,
    val topBarSurface: Color,
    val bottomBarSurface: Color,
    val barDivider: Color,
    val cardBackground: Color,
    val cardBorder: Color,
    val chipDefaultBackground: Color,
    val chipDefaultBorder: Color,
    val chipDefaultContent: Color,
    val chipSelectedBackground: Color,
    val chipSelectedBorder: Color,
    val chipSelectedContent: Color,
    val primaryButtonBackground: Color,
    val primaryButtonContent: Color,
    val secondaryButtonBackground: Color,
    val secondaryButtonContent: Color,
    val secondaryButtonBorder: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val accentSuccess: Color,
    val badgeSuccessBackground: Color,
    val badgeSuccessBorder: Color,
    val accentWarning: Color,
    val badgeWarningBackground: Color,
    val badgeWarningBorder: Color,
    val accentInfo: Color,
    val badgeInfoBackground: Color,
    val badgeInfoBorder: Color,
    val accentError: Color,
    val panicUnarmedBackground: Color,
    val panicUnarmedContent: Color,
    val panicArmedBackground: Color,
    val panicArmedContent: Color
)

object SilentColors {
    // Shared accents
    val EmeraldAccent = Color(0xFF2EE58A)
    val EmeraldBright = Color(0xFF22C55E)
    val TealAccent = Color(0xFF14B8A6)
    val TealLight = Color(0xFF5EEAD4)
    val AmberAccent = Color(0xFFD99B26)
    val AmberLight = Color(0xFFFBBF24)
    val SkyAccent = Color(0xFF38BDF8)
    val DangerRed = Color(0xFFEF4444)
    val DangerRedLight = Color(0xFFDC2626)

    // =========================================================
    // 1. BLACK THEME (Pure OLED black + crisp high-contrast UI)
    // =========================================================
    val BlackBg = Color(0xFF000000)
    val BlackBar = Color(0xFF080808)
    val BlackCard = Color(0xFF101010)
    val BlackElevated = Color(0xFF181818)
    val BlackBorder = Color(0xFF262626)
    val BlackBorderStrong = Color(0xFF3A3A3A)
    val BlackTextPrimary = Color(0xFFFFFFFF)
    val BlackTextSecondary = Color(0xFFB3B3B3)
    val BlackTextMuted = Color(0xFF7A7A7A)

    val BlackExtended = SilentExtendedColors(
        isDark = true,
        screenBackground = BlackBg,
        topBarSurface = BlackBar,
        bottomBarSurface = BlackBar,
        barDivider = BlackBorder,
        cardBackground = BlackCard,
        cardBorder = BlackBorder,
        chipDefaultBackground = BlackElevated,
        chipDefaultBorder = BlackBorder,
        chipDefaultContent = BlackTextSecondary,
        chipSelectedBackground = Color(0xFF07261B),
        chipSelectedBorder = EmeraldBright,
        chipSelectedContent = EmeraldAccent,
        primaryButtonBackground = EmeraldBright,
        primaryButtonContent = Color(0xFF051A0D),
        secondaryButtonBackground = BlackElevated,
        secondaryButtonContent = BlackTextPrimary,
        secondaryButtonBorder = BlackBorderStrong,
        textPrimary = BlackTextPrimary,
        textSecondary = BlackTextSecondary,
        textMuted = BlackTextMuted,
        accentSuccess = EmeraldAccent,
        badgeSuccessBackground = Color(0xFF06291D),
        badgeSuccessBorder = Color(0xFF135C41),
        accentWarning = AmberLight,
        badgeWarningBackground = Color(0xFF291B04),
        badgeWarningBorder = Color(0xFF6B460B),
        accentInfo = SkyAccent,
        badgeInfoBackground = Color(0xFF072133),
        badgeInfoBorder = Color(0xFF134E73),
        accentError = DangerRed,
        panicUnarmedBackground = BlackElevated,
        panicUnarmedContent = BlackTextSecondary,
        panicArmedBackground = DangerRed,
        panicArmedContent = Color(0xFFFFFFFF)
    )

    // =========================================================
    // 2. WHITE THEME (Default light surfaces + crisp brand green)
    // =========================================================
    val WhiteBg = Color(0xFFFFFFFF)
    val WhiteSurface = Color(0xFFF5F7F6)
    val WhiteChip = Color(0xFFF5F7F6)
    val WhiteSelectedChip = Color(0xFFE7F5ED)
    val WhiteBorder = Color(0xFFE5EAE7)
    val WhiteDivider = Color(0xFFE5EAE7)
    val WhiteTextPrimary = Color(0xFF17231C)
    val WhiteTextSecondary = Color(0xFF667085)
    val WhiteTextMuted = Color(0xFF667085)
    val WhiteBrandPrimary = Color(0xFF08783A)
    val WhiteBrandSecondary = Color(0xFF0A9650)

    val WhiteExtended = SilentExtendedColors(
        isDark = false,
        screenBackground = WhiteBg,
        topBarSurface = WhiteBg,
        bottomBarSurface = WhiteBg,
        barDivider = WhiteDivider,
        cardBackground = WhiteSurface,
        cardBorder = WhiteBorder,
        chipDefaultBackground = WhiteChip,
        chipDefaultBorder = WhiteBorder,
        chipDefaultContent = WhiteTextPrimary,
        chipSelectedBackground = WhiteSelectedChip,
        chipSelectedBorder = WhiteBrandSecondary,
        chipSelectedContent = WhiteBrandPrimary,
        primaryButtonBackground = WhiteBrandPrimary,
        primaryButtonContent = Color(0xFFFFFFFF),
        secondaryButtonBackground = WhiteBg,
        secondaryButtonContent = WhiteTextPrimary,
        secondaryButtonBorder = WhiteBorder,
        textPrimary = WhiteTextPrimary,
        textSecondary = WhiteTextSecondary,
        textMuted = WhiteTextMuted,
        accentSuccess = WhiteBrandSecondary,
        badgeSuccessBackground = Color(0xFFE7F5ED),
        badgeSuccessBorder = Color(0xFFA7DFC0),
        accentWarning = Color(0xFFB45309),
        badgeWarningBackground = Color(0xFFFEF3C7),
        badgeWarningBorder = Color(0xFFFCD34D),
        accentInfo = Color(0xFF0369A1),
        badgeInfoBackground = Color(0xFFE0F2FE),
        badgeInfoBorder = Color(0xFF7DD3FC),
        accentError = DangerRedLight,
        panicUnarmedBackground = WhiteSurface,
        panicUnarmedContent = WhiteTextSecondary,
        panicArmedBackground = DangerRedLight,
        panicArmedContent = Color(0xFFFFFFFF)
    )

    // =========================================================
    // 3. MIDNIGHT THEME (Deep midnight navy-slate + cyber teal)
    // =========================================================
    val MidnightBg = Color(0xFF060D16)
    val MidnightBar = Color(0xFF091320)
    val MidnightCard = Color(0xFF07121C)
    val MidnightElevated = Color(0xFF0D1B2A)
    val MidnightBorder = Color(0xFF143547)
    val MidnightBorderBright = Color(0xFF1E4E68)
    val MidnightTextPrimary = Color(0xFFF1F5F9)
    val MidnightTextSecondary = Color(0xFF94A3B8)
    val MidnightTextMuted = Color(0xFF7D93A6)

    val MidnightExtended = SilentExtendedColors(
        isDark = true,
        screenBackground = MidnightBg,
        topBarSurface = MidnightBar,
        bottomBarSurface = MidnightBar,
        barDivider = MidnightBorder,
        cardBackground = MidnightCard,
        cardBorder = MidnightBorder,
        chipDefaultBackground = MidnightElevated,
        chipDefaultBorder = MidnightBorder,
        chipDefaultContent = MidnightTextSecondary,
        chipSelectedBackground = Color(0xFF06291D),
        chipSelectedBorder = TealAccent,
        chipSelectedContent = TealLight,
        primaryButtonBackground = TealAccent,
        primaryButtonContent = Color(0xFF041318),
        secondaryButtonBackground = MidnightElevated,
        secondaryButtonContent = MidnightTextPrimary,
        secondaryButtonBorder = MidnightBorderBright,
        textPrimary = MidnightTextPrimary,
        textSecondary = MidnightTextSecondary,
        textMuted = MidnightTextMuted,
        accentSuccess = EmeraldAccent,
        badgeSuccessBackground = Color(0xFF06291D),
        badgeSuccessBorder = Color(0xFF135C41),
        accentWarning = AmberAccent,
        badgeWarningBackground = Color(0xFF261905),
        badgeWarningBorder = Color(0xFF63420D),
        accentInfo = SkyAccent,
        badgeInfoBackground = Color(0xFF072133),
        badgeInfoBorder = Color(0xFF134E73),
        accentError = DangerRed,
        panicUnarmedBackground = MidnightElevated,
        panicUnarmedContent = MidnightTextSecondary,
        panicArmedBackground = DangerRed,
        panicArmedContent = Color(0xFFFFFFFF)
    )
}

val LocalSilentColors = staticCompositionLocalOf { SilentColors.WhiteExtended }

val MaterialTheme.silentColors: SilentExtendedColors
    @Composable
    get() = LocalSilentColors.current

// Legacy compatibility color tokens
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanLight = Color(0xFF80F0FF)
val CyberCyanDark = Color(0xFF009AB2)
val CyberBlue = Color(0xFF0091EA)
val CyberMint = Color(0xFF00E676)
val CyberRed = Color(0xFFFF3366)
val CyberOrange = Color(0xFFFF9100)
val CyberPurple = Color(0xFFB388FF)

// Backgrounds & Surfaces (Theme defaults)
val CyberBackground = Color(0xFF060A13)
val CyberSurface = Color(0xFF0D1526)
val CyberSurfaceVariant = Color(0xFF142038)
val CyberBorder = Color(0xFF1E3154)
val CyberGlow = Color(0x3300E5FF)

val TextPrimary = Color(0xFFE2F1FF)
val TextSecondary = Color(0xFF9CB2CE)
val TextMuted = Color(0xFF7B93B2)
val TextCyan = Color(0xFF00E5FF)

// Cyber Discovery Feed & Filter Chip Tokens
val CyberFeedCardBg = Color(0xFF0A1726)
val CyberFeedCardBorder = Color(0xFF1E4861)
val CyberBadgeBg = Color(0xFF06291D)
val CyberBadgeBorder = Color(0xFF197A56)
val CyberBadgeAccent = Color(0xFF2EE58A)
val CyberCategoryGold = Color(0xFFE5A93B)
val CyberFeedTitleText = Color(0xFFF1F5F9)
val CyberFeedMutedText = Color(0xFF94A9BD)
val CyberChipActiveBg = Color(0xFF083325)
val CyberChipInactiveBg = Color(0xFF0C1829)
val CyberChipActiveBorder = Color(0xFF14B8A6)
val CyberChipInactiveBorder = Color(0xFF1D3E56)
val CyberChipActiveText = Color(0xFF5EEAD4)
val CyberChipInactiveText = Color(0xFFA8BACD)
