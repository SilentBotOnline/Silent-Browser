package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrowserExtension
import com.example.ui.components.CyberCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberMint
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun ExtensionsScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val extensions by viewModel.extensions.collectAsState()

    var showInstallDialog by remember { mutableStateOf(false) }
    var selectedExtForOptions by remember { mutableStateOf<BrowserExtension?>(null) }

    var newExtName by remember { mutableStateOf("") }
    var newExtDesc by remember { mutableStateOf("") }
    var newExtScript by remember { mutableStateOf("") }

    BackHandler {
        viewModel.navigateTo(ScreenDestination.BROWSER)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.BROWSER) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = silent.accentSuccess
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "EXTENSIONS & USERSCRIPTS",
                        color = silent.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${extensions.count { it.isEnabled }} of ${extensions.size} Active",
                        color = silent.accentSuccess,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = { showInstallDialog = true },
                    modifier = Modifier.size(48.dp).testTag("install_extension_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Install Extension",
                        tint = silent.accentSuccess
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showInstallDialog = true },
                containerColor = silent.primaryButtonBackground,
                contentColor = silent.primaryButtonContent,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.navigationBarsPadding().testTag("install_extension_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Extension", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 84.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Extension,
                            contentDescription = null,
                            tint = silent.accentSuccess,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Standard Chrome / WebExtension Engine",
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Scripts are injected directly into DOM before page rendering for privacy & ad-blocking capabilities.",
                                color = silent.textSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            items(extensions, key = { it.id }) { ext ->
                CyberCard(
                    borderColor = if (ext.isEnabled) silent.chipSelectedBorder else silent.cardBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ext.iconLetter,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = ext.name,
                                            color = if (ext.isEnabled) silent.accentSuccess else silent.textPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "v${ext.version}",
                                            color = silent.textMuted,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Text(
                                        text = "by ${ext.author}",
                                        color = silent.textMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Switch(
                                checked = ext.isEnabled,
                                onCheckedChange = {
                                    viewModel.toggleExtension(ext.id, it)
                                    Toast.makeText(context, "${ext.name} ${if (it) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = silent.primaryButtonContent,
                                    checkedTrackColor = silent.accentSuccess,
                                    uncheckedThumbColor = silent.textMuted,
                                    uncheckedTrackColor = silent.chipDefaultBackground
                                ),
                                modifier = Modifier.testTag("switch_ext_${ext.id}")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = ext.description,
                            color = silent.textSecondary,
                            fontSize = 11.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                ext.permissions.take(2).forEach { perm ->
                                    StatusBadge(text = perm, color = silent.accentSuccess)
                                }
                                if (!ext.isBuiltIn) {
                                    StatusBadge(text = "CUSTOM", color = silent.accentWarning)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { selectedExtForOptions = ext },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Code,
                                        contentDescription = "View Script",
                                        tint = silent.accentInfo,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                if (!ext.isBuiltIn) {
                                    IconButton(
                                        onClick = {
                                            viewModel.removeExtension(ext.id)
                                            Toast.makeText(context, "Extension removed.", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove Extension",
                                            tint = silent.accentError,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Install Custom Extension Dialog
    if (showInstallDialog) {
        AlertDialog(
            onDismissRequest = { showInstallDialog = false },
            containerColor = silent.cardBackground,
            title = {
                Text(
                    text = "Install Custom WebExtension / Script",
                    color = silent.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newExtName,
                        onValueChange = { newExtName = it },
                        label = { Text("Extension / Script Name", color = silent.textSecondary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = newExtDesc,
                        onValueChange = { newExtDesc = it },
                        label = { Text("Description", color = silent.textSecondary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )

                    OutlinedTextField(
                        value = newExtScript,
                        onValueChange = { newExtScript = it },
                        label = { Text("JavaScript Injected Code", color = silent.textSecondary) },
                        placeholder = { Text("(function() { /* your script */ })();", color = silent.textMuted) },
                        minLines = 4,
                        maxLines = 6,
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = silent.textPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = silent.accentSuccess,
                            unfocusedBorderColor = silent.cardBorder,
                            focusedContainerColor = silent.screenBackground,
                            unfocusedContainerColor = silent.screenBackground
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newExtName.isNotBlank() && newExtScript.isNotBlank()) {
                            viewModel.installExtension(newExtName, newExtDesc, newExtScript)
                            newExtName = ""
                            newExtDesc = ""
                            newExtScript = ""
                            showInstallDialog = false
                            Toast.makeText(context, "Extension installed & active!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Install", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showInstallDialog = false }) {
                    Text("Cancel", color = silent.textSecondary)
                }
            }
        )
    }

    // View Script / Options Dialog
    if (selectedExtForOptions != null) {
        val ext = selectedExtForOptions!!
        AlertDialog(
            onDismissRequest = { selectedExtForOptions = null },
            containerColor = silent.cardBackground,
            title = {
                Text(
                    text = "${ext.name} (Source Script)",
                    color = silent.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Permissions: ${ext.permissions.joinToString(", ")}", color = silent.accentSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))
                    // Explicit dark monospace code viewer for readability across all themes
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0A111A))
                            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = ext.contentScript,
                            color = CyberMint,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedExtForOptions = null },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.primaryButtonBackground,
                        contentColor = silent.primaryButtonContent
                    )
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
