package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Https
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.privacy.PrivacyEngine
import com.example.ui.components.BlockedRequestsFeedCard
import com.example.ui.components.CustomFilterRulesCard
import com.example.ui.components.CyberCard
import com.example.ui.components.LivePrivacyProbeCard
import com.example.ui.components.PrivacyAuditChecklistCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.cyberAtmosphericBrush
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun PrivacyDashboardScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val themePreset by viewModel.selectedThemePreset.collectAsState()
    val totalBlocked by viewModel.totalBlockedTrackers.collectAsState()
    val blockedAds by viewModel.blockedAdsCount.collectAsState()
    val blockedTrackersOnly by viewModel.blockedTrackersOnlyCount.collectAsState()
    val blockedScamsBots by viewModel.blockedScamsBotsCount.collectAsState()
    val dntHeadersSent by viewModel.dntHeadersSentCount.collectAsState()

    val customBlockedDomains by viewModel.customBlockedDomains.collectAsState()
    val customAllowedDomains by viewModel.customAllowedDomains.collectAsState()
    val blockedRequestLog by viewModel.blockedRequestLog.collectAsState()
    val liveProbeResult by viewModel.liveProbeResult.collectAsState()
    val isProbingPrivacy by viewModel.isProbingPrivacy.collectAsState()
    val privacyAuditReport by viewModel.privacyAuditReport.collectAsState()

    val adblockEnabled by viewModel.adblockEnabled.collectAsState()
    val fingerprintShieldEnabled by viewModel.fingerprintShieldEnabled.collectAsState()
    val httpsEverywhereEnabled by viewModel.httpsEverywhereEnabled.collectAsState()
    val javascriptEnabled by viewModel.javascriptEnabled.collectAsState()
    val thirdPartyCookiesBlocked by viewModel.thirdPartyCookiesBlocked.collectAsState()
    val doNotTrackEnabled by viewModel.doNotTrackEnabled.collectAsState()
    val antiScamEnabled by viewModel.antiScamProtectionEnabled.collectAsState()
    val shieldedIpEnabled by viewModel.shieldedIpEnabled.collectAsState()
    val activeRelayNode by viewModel.activeRelayNode.collectAsState()
    val engineMode by viewModel.engineMode.collectAsState()

    var probeInput by remember { mutableStateOf("doubleclick.net") }
    var showAuditChecklist by remember { mutableStateOf(false) }

    val activeLayersCount = listOf(
        adblockEnabled,
        fingerprintShieldEnabled,
        httpsEverywhereEnabled,
        thirdPartyCookiesBlocked,
        doNotTrackEnabled,
        antiScamEnabled,
        shieldedIpEnabled
    ).count { it }
    val protectionScore = ((activeLayersCount / 7f) * 100).toInt()
    val activeRuleCount = PrivacyEngine.AD_NETWORK_HOSTS.size +
        PrivacyEngine.ANALYTICS_TRACKER_HOSTS.size +
        PrivacyEngine.SCAM_AND_BOT_HOSTS.size +
        customBlockedDomains.size

    BackHandler {
        viewModel.navigateTo(ScreenDestination.DASHBOARD)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
            .background(cyberAtmosphericBrush(themePreset)),
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(silent.topBarSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                        modifier = Modifier.size(48.dp).testTag("privacy_dashboard_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Home",
                            tint = silent.accentSuccess
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = "PRIVACY DASHBOARD",
                            color = silent.textPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Real Ad-Blocking & Live Defense Telemetry",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.SETTINGS) },
                    modifier = Modifier.size(48.dp).testTag("privacy_dashboard_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Browser Settings",
                        tint = silent.accentSuccess
                    )
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Defense Posture Score Hero Card + Quick Lockdown & Audit
            item {
                val scoreColor = if (protectionScore >= 85) silent.accentSuccess else silent.accentWarning
                CyberCard(
                    borderColor = scoreColor,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(scoreColor.copy(alpha = 0.15f))
                                        .border(1.5.dp, scoreColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = "Defense Integrity",
                                        tint = scoreColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "SHIELD INTEGRITY",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "$protectionScore% HARDENED",
                                        color = scoreColor,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            StatusBadge(
                                text = engineMode.badge,
                                color = silent.accentSuccess
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        LinearProgressIndicator(
                            progress = { protectionScore / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = scoreColor,
                            trackColor = silent.barDivider
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "$activeLayersCount of 7 defense shields engaged • $activeRuleCount active block signatures.",
                            color = silent.textSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.maximizeAllPrivacyShields()
                                    showAuditChecklist = true
                                    Toast.makeText(context, "All 7 configurable privacy shields enabled", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = silent.primaryButtonBackground,
                                    contentColor = silent.primaryButtonContent
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("maximize_privacy_shields_button")
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Enable All 7", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }

                            OutlinedButton(
                                onClick = {
                                    viewModel.runProductionPrivacyAudit(logToTerminal = true)
                                    showAuditChecklist = !showAuditChecklist
                                },
                                border = BorderStroke(1.dp, silent.accentInfo),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("run_privacy_audit_button")
                            ) {
                                Icon(Icons.Default.GppGood, contentDescription = null, tint = silent.accentInfo, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (showAuditChecklist) "Hide Audit" else "7-Point Audit",
                                    fontSize = 12.sp,
                                    color = silent.accentInfo,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            if (showAuditChecklist && privacyAuditReport != null) {
                item {
                    PrivacyAuditChecklistCard(
                        report = privacyAuditReport!!,
                        onCopyReport = {
                            val r = privacyAuditReport!!
                            val summary = buildString {
                                appendLine("Silent Browser Production Privacy Audit (${r.scorePercent}% - ${r.passedCount}/${r.totalChecks})")
                                appendLine("Total Blocked: $totalBlocked (Ads: $blockedAds, Trackers: $blockedTrackersOnly, Threats: $blockedScamsBots)")
                                appendLine("DNT & Sec-GPC Sent: $dntHeadersSent")
                                r.items.forEach { item ->
                                    appendLine("- [${if (item.passed) "PASS" else "FAIL"}] ${item.name}: ${item.detail}")
                                }
                            }
                            val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cb?.setPrimaryClip(ClipData.newPlainText("Privacy Audit", summary))
                            Toast.makeText(context, "Privacy audit copied to clipboard", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // 2. Live Blocked Telemetry Metrics Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE INTERCEPTION METRICS",
                        color = silent.accentInfo,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    TextButton(
                        onClick = {
                            viewModel.resetPrivacyTelemetry()
                            Toast.makeText(context, "Privacy telemetry counters reset", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.heightIn(min = 48.dp).testTag("reset_privacy_telemetry_button")
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, tint = silent.textSecondary, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset Counters", fontSize = 11.sp, color = silent.textSecondary)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricTileCard(
                            modifier = Modifier.weight(1f).testTag("metric_blocked_ads"),
                            title = "ADS BLOCKED",
                            value = "$blockedAds",
                            subtitle = if (adblockEnabled) "Cosmetic & URL shield ON" else "AdBlocker paused",
                            accentColor = silent.accentSuccess,
                            icon = Icons.Default.Block
                        )
                        MetricTileCard(
                            modifier = Modifier.weight(1f).testTag("metric_blocked_trackers"),
                            title = "TRACKERS STOPPED",
                            value = "$blockedTrackersOnly",
                            subtitle = "Total intercepted: $totalBlocked",
                            accentColor = CyberBlue,
                            icon = Icons.Default.TrackChanges
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricTileCard(
                            modifier = Modifier.weight(1f).testTag("metric_dnt_headers"),
                            title = "DNT: 1 & SEC-GPC",
                            value = "$dntHeadersSent",
                            subtitle = if (doNotTrackEnabled) "OkHttp & WebView Active" else "Interceptor Paused",
                            accentColor = silent.accentInfo,
                            icon = Icons.Default.PrivacyTip
                        )
                        MetricTileCard(
                            modifier = Modifier.weight(1f).testTag("metric_scams_blocked"),
                            title = "SCAMS & MINERS",
                            value = "$blockedScamsBots",
                            subtitle = if (antiScamEnabled) "Homograph & Bot Guard" else "Guard Disabled",
                            accentColor = silent.accentError,
                            icon = Icons.Default.GppGood
                        )
                    }
                }
            }

            // 3. Real Ad-Block & Live HTTP Response Probe
            item {
                LivePrivacyProbeCard(
                    probeInput = probeInput,
                    onInputChange = { probeInput = it },
                    isProbing = isProbingPrivacy,
                    probeResult = liveProbeResult,
                    onRunProbe = { target -> viewModel.runLiveAdblockAndHeaderProbe(target) },
                    onOpenCleanUrl = { target -> viewModel.openUrl(target) }
                )
            }

            // 4. Custom Blocklist & Allowlist Manager
            item {
                CustomFilterRulesCard(
                    blockedDomains = customBlockedDomains,
                    allowedDomains = customAllowedDomains,
                    onAddBlocked = { viewModel.addCustomBlockedDomain(it) },
                    onRemoveBlocked = { viewModel.removeCustomBlockedDomain(it) },
                    onAddAllowed = { viewModel.addCustomAllowedDomain(it) },
                    onRemoveAllowed = { viewModel.removeCustomAllowedDomain(it) }
                )
            }

            // 5. Live Blocked Requests Feed
            item {
                BlockedRequestsFeedCard(
                    records = blockedRequestLog,
                    onAllowDomain = { host ->
                        if (viewModel.addCustomAllowedDomain(host)) {
                            Toast.makeText(context, "Added $host to Allowlist", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onClearLog = { viewModel.clearBlockedRequestLog() }
                )
            }

            // 6. Proxy & Virtual Shielded IP Status Card + Multi-Node Selector
            item {
                Text(
                    text = "PROXY & VIRTUAL SHIELDED IP SETUP",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(
                    borderColor = if (shieldedIpEnabled) silent.badgeSuccessBorder else silent.badgeWarningBorder,
                    backgroundColor = silent.cardBackground
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = "Proxy Shield Status",
                                    tint = if (shieldedIpEnabled) silent.accentSuccess else silent.accentWarning,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (shieldedIpEnabled) "Shielded IP Tunnel Active" else "Direct Connection (Unshielded)",
                                        color = if (shieldedIpEnabled) silent.accentSuccess else silent.accentWarning,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (shieldedIpEnabled) "WebRTC ICE relay-only leak guard active" else "Enable relay to conceal device IP",
                                        color = silent.textSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Switch(
                                checked = shieldedIpEnabled,
                                onCheckedChange = { viewModel.toggleShieldedIp(it) },
                                modifier = Modifier.testTag("privacy_shielded_ip_switch"),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = silent.primaryButtonContent,
                                    checkedTrackColor = silent.accentSuccess,
                                    uncheckedThumbColor = silent.textMuted,
                                    uncheckedTrackColor = silent.chipDefaultBackground
                                )
                            )
                        }

                        if (shieldedIpEnabled) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(silent.screenBackground)
                                    .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(activeRelayNode.flag, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = activeRelayNode.location,
                                            color = silent.textPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "Virtual IP: ${activeRelayNode.virtualIp} • ${activeRelayNode.latencyMs}ms",
                                        color = silent.accentInfo,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Tunnel: ${activeRelayNode.protocol}",
                                        color = silent.textMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.rotateShieldedIp()
                                        Toast.makeText(context, "IP rotated to ${viewModel.activeRelayNode.value.virtualIp}", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = silent.secondaryButtonBackground,
                                        contentColor = silent.accentSuccess
                                    ),
                                    border = BorderStroke(1.dp, silent.accentSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("privacy_rotate_ip_button")
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rotate", color = silent.accentSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(viewModel.relayNodes) { node ->
                                    val isSelected = node.virtualIp == activeRelayNode.virtualIp
                                    Column(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) silent.badgeSuccessBackground else silent.screenBackground)
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) silent.accentSuccess else silent.cardBorder,
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                            .clickable { viewModel.selectRelayNode(node) }
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Text("${node.flag} ${node.location.substringBefore(",")}", color = silent.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text("${node.latencyMs}ms • ${node.virtualIp}", color = silent.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 7. Active Defense & Cosmetic Shield Matrix
            item {
                Text(
                    text = "ACTIVE TRACKING PREVENTIONS",
                    color = silent.accentInfo,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                CyberCard(borderColor = silent.cardBorder, backgroundColor = silent.cardBackground) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PreventionToggleRow(
                            icon = Icons.Default.Block,
                            iconTint = silent.accentSuccess,
                            title = "Ad & Cosmetic Element Blocker",
                            subtitle = "Stops ad domains ($activeRuleCount rules) and hides banner slots via CSS",
                            checked = adblockEnabled,
                            onCheckedChange = { viewModel.toggleAdblock(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.PrivacyTip,
                            iconTint = silent.accentInfo,
                            title = "DNT: 1 & Sec-GPC Header Interceptor",
                            subtitle = "Appends Do Not Track headers to all outgoing browser & API traffic",
                            checked = doNotTrackEnabled,
                            onCheckedChange = { viewModel.toggleDoNotTrack(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.Security,
                            iconTint = silent.accentError,
                            title = "Anti-Scammer & Cryptominer Guard",
                            subtitle = "Blocks phishing links, punycode homographs, and cryptojackers",
                            checked = antiScamEnabled,
                            onCheckedChange = { viewModel.toggleAntiScamProtection(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.Fingerprint,
                            iconTint = CyberPurple,
                            title = "Canvas, WebGL & WebRTC Spoofing",
                            subtitle = "Poisons device fingerprinting and enforces relay-only WebRTC ICE",
                            checked = fingerprintShieldEnabled,
                            onCheckedChange = { viewModel.toggleFingerprintShield(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.Cookie,
                            iconTint = silent.accentWarning,
                            title = "Third-Party Cookie Partitioning",
                            subtitle = "Isolates cross-site tracking cookies per active origin",
                            checked = thirdPartyCookiesBlocked,
                            onCheckedChange = { viewModel.toggleThirdPartyCookies(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.Https,
                            iconTint = CyberBlue,
                            title = "HTTPS Everywhere Enforcement",
                            subtitle = "Automatically upgrades unencrypted HTTP connections to TLS",
                            checked = httpsEverywhereEnabled,
                            onCheckedChange = { viewModel.toggleHttpsEverywhere(it) }
                        )
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

                        PreventionToggleRow(
                            icon = Icons.Default.Code,
                            iconTint = silent.accentInfo,
                            title = "WebView JavaScript Engine",
                            subtitle = "Toggle off for ultra-strict static browsing against script exploits",
                            checked = javascriptEnabled,
                            onCheckedChange = { viewModel.toggleJavascript(it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTileCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    CyberCard(
        modifier = modifier,
        borderColor = accentColor.copy(alpha = 0.45f),
        backgroundColor = silent.cardBackground
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = silent.textMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                color = accentColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = silent.textSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun PreventionToggleRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (checked) iconTint else silent.textMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = silent.textPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = silent.textSecondary,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = silent.primaryButtonContent,
                checkedTrackColor = iconTint,
                uncheckedThumbColor = silent.textMuted,
                uncheckedTrackColor = silent.chipDefaultBackground
            )
        )
    }
}
