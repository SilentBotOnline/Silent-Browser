package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.privacy.BlockedRequestRecord
import com.example.data.privacy.LiveProbeResponse
import com.example.data.privacy.PrivacyAuditReport
import com.example.data.privacy.RequestBlockCategory
import com.example.ui.theme.silentColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PrivacyAuditChecklistCard(
    report: PrivacyAuditReport,
    onCopyReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    CyberCard(
        modifier = modifier.testTag("privacy_audit_checklist_card"),
        borderColor = if (report.scorePercent >= 85) silent.badgeSuccessBorder else silent.badgeWarningBorder,
        backgroundColor = silent.cardBackground
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PRODUCTION 7-POINT AUDIT",
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${report.passedCount} of ${report.totalChecks} shields verified (${report.scorePercent}%)",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
                OutlinedButton(
                    onClick = onCopyReport,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, silent.cardBorder),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.heightIn(min = 48.dp).testTag("copy_privacy_audit_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Audit Report",
                        tint = silent.accentInfo,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy Report", fontSize = 11.sp, color = silent.textPrimary)
                }
            }

            HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)

            report.items.forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = if (item.passed) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                        contentDescription = if (item.passed) "Passed" else "Attention Needed",
                        tint = if (item.passed) silent.accentSuccess else silent.accentWarning,
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.name,
                            color = silent.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = item.detail,
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LivePrivacyProbeCard(
    probeInput: String,
    onInputChange: (String) -> Unit,
    isProbing: Boolean,
    probeResult: LiveProbeResponse?,
    onRunProbe: (String) -> Unit,
    onOpenCleanUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    val quickSamples = listOf(
        "doubleclick.net",
        "google-analytics.com",
        "coinhive.com",
        "https://browser.silentbot.online/"
    )

    CyberCard(
        modifier = modifier.testTag("live_privacy_probe_card"),
        borderColor = silent.cardBorder,
        backgroundColor = silent.cardBackground
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Radar,
                    contentDescription = null,
                    tint = silent.accentInfo,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "REAL AD-BLOCK & LIVE RESPONSE INSPECTOR",
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Test real filter rules locally or send a live OkHttp DNT/GPC probe",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            OutlinedTextField(
                value = probeInput,
                onValueChange = onInputChange,
                singleLine = true,
                label = { Text("Domain or URL to test", fontSize = 12.sp) },
                placeholder = { Text("e.g. doubleclick.net or browser.silentbot.online", fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = silent.accentSuccess,
                    unfocusedBorderColor = silent.cardBorder,
                    focusedTextColor = silent.textPrimary,
                    unfocusedTextColor = silent.textPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("privacy_probe_input")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickSamples.forEach { sample ->
                    FilterChip(
                        selected = probeInput.trim().equals(sample, ignoreCase = true),
                        onClick = {
                            onInputChange(sample)
                            onRunProbe(sample)
                        },
                        label = { Text(sample.removePrefix("https://").removeSuffix("/"), fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = silent.chipDefaultBackground,
                            labelColor = silent.textPrimary,
                            selectedContainerColor = silent.badgeInfoBackground,
                            selectedLabelColor = silent.accentInfo
                        )
                    )
                }
            }

            Button(
                onClick = { onRunProbe(probeInput) },
                enabled = !isProbing && probeInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = silent.primaryButtonBackground,
                    contentColor = silent.primaryButtonContent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("privacy_probe_button")
            ) {
                if (isProbing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = silent.primaryButtonContent,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Inspecting Network & Rules...", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    Icon(Icons.Default.Http, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Inspect Filter & Live Response", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            if (probeResult != null) {
                val blocked = probeResult.filterDecision.blocked
                val badgeColor = if (blocked) silent.accentSuccess else silent.accentInfo
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(silent.screenBackground)
                        .border(1.dp, badgeColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                        .testTag("privacy_probe_result_card"),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusBadge(
                            text = if (blocked) {
                                "BLOCKED • ${probeResult.filterDecision.category.label}"
                            } else {
                                "HTTP ${probeResult.httpStatusCode ?: 0} • ${probeResult.filterDecision.category.label}"
                            },
                            color = badgeColor
                        )
                        Text(
                            text = if (blocked) "0 ms • 0 B" else "${probeResult.latencyMs ?: 0} ms",
                            color = silent.textMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = probeResult.summary,
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "Host: ${probeResult.host} | Rule: ${probeResult.filterDecision.matchedRule}",
                        color = silent.textSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    if (!blocked) {
                        Text(
                            text = "Origin: ${probeResult.serverHeader ?: "Unknown"} | DNT: ${if (probeResult.dntHeaderSent) "1" else "OFF"} | Sec-GPC: ${if (probeResult.gpcHeaderSent) "1" else "OFF"}",
                            color = silent.textSecondary,
                            fontSize = 11.sp
                        )
                        if ((probeResult.httpStatusCode ?: 0) in 200..399) {
                            TextButton(
                                onClick = { onOpenCleanUrl(probeResult.inputUrl) },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(
                                    text = "Open Verified Clean URL in Browser →",
                                    color = silent.accentSuccess,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomFilterRulesCard(
    blockedDomains: Set<String>,
    allowedDomains: Set<String>,
    onAddBlocked: (String) -> Boolean,
    onRemoveBlocked: (String) -> Unit,
    onAddAllowed: (String) -> Boolean,
    onRemoveAllowed: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    var domainInput by remember { mutableStateOf("") }
    var feedbackMsg by remember { mutableStateOf<String?>(null) }

    CyberCard(
        modifier = modifier.testTag("custom_filter_rules_card"),
        borderColor = silent.cardBorder,
        backgroundColor = silent.cardBackground
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Rule,
                    contentDescription = null,
                    tint = silent.accentSuccess,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "CUSTOM BLOCKLIST & ALLOWLIST",
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Rules enforce live inside WebView request interception",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            OutlinedTextField(
                value = domainInput,
                onValueChange = {
                    domainInput = it
                    feedbackMsg = null
                },
                singleLine = true,
                label = { Text("Domain (e.g. ads.example.com)", fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = silent.accentSuccess,
                    unfocusedBorderColor = silent.cardBorder,
                    focusedTextColor = silent.textPrimary,
                    unfocusedTextColor = silent.textPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_domain_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (onAddBlocked(domainInput)) {
                            feedbackMsg = "Blocked ${domainInput.trim()} at request level."
                            domainInput = ""
                        } else {
                            feedbackMsg = "Enter a valid domain such as tracker.example.com"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = silent.accentError,
                        contentColor = silent.primaryButtonContent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("add_custom_block_button")
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Block Domain", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = {
                        if (onAddAllowed(domainInput)) {
                            feedbackMsg = "Trusted ${domainInput.trim()} on allowlist."
                            domainInput = ""
                        } else {
                            feedbackMsg = "Enter a valid domain such as docs.example.com"
                        }
                    },
                    border = BorderStroke(1.dp, silent.accentSuccess),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("add_custom_allow_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = silent.accentSuccess, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Allow Domain", fontSize = 12.sp, color = silent.accentSuccess, fontWeight = FontWeight.SemiBold)
                }
            }

            if (!feedbackMsg.isNullOrBlank()) {
                Text(
                    text = feedbackMsg!!,
                    color = silent.accentInfo,
                    fontSize = 11.sp
                )
            }

            if (blockedDomains.isNotEmpty()) {
                Text(
                    text = "Custom Blocked (${blockedDomains.size})",
                    color = silent.accentError,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    blockedDomains.sorted().forEach { domain ->
                        DomainRuleChip(
                            domain = domain,
                            isAllow = false,
                            onRemove = { onRemoveBlocked(domain) }
                        )
                    }
                }
            }

            if (allowedDomains.isNotEmpty()) {
                Text(
                    text = "Trusted Allowlist (${allowedDomains.size})",
                    color = silent.accentSuccess,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    allowedDomains.sorted().forEach { domain ->
                        DomainRuleChip(
                            domain = domain,
                            isAllow = true,
                            onRemove = { onRemoveAllowed(domain) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DomainRuleChip(
    domain: String,
    isAllow: Boolean,
    onRemove: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    val tint = if (isAllow) silent.accentSuccess else silent.accentError
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(tint.copy(alpha = 0.1f))
            .border(1.dp, tint.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
            .padding(start = 10.dp, end = 4.dp, top = 2.dp, bottom = 2.dp)
    ) {
        Text(
            text = domain,
            color = silent.textPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        IconButton(
            onClick = onRemove,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove rule $domain",
                tint = tint,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun BlockedRequestsFeedCard(
    records: List<BlockedRequestRecord>,
    onAllowDomain: (String) -> Unit,
    onClearLog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val silent = MaterialTheme.silentColors
    var selectedFilter by remember { mutableStateOf("ALL") }
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    val filtered = remember(records, selectedFilter) {
        when (selectedFilter) {
            "ADS" -> records.filter {
                it.category == RequestBlockCategory.AD_NETWORK || it.category == RequestBlockCategory.CUSTOM_RULE
            }
            "TRACKERS" -> records.filter { it.category == RequestBlockCategory.ANALYTICS_TRACKER }
            "SCAMS" -> records.filter {
                it.category == RequestBlockCategory.SCAM_PHISHING || it.category == RequestBlockCategory.CRYPTOMINER_BOT
            }
            else -> records
        }
    }

    CyberCard(
        modifier = modifier.testTag("blocked_requests_feed_card"),
        borderColor = silent.cardBorder,
        backgroundColor = silent.cardBackground
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "LIVE INTERCEPTED REQUEST LOG",
                        color = silent.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${records.size} real blocked request(s) captured",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
                if (records.isNotEmpty()) {
                    TextButton(
                        onClick = onClearLog,
                        modifier = Modifier.heightIn(min = 48.dp).testTag("clear_blocked_log_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = null,
                            tint = silent.accentError,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", color = silent.accentError, fontSize = 12.sp)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL" to "All", "ADS" to "Ads", "TRACKERS" to "Trackers", "SCAMS" to "Scams & Bots").forEach { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = silent.chipDefaultBackground,
                            labelColor = silent.textPrimary,
                            selectedContainerColor = silent.badgeSuccessBackground,
                            selectedLabelColor = silent.accentSuccess
                        )
                    )
                }
            }

            if (filtered.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(silent.screenBackground)
                        .border(1.dp, silent.cardBorder, RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(silent.badgeSuccessBackground),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = silent.accentSuccess,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "No blocked requests match this filter yet. Browse any site or run the Live Response Inspector above.",
                        color = silent.textSecondary,
                        fontSize = 11.sp
                    )
                }
            } else {
                filtered.take(15).forEachIndexed { idx, record ->
                    val catColor = when (record.category) {
                        RequestBlockCategory.AD_NETWORK, RequestBlockCategory.CUSTOM_RULE -> silent.accentSuccess
                        RequestBlockCategory.ANALYTICS_TRACKER -> silent.accentInfo
                        RequestBlockCategory.SCAM_PHISHING, RequestBlockCategory.CRYPTOMINER_BOT -> silent.accentError
                        RequestBlockCategory.ALLOWED -> silent.textMuted
                    }
                    if (idx > 0) {
                        HorizontalDivider(color = silent.cardBorder, thickness = 0.5.dp)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StatusBadge(text = record.category.label, color = catColor)
                                Text(
                                    text = formatter.format(Date(record.timestampMs)),
                                    color = silent.textMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = record.host.ifBlank { record.url },
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Rule: ${record.matchedRule}",
                                color = silent.textSecondary,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (record.category != RequestBlockCategory.SCAM_PHISHING &&
                            record.category != RequestBlockCategory.CRYPTOMINER_BOT &&
                            record.host.isNotBlank()
                        ) {
                            OutlinedButton(
                                onClick = { onAllowDomain(record.host) },
                                border = BorderStroke(1.dp, silent.cardBorder),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.heightIn(min = 40.dp)
                            ) {
                                Text("Allow", fontSize = 11.sp, color = silent.textPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
