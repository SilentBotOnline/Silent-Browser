package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuthSheetMode
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountAuthModal(
    viewModel: BrowserViewModel
) {
    val authState by viewModel.authUiState.collectAsState()
    val silent = MaterialTheme.silentColors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = silent.primaryButtonBackground,
        unfocusedBorderColor = silent.cardBorder,
        focusedTextColor = silent.textPrimary,
        unfocusedTextColor = silent.textPrimary,
        focusedLabelColor = silent.primaryButtonBackground,
        unfocusedLabelColor = silent.textSecondary,
        focusedContainerColor = silent.screenBackground,
        unfocusedContainerColor = silent.screenBackground,
        cursorColor = silent.primaryButtonBackground
    )

    ModalBottomSheet(
        onDismissRequest = { if (!authState.isSubmitting) viewModel.dismissAccountAuthModal() },
        containerColor = silent.topBarSurface,
        contentColor = silent.textPrimary,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.CloudSync,
                        contentDescription = null,
                        tint = silent.primaryButtonBackground,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (authState.mode == AuthSheetMode.SIGN_IN) {
                                "Sign In to Cloud Sync"
                            } else {
                                "Create Sync Account"
                            },
                            color = silent.textPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Sync bookmarks, history & privacy settings across devices",
                            color = silent.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(
                    onClick = { if (!authState.isSubmitting) viewModel.dismissAccountAuthModal() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("auth_modal_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close authentication modal",
                        tint = silent.textMuted
                    )
                }
            }

            // Mode Segmented Toggle (SIGN_IN vs CREATE_ACCOUNT)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(silent.cardBackground)
                    .border(1.dp, silent.cardBorder, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    AuthSheetMode.SIGN_IN to "Sign In",
                    AuthSheetMode.CREATE_ACCOUNT to "Create Account"
                ).forEach { (mode, label) ->
                    val selected = authState.mode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) silent.primaryButtonBackground else silent.cardBackground)
                            .clickable(enabled = !authState.isSubmitting) {
                                viewModel.setAuthSheetMode(mode)
                            }
                            .testTag(
                                if (mode == AuthSheetMode.SIGN_IN) "auth_mode_signin_tab"
                                else "auth_mode_create_tab"
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (selected) silent.primaryButtonContent else silent.textSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (authState.errorMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_modal_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = authState.errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            if (authState.mode == AuthSheetMode.CREATE_ACCOUNT) {
                OutlinedTextField(
                    value = authState.displayName,
                    onValueChange = { viewModel.updateAuthDisplayName(it) },
                    label = { Text("Display Name (Optional)") },
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, tint = silent.textMuted)
                    },
                    singleLine = true,
                    enabled = !authState.isSubmitting,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_display_name_input")
                )
            }

            OutlinedTextField(
                value = authState.email,
                onValueChange = { viewModel.updateAuthEmail(it) },
                label = { Text("Email Address") },
                leadingIcon = {
                    Icon(Icons.Default.Email, contentDescription = null, tint = silent.textMuted)
                },
                singleLine = true,
                enabled = !authState.isSubmitting,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_email_input")
            )

            OutlinedTextField(
                value = authState.password,
                onValueChange = { viewModel.updateAuthPassword(it) },
                label = { Text("Password (min 6 characters)") },
                leadingIcon = {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = silent.textMuted)
                },
                trailingIcon = {
                    IconButton(
                        onClick = { viewModel.toggleAuthPasswordVisibility() },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (authState.isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (authState.isPasswordVisible) "Hide password" else "Show password",
                            tint = silent.textMuted
                        )
                    }
                },
                visualTransformation = if (authState.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                enabled = !authState.isSubmitting,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = if (authState.mode == AuthSheetMode.CREATE_ACCOUNT) ImeAction.Next else ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        if (authState.mode == AuthSheetMode.SIGN_IN) {
                            viewModel.submitAccountAuth()
                        }
                    }
                ),
                colors = fieldColors,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_password_input")
            )

            if (authState.mode == AuthSheetMode.CREATE_ACCOUNT) {
                OutlinedTextField(
                    value = authState.confirmPassword,
                    onValueChange = { viewModel.updateAuthConfirmPassword(it) },
                    label = { Text("Confirm Password") },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = silent.textMuted)
                    },
                    visualTransformation = if (authState.isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    enabled = !authState.isSubmitting,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { viewModel.submitAccountAuth() }
                    ),
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_confirm_password_input")
                )
            }

            Text(
                text = "Local device records remain your source of truth during cross-device conflict resolution.",
                color = silent.textMuted,
                fontSize = 11.sp
            )

            Button(
                onClick = { viewModel.submitAccountAuth() },
                enabled = !authState.isSubmitting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = silent.primaryButtonBackground,
                    contentColor = silent.primaryButtonContent,
                    disabledContainerColor = silent.primaryButtonBackground.copy(alpha = 0.55f),
                    disabledContentColor = silent.primaryButtonContent
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("auth_submit_button")
            ) {
                if (authState.isSubmitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = silent.primaryButtonContent
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (authState.mode == AuthSheetMode.SIGN_IN) "Signing In..." else "Creating Account...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                } else {
                    Text(
                        text = if (authState.mode == AuthSheetMode.SIGN_IN) "Sign In & Sync" else "Create Account & Sync",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}
