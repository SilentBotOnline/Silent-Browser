package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BrowserBottomBar
import com.example.ui.components.BrowserWebView
import com.example.ui.components.CommandHubModal
import com.example.ui.components.Omnibox
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.silentColors
import com.example.ui.viewmodel.BrowserViewModel
import com.example.ui.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val silent = MaterialTheme.silentColors
    val tabs by viewModel.tabs.collectAsState()
    val isBrowsing by viewModel.isBrowsing.collectAsState()
    val adblockEnabled by viewModel.adblockEnabled.collectAsState()
    val fingerprintEnabled by viewModel.fingerprintShieldEnabled.collectAsState()
    val javascriptEnabled by viewModel.javascriptEnabled.collectAsState()
    val doNotTrackEnabled by viewModel.doNotTrackEnabled.collectAsState()
    val httpsEverywhereEnabled by viewModel.httpsEverywhereEnabled.collectAsState()
    val thirdPartyCookiesBlocked by viewModel.thirdPartyCookiesBlocked.collectAsState()
    val antiScamEnabled by viewModel.antiScamProtectionEnabled.collectAsState()
    val showCommandHubModal by viewModel.showCommandHubModal.collectAsState()
    val activeSearchEngine by viewModel.activeSearchEngine.collectAsState()
    val searchSuggestions by viewModel.searchSuggestions.collectAsState()
    val isFetchingSuggestions by viewModel.isFetchingSuggestions.collectAsState()
    val cleanStealthMode by viewModel.cleanStealthMode.collectAsState()
    val currentAutofillCandidate by viewModel.currentAutofillCandidate.collectAsState()
    val showAutofillPrompt by viewModel.showAutofillPrompt.collectAsState()
    val autofillEnabled by viewModel.autofillEnabled.collectAsState()
    val activeTab = viewModel.activeTab

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showMenuSheet by remember { mutableStateOf(false) }

    // Intercept hardware/system back button
    BackHandler(enabled = activeTab?.canGoBack == true) {
        webViewRef?.goBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(silent.screenBackground)
    ) {
        // Top Omnibox
        Omnibox(
            activeTab = activeTab,
            openTabsCount = tabs.size,
            currentSearchEngine = activeSearchEngine,
            suggestions = searchSuggestions,
            isFetchingSuggestions = isFetchingSuggestions,
            isIncognito = activeTab?.isIncognito == true,
            cleanStealthMode = cleanStealthMode,
            onToggleIncognito = { viewModel.toggleActiveTabIncognito() },
            onSearchEngineSelected = { viewModel.setSearchEngine(it) },
            onUrlSubmit = { url ->
                viewModel.openUrl(url)
                webViewRef?.loadUrl(viewModel.activeTab?.url ?: url)
            },
            onSearchWithEngine = { query, engine ->
                viewModel.openUrl(query, engine)
                webViewRef?.loadUrl(viewModel.activeTab?.url ?: "")
            },
            onQueryChanged = { viewModel.onSearchInputChanged(it) },
            onClearSuggestions = { viewModel.clearSuggestions() },
            onReload = { webViewRef?.reload() },
            onOpenDashboard = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
            onOpenTabsOverview = { viewModel.navigateTo(ScreenDestination.TABS_OVERVIEW) },
            onOpenMenu = { showMenuSheet = true }
        )

        // Active Browser Action Bar (Back, Forward, Bookmark, Shield/Long-Press Panic, Privacy, Command Hub, Settings)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(silent.topBarSurface)
                .border(width = 0.5.dp, color = silent.barDivider)
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { webViewRef?.goBack() },
                    enabled = activeTab?.canGoBack == true,
                    modifier = Modifier.size(48.dp).testTag("browser_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = if (activeTab?.canGoBack == true) silent.accentInfo else silent.textMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { webViewRef?.goForward() },
                    enabled = activeTab?.canGoForward == true,
                    modifier = Modifier.size(48.dp).testTag("browser_bar_forward_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Forward",
                        tint = if (activeTab?.canGoForward == true) silent.accentInfo else silent.textMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = {
                        val url = activeTab?.url ?: ""
                        val title = activeTab?.title ?: ""
                        if (url.isNotBlank() && url != "about:blank") {
                            viewModel.toggleBookmark(url, title)
                            Toast.makeText(context, "Bookmark saved/updated", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY)
                        }
                    },
                    modifier = Modifier.size(48.dp).testTag("browser_bar_bookmark_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = "Bookmark Current Page",
                        tint = silent.accentSuccess,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Tap for Privacy HUD; Long-Press triggers instant Panic Wipe
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .heightIn(min = 48.dp)
                        .combinedClickable(
                            onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) },
                            onLongClick = {
                                viewModel.panicPurge()
                                Toast.makeText(context, "Panic Wipe executed", Toast.LENGTH_SHORT).show()
                            }
                        )
                        .padding(horizontal = 6.dp)
                        .testTag("browser_panic_long_press"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = buildString {
                            append(if (doNotTrackEnabled) "DNT:1" else "STD")
                            append(" • ")
                            append(if (antiScamEnabled) "SHIELDED" else "DIRECT")
                        },
                        color = if (antiScamEnabled) silent.accentSuccess else silent.textMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD) },
                    modifier = Modifier.size(48.dp).testTag("browser_bar_privacy_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PrivacyTip,
                        contentDescription = "Privacy Dashboard",
                        tint = silent.accentSuccess,
                        modifier = Modifier.size(19.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.openCommandHub() },
                    modifier = Modifier.size(48.dp).testTag("browser_bar_command_hub_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = "Open Command Hub",
                        tint = silent.accentInfo,
                        modifier = Modifier.size(19.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.SETTINGS) },
                    modifier = Modifier.size(48.dp).testTag("browser_bar_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Browser Settings",
                        tint = silent.textPrimary,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }

        // Loading Progress Bar
        if (activeTab?.isLoading == true) {
            LinearProgressIndicator(
                progress = { (activeTab.progress / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = silent.accentSuccess,
                trackColor = silent.barDivider
            )
        } else {
            Spacer(modifier = Modifier.height(2.dp))
        }

        // Interactive Credentials Autofill Banner
        AnimatedVisibility(visible = autofillEnabled && showAutofillPrompt && currentAutofillCandidate != null) {
            currentAutofillCandidate?.let { candidate ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(silent.cardBackground)
                        .border(1.dp, silent.chipSelectedBorder)
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Autofill",
                            tint = silent.accentInfo,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Autofill credentials for ${candidate.domain}?",
                                color = silent.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Account: ${candidate.username}",
                                color = silent.accentSuccess,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                val script = viewModel.getAutofillInjectionScript(candidate)
                                webViewRef?.evaluateJavascript(script, null)
                                viewModel.dismissAutofillPrompt()
                                Toast.makeText(context, "Credentials autofilled!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = silent.primaryButtonBackground,
                                contentColor = silent.primaryButtonContent
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.heightIn(min = 40.dp)
                        ) {
                            Text("Auto-Fill", color = silent.primaryButtonContent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        IconButton(
                            onClick = { viewModel.dismissAutofillPrompt() },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = silent.textMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Real Android WebView (absorbs full height above navigation inset while browsing)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(silent.screenBackground)
                .then(if (isBrowsing) Modifier.navigationBarsPadding() else Modifier)
        ) {
            val activeUrl = activeTab?.url ?: "about:blank"

            BrowserWebView(
                url = activeUrl,
                javascriptEnabled = javascriptEnabled,
                adblockEnabled = adblockEnabled,
                fingerprintEnabled = fingerprintEnabled,
                doNotTrackEnabled = doNotTrackEnabled,
                httpsEverywhereEnabled = httpsEverywhereEnabled,
                thirdPartyCookiesBlocked = thirdPartyCookiesBlocked,
                antiScamEnabled = antiScamEnabled,
                extensionScripts = viewModel.getInjectedExtensionScripts(),
                userAgent = viewModel.getUserAgentString(),
                onProgressChanged = { progress, isLoading ->
                    viewModel.updateActiveTabProgress(progress, isLoading)
                },
                onPageFinished = { url, title, canGoBack, canGoForward ->
                    viewModel.updateActiveTabDetails(url, title, canGoBack, canGoForward)
                },
                onBlockedTracker = { blockedUrl ->
                    viewModel.recordBlockedRequest(blockedUrl)
                },
                onBlockedThreat = { threatUrl ->
                    viewModel.incrementScamBotBlockedCount(threatUrl)
                },
                onDownloadRequested = { url, ua, contentDisposition, mimetype, contentLength ->
                    viewModel.enqueueDownload(url, contentDisposition, mimetype, contentLength)
                },
                onWebViewCreated = { webView ->
                    webViewRef = webView
                },
                backgroundColor = silent.screenBackground.toArgb(),
                modifier = Modifier.fillMaxSize()
            )
        }

        // Auto-collapsing Bottom Navigation Bar (hidden while active page is loaded/browsing)
        AnimatedVisibility(
            visible = !isBrowsing,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            BrowserBottomBar(
                openTabsCount = tabs.size,
                isHomeSelected = false,
                isAccountSelected = false,
                onHome = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                onBookmarks = { viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY) },
                onTabs = { viewModel.navigateTo(ScreenDestination.TABS_OVERVIEW) },
                onAccount = { viewModel.navigateTo(ScreenDestination.ACCOUNT) }
            )
        }
    }

    if (showCommandHubModal) {
        CommandHubModal(
            viewModel = viewModel,
            onDismiss = { viewModel.closeCommandHub() }
        )
    }

    // Modal Menu Sheet
    if (showMenuSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMenuSheet = false },
            containerColor = silent.cardBackground,
            contentColor = silent.textPrimary,
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "SILENT BROWSER MENU",
                    color = silent.accentSuccess,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                BrowserMenuRow(
                    icon = Icons.Default.Dashboard,
                    iconTint = silent.accentInfo,
                    title = "New Tab",
                    onClick = {
                        showMenuSheet = false
                        viewModel.createNewTab()
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Bookmark,
                    iconTint = silent.accentSuccess,
                    title = "Bookmarks & History",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.BOOKMARKS_HISTORY)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.VpnKey,
                    iconTint = silent.accentInfo,
                    title = "Encrypted Password Vault",
                    subtitle = "AES-256 GCM logins & auto-fill",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.PASSWORD_VAULT)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Download,
                    iconTint = silent.accentInfo,
                    title = "Download Manager",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.DOWNLOADS)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.VisibilityOff,
                    iconTint = CyberPurple,
                    title = "New Incognito Tab",
                    titleColor = CyberPurple,
                    onClick = {
                        showMenuSheet = false
                        viewModel.createNewTab(isIncognito = true)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Extension,
                    iconTint = silent.accentSuccess,
                    title = "Browser Extensions & Scripts",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.EXTENSIONS)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Terminal,
                    iconTint = silent.accentInfo,
                    title = "Network & Sync Diagnostics",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.DEVOPS_CENTER)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Security,
                    iconTint = silent.accentSuccess,
                    title = "Privacy Dashboard & Metrics",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.PRIVACY_DASHBOARD)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Settings,
                    iconTint = silent.textPrimary,
                    title = "Shield Settings & Privacy",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.SETTINGS)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Info,
                    iconTint = silent.accentInfo,
                    title = "About Silent Browser",
                    onClick = {
                        showMenuSheet = false
                        viewModel.navigateTo(ScreenDestination.ABOUT)
                    }
                )

                BrowserMenuRow(
                    icon = Icons.Default.Share,
                    iconTint = silent.textSecondary,
                    title = "Share Page",
                    onClick = {
                        showMenuSheet = false
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, activeTab?.url ?: "")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Link"))
                    }
                )

                BrowserMenuRow(
                    icon = Icons.AutoMirrored.Filled.OpenInNew,
                    iconTint = silent.accentSuccess,
                    title = "Open in External App",
                    onClick = {
                        showMenuSheet = false
                        viewModel.openInExternalApp(context)
                    }
                )

                // Panic Purge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(silent.panicArmedBackground.copy(alpha = 0.14f))
                        .border(1.dp, silent.accentError.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .clickable {
                            showMenuSheet = false
                            viewModel.panicPurge()
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = silent.accentError)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Panic Wipe (Amnesic RAM Purge)", color = silent.accentError, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun BrowserMenuRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String? = null,
    titleColor: Color? = null,
    onClick: () -> Unit
) {
    val silent = MaterialTheme.silentColors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(silent.chipDefaultBackground)
            .border(1.dp, silent.cardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = iconTint)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, color = titleColor ?: silent.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            if (subtitle != null) {
                Text(subtitle, color = silent.textMuted, fontSize = 10.sp)
            }
        }
    }
}
