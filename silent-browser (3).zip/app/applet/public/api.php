<?php
/**
 * Silent Browser - Production Authentication & Sync API
 * Target Portal: https://browser.silentbot.online/
 * Database: u562139744_silentbrowser on srv1169.hstgr.io:3306
 * Implements timestamp-based conflict resolution, strictly prioritizing local storage as the source of truth.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'status'));

function silentEnv(string $key, string $default = ''): string {
    $val = getenv($key);
    if ($val !== false && $val !== '') return $val;
    if (isset($_ENV[$key]) && $_ENV[$key] !== '') return $_ENV[$key];
    if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') return $_SERVER[$key];
    return $default;
}

function readJsonBody(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

$defaultReleases = [
    'android' => [
        'name' => 'Android (Jetpack Compose APK)',
        'package' => 'silent-browser-v0.1-android.apk',
        'size' => '28.4 MB',
        'url' => 'https://browser.silentbot.online/releases/silent-browser-v0.1-android.apk',
        'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
    ],
    'windows' => [
        'name' => 'Windows 10/11 (x64 Desktop)',
        'package' => 'silent-browser-v0.1-win-x64.exe',
        'size' => '64.2 MB',
        'url' => 'https://browser.silentbot.online/releases/silent-browser-v0.1-win-x64.exe',
        'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
    ],
    'ios' => [
        'name' => 'iPhone / iPad (iOS 15+)',
        'package' => 'Silent Browser iOS App / TestFlight',
        'size' => '31.8 MB',
        'url' => 'https://browser.silentbot.online/releases/silent-browser-ios.html',
        'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
    ],
    'macos' => [
        'name' => 'macOS (Universal Apple Silicon & Intel)',
        'package' => 'silent-browser-v0.1-macos.dmg',
        'size' => '68.9 MB',
        'url' => 'https://browser.silentbot.online/releases/silent-browser-v0.1-macos.dmg',
        'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
    ],
    'other' => [
        'name' => 'Linux / Other OS (AppImage & Source)',
        'package' => 'silent-browser-v0.1-linux-x86_64.AppImage',
        'size' => '59.5 MB',
        'url' => 'https://browser.silentbot.online/releases/silent-browser-v0.1-linux-x86_64.AppImage',
        'checksum_url' => 'https://browser.silentbot.online/releases/SHA256SUMS.txt'
    ]
];

$dbHost = silentEnv('SILENT_DB_HOST', 'srv1169.hstgr.io');
$dbPort = (int)silentEnv('SILENT_DB_PORT', '3306');
if ($dbPort <= 0 || $dbPort > 65535) $dbPort = 3306;
$dbName = silentEnv('SILENT_DB_NAME', 'u562139744_silentbrowser');
$dbUser = silentEnv('SILENT_DB_USER', 'u562139744_silentbrowser');
$dbPass = silentEnv('SILENT_DB_PASS', '@Silentbrowser@2026@');

function connectPdo(string $host, int $port, string $name, string $user, string $pass): ?PDO {
    if ($name === '' || $user === '' || $pass === '') {
        return null;
    }
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    return new PDO($dsn, $user, $pass, $options);
}

if ($action === 'status') {
    $dbConnected = false;
    try {
        $pdo = connectPdo($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
        if ($pdo !== null) {
            $pdo->query('SELECT 1');
            $dbConnected = true;
        }
    } catch (\Throwable $e) {
        $dbConnected = false;
    }
    echo json_encode([
        'status' => 'online',
        'app' => 'Silent Browser Backend',
        'portal' => 'https://browser.silentbot.online/',
        'database' => 'u562139744_silentbrowser',
        'database_connected' => $dbConnected,
        'conflict_resolution' => 'local_storage_priority',
        'version' => '0.1-prod',
        'timestamp' => time()
    ]);
    exit;
}

if ($action === 'releases') {
    echo json_encode([
        'status' => 'success',
        'version' => '0.1-prod',
        'portal' => 'https://browser.silentbot.online/',
        'platforms' => $defaultReleases
    ]);
    exit;
}

$pdo = connectPdo($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
if (!$pdo) {
    http_response_code(503);
    echo json_encode([
        'status' => 'not_configured',
        'message' => 'Database credentials not configured or connection failed.'
    ]);
    exit;
}

// 1. Register User Endpoint
if ($action === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = readJsonBody();
    $email = trim((string)($input['email'] ?? ''));
    $pass = (string)($input['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password (min 6 chars).']);
        exit;
    }
    $hash = password_hash($pass, PASSWORD_BCRYPT);
    try {
        $stmt = $pdo->prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)");
        $stmt->execute([$email, $hash]);
        $userId = $pdo->lastInsertId();
        $token = bin2hex(random_bytes(32));
        $expires = gmdate('Y-m-d H:i:s', time() + 86400 * 30);
        $sess = $pdo->prepare("INSERT INTO user_sessions (user_id, token, expires_at) VALUES (?, ?, ?)");
        $sess->execute([$userId, $token, $expires]);
        echo json_encode(['status' => 'success', 'user_id' => $userId, 'email' => $email, 'token' => $token]);
    } catch (\PDOException $e) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Email already registered or database error.']);
    }
    exit;
}

// 2. Login User Endpoint
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = readJsonBody();
    $email = trim((string)($input['email'] ?? ''));
    $pass = (string)($input['password'] ?? '');
    $stmt = $pdo->prepare("SELECT id, email, password_hash FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($pass, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password.']);
        exit;
    }
    $token = bin2hex(random_bytes(32));
    $expires = gmdate('Y-m-d H:i:s', time() + 86400 * 30);
    $sess = $pdo->prepare("INSERT INTO user_sessions (user_id, token, expires_at) VALUES (?, ?, ?)");
    $sess->execute([$user['id'], $token, $expires]);
    echo json_encode(['status' => 'success', 'user_id' => $user['id'], 'email' => $user['email'], 'token' => $token]);
    exit;
}

// Helper: authenticate bearer token
function authenticateUser(PDO $pdo): ?array {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_starts_with($authHeader, 'Bearer ') ? substr($authHeader, 7) : '';
    if ($token === '') return null;
    $stmt = $pdo->prepare("SELECT u.id, u.email FROM user_sessions s JOIN users u ON s.user_id = u.id WHERE s.token = ? AND s.expires_at >= UTC_TIMESTAMP()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    return $user ?: null;
}

if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_starts_with($authHeader, 'Bearer ') ? substr($authHeader, 7) : '';
    if ($token !== '') {
        $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE token = ?");
        $stmt->execute([$token]);
    }
    echo json_encode(['status' => 'success']);
    exit;
}

// 3. Sync Push Endpoint with Timestamp Conflict Resolution (Local Storage Priority)
if ($action === 'sync_push' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = authenticateUser($pdo);
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status' => 'unauthorized']);
        exit;
    }
    $input = readJsonBody();
    $userId = $user['id'];

    // Push Settings with timestamp conflict resolution (local storage priority)
    if (isset($input['settings']) && is_array($input['settings'])) {
        $st = $input['settings'];
        $clientTs = (int)($st['client_timestamp'] ?? time() * 1000);
        $sStmt = $pdo->prepare(
            "INSERT INTO browser_settings 
             (user_id, engine_mode, search_engine_id, adblock_enabled, fingerprint_shield, https_everywhere, javascript_enabled, block_third_party_cookies, dnt_enabled, anti_scam_enabled, shielded_ip_enabled, active_relay_location, clean_stealth_mode, suggestions_enabled, always_incognito, auto_purge_tab_closure, selected_user_agent, client_timestamp) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
             ON DUPLICATE KEY UPDATE 
               engine_mode = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(engine_mode), engine_mode),
               search_engine_id = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(search_engine_id), search_engine_id),
               adblock_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(adblock_enabled), adblock_enabled),
               fingerprint_shield = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(fingerprint_shield), fingerprint_shield),
               https_everywhere = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(https_everywhere), https_everywhere),
               javascript_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(javascript_enabled), javascript_enabled),
               block_third_party_cookies = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(block_third_party_cookies), block_third_party_cookies),
               dnt_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(dnt_enabled), dnt_enabled),
               anti_scam_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(anti_scam_enabled), anti_scam_enabled),
               shielded_ip_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(shielded_ip_enabled), shielded_ip_enabled),
               active_relay_location = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(active_relay_location), active_relay_location),
               clean_stealth_mode = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(clean_stealth_mode), clean_stealth_mode),
               suggestions_enabled = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(suggestions_enabled), suggestions_enabled),
               always_incognito = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(always_incognito), always_incognito),
               auto_purge_tab_closure = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(auto_purge_tab_closure), auto_purge_tab_closure),
               selected_user_agent = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(selected_user_agent), selected_user_agent),
               client_timestamp = GREATEST(client_timestamp, VALUES(client_timestamp))"
        );
        $sStmt->execute([
            $userId,
            substr((string)($st['engine_mode'] ?? 'MULTI_ENGINE'), 0, 32),
            substr((string)($st['search_engine_id'] ?? 'silent_stealth'), 0, 32),
            !empty($st['adblock_enabled']) ? 1 : 0,
            !empty($st['fingerprint_shield']) ? 1 : 0,
            !empty($st['https_everywhere']) ? 1 : 0,
            !empty($st['javascript_enabled']) ? 1 : 0,
            !empty($st['block_third_party_cookies']) ? 1 : 0,
            !empty($st['dnt_enabled']) ? 1 : 0,
            !empty($st['anti_scam_enabled']) ? 1 : 0,
            !empty($st['shielded_ip_enabled']) ? 1 : 0,
            substr((string)($st['active_relay_location'] ?? 'Zurich, Switzerland'), 0, 64),
            !empty($st['clean_stealth_mode']) ? 1 : 0,
            !empty($st['suggestions_enabled']) ? 1 : 0,
            !empty($st['always_incognito']) ? 1 : 0,
            !empty($st['auto_purge_tab_closure']) ? 1 : 0,
            substr((string)($st['selected_user_agent'] ?? 'Tor Browser (Spoofed)'), 0, 64),
            $clientTs
        ]);
    }

    // Push Browsing Sync Items with timestamp conflict resolution (local storage priority source of truth)
    if (isset($input['items']) && is_array($input['items'])) {
        $itemStmt = $pdo->prepare(
            "INSERT INTO browsing_sync_items (user_id, item_type, title, url, folder, category, is_pinned, visit_count, client_timestamp) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               title = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(title), title),
               folder = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(folder), folder),
               category = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(category), category),
               is_pinned = IF(VALUES(client_timestamp) >= client_timestamp, VALUES(is_pinned), is_pinned),
               visit_count = IF(VALUES(client_timestamp) >= client_timestamp, GREATEST(visit_count, VALUES(visit_count)), visit_count),
               client_timestamp = GREATEST(client_timestamp, VALUES(client_timestamp))"
        );
        foreach (array_slice($input['items'], 0, 500) as $item) {
            if (!is_array($item)) continue;
            $url = substr(trim((string)($item['url'] ?? '')), 0, 512);
            if (!preg_match('/^https?:\/\//i', $url)) continue;
            $itemType = substr(trim((string)($item['item_type'] ?? 'bookmark')), 0, 24);
            $title = substr(trim((string)($item['title'] ?? $url)), 0, 160);
            $folder = substr(trim((string)($item['folder'] ?? 'Favorites')), 0, 64);
            $category = substr(trim((string)($item['category'] ?? 'General')), 0, 64);
            $isPinned = !empty($item['is_pinned']) ? 1 : 0;
            $visitCount = max(0, (int)($item['visit_count'] ?? 0));
            $clientTs = (int)($item['client_timestamp'] ?? time() * 1000);
            $itemStmt->execute([$userId, $itemType, $title, $url, $folder, $category, $isPinned, $visitCount, $clientTs]);
        }
    }
    echo json_encode(['status' => 'success', 'message' => 'Cloud sync push completed with local storage priority conflict resolution.', 'timestamp' => time()]);
    exit;
}

// 4. Sync Pull Endpoint (Merge-by-Timestamp prioritizing local storage as source of truth)
if ($action === 'sync_pull') {
    $user = authenticateUser($pdo);
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status' => 'unauthorized']);
        exit;
    }
    $userId = $user['id'];
    $sStmt = $pdo->prepare("SELECT * FROM browser_settings WHERE user_id = ?");
    $sStmt->execute([$userId]);
    $settings = $sStmt->fetch() ?: null;

    $iStmt = $pdo->prepare("SELECT item_type, title, url, folder, category, is_pinned, visit_count, client_timestamp, updated_at FROM browsing_sync_items WHERE user_id = ? ORDER BY client_timestamp DESC LIMIT 500");
    $iStmt->execute([$userId]);
    $items = $iStmt->fetchAll();

    echo json_encode([
        'status' => 'success',
        'settings' => $settings,
        'items' => $items,
        'conflict_resolution' => 'local_storage_priority',
        'timestamp' => time()
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['status' => 'unknown_action']);
?>
