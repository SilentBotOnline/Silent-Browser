export type ThemeMode = 'white' | 'black' | 'midnight';

export type SearchEngineId =
  | 'silent'
  | 'duckduckgo'
  | 'brave'
  | 'startpage'
  | 'google'
  | 'yahoo'
  | 'bing'
  | 'ecosia'
  | 'mojeek';

export interface SearchEngineOption {
  id: SearchEngineId;
  displayName: string;
  badge: string;
  queryTemplate: string;
}

export const SEARCH_ENGINES: SearchEngineOption[] = [
  {
    id: 'silent',
    displayName: 'Silent Search',
    badge: '⚡',
    queryTemplate: 'https://duckduckgo.com/?q={q}&kp=-2&kz=-1&kac=-1&kn=1',
  },
  {
    id: 'duckduckgo',
    displayName: 'DuckDuckGo',
    badge: '🦆',
    queryTemplate: 'https://duckduckgo.com/?q={q}',
  },
  {
    id: 'brave',
    displayName: 'Brave Search',
    badge: '🦁',
    queryTemplate: 'https://search.brave.com/search?q={q}',
  },
  {
    id: 'startpage',
    displayName: 'Startpage',
    badge: 'SP',
    queryTemplate: 'https://www.startpage.com/do/search?q={q}',
  },
  {
    id: 'mojeek',
    displayName: 'Mojeek',
    badge: 'M',
    queryTemplate: 'https://www.mojeek.com/search?q={q}',
  },
  {
    id: 'google',
    displayName: 'Google',
    badge: 'G',
    queryTemplate: 'https://www.google.com/search?q={q}',
  },
  {
    id: 'yahoo',
    displayName: 'Yahoo Search',
    badge: 'Y!',
    queryTemplate: 'https://search.yahoo.com/search?p={q}',
  },
  {
    id: 'bing',
    displayName: 'Microsoft Bing',
    badge: 'B',
    queryTemplate: 'https://www.bing.com/search?q={q}',
  },
  {
    id: 'ecosia',
    displayName: 'Ecosia',
    badge: '🌱',
    queryTemplate: 'https://www.ecosia.org/search?q={q}',
  },
];

export type FeedCategory = 'all' | 'news' | 'github';

export interface BrowserSettings {
  theme: ThemeMode;
  searchEngine: SearchEngineId;
  adblockEnabled: boolean;
  fingerprintShield: boolean;
  httpsEverywhere: boolean;
  dntEnabled: boolean;
  antiScamEnabled: boolean;
  alwaysIncognito: boolean;
  autoPurgeOnExit: boolean;
  userAgentProfile: string;
}

export interface BrowserTabState {
  id: string;
  title: string;
  url: string;
  isHome: boolean;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  isIncognito: boolean;
  faviconUrl: string | null;
}

export interface ShieldStats {
  blockedAds: number;
  blockedTrackers: number;
  blockedScams: number;
  upgradedHttps: number;
  lastBlockedDomain: string | null;
}

export interface BookmarkRecord {
  id: number;
  title: string;
  url: string;
  folder: string;
  isPinned: boolean;
  clientTimestamp: number;
}

export interface HistoryRecord {
  id: number;
  title: string;
  url: string;
  visitCount: number;
  clientTimestamp: number;
}

export interface VaultEntry {
  id: number;
  origin: string;
  username: string;
  password: string;
  notes: string;
  updatedAt: number;
}

export interface VaultDisplayEntry {
  id: number;
  origin: string;
  username: string;
  passwordMasked: string;
  notes: string;
  updatedAt: number;
}

export interface LiveFeedItem {
  id: string;
  category: 'news' | 'github';
  source: string;
  title: string;
  summary: string;
  url: string;
  image: string | null;
  avatar: string | null;
  metric: string;
  publishedAt: string;
}

export interface LiveFeedResponse {
  status: 'live' | 'degraded';
  updatedUtc: string;
  newsCount: number;
  githubCount: number;
  items: LiveFeedItem[];
}

export interface SyncConflictItem {
  id: string;
  itemType: 'bookmark' | 'history' | 'settings';
  url: string;
  localTitle: string;
  localTimestamp: number;
  remoteTitle: string;
  remoteTimestamp: number;
}

export type ConflictResolutionStrategy = 'KEEP_LOCAL' | 'USE_REMOTE' | 'MERGE';

export interface AccountSessionState {
  isSignedIn: boolean;
  email: string | null;
  lastSyncedAt: number | null;
  portalUrl: string;
}

export interface SyncOperationResult {
  success: boolean;
  message: string;
  appliedCount: number;
  conflicts: SyncConflictItem[];
  syncedAt: number;
}

export interface AppDiagnosticInfo {
  appVersion: string;
  electronVersion: string;
  platform: string;
  arch: string;
  userDataPath: string;
  logFilePath: string;
  dbFilePath: string;
}

export interface ElectronAPI {
  // Window & Chrome
  getSettings: () => Promise<BrowserSettings>;
  updateSettings: (patch: Partial<BrowserSettings>) => Promise<BrowserSettings>;
  setOverlayActive: (hidden: boolean) => Promise<void>;

  // Tabs & Navigation
  getTabsSnapshot: () => Promise<{ tabs: BrowserTabState[]; activeTabId: string }>;
  createTab: (url?: string, incognito?: boolean) => Promise<void>;
  closeTab: (tabId: string) => Promise<void>;
  selectTab: (tabId: string) => Promise<void>;
  navigate: (urlOrQuery: string) => Promise<void>;
  goBack: () => Promise<void>;
  goForward: () => Promise<void>;
  reloadTab: () => Promise<void>;
  goHome: () => Promise<void>;

  // Privacy & Panic Wipe
  getShieldStats: () => Promise<ShieldStats>;
  triggerPanicWipe: () => Promise<{ clearedAt: number }>;

  // Local SQLite Data
  listBookmarks: () => Promise<BookmarkRecord[]>;
  addBookmark: (title: string, url: string, folder?: string) => Promise<BookmarkRecord>;
  deleteBookmark: (id: number) => Promise<void>;
  listHistory: (limit?: number) => Promise<HistoryRecord[]>;
  clearHistory: () => Promise<void>;

  // Encrypted Vault
  listVault: () => Promise<VaultDisplayEntry[]>;
  revealVaultPassword: (id: number) => Promise<string>;
  saveVaultEntry: (origin: string, username: string, password: string, notes?: string) => Promise<VaultDisplayEntry>;
  deleteVaultEntry: (id: number) => Promise<void>;

  // Live Feed & Cloud Sync
  fetchLiveFeed: (forceRefresh?: boolean) => Promise<LiveFeedResponse>;
  getAccountState: () => Promise<AccountSessionState>;
  registerAccount: (email: string, password: string) => Promise<AccountSessionState>;
  loginAccount: (email: string, password: string) => Promise<AccountSessionState>;
  logoutAccount: () => Promise<AccountSessionState>;
  runCloudSync: () => Promise<SyncOperationResult>;
  resolveSyncConflict: (
    conflict: SyncConflictItem,
    strategy: ConflictResolutionStrategy
  ) => Promise<SyncOperationResult>;

  // Diagnostics & Support
  getDiagnostics: () => Promise<AppDiagnosticInfo>;
  openExternalSafe: (url: string) => Promise<void>;

  // Main -> Renderer push subscriptions (returns unsubscribe function)
  onTabsUpdated: (cb: (payload: { tabs: BrowserTabState[]; activeTabId: string }) => void) => () => void;
  onShieldStatsUpdated: (cb: (stats: ShieldStats) => void) => () => void;
  onPanicWiped: (cb: (payload: { clearedAt: number }) => void) => () => void;
}
