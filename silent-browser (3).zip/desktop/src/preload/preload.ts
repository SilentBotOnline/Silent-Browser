import { contextBridge, ipcRenderer, IpcRendererEvent } from 'electron';
import {
  BrowserSettings,
  BrowserTabState,
  ConflictResolutionStrategy,
  ElectronAPI,
  ShieldStats,
  SyncConflictItem,
} from '../shared/types';

const electronAPI: ElectronAPI = {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  updateSettings: (patch: Partial<BrowserSettings>) => ipcRenderer.invoke('settings:update', patch),
  setOverlayActive: (hidden: boolean) => ipcRenderer.invoke('overlay:setActive', hidden),

  getTabsSnapshot: () => ipcRenderer.invoke('tabs:snapshot'),
  createTab: (url?: string, incognito?: boolean) => ipcRenderer.invoke('tabs:create', url, incognito),
  closeTab: (tabId: string) => ipcRenderer.invoke('tabs:close', tabId),
  selectTab: (tabId: string) => ipcRenderer.invoke('tabs:select', tabId),
  navigate: (urlOrQuery: string) => ipcRenderer.invoke('tabs:navigate', urlOrQuery),
  goBack: () => ipcRenderer.invoke('tabs:back'),
  goForward: () => ipcRenderer.invoke('tabs:forward'),
  reloadTab: () => ipcRenderer.invoke('tabs:reload'),
  goHome: () => ipcRenderer.invoke('tabs:home'),

  getShieldStats: () => ipcRenderer.invoke('shields:getStats'),
  triggerPanicWipe: () => ipcRenderer.invoke('panic:wipe'),

  listBookmarks: () => ipcRenderer.invoke('bookmarks:list'),
  addBookmark: (title: string, url: string, folder?: string) =>
    ipcRenderer.invoke('bookmarks:add', title, url, folder),
  deleteBookmark: (id: number) => ipcRenderer.invoke('bookmarks:delete', id),

  listHistory: (limit?: number) => ipcRenderer.invoke('history:list', limit),
  clearHistory: () => ipcRenderer.invoke('history:clear'),

  listVault: () => ipcRenderer.invoke('vault:list'),
  revealVaultPassword: (id: number) => ipcRenderer.invoke('vault:reveal', id),
  saveVaultEntry: (origin: string, username: string, password: string, notes?: string) =>
    ipcRenderer.invoke('vault:save', origin, username, password, notes),
  deleteVaultEntry: (id: number) => ipcRenderer.invoke('vault:delete', id),

  fetchLiveFeed: (forceRefresh?: boolean) => ipcRenderer.invoke('feed:fetch', forceRefresh),
  getAccountState: () => ipcRenderer.invoke('account:state'),
  registerAccount: (email: string, password: string) =>
    ipcRenderer.invoke('account:register', email, password),
  loginAccount: (email: string, password: string) =>
    ipcRenderer.invoke('account:login', email, password),
  logoutAccount: () => ipcRenderer.invoke('account:logout'),
  runCloudSync: () => ipcRenderer.invoke('sync:run'),
  resolveSyncConflict: (conflict: SyncConflictItem, strategy: ConflictResolutionStrategy) =>
    ipcRenderer.invoke('sync:resolveConflict', conflict, strategy),

  getDiagnostics: () => ipcRenderer.invoke('app:diagnostics'),
  openExternalSafe: (url: string) => ipcRenderer.invoke('shell:openExternalSafe', url),

  onTabsUpdated: (cb: (payload: { tabs: BrowserTabState[]; activeTabId: string }) => void) => {
    const handler = (
      _event: IpcRendererEvent,
      payload: { tabs: BrowserTabState[]; activeTabId: string }
    ) => cb(payload);
    ipcRenderer.on('tabs:updated', handler);
    return () => {
      ipcRenderer.removeListener('tabs:updated', handler);
    };
  },

  onShieldStatsUpdated: (cb: (stats: ShieldStats) => void) => {
    const handler = (_event: IpcRendererEvent, stats: ShieldStats) => cb(stats);
    ipcRenderer.on('shields:updated', handler);
    return () => {
      ipcRenderer.removeListener('shields:updated', handler);
    };
  },

  onPanicWiped: (cb: (payload: { clearedAt: number }) => void) => {
    const handler = (_event: IpcRendererEvent, payload: { clearedAt: number }) => cb(payload);
    ipcRenderer.on('panic:wiped', handler);
    return () => {
      ipcRenderer.removeListener('panic:wiped', handler);
    };
  },
};

contextBridge.exposeInMainWorld('electronAPI', electronAPI);
