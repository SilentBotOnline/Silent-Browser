import Store from 'electron-store';
import { BrowserSettings, SearchEngineId, ThemeMode } from '../../shared/types';

export interface WindowBounds {
  width: number;
  height: number;
  x?: number;
  y?: number;
  isMaximized: boolean;
}

interface StoreSchema {
  settings: BrowserSettings;
  windowBounds: WindowBounds;
  accountEmail: string | null;
  authTokenEncrypted: string | null;
  lastSyncedAt: number | null;
}

const DEFAULT_SETTINGS: BrowserSettings = {
  theme: 'white',
  searchEngine: 'silent',
  adblockEnabled: true,
  fingerprintShield: true,
  httpsEverywhere: true,
  dntEnabled: true,
  antiScamEnabled: true,
  alwaysIncognito: false,
  autoPurgeOnExit: false,
  userAgentProfile: 'Silent Desktop Stealth (Windows NT 10.0; Win64)',
};

const DEFAULT_BOUNDS: WindowBounds = {
  width: 1320,
  height: 840,
  isMaximized: false,
};

export class ConfigStore {
  private readonly store: Store<StoreSchema>;

  constructor() {
    this.store = new Store<StoreSchema>({
      name: 'silent-browser-config',
      defaults: {
        settings: DEFAULT_SETTINGS,
        windowBounds: DEFAULT_BOUNDS,
        accountEmail: null,
        authTokenEncrypted: null,
        lastSyncedAt: null,
      },
    });
  }

  getSettings(): BrowserSettings {
    const saved = this.store.get('settings');
    return {
      ...DEFAULT_SETTINGS,
      ...saved,
      theme: this.validateTheme(saved?.theme),
      searchEngine: this.validateEngine(saved?.searchEngine),
    };
  }

  updateSettings(patch: Partial<BrowserSettings>): BrowserSettings {
    const current = this.getSettings();
    const next: BrowserSettings = {
      ...current,
      ...patch,
      theme: patch.theme ? this.validateTheme(patch.theme) : current.theme,
      searchEngine: patch.searchEngine
        ? this.validateEngine(patch.searchEngine)
        : current.searchEngine,
    };
    this.store.set('settings', next);
    return next;
  }

  getWindowBounds(): WindowBounds {
    return this.store.get('windowBounds', DEFAULT_BOUNDS);
  }

  setWindowBounds(bounds: WindowBounds): void {
    this.store.set('windowBounds', bounds);
  }

  getAccountEmail(): string | null {
    return this.store.get('accountEmail', null);
  }

  getEncryptedAuthToken(): string | null {
    return this.store.get('authTokenEncrypted', null);
  }

  getLastSyncedAt(): number | null {
    return this.store.get('lastSyncedAt', null);
  }

  setAccountSession(email: string | null, encryptedToken: string | null): void {
    this.store.set('accountEmail', email);
    this.store.set('authTokenEncrypted', encryptedToken);
  }

  setLastSyncedAt(ts: number | null): void {
    this.store.set('lastSyncedAt', ts);
  }

  resetOnPanicWipe(): void {
    this.store.set('accountEmail', null);
    this.store.set('authTokenEncrypted', null);
    this.store.set('lastSyncedAt', null);
  }

  private validateTheme(val: unknown): ThemeMode {
    if (val === 'black' || val === 'midnight' || val === 'white') {
      return val;
    }
    return 'white';
  }

  private validateEngine(val: unknown): SearchEngineId {
    const allowed: SearchEngineId[] = [
      'silent',
      'duckduckgo',
      'brave',
      'startpage',
      'google',
      'yahoo',
      'bing',
      'ecosia',
      'mojeek',
    ];
    return allowed.includes(val as SearchEngineId) ? (val as SearchEngineId) : 'silent';
  }
}
