import { BrowserWindow, WebContentsView, session, shell } from 'electron';
import crypto from 'node:crypto';
import { BrowserTabState, SEARCH_ENGINES, SearchEngineId } from '../../shared/types';
import { ConfigStore } from './ConfigStore';
import { DatabaseService } from './DatabaseService';
import { PrivacyNetworkService } from './PrivacyNetworkService';
import { log } from '../utils/logger';

interface ManagedTab {
  state: BrowserTabState;
  view: WebContentsView | null;
}

const TOP_CHROME_HEIGHT = 122;

export class BrowserTabManager {
  private tabs: ManagedTab[] = [];
  private activeTabId = '';
  private overlayHidden = false;
  private onTabsChanged: ((payload: { tabs: BrowserTabState[]; activeTabId: string }) => void) | null = null;

  constructor(
    private readonly mainWindow: BrowserWindow,
    private readonly configStore: ConfigStore,
    private readonly dbService: DatabaseService,
    private readonly privacyService: PrivacyNetworkService
  ) {
    this.mainWindow.on('resize', () => {
      this.layoutActiveView();
    });
    this.mainWindow.on('maximize', () => this.layoutActiveView());
    this.mainWindow.on('unmaximize', () => this.layoutActiveView());
  }

  setTabsListener(listener: (payload: { tabs: BrowserTabState[]; activeTabId: string }) => void): void {
    this.onTabsChanged = listener;
  }

  initializeDefaultTab(): void {
    const settings = this.configStore.getSettings();
    this.createTab(undefined, settings.alwaysIncognito);
  }

  getSnapshot(): { tabs: BrowserTabState[]; activeTabId: string } {
    return {
      tabs: this.tabs.map((t) => ({ ...t.state })),
      activeTabId: this.activeTabId,
    };
  }

  setOverlayActive(hidden: boolean): void {
    this.overlayHidden = hidden;
    this.layoutActiveView();
  }

  createTab(initialUrl?: string, incognito = false): void {
    const id = crypto.randomUUID();
    const cleanUrl = initialUrl ? this.resolveUserInputToUrl(initialUrl) : '';
    const isHome = cleanUrl === '';

    const tab: ManagedTab = {
      state: {
        id,
        title: isHome ? 'Silent Home' : cleanUrl,
        url: isHome ? 'silent://home' : cleanUrl,
        isHome,
        isLoading: !isHome,
        canGoBack: false,
        canGoForward: false,
        isIncognito: incognito,
        faviconUrl: null,
      },
      view: null,
    };

    this.tabs.push(tab);
    this.activeTabId = id;

    if (!isHome) {
      this.ensureViewForTab(tab);
      void tab.view?.webContents.loadURL(cleanUrl);
    }

    this.layoutActiveView();
    this.emitTabs();
  }

  closeTab(tabId: string): void {
    const idx = this.tabs.findIndex((t) => t.state.id === tabId);
    if (idx === -1) return;

    const [removed] = this.tabs.splice(idx, 1);
    this.destroyView(removed);

    if (this.tabs.length === 0) {
      const settings = this.configStore.getSettings();
      this.createTab(undefined, settings.alwaysIncognito);
      return;
    }

    if (this.activeTabId === tabId) {
      const nextIdx = Math.max(0, idx - 1);
      this.activeTabId = this.tabs[nextIdx].state.id;
    }

    this.layoutActiveView();
    this.emitTabs();
  }

  selectTab(tabId: string): void {
    if (!this.tabs.some((t) => t.state.id === tabId)) return;
    this.activeTabId = tabId;
    this.layoutActiveView();
    this.emitTabs();
  }

  navigate(urlOrQuery: string): void {
    const tab = this.getActiveTab();
    if (!tab) return;

    const trimmed = urlOrQuery.trim();
    if (trimmed === '' || trimmed.toLowerCase() === 'silent://home' || trimmed.toLowerCase() === 'about:blank') {
      this.goHome();
      return;
    }

    const targetUrl = this.resolveUserInputToUrl(trimmed);
    tab.state.isHome = false;
    tab.state.url = targetUrl;
    tab.state.isLoading = true;
    this.ensureViewForTab(tab);
    this.layoutActiveView();
    this.emitTabs();

    tab.view?.webContents.loadURL(targetUrl).catch((err) => {
      log.warn('Navigation error for', targetUrl, err);
    });
  }

  goHome(): void {
    const tab = this.getActiveTab();
    if (!tab) return;
    tab.state.isHome = true;
    tab.state.url = 'silent://home';
    tab.state.title = 'Silent Home';
    tab.state.isLoading = false;
    tab.state.canGoBack = false;
    tab.state.canGoForward = false;
    this.detachViewFromWindow(tab);
    this.layoutActiveView();
    this.emitTabs();
  }

  goBack(): void {
    const tab = this.getActiveTab();
    if (!tab || !tab.view) return;
    const wc = tab.view.webContents;
    if (wc.navigationHistory.canGoBack()) {
      wc.navigationHistory.goBack();
    } else if (!tab.state.isHome) {
      this.goHome();
    }
  }

  goForward(): void {
    const tab = this.getActiveTab();
    if (!tab || !tab.view) return;
    const wc = tab.view.webContents;
    if (wc.navigationHistory.canGoForward()) {
      wc.navigationHistory.goForward();
    }
  }

  reloadTab(): void {
    const tab = this.getActiveTab();
    if (!tab || tab.state.isHome || !tab.view) return;
    tab.view.webContents.reload();
  }

  async panicWipe(): Promise<number> {
    for (const tab of this.tabs) {
      this.destroyView(tab);
    }
    this.tabs = [];

    const persistentSession = session.fromPartition('persist:silent-session');
    const incognitoSession = session.fromPartition('silent-incognito');

    await Promise.all([
      persistentSession.clearStorageData(),
      persistentSession.clearCache(),
      incognitoSession.clearStorageData(),
      incognitoSession.clearCache(),
    ]);

    this.dbService.purgeAllBrowsingData();
    this.privacyService.resetStats();

    const settings = this.configStore.getSettings();
    this.createTab(undefined, settings.alwaysIncognito);
    return Date.now();
  }

  disposeAll(): void {
    for (const tab of this.tabs) {
      this.destroyView(tab);
    }
    this.tabs = [];
  }

  private getActiveTab(): ManagedTab | undefined {
    return this.tabs.find((t) => t.state.id === this.activeTabId);
  }

  private ensureViewForTab(tab: ManagedTab): void {
    if (tab.view) return;

    const partition = tab.state.isIncognito ? 'silent-incognito' : 'persist:silent-session';
    const tabSession = session.fromPartition(partition);
    this.privacyService.attachToSession(tabSession);

    const view = new WebContentsView({
      webPreferences: {
        session: tabSession,
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        webSecurity: true,
        allowRunningInsecureContent: false,
      },
    });

    const wc = view.webContents;
    wc.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) {
        this.createTab(url, tab.state.isIncognito);
      }
      return { action: 'deny' };
    });

    wc.on('did-start-loading', () => {
      tab.state.isLoading = true;
      this.emitTabs();
    });

    wc.on('did-stop-loading', () => {
      tab.state.isLoading = false;
      tab.state.canGoBack = wc.navigationHistory.canGoBack();
      tab.state.canGoForward = wc.navigationHistory.canGoForward();
      this.emitTabs();
    });

    wc.on('page-title-updated', (_event, title) => {
      if (!tab.state.isHome) {
        tab.state.title = title || tab.state.url;
        this.emitTabs();
      }
    });

    wc.on('did-navigate', (_event, url) => {
      tab.state.url = url;
      tab.state.title = wc.getTitle() || url;
      tab.state.canGoBack = wc.navigationHistory.canGoBack();
      tab.state.canGoForward = wc.navigationHistory.canGoForward();
      if (!tab.state.isIncognito) {
        this.dbService.recordVisit(tab.state.title, url, Date.now());
      }
      this.emitTabs();
    });

    wc.on('did-navigate-in-page', (_event, url) => {
      tab.state.url = url;
      tab.state.canGoBack = wc.navigationHistory.canGoBack();
      tab.state.canGoForward = wc.navigationHistory.canGoForward();
      this.emitTabs();
    });

    wc.on('page-favicon-updated', (_event, favicons) => {
      tab.state.faviconUrl = favicons.length > 0 ? favicons[0] : null;
      this.emitTabs();
    });

    tab.view = view;
  }

  private layoutActiveView(): void {
    const [contentWidth, contentHeight] = this.mainWindow.getContentSize();
    const active = this.getActiveTab();

    for (const tab of this.tabs) {
      if (!tab.view) continue;
      const shouldShow =
        !this.overlayHidden &&
        active?.state.id === tab.state.id &&
        !tab.state.isHome;

      if (shouldShow) {
        if (!this.mainWindow.contentView.children.includes(tab.view)) {
          this.mainWindow.contentView.addChildView(tab.view);
        }
        tab.view.setBounds({
          x: 0,
          y: TOP_CHROME_HEIGHT,
          width: Math.max(200, contentWidth),
          height: Math.max(120, contentHeight - TOP_CHROME_HEIGHT),
        });
      } else {
        this.detachViewFromWindow(tab);
      }
    }
  }

  private detachViewFromWindow(tab: ManagedTab): void {
    if (tab.view && this.mainWindow.contentView.children.includes(tab.view)) {
      this.mainWindow.contentView.removeChildView(tab.view);
    }
  }

  private destroyView(tab: ManagedTab): void {
    if (!tab.view) return;
    this.detachViewFromWindow(tab);
    try {
      tab.view.webContents.close();
    } catch (err) {
      log.warn('View close error:', err);
    }
    tab.view = null;
  }

  private resolveUserInputToUrl(input: string): string {
    const trimmed = input.trim();
    if (/^https?:\/\//i.test(trimmed)) {
      return trimmed;
    }
    if (!trimmed.includes(' ') && /^[a-z0-9.-]+\.[a-z]{2,}(\/.*)?$/i.test(trimmed)) {
      const settings = this.configStore.getSettings();
      const proto = settings.httpsEverywhere ? 'https://' : 'http://';
      return `${proto}${trimmed}`;
    }
    const engine = this.configStore.getSettings().searchEngine;
    return this.buildSearchUrl(trimmed, engine);
  }

  private buildSearchUrl(query: string, engine: SearchEngineId): string {
    const encoded = encodeURIComponent(query);
    const matched = SEARCH_ENGINES.find((item) => item.id === engine) ?? SEARCH_ENGINES[0];
    return matched.queryTemplate.replace('{q}', encoded);
  }

  openExternalSafe(url: string): void {
    if (/^https:\/\//i.test(url)) {
      void shell.openExternal(url);
    }
  }

  private emitTabs(): void {
    if (this.onTabsChanged) {
      this.onTabsChanged(this.getSnapshot());
    }
  }
}
