import { Session } from 'electron';
import { URL } from 'node:url';
import { ShieldStats } from '../../shared/types';
import { ConfigStore } from './ConfigStore';

const AD_AND_TRACKER_DOMAINS = [
  'doubleclick.net',
  'googlesyndication.com',
  'googleadservices.com',
  'google-analytics.com',
  'googletagmanager.com',
  'adservice.google.com',
  'connect.facebook.net',
  'pixel.facebook.com',
  'analytics.twitter.com',
  'ads-twitter.com',
  'scorecardresearch.com',
  'quantserve.com',
  'taboola.com',
  'outbrain.com',
  'criteo.com',
  'pubmatic.com',
  'rubiconproject.com',
  'openx.net',
  'adnxs.com',
  'hotjar.com',
  'mixpanel.com',
  'segment.io',
  'amplitude.com',
  'bugsnag.com',
  'sentry.io',
  'coin-hive.com',
  'coinhive.com',
  'cryptoloot.pro',
];

const SCAM_KEYWORDS = [
  'free-crypto-claim',
  'verify-wallet-now',
  'urgent-account-suspend',
  'airdrop-claim-now',
];

export class PrivacyNetworkService {
  private stats: ShieldStats = {
    blockedAds: 0,
    blockedTrackers: 0,
    blockedScams: 0,
    upgradedHttps: 0,
    lastBlockedDomain: null,
  };

  private attachedSessions = new WeakSet<Session>();
  private onStatsChanged: ((stats: ShieldStats) => void) | null = null;

  constructor(private readonly configStore: ConfigStore) {}

  setStatsListener(listener: (stats: ShieldStats) => void): void {
    this.onStatsChanged = listener;
  }

  getStats(): ShieldStats {
    return { ...this.stats };
  }

  resetStats(): void {
    this.stats = {
      blockedAds: 0,
      blockedTrackers: 0,
      blockedScams: 0,
      upgradedHttps: 0,
      lastBlockedDomain: null,
    };
    this.emitStats();
  }

  attachToSession(targetSession: Session): void {
    if (this.attachedSessions.has(targetSession)) {
      return;
    }
    this.attachedSessions.add(targetSession);

    targetSession.webRequest.onBeforeRequest(
      { urls: ['http://*/*', 'https://*/*'] },
      (details, callback) => {
        const settings = this.configStore.getSettings();
        let parsed: URL;
        try {
          parsed = new URL(details.url);
        } catch {
          callback({});
          return;
        }

        const host = parsed.hostname.toLowerCase();

        // Anti-scam & punycode phishing check
        if (settings.antiScamEnabled && this.isSuspiciousHost(host, details.url)) {
          this.stats.blockedScams += 1;
          this.stats.lastBlockedDomain = host;
          this.emitStats();
          callback({ cancel: true });
          return;
        }

        // Ad & tracker domain filtering (skip top-level mainFrame navigation to avoid breaking legitimate top navigation)
        if (
          settings.adblockEnabled &&
          details.resourceType !== 'mainFrame' &&
          this.matchesTrackerDomain(host)
        ) {
          if (host.includes('analytics') || host.includes('pixel') || host.includes('mixpanel') || host.includes('segment')) {
            this.stats.blockedTrackers += 1;
          } else {
            this.stats.blockedAds += 1;
          }
          this.stats.lastBlockedDomain = host;
          this.emitStats();
          callback({ cancel: true });
          return;
        }

        // HTTPS upgrade for non-local plaintext requests
        if (
          settings.httpsEverywhere &&
          parsed.protocol === 'http:' &&
          host !== 'localhost' &&
          host !== '127.0.0.1'
        ) {
          parsed.protocol = 'https:';
          this.stats.upgradedHttps += 1;
          this.emitStats();
          callback({ redirectURL: parsed.toString() });
          return;
        }

        callback({});
      }
    );

    targetSession.webRequest.onBeforeSendHeaders(
      { urls: ['http://*/*', 'https://*/*'] },
      (details, callback) => {
        const settings = this.configStore.getSettings();
        const requestHeaders = { ...details.requestHeaders };

        if (settings.dntEnabled) {
          requestHeaders['DNT'] = '1';
          requestHeaders['Sec-GPC'] = '1';
        }

        callback({ requestHeaders });
      }
    );
  }

  private matchesTrackerDomain(host: string): boolean {
    return AD_AND_TRACKER_DOMAINS.some(
      (domain) => host === domain || host.endsWith(`.${domain}`)
    );
  }

  private isSuspiciousHost(host: string, fullUrl: string): boolean {
    if (host.includes('xn--')) {
      return true;
    }
    const lowerUrl = fullUrl.toLowerCase();
    return SCAM_KEYWORDS.some((kw) => lowerUrl.includes(kw));
  }

  private emitStats(): void {
    if (this.onStatsChanged) {
      this.onStatsChanged(this.getStats());
    }
  }
}
