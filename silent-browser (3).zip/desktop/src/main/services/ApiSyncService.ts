import {
  AccountSessionState,
  ConflictResolutionStrategy,
  LiveFeedItem,
  LiveFeedResponse,
  SyncConflictItem,
  SyncOperationResult,
} from '../../shared/types';
import { ConfigStore } from './ConfigStore';
import { DatabaseService } from './DatabaseService';
import { log } from '../utils/logger';

const PORTAL_BASE_URL = 'https://silentbrowser.silentbot.online/';
const API_BASE_URL = 'https://silentbrowser.silentbot.online/api.php';

export class ApiSyncService {
  private feedCache: LiveFeedResponse | null = null;
  private feedCacheAt = 0;

  constructor(
    private readonly configStore: ConfigStore,
    private readonly dbService: DatabaseService
  ) {}

  getAccountState(): AccountSessionState {
    const email = this.configStore.getAccountEmail();
    const token = this.configStore.getEncryptedAuthToken();
    return {
      isSignedIn: Boolean(email && token),
      email,
      lastSyncedAt: this.configStore.getLastSyncedAt(),
      portalUrl: PORTAL_BASE_URL,
    };
  }

  async fetchLiveFeed(forceRefresh = false): Promise<LiveFeedResponse> {
    const now = Date.now();
    if (!forceRefresh && this.feedCache && now - this.feedCacheAt < 5 * 60 * 1000) {
      return this.feedCache;
    }

    try {
      const url = `${API_BASE_URL}?action=feed${forceRefresh ? '&refresh=1' : ''}`;
      const resp = await fetch(url, {
        headers: {
          Accept: 'application/json',
          'User-Agent': 'SilentBrowserDesktop/1.0.0',
        },
        signal: AbortSignal.timeout(10000),
      });

      if (!resp.ok) {
        throw new Error(`Feed HTTP ${resp.status}`);
      }

      const raw = (await resp.json()) as {
        status?: string;
        updated_utc?: string;
        news_count?: number;
        github_count?: number;
        items?: Array<Record<string, unknown>>;
      };

      const items: LiveFeedItem[] = Array.isArray(raw.items)
        ? raw.items.map((row, idx) => ({
            id: String(row.id ?? `feed_${idx}`),
            category: row.category === 'github' ? 'github' : 'news',
            source: String(row.source ?? (row.category === 'github' ? 'Trending GitHub' : 'Daily Tech News')),
            title: String(row.title ?? 'Untitled'),
            summary: String(row.summary ?? ''),
            url: String(row.url ?? PORTAL_BASE_URL),
            image: typeof row.image === 'string' && /^https:\/\//i.test(row.image) ? row.image : null,
            avatar: typeof row.avatar === 'string' && /^https:\/\//i.test(row.avatar) ? row.avatar : null,
            metric: String(row.metric ?? ''),
            publishedAt: String(row.published_at ?? ''),
          }))
        : [];

      const result: LiveFeedResponse = {
        status: raw.status === 'live' ? 'live' : 'degraded',
        updatedUtc: String(raw.updated_utc ?? new Date().toISOString()),
        newsCount: Number(raw.news_count ?? items.filter((i) => i.category === 'news').length),
        githubCount: Number(raw.github_count ?? items.filter((i) => i.category === 'github').length),
        items,
      };

      this.feedCache = result;
      this.feedCacheAt = now;
      return result;
    } catch (error) {
      log.warn('Live feed fetch failed:', error);
      if (this.feedCache) {
        return this.feedCache;
      }
      return {
        status: 'degraded',
        updatedUtc: 'Unavailable',
        newsCount: 0,
        githubCount: 0,
        items: [],
      };
    }
  }

  async registerAccount(email: string, password: string): Promise<AccountSessionState> {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || password.length < 6) {
      throw new Error('Provide a valid email and a password with at least 6 characters.');
    }

    const resp = await fetch(`${API_BASE_URL}?action=register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: cleanEmail, password }),
      signal: AbortSignal.timeout(12000),
    });

    const data = (await resp.json()) as { status?: string; message?: string; email?: string; token?: string };
    if (!resp.ok || data.status !== 'success' || !data.token) {
      throw new Error(data.message ?? 'Registration failed on sync server.');
    }

    const encryptedToken = this.dbService.encryptSecret(data.token);
    this.configStore.setAccountSession(data.email ?? cleanEmail, encryptedToken);
    return this.getAccountState();
  }

  async loginAccount(email: string, password: string): Promise<AccountSessionState> {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || password.length === 0) {
      throw new Error('Email and password are required.');
    }

    const resp = await fetch(`${API_BASE_URL}?action=login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: cleanEmail, password }),
      signal: AbortSignal.timeout(12000),
    });

    const data = (await resp.json()) as { status?: string; message?: string; email?: string; token?: string };
    if (!resp.ok || data.status !== 'success' || !data.token) {
      throw new Error(data.message ?? 'Invalid email or password.');
    }

    const encryptedToken = this.dbService.encryptSecret(data.token);
    this.configStore.setAccountSession(data.email ?? cleanEmail, encryptedToken);
    return this.getAccountState();
  }

  async logoutAccount(): Promise<AccountSessionState> {
    const token = this.getPlainAuthToken();
    if (token) {
      try {
        await fetch(`${API_BASE_URL}?action=logout`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          signal: AbortSignal.timeout(6000),
        });
      } catch (err) {
        log.warn('Logout HTTP notification skipped:', err);
      }
    }
    this.configStore.resetOnPanicWipe();
    return this.getAccountState();
  }

  async runCloudSync(): Promise<SyncOperationResult> {
    const token = this.getPlainAuthToken();
    if (!token) {
      throw new Error('Sign in to your Silent Sync account first.');
    }

    const bookmarks = this.dbService.listBookmarks();
    const history = this.dbService.listHistory(150);
    const settings = this.configStore.getSettings();
    const now = Date.now();

    const pushBody = {
      settings: {
        engine_mode: 'MULTI_ENGINE',
        search_engine_id: settings.searchEngine,
        adblock_enabled: settings.adblockEnabled,
        fingerprint_shield: settings.fingerprintShield,
        https_everywhere: settings.httpsEverywhere,
        dnt_enabled: settings.dntEnabled,
        anti_scam_enabled: settings.antiScamEnabled,
        always_incognito: settings.alwaysIncognito,
        auto_purge_tab_closure: settings.autoPurgeOnExit,
        selected_user_agent: settings.userAgentProfile,
        client_timestamp: now,
      },
      items: [
        ...bookmarks.map((b) => ({
          item_type: 'bookmark',
          title: b.title,
          url: b.url,
          folder: b.folder,
          category: 'Desktop',
          is_pinned: b.isPinned,
          visit_count: 1,
          client_timestamp: b.clientTimestamp,
        })),
        ...history.map((h) => ({
          item_type: 'history',
          title: h.title,
          url: h.url,
          folder: 'History',
          category: 'Desktop',
          is_pinned: false,
          visit_count: h.visitCount,
          client_timestamp: h.clientTimestamp,
        })),
      ],
    };

    const pushResp = await fetch(`${API_BASE_URL}?action=sync_push`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(pushBody),
      signal: AbortSignal.timeout(15000),
    });

    const pushData = (await pushResp.json()) as {
      status?: string;
      message?: string;
      applied_count?: number;
      conflicts?: Array<Record<string, unknown>>;
    };

    if (!pushResp.ok || pushData.status !== 'success') {
      throw new Error(pushData.message ?? 'Cloud sync push failed.');
    }

    const pullResp = await fetch(`${API_BASE_URL}?action=sync_pull`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(15000),
    });
    const pullData = (await pullResp.json()) as {
      status?: string;
      items?: Array<{
        item_type?: string;
        title?: string;
        url?: string;
        folder?: string;
        is_pinned?: number | boolean;
        visit_count?: number;
        client_timestamp?: number;
      }>;
    };

    const conflicts: SyncConflictItem[] = [];
    const localBookmarkMap = new Map(bookmarks.map((b) => [b.url, b]));
    const localHistoryMap = new Map(history.map((h) => [h.url, h]));

    if (Array.isArray(pullData.items)) {
      for (const remote of pullData.items) {
        const url = String(remote.url ?? '');
        if (!/^https?:\/\//i.test(url)) continue;
        const remoteTs = Number(remote.client_timestamp ?? 0);
        const remoteTitle = String(remote.title ?? url);

        if (remote.item_type === 'bookmark') {
          const local = localBookmarkMap.get(url);
          if (!local) {
            this.dbService.upsertBookmark(
              remoteTitle,
              url,
              String(remote.folder ?? 'Favorites'),
              remoteTs || now,
              Boolean(remote.is_pinned)
            );
          } else if (Math.abs(local.clientTimestamp - remoteTs) > 1000 && local.title !== remoteTitle) {
            conflicts.push({
              id: `bm_${url}`,
              itemType: 'bookmark',
              url,
              localTitle: local.title,
              localTimestamp: local.clientTimestamp,
              remoteTitle,
              remoteTimestamp: remoteTs,
            });
          }
        } else if (remote.item_type === 'history') {
          const localH = localHistoryMap.get(url);
          if (!localH) {
            this.dbService.upsertSyncedHistory(
              remoteTitle,
              url,
              Number(remote.visit_count ?? 1),
              remoteTs || now
            );
          } else if (Math.abs(localH.clientTimestamp - remoteTs) > 5000 && localH.title !== remoteTitle) {
            conflicts.push({
              id: `hist_${url}`,
              itemType: 'history',
              url,
              localTitle: localH.title,
              localTimestamp: localH.clientTimestamp,
              remoteTitle,
              remoteTimestamp: remoteTs,
            });
          }
        }
      }
    }

    if (Array.isArray(pushData.conflicts)) {
      for (const c of pushData.conflicts) {
        const url = String(c.url ?? '');
        if (!url) continue;
        const id = `${String(c.item_type ?? 'bookmark')}_${url}`;
        if (!conflicts.some((existing) => existing.id === id)) {
          conflicts.push({
            id,
            itemType: c.item_type === 'history' ? 'history' : 'bookmark',
            url,
            localTitle: String(c.local_title ?? url),
            localTimestamp: Number(c.local_timestamp ?? now),
            remoteTitle: String(c.remote_title ?? url),
            remoteTimestamp: Number(c.remote_timestamp ?? now),
          });
        }
      }
    }

    this.configStore.setLastSyncedAt(now);

    return {
      success: true,
      message:
        conflicts.length > 0
          ? `Sync finished with ${conflicts.length} timestamp conflict(s) requiring your selection.`
          : 'Cloud sync completed cleanly.',
      appliedCount: Number(pushData.applied_count ?? 0),
      conflicts,
      syncedAt: now,
    };
  }

  async resolveSyncConflict(
    conflict: SyncConflictItem,
    strategy: ConflictResolutionStrategy
  ): Promise<SyncOperationResult> {
    const token = this.getPlainAuthToken();
    const resolvedTs = Date.now();
    let finalTitle = conflict.localTitle;

    if (strategy === 'USE_REMOTE') {
      finalTitle = conflict.remoteTitle;
    } else if (strategy === 'MERGE') {
      finalTitle =
        conflict.localTitle === conflict.remoteTitle
          ? conflict.localTitle
          : `${conflict.localTitle} · ${conflict.remoteTitle}`.slice(0, 160);
    }

    if (conflict.itemType === 'bookmark') {
      this.dbService.upsertBookmark(finalTitle, conflict.url, 'Favorites', resolvedTs);
    } else if (conflict.itemType === 'history') {
      this.dbService.upsertSyncedHistory(finalTitle, conflict.url, 1, resolvedTs);
    }

    if (token && (strategy === 'KEEP_LOCAL' || strategy === 'MERGE')) {
      await fetch(`${API_BASE_URL}?action=sync_push`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          items: [
            {
              item_type: conflict.itemType,
              title: finalTitle,
              url: conflict.url,
              folder: 'Favorites',
              category: 'Desktop',
              client_timestamp: resolvedTs,
              force_local: true,
            },
          ],
        }),
        signal: AbortSignal.timeout(10000),
      });
    }

    this.configStore.setLastSyncedAt(resolvedTs);
    return {
      success: true,
      message: `Resolved ${conflict.url} using ${strategy}.`,
      appliedCount: 1,
      conflicts: [],
      syncedAt: resolvedTs,
    };
  }

  private getPlainAuthToken(): string | null {
    const enc = this.configStore.getEncryptedAuthToken();
    if (!enc) return null;
    try {
      return this.dbService.decryptSecret(enc);
    } catch {
      return null;
    }
  }
}
