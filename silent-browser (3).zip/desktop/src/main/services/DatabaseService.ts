import Database from 'better-sqlite3';
import { safeStorage } from 'electron';
import crypto from 'node:crypto';
import {
  BookmarkRecord,
  HistoryRecord,
  VaultDisplayEntry,
} from '../../shared/types';
import { getDatabaseFilePath } from '../utils/paths';
import { log } from '../utils/logger';

export class DatabaseService {
  private db: Database.Database | null = null;

  initialize(): void {
    if (this.db) return;
    const dbPath = getDatabaseFilePath();
    this.db = new Database(dbPath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS bookmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        url TEXT NOT NULL UNIQUE,
        folder TEXT NOT NULL DEFAULT 'Favorites',
        is_pinned INTEGER NOT NULL DEFAULT 0,
        client_timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        url TEXT NOT NULL UNIQUE,
        visit_count INTEGER NOT NULL DEFAULT 1,
        client_timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS vault_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        origin TEXT NOT NULL,
        username TEXT NOT NULL,
        encrypted_password TEXT NOT NULL,
        notes TEXT NOT NULL DEFAULT '',
        updated_at INTEGER NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_history_ts ON history (client_timestamp DESC);
      CREATE INDEX IF NOT EXISTS idx_bookmarks_ts ON bookmarks (client_timestamp DESC);
    `);

    log.info('SQLite database initialized at', dbPath);
  }

  private getConn(): Database.Database {
    if (!this.db) {
      this.initialize();
    }
    if (!this.db) {
      throw new Error('SQLite database connection could not be established.');
    }
    return this.db;
  }

  listBookmarks(): BookmarkRecord[] {
    const rows = this.getConn()
      .prepare(
        `SELECT id, title, url, folder, is_pinned, client_timestamp
         FROM bookmarks
         ORDER BY is_pinned DESC, client_timestamp DESC`
      )
      .all() as Array<{
      id: number;
      title: string;
      url: string;
      folder: string;
      is_pinned: number;
      client_timestamp: number;
    }>;

    return rows.map((row) => ({
      id: row.id,
      title: row.title,
      url: row.url,
      folder: row.folder,
      isPinned: row.is_pinned === 1,
      clientTimestamp: row.client_timestamp,
    }));
  }

  upsertBookmark(
    title: string,
    url: string,
    folder = 'Favorites',
    timestamp = Date.now(),
    isPinned = false
  ): BookmarkRecord {
    const cleanTitle = title.trim().slice(0, 160) || url;
    const cleanUrl = url.trim().slice(0, 512);
    const cleanFolder = folder.trim().slice(0, 64) || 'Favorites';

    this.getConn()
      .prepare(
        `INSERT INTO bookmarks (title, url, folder, is_pinned, client_timestamp)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(url) DO UPDATE SET
           title = excluded.title,
           folder = excluded.folder,
           is_pinned = excluded.is_pinned,
           client_timestamp = excluded.client_timestamp`
      )
      .run(cleanTitle, cleanUrl, cleanFolder, isPinned ? 1 : 0, timestamp);

    const saved = this.getConn()
      .prepare('SELECT id, title, url, folder, is_pinned, client_timestamp FROM bookmarks WHERE url = ?')
      .get(cleanUrl) as {
      id: number;
      title: string;
      url: string;
      folder: string;
      is_pinned: number;
      client_timestamp: number;
    };

    return {
      id: saved.id,
      title: saved.title,
      url: saved.url,
      folder: saved.folder,
      isPinned: saved.is_pinned === 1,
      clientTimestamp: saved.client_timestamp,
    };
  }

  deleteBookmark(id: number): void {
    this.getConn().prepare('DELETE FROM bookmarks WHERE id = ?').run(id);
  }

  listHistory(limit = 150): HistoryRecord[] {
    const safeLimit = Math.max(1, Math.min(limit, 500));
    const rows = this.getConn()
      .prepare(
        `SELECT id, title, url, visit_count, client_timestamp
         FROM history
         ORDER BY client_timestamp DESC
         LIMIT ?`
      )
      .all(safeLimit) as Array<{
      id: number;
      title: string;
      url: string;
      visit_count: number;
      client_timestamp: number;
    }>;

    return rows.map((row) => ({
      id: row.id,
      title: row.title,
      url: row.url,
      visitCount: row.visit_count,
      clientTimestamp: row.client_timestamp,
    }));
  }

  recordVisit(title: string, url: string, timestamp = Date.now()): void {
    if (!/^https?:\/\//i.test(url)) return;
    const cleanTitle = title.trim().slice(0, 160) || url;
    const cleanUrl = url.trim().slice(0, 512);

    this.getConn()
      .prepare(
        `INSERT INTO history (title, url, visit_count, client_timestamp)
         VALUES (?, ?, 1, ?)
         ON CONFLICT(url) DO UPDATE SET
           title = CASE WHEN excluded.title <> '' THEN excluded.title ELSE history.title END,
           visit_count = history.visit_count + 1,
           client_timestamp = MAX(history.client_timestamp, excluded.client_timestamp)`
      )
      .run(cleanTitle, cleanUrl, timestamp);
  }

  upsertSyncedHistory(
    title: string,
    url: string,
    visitCount: number,
    timestamp: number
  ): void {
    if (!/^https?:\/\//i.test(url)) return;
    this.getConn()
      .prepare(
        `INSERT INTO history (title, url, visit_count, client_timestamp)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(url) DO UPDATE SET
           title = excluded.title,
           visit_count = MAX(history.visit_count, excluded.visit_count),
           client_timestamp = excluded.client_timestamp`
      )
      .run(title.slice(0, 160), url.slice(0, 512), Math.max(1, visitCount), timestamp);
  }

  clearHistory(): void {
    this.getConn().prepare('DELETE FROM history').run();
  }

  listVaultEntries(): VaultDisplayEntry[] {
    const rows = this.getConn()
      .prepare(
        `SELECT id, origin, username, notes, updated_at
         FROM vault_entries
         ORDER BY updated_at DESC`
      )
      .all() as Array<{
      id: number;
      origin: string;
      username: string;
      notes: string;
      updated_at: number;
    }>;

    return rows.map((row) => ({
      id: row.id,
      origin: row.origin,
      username: row.username,
      passwordMasked: '••••••••••••',
      notes: row.notes,
      updatedAt: row.updated_at,
    }));
  }

  saveVaultEntry(
    origin: string,
    username: string,
    plaintextPassword: string,
    notes = ''
  ): VaultDisplayEntry {
    const now = Date.now();
    const cipherPayload = this.encryptSecret(plaintextPassword);
    const res = this.getConn()
      .prepare(
        `INSERT INTO vault_entries (origin, username, encrypted_password, notes, updated_at)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(origin.trim().slice(0, 200), username.trim().slice(0, 160), cipherPayload, notes.trim().slice(0, 500), now);

    return {
      id: Number(res.lastInsertRowid),
      origin: origin.trim().slice(0, 200),
      username: username.trim().slice(0, 160),
      passwordMasked: '••••••••••••',
      notes: notes.trim().slice(0, 500),
      updatedAt: now,
    };
  }

  revealVaultPassword(id: number): string {
    const row = this.getConn()
      .prepare('SELECT encrypted_password FROM vault_entries WHERE id = ?')
      .get(id) as { encrypted_password: string } | undefined;
    if (!row) {
      throw new Error('Vault entry not found.');
    }
    return this.decryptSecret(row.encrypted_password);
  }

  deleteVaultEntry(id: number): void {
    this.getConn().prepare('DELETE FROM vault_entries WHERE id = ?').run(id);
  }

  purgeAllBrowsingData(): void {
    const conn = this.getConn();
    const trx = conn.transaction(() => {
      conn.prepare('DELETE FROM history').run();
    });
    trx();
  }

  encryptSecret(plain: string): string {
    if (safeStorage.isEncryptionAvailable()) {
      const buf = safeStorage.encryptString(plain);
      return `safe:${buf.toString('base64')}`;
    }
    const key = crypto.scryptSync(getDatabaseFilePath(), 'silent-browser-local-vault', 32);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    return `aes:${iv.toString('base64')}:${tag.toString('base64')}:${encrypted.toString('base64')}`;
  }

  decryptSecret(payload: string): string {
    if (payload.startsWith('safe:')) {
      const raw = Buffer.from(payload.slice(5), 'base64');
      return safeStorage.decryptString(raw);
    }
    if (payload.startsWith('aes:')) {
      const parts = payload.slice(4).split(':');
      if (parts.length !== 3) throw new Error('Corrupt encrypted payload.');
      const key = crypto.scryptSync(getDatabaseFilePath(), 'silent-browser-local-vault', 32);
      const iv = Buffer.from(parts[0], 'base64');
      const tag = Buffer.from(parts[1], 'base64');
      const data = Buffer.from(parts[2], 'base64');
      const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
      decipher.setAuthTag(tag);
      return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
    }
    throw new Error('Unsupported encryption envelope.');
  }

  close(): void {
    if (this.db) {
      try {
        this.db.close();
        log.info('SQLite database closed cleanly.');
      } catch (err) {
        log.error('Error closing SQLite database:', err);
      } finally {
        this.db = null;
      }
    }
  }
}
