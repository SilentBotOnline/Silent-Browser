import { app, BrowserWindow, ipcMain, nativeTheme, session } from 'electron';
import path from 'node:path';
import {
  BrowserSettings,
  ConflictResolutionStrategy,
  SyncConflictItem,
  ThemeMode,
} from '../shared/types';
import { initializeLogging, registerGlobalErrorHandlers, log } from './utils/logger';
import { getDatabaseFilePath, getMainLogPath, getUserDataDirectory, resolveResourcePath } from './utils/paths';
import { ConfigStore } from './services/ConfigStore';
import { DatabaseService } from './services/DatabaseService';
import { PrivacyNetworkService } from './services/PrivacyNetworkService';
import { ApiSyncService } from './services/ApiSyncService';
import { BrowserTabManager } from './services/BrowserTabManager';

initializeLogging();
registerGlobalErrorHandlers();

const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
  process.exit(0);
}

let mainWindow: BrowserWindow | null = null;
const configStore = new ConfigStore();
const dbService = new DatabaseService();
const privacyService = new PrivacyNetworkService(configStore);
const apiSyncService = new ApiSyncService(configStore, dbService);
let tabManager: BrowserTabManager | null = null;
let isShuttingDown = false;

function getTitleBarOverlayColors(theme: ThemeMode): { color: string; symbolColor: string } {
  if (theme === 'black') {
    return { color: '#0A0A0A', symbolColor: '#FFFFFF' };
  }
  if (theme === 'midnight') {
    return { color: '#0F172A', symbolColor: '#F8FAFC' };
  }
  return { color: '#F5F7F6', symbolColor: '#17231C' };
}

function applyNativeTheme(theme: ThemeMode): void {
  nativeTheme.themeSource = theme === 'white' ? 'light' : 'dark';
  if (mainWindow && !mainWindow.isDestroyed() && process.platform === 'win32') {
    const overlay = getTitleBarOverlayColors(theme);
    mainWindow.setTitleBarOverlay({
      color: overlay.color,
      symbolColor: overlay.symbolColor,
      height: 40,
    });
  }
}

function createMainWindow(): void {
  const settings = configStore.getSettings();
  const savedBounds = configStore.getWindowBounds();
  const overlay = getTitleBarOverlayColors(settings.theme);

  const preloadPath = path.resolve(__dirname, '../preload/preload.js');
  const iconPath = resolveResourcePath('icon.ico');

  mainWindow = new BrowserWindow({
    width: savedBounds.width,
    height: savedBounds.height,
    x: savedBounds.x,
    y: savedBounds.y,
    minWidth: 1024,
    minHeight: 680,
    title: 'Silent Browser',
    icon: iconPath,
    backgroundColor: settings.theme === 'white' ? '#FFFFFF' : settings.theme === 'midnight' ? '#0B1120' : '#000000',
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: overlay.color,
      symbolColor: overlay.symbolColor,
      height: 40,
    },
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      devTools: !app.isPackaged,
    },
  });

  if (savedBounds.isMaximized) {
    mainWindow.maximize();
  }

  mainWindow.webContents.on('will-attach-webview', (event) => {
    event.preventDefault();
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  const saveWindowGeometry = (): void => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    const isMaximized = mainWindow.isMaximized();
    const bounds = mainWindow.getBounds();
    configStore.setWindowBounds({
      width: bounds.width,
      height: bounds.height,
      x: bounds.x,
      y: bounds.y,
      isMaximized,
    });
  };

  mainWindow.on('resized', saveWindowGeometry);
  mainWindow.on('moved', saveWindowGeometry);

  tabManager = new BrowserTabManager(mainWindow, configStore, dbService, privacyService);
  tabManager.setTabsListener((payload) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('tabs:updated', payload);
    }
  });

  privacyService.setStatsListener((stats) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('shields:updated', stats);
    }
  });

  if (app.isPackaged) {
    const rendererIndex = path.resolve(__dirname, '../../renderer/index.html');
    void mainWindow.loadFile(rendererIndex);
  } else {
    void mainWindow.loadURL('http://localhost:5173');
  }

  tabManager.initializeDefaultTab();
  applyNativeTheme(settings.theme);

  mainWindow.on('closed', () => {
    tabManager?.disposeAll();
    tabManager = null;
    mainWindow = null;
  });
}

function registerIpcHandlers(): void {
  ipcMain.handle('settings:get', () => configStore.getSettings());

  ipcMain.handle('settings:update', (_event, patch: Partial<BrowserSettings>) => {
    const updated = configStore.updateSettings(patch);
    if (patch.theme) {
      applyNativeTheme(updated.theme);
    }
    return updated;
  });

  ipcMain.handle('overlay:setActive', (_event, hidden: boolean) => {
    tabManager?.setOverlayActive(Boolean(hidden));
  });

  ipcMain.handle('tabs:snapshot', () => {
    return tabManager ? tabManager.getSnapshot() : { tabs: [], activeTabId: '' };
  });

  ipcMain.handle('tabs:create', (_event, url?: string, incognito?: boolean) => {
    tabManager?.createTab(url, Boolean(incognito));
  });

  ipcMain.handle('tabs:close', (_event, tabId: string) => {
    tabManager?.closeTab(String(tabId));
  });

  ipcMain.handle('tabs:select', (_event, tabId: string) => {
    tabManager?.selectTab(String(tabId));
  });

  ipcMain.handle('tabs:navigate', (_event, urlOrQuery: string) => {
    tabManager?.navigate(String(urlOrQuery));
  });

  ipcMain.handle('tabs:back', () => {
    tabManager?.goBack();
  });

  ipcMain.handle('tabs:forward', () => {
    tabManager?.goForward();
  });

  ipcMain.handle('tabs:reload', () => {
    tabManager?.reloadTab();
  });

  ipcMain.handle('tabs:home', () => {
    tabManager?.goHome();
  });

  ipcMain.handle('shields:getStats', () => privacyService.getStats());

  ipcMain.handle('panic:wipe', async () => {
    const clearedAt = tabManager ? await tabManager.panicWipe() : Date.now();
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('panic:wiped', { clearedAt });
    }
    return { clearedAt };
  });

  ipcMain.handle('bookmarks:list', () => dbService.listBookmarks());

  ipcMain.handle('bookmarks:add', (_event, title: string, url: string, folder?: string) => {
    return dbService.upsertBookmark(String(title), String(url), folder ? String(folder) : 'Favorites');
  });

  ipcMain.handle('bookmarks:delete', (_event, id: number) => {
    dbService.deleteBookmark(Number(id));
  });

  ipcMain.handle('history:list', (_event, limit?: number) => {
    return dbService.listHistory(typeof limit === 'number' ? limit : 150);
  });

  ipcMain.handle('history:clear', () => {
    dbService.clearHistory();
  });

  ipcMain.handle('vault:list', () => dbService.listVaultEntries());

  ipcMain.handle('vault:reveal', (_event, id: number) => {
    return dbService.revealVaultPassword(Number(id));
  });

  ipcMain.handle(
    'vault:save',
    (_event, origin: string, username: string, password: string, notes?: string) => {
      return dbService.saveVaultEntry(String(origin), String(username), String(password), notes ? String(notes) : '');
    }
  );

  ipcMain.handle('vault:delete', (_event, id: number) => {
    dbService.deleteVaultEntry(Number(id));
  });

  ipcMain.handle('feed:fetch', async (_event, forceRefresh?: boolean) => {
    return apiSyncService.fetchLiveFeed(Boolean(forceRefresh));
  });

  ipcMain.handle('account:state', () => apiSyncService.getAccountState());

  ipcMain.handle('account:register', async (_event, email: string, password: string) => {
    return apiSyncService.registerAccount(String(email), String(password));
  });

  ipcMain.handle('account:login', async (_event, email: string, password: string) => {
    return apiSyncService.loginAccount(String(email), String(password));
  });

  ipcMain.handle('account:logout', async () => {
    return apiSyncService.logoutAccount();
  });

  ipcMain.handle('sync:run', async () => {
    return apiSyncService.runCloudSync();
  });

  ipcMain.handle(
    'sync:resolveConflict',
    async (_event, conflict: SyncConflictItem, strategy: ConflictResolutionStrategy) => {
      return apiSyncService.resolveSyncConflict(conflict, strategy);
    }
  );

  ipcMain.handle('app:diagnostics', () => ({
    appVersion: app.getVersion(),
    electronVersion: process.versions.electron,
    platform: process.platform,
    arch: process.arch,
    userDataPath: getUserDataDirectory(),
    logFilePath: getMainLogPath(),
    dbFilePath: getDatabaseFilePath(),
  }));

  ipcMain.handle('shell:openExternalSafe', (_event, url: string) => {
    tabManager?.openExternalSafe(String(url));
  });
}

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) {
      mainWindow.restore();
    }
    mainWindow.focus();
  }
});

app.whenReady().then(() => {
  dbService.initialize();
  registerIpcHandlers();
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('before-quit', async (event) => {
  if (isShuttingDown) return;
  isShuttingDown = true;

  const settings = configStore.getSettings();
  if (settings.autoPurgeOnExit) {
    event.preventDefault();
    try {
      await session.fromPartition('persist:silent-session').clearStorageData();
      dbService.purgeAllBrowsingData();
    } catch (err) {
      log.warn('Auto-purge on exit encountered an error:', err);
    } finally {
      tabManager?.disposeAll();
      dbService.close();
      app.quit();
    }
    return;
  }

  tabManager?.disposeAll();
  dbService.close();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
