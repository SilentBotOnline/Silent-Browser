import { app } from 'electron';
import path from 'node:path';
import fs from 'node:fs';

export function resolveResourcePath(...segments: string[]): string {
  const basePath = app.isPackaged
    ? path.join(process.resourcesPath, 'resources')
    : path.resolve(__dirname, '../../../resources');
  return path.join(basePath, ...segments);
}

export function getUserDataDirectory(): string {
  const dir = app.getPath('userData');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

export function getDatabaseFilePath(): string {
  return path.join(getUserDataDirectory(), 'silent-browser.db');
}

export function getLogsDirectory(): string {
  const logsDir = path.join(getUserDataDirectory(), 'logs');
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  return logsDir;
}

export function getMainLogPath(): string {
  return path.join(getLogsDirectory(), 'main.log');
}
