import log from 'electron-log/main';
import { app, dialog } from 'electron';
import { getMainLogPath } from './paths';

let initialized = false;

export function initializeLogging(): typeof log {
  if (initialized) {
    return log;
  }

  log.initialize();
  log.transports.file.resolvePathFn = () => getMainLogPath();
  log.transports.file.level = 'info';
  log.transports.file.maxSize = 5 * 1024 * 1024;
  log.transports.console.level = app.isPackaged ? 'warn' : 'debug';

  initialized = true;
  log.info('Silent Browser logging initialized at', getMainLogPath());
  return log;
}

export function registerGlobalErrorHandlers(): void {
  process.on('uncaughtException', (error: Error) => {
    log.error('Uncaught Exception in Main process:', error);
    if (app.isReady()) {
      dialog.showErrorBox(
        'Silent Browser — Unexpected Error',
        `An unexpected error occurred in the main process.\n\n${error.message}\n\nDiagnostic log: ${getMainLogPath()}`
      );
    }
  });

  process.on('unhandledRejection', (reason: unknown) => {
    const message = reason instanceof Error ? reason.stack ?? reason.message : String(reason);
    log.error('Unhandled Promise Rejection in Main process:', message);
  });
}

export { log };
