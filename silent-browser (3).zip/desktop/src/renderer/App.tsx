import React, { useCallback, useEffect, useState } from 'react';
import {
  AccountSessionState,
  AppDiagnosticInfo,
  BookmarkRecord,
  BrowserSettings,
  BrowserTabState,
  ConflictResolutionStrategy,
  HistoryRecord,
  LiveFeedResponse,
  SearchEngineId,
  ShieldStats,
  SyncConflictItem,
  VaultDisplayEntry,
} from '../shared/types';
import { TitleBar } from './components/TitleBar';
import { AddressBar } from './components/AddressBar';
import { DashboardView } from './components/DashboardView';
import { SettingsModal } from './components/SettingsModal';
import { SyncConflictsModal } from './components/SyncConflictsModal';
import { VaultBookmarksModal } from './components/VaultBookmarksModal';

const DEFAULT_SETTINGS: BrowserSettings = {
  theme: 'white',
  searchEngine: 'silent',
  adblockEnabled: true,
  fingerprintShield: true,
  httpsEverywhere: true,
  dntEnabled: true,
  antiScamEnabled: true,
  alwaysIncognito: false,
  autoPurgeOnExit: false,
  userAgentProfile: 'Silent Desktop Stealth',
};

const DEFAULT_STATS: ShieldStats = {
  blockedAds: 0,
  blockedTrackers: 0,
  blockedScams: 0,
  upgradedHttps: 0,
  lastBlockedDomain: null,
};

const DEFAULT_ACCOUNT: AccountSessionState = {
  isSignedIn: false,
  email: null,
  lastSyncedAt: null,
  portalUrl: 'https://silentbrowser.silentbot.online/',
};

export const App: React.FC = () => {
  const [settings, setSettings] = useState<BrowserSettings>(DEFAULT_SETTINGS);
  const [tabs, setTabs] = useState<BrowserTabState[]>([]);
  const [activeTabId, setActiveTabId] = useState('');
  const [shieldStats, setShieldStats] = useState<ShieldStats>(DEFAULT_STATS);
  const [feed, setFeed] = useState<LiveFeedResponse | null>(null);
  const [feedLoading, setFeedLoading] = useState(true);
  const [account, setAccount] = useState<AccountSessionState>(DEFAULT_ACCOUNT);
  const [conflicts, setConflicts] = useState<SyncConflictItem[]>([]);
  const [syncBusy, setSyncBusy] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<AppDiagnosticInfo | null>(null);

  const [bookmarks, setBookmarks] = useState<BookmarkRecord[]>([]);
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [vaultEntries, setVaultEntries] = useState<VaultDisplayEntry[]>([]);

  const [activeModal, setActiveModal] = useState<'none' | 'settings' | 'sync' | 'vault'>('none');
  const [toastText, setToastText] = useState<string | null>(null);

  const showToast = useCallback((msg: string): void => {
    setToastText(msg);
    window.setTimeout(() => {
      setToastText((curr) => (curr === msg ? null : curr));
    }, 3500);
  }, []);

  const refreshLibraryData = useCallback(async (): Promise<void> => {
    const [bms, hist, vault] = await Promise.all([
      window.electronAPI.listBookmarks(),
      window.electronAPI.listHistory(150),
      window.electronAPI.listVault(),
    ]);
    setBookmarks(bms);
    setHistory(hist);
    setVaultEntries(vault);
  }, []);

  const refreshFeed = useCallback(async (forceRefresh = false): Promise<void> => {
    setFeedLoading(true);
    try {
      const data = await window.electronAPI.fetchLiveFeed(forceRefresh);
      setFeed(data);
    } finally {
      setFeedLoading(false);
    }
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme);
  }, [settings.theme]);

  useEffect(() => {
    void window.electronAPI.setOverlayActive(activeModal !== 'none');
  }, [activeModal]);

  useEffect(() => {
    let mounted = true;
    void (async () => {
      const [loadedSettings, snapshot, stats, acct, diag] = await Promise.all([
        window.electronAPI.getSettings(),
        window.electronAPI.getTabsSnapshot(),
        window.electronAPI.getShieldStats(),
        window.electronAPI.getAccountState(),
        window.electronAPI.getDiagnostics(),
      ]);
      if (!mounted) return;
      setSettings(loadedSettings);
      setTabs(snapshot.tabs);
      setActiveTabId(snapshot.activeTabId);
      setShieldStats(stats);
      setAccount(acct);
      setDiagnostics(diag);
      await refreshLibraryData();
      await refreshFeed(false);
    })();

    const unsubTabs = window.electronAPI.onTabsUpdated((payload) => {
      setTabs(payload.tabs);
      setActiveTabId(payload.activeTabId);
    });
    const unsubShields = window.electronAPI.onShieldStatsUpdated((stats) => {
      setShieldStats(stats);
    });
    const unsubPanic = window.electronAPI.onPanicWiped(() => {
      setHistory([]);
      setConflicts([]);
      showToast('Amnesic Panic Wipe completed — tabs, cache, cookies & history purged.');
    });

    return () => {
      mounted = false;
      unsubTabs();
      unsubShields();
      unsubPanic();
    };
  }, [refreshFeed, refreshLibraryData, showToast]);

  const activeTab = tabs.find((t) => t.id === activeTabId);

  const handleUpdateSettings = async (patch: Partial<BrowserSettings>): Promise<void> => {
    const updated = await window.electronAPI.updateSettings(patch);
    setSettings(updated);
  };

  const handleBookmarkCurrent = async (): Promise<void> => {
    if (!activeTab || activeTab.isHome) return;
    await window.electronAPI.addBookmark(activeTab.title, activeTab.url, 'Favorites');
    await refreshLibraryData();
    showToast(`Bookmarked ${activeTab.title}`);
  };

  const handlePanicWipe = async (): Promise<void> => {
    setActiveModal('none');
    await window.electronAPI.triggerPanicWipe();
    await refreshLibraryData();
  };

  const handleRunSync = async (): Promise<void> => {
    setSyncBusy(true);
    setSyncMessage(null);
    try {
      const result = await window.electronAPI.runCloudSync();
      setConflicts(result.conflicts);
      setSyncMessage(result.message);
      setAccount(await window.electronAPI.getAccountState());
      await refreshLibraryData();
    } catch (err) {
      setSyncMessage(err instanceof Error ? err.message : 'Cloud sync error.');
    } finally {
      setSyncBusy(false);
    }
  };

  const handleResolveConflict = async (
    conflict: SyncConflictItem,
    strategy: ConflictResolutionStrategy
  ): Promise<void> => {
    setSyncBusy(true);
    try {
      const res = await window.electronAPI.resolveSyncConflict(conflict, strategy);
      setConflicts((prev) => prev.filter((c) => c.id !== conflict.id));
      setSyncMessage(res.message);
      await refreshLibraryData();
    } catch (err) {
      setSyncMessage(err instanceof Error ? err.message : 'Conflict resolution failed.');
    } finally {
      setSyncBusy(false);
    }
  };

  return (
    <div className="app-shell">
      <TitleBar
        tabs={tabs}
        activeTabId={activeTabId}
        onSelectTab={(id) => void window.electronAPI.selectTab(id)}
        onCloseTab={(id) => void window.electronAPI.closeTab(id)}
        onNewTab={(incognito) => void window.electronAPI.createTab(undefined, incognito)}
      />

      <AddressBar
        activeTab={activeTab}
        shieldStats={shieldStats}
        conflictCount={conflicts.length}
        onGoBack={() => void window.electronAPI.goBack()}
        onGoForward={() => void window.electronAPI.goForward()}
        onReload={() => void window.electronAPI.reloadTab()}
        onGoHome={() => void window.electronAPI.goHome()}
        onNavigate={(input) => void window.electronAPI.navigate(input)}
        onBookmarkCurrent={() => void handleBookmarkCurrent()}
        onOpenVault={() => {
          void refreshLibraryData();
          setActiveModal('vault');
        }}
        onOpenSync={() => setActiveModal('sync')}
        onOpenSettings={() => setActiveModal('settings')}
        onPanicWipe={() => void handlePanicWipe()}
      />

      <div className="status-bar">
        <div className="status-chips">
          <span>{activeTab?.isIncognito ? 'Incognito Session' : 'Sandboxed Session'}</span>
          <span>DNT: {settings.dntEnabled ? '1' : 'Off'} · Sec-GPC: {settings.dntEnabled ? '1' : 'Off'}</span>
          {shieldStats.lastBlockedDomain && (
            <span>Last Blocked: {shieldStats.lastBlockedDomain}</span>
          )}
        </div>
        <div>
          {toastText ? (
            <span style={{ color: 'var(--brand)', fontWeight: 700 }}>{toastText}</span>
          ) : (
            <span>Theme: {settings.theme.toUpperCase()} · Search: {settings.searchEngine}</span>
          )}
        </div>
      </div>

      {(!activeTab || activeTab.isHome) && (
        <DashboardView
          settings={settings}
          shieldStats={shieldStats}
          feed={feed}
          feedLoading={feedLoading}
          onRefreshFeed={() => void refreshFeed(true)}
          onNavigate={(input) => void window.electronAPI.navigate(input)}
          onUpdateSearchEngine={(engine: SearchEngineId) =>
            void handleUpdateSettings({ searchEngine: engine })
          }
          onOpenPortal={() =>
            void window.electronAPI.navigate('https://silentbrowser.silentbot.online/')
          }
        />
      )}

      {activeModal === 'settings' && (
        <SettingsModal
          settings={settings}
          diagnostics={diagnostics}
          onUpdateSettings={(patch) => void handleUpdateSettings(patch)}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'sync' && (
        <SyncConflictsModal
          account={account}
          conflicts={conflicts}
          syncBusy={syncBusy}
          statusMessage={syncMessage}
          onLogin={async (email, password) => {
            setSyncBusy(true);
            try {
              const state = await window.electronAPI.loginAccount(email, password);
              setAccount(state);
              setSyncMessage('Signed in cleanly.');
            } finally {
              setSyncBusy(false);
            }
          }}
          onRegister={async (email, password) => {
            setSyncBusy(true);
            try {
              const state = await window.electronAPI.registerAccount(email, password);
              setAccount(state);
              setSyncMessage('Account registered & authenticated.');
            } finally {
              setSyncBusy(false);
            }
          }}
          onLogout={async () => {
            setSyncBusy(true);
            try {
              const state = await window.electronAPI.logoutAccount();
              setAccount(state);
              setConflicts([]);
              setSyncMessage('Signed out.');
            } finally {
              setSyncBusy(false);
            }
          }}
          onRunSync={handleRunSync}
          onResolveConflict={handleResolveConflict}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'vault' && (
        <VaultBookmarksModal
          bookmarks={bookmarks}
          history={history}
          vaultEntries={vaultEntries}
          onOpenUrl={(url) => void window.electronAPI.navigate(url)}
          onDeleteBookmark={async (id) => {
            await window.electronAPI.deleteBookmark(id);
            await refreshLibraryData();
          }}
          onClearHistory={async () => {
            await window.electronAPI.clearHistory();
            await refreshLibraryData();
          }}
          onSaveVaultEntry={async (origin, username, password) => {
            await window.electronAPI.saveVaultEntry(origin, username, password);
            await refreshLibraryData();
          }}
          onRevealVaultPassword={(id) => window.electronAPI.revealVaultPassword(id)}
          onDeleteVaultEntry={async (id) => {
            await window.electronAPI.deleteVaultEntry(id);
            await refreshLibraryData();
          }}
          onClose={() => setActiveModal('none')}
        />
      )}
    </div>
  );
};
