import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Cloud,
  Flame,
  Home,
  Lock,
  RotateCw,
  Settings,
  ShieldCheck,
} from 'lucide-react';
import { BrowserTabState, ShieldStats } from '../../shared/types';

interface AddressBarProps {
  activeTab: BrowserTabState | undefined;
  shieldStats: ShieldStats;
  conflictCount: number;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: () => void;
  onGoHome: () => void;
  onNavigate: (input: string) => void;
  onBookmarkCurrent: () => void;
  onOpenVault: () => void;
  onOpenSync: () => void;
  onOpenSettings: () => void;
  onPanicWipe: () => void;
}

export const AddressBar: React.FC<AddressBarProps> = ({
  activeTab,
  shieldStats,
  conflictCount,
  onGoBack,
  onGoForward,
  onReload,
  onGoHome,
  onNavigate,
  onBookmarkCurrent,
  onOpenVault,
  onOpenSync,
  onOpenSettings,
  onPanicWipe,
}) => {
  const [addressInput, setAddressInput] = useState(activeTab?.url ?? 'silent://home');

  useEffect(() => {
    setAddressInput(activeTab?.isHome ? '' : activeTab?.url ?? '');
  }, [activeTab?.id, activeTab?.url, activeTab?.isHome]);

  const totalBlocked =
    shieldStats.blockedAds + shieldStats.blockedTrackers + shieldStats.blockedScams;

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onNavigate(addressInput);
  };

  return (
    <div className="address-toolbar">
      <div className="nav-cluster">
        <button
          type="button"
          className="icon-btn"
          title="Back"
          aria-label="Back"
          disabled={!activeTab?.canGoBack}
          onClick={onGoBack}
        >
          <ArrowLeft size={16} />
        </button>
        <button
          type="button"
          className="icon-btn"
          title="Forward"
          aria-label="Forward"
          disabled={!activeTab?.canGoForward}
          onClick={onGoForward}
        >
          <ArrowRight size={16} />
        </button>
        <button
          type="button"
          className="icon-btn"
          title="Reload"
          aria-label="Reload"
          disabled={!activeTab || activeTab.isHome}
          onClick={onReload}
        >
          <RotateCw size={15} />
        </button>
        <button
          type="button"
          className="icon-btn"
          title="Silent Home"
          aria-label="Home"
          onClick={onGoHome}
        >
          <Home size={16} />
        </button>
      </div>

      <form className="omnibox-form" onSubmit={handleSubmit}>
        <Lock size={14} color="var(--brand)" />
        <input
          type="text"
          className="omnibox-input"
          value={addressInput}
          onChange={(e) => setAddressInput(e.target.value)}
          placeholder="Search privately or enter HTTPS URL..."
          aria-label="Address bar"
        />
        {!activeTab?.isHome && (
          <button
            type="button"
            className="icon-btn"
            style={{ width: 28, height: 28 }}
            title="Bookmark this page"
            aria-label="Bookmark page"
            onClick={onBookmarkCurrent}
          >
            <Bookmark size={14} />
          </button>
        )}
      </form>

      <button
        type="button"
        className="shield-chip"
        title="Open Bookmarks, History & AES-256 Vault"
        onClick={onOpenVault}
      >
        <ShieldCheck size={14} />
        <span>{totalBlocked} Blocked</span>
      </button>

      <button
        type="button"
        className="icon-btn"
        title={conflictCount > 0 ? `Sync (${conflictCount} conflicts)` : 'Cloud Sync & Conflicts'}
        aria-label="Cloud Sync"
        onClick={onOpenSync}
        style={{
          borderColor: conflictCount > 0 ? 'var(--warn)' : undefined,
          color: conflictCount > 0 ? 'var(--warn)' : undefined,
        }}
      >
        <Cloud size={16} />
      </button>

      <button
        type="button"
        className="icon-btn"
        title="Settings & Appearance"
        aria-label="Settings"
        onClick={onOpenSettings}
      >
        <Settings size={16} />
      </button>

      <button
        type="button"
        className="panic-btn"
        title="Instant Amnesic Panic Wipe — clear tabs, session cache & local history"
        onClick={onPanicWipe}
      >
        <Flame size={14} />
        <span>Panic Wipe</span>
      </button>
    </div>
  );
};
