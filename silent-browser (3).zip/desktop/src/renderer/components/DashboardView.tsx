import React, { useState } from 'react';
import { ExternalLink, RefreshCw, Search, ShieldCheck } from 'lucide-react';
import {
  BrowserSettings,
  FeedCategory,
  LiveFeedItem,
  LiveFeedResponse,
  SEARCH_ENGINES,
  SearchEngineId,
  ShieldStats,
} from '../../shared/types';
import brandLogo from '../assets/brand-logo.png';

interface DashboardViewProps {
  settings: BrowserSettings;
  shieldStats: ShieldStats;
  feed: LiveFeedResponse | null;
  feedLoading: boolean;
  onRefreshFeed: () => void;
  onNavigate: (urlOrQuery: string) => void;
  onUpdateSearchEngine: (engine: SearchEngineId) => void;
  onOpenPortal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  settings,
  shieldStats,
  feed,
  feedLoading,
  onRefreshFeed,
  onNavigate,
  onUpdateSearchEngine,
  onOpenPortal,
}) => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FeedCategory>('all');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const items: LiveFeedItem[] = feed?.items ?? [];
  const filteredItems = items.filter((item) =>
    filter === 'all' ? true : item.category === filter
  );

  const handleSearch = (e: React.FormEvent): void => {
    e.preventDefault();
    if (query.trim()) {
      onNavigate(query.trim());
    }
  };

  return (
    <div className="workspace-scroll">
      <div className="dashboard-container">
        <section className="hero-panel">
          <div>
            <div className="badge-pill">
              <ShieldCheck size={14} />
              <span>SILENT BROWSER DESKTOP · v1.0.0 · SILENT BOT LLC</span>
            </div>
            <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 8 }}>
              Private Desktop Browsing Built for Speed &amp; Control
            </h1>
            <p style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.6 }}>
              Sandboxed Chromium tabs with automatic DNT: 1 / Sec-GPC: 1 headers, on-device tracker blocking,
              local SQLite + AES-256 vault, and White / Black / Midnight themes.
            </p>

            <form className="hero-search" onSubmit={handleSearch}>
              <Search size={18} style={{ alignSelf: 'center', marginLeft: 8, color: 'var(--muted)' }} />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search privately or enter a website URL..."
                aria-label="Private dashboard search"
              />
              <select
                className="field-select"
                style={{ width: 165 }}
                value={settings.searchEngine}
                onChange={(e) => onUpdateSearchEngine(e.target.value as SearchEngineId)}
                aria-label="Default search engine"
              >
                {SEARCH_ENGINES.map((eng) => (
                  <option key={eng.id} value={eng.id}>
                    {eng.displayName}
                  </option>
                ))}
              </select>
              <button type="submit" className="btn btn-primary">
                Go
              </button>
            </form>

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: 6,
                marginTop: 10,
              }}
              aria-label="Quick search engine selector"
            >
              {SEARCH_ENGINES.map((eng) => {
                const isSelected = eng.id === settings.searchEngine;
                return (
                  <button
                    key={eng.id}
                    type="button"
                    className={`filter-tab ${isSelected ? 'active' : ''}`}
                    style={{ height: 30, padding: '0 10px', fontSize: 11 }}
                    onClick={() => {
                      onUpdateSearchEngine(eng.id);
                      if (query.trim()) {
                        onNavigate(eng.queryTemplate.replace('{q}', encodeURIComponent(query.trim())));
                      }
                    }}
                  >
                    {eng.badge} {eng.displayName}
                  </button>
                );
              })}
            </div>
          </div>

          <div
            style={{
              background: 'var(--surface-elevated)',
              border: '1px solid var(--border)',
              borderRadius: 16,
              padding: 18,
              display: 'flex',
              flexDirection: 'column',
              gap: 14,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <img
                src={brandLogo}
                alt="Silent Browser emblem"
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 12,
                  background: '#061626',
                  padding: 6,
                }}
              />
              <div>
                <div style={{ fontWeight: 800, fontSize: 15 }}>Live Privacy Shield</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                  Theme: {settings.theme.toUpperCase()} · {settings.dntEnabled ? 'DNT + GPC On' : 'Headers Off'}
                </div>
              </div>
            </div>

            <div className="stats-grid">
              <div className="stat-card">
                <strong>{shieldStats.blockedAds}</strong>
                <span>Ads Blocked</span>
              </div>
              <div className="stat-card">
                <strong>{shieldStats.blockedTrackers}</strong>
                <span>Trackers Blocked</span>
              </div>
              <div className="stat-card">
                <strong>{shieldStats.blockedScams}</strong>
                <span>Scams Blocked</span>
              </div>
              <div className="stat-card">
                <strong>{shieldStats.upgradedHttps}</strong>
                <span>HTTPS Upgrades</span>
              </div>
            </div>

            <button type="button" className="btn btn-secondary" onClick={onOpenPortal}>
              <ExternalLink size={14} />
              <span>Open Staging Portal</span>
            </button>
          </div>
        </section>

        <section style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="feed-header">
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 800 }}>
                Latest Tech News &amp; Trending GitHub
              </h2>
              <p style={{ fontSize: 12, color: 'var(--muted)' }}>
                {feedLoading
                  ? 'Fetching live daily stories & trending repositories…'
                  : `Live status: ${feed?.status ?? 'idle'} · Updated: ${feed?.updatedUtc ?? 'N/A'}`}
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <div className="filter-tabs" role="tablist" aria-label="Feed filter">
                <button
                  type="button"
                  className={`filter-tab ${filter === 'all' ? 'active' : ''}`}
                  onClick={() => setFilter('all')}
                >
                  All ({items.length})
                </button>
                <button
                  type="button"
                  className={`filter-tab ${filter === 'news' ? 'active' : ''}`}
                  onClick={() => setFilter('news')}
                >
                  Latest News ({feed?.newsCount ?? 0})
                </button>
                <button
                  type="button"
                  className={`filter-tab ${filter === 'github' ? 'active' : ''}`}
                  onClick={() => setFilter('github')}
                >
                  Trending GitHub ({feed?.githubCount ?? 0})
                </button>
              </div>

              <button
                type="button"
                className="btn btn-secondary"
                disabled={feedLoading}
                onClick={onRefreshFeed}
              >
                <RefreshCw size={14} />
                <span>{feedLoading ? 'Refreshing…' : 'Refresh'}</span>
              </button>
            </div>
          </div>

          {filteredItems.length === 0 ? (
            <div
              style={{
                padding: 24,
                borderRadius: 14,
                border: '1px solid var(--border)',
                background: 'var(--surface)',
              }}
            >
              <strong style={{ display: 'block', marginBottom: 4 }}>
                {feedLoading ? 'Loading daily live feed…' : 'No live feed entries available'}
              </strong>
              <span style={{ fontSize: 13, color: 'var(--muted)' }}>
                Click Refresh when connected to the internet to fetch today&apos;s stories and trending repositories.
              </span>
            </div>
          ) : (
            <div className="feed-grid">
              {filteredItems.map((item) => {
                const showImage = Boolean(item.image) && !failedImages[item.id];
                return (
                  <article
                    key={item.id}
                    className="feed-card"
                    onClick={() => onNavigate(item.url)}
                  >
                    <div className="feed-thumb">
                      {showImage && item.image ? (
                        <img
                          src={item.image}
                          alt={item.title}
                          loading="lazy"
                          onError={() =>
                            setFailedImages((prev) => ({ ...prev, [item.id]: true }))
                          }
                        />
                      ) : (
                        <div className="feed-thumb-fallback">
                          {item.category === 'github'
                            ? 'GitHub Trending Repository'
                            : 'Daily Tech News'}
                        </div>
                      )}
                    </div>

                    <div className="feed-card-body">
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: 8,
                        }}
                      >
                        <span className="badge-pill" style={{ marginBottom: 0 }}>
                          {item.source}
                        </span>
                        <span style={{ fontSize: 11, color: 'var(--muted)' }}>{item.metric}</span>
                      </div>
                      <h3 className="feed-card-title">{item.title}</h3>
                      <p className="feed-card-summary">
                        {item.summary || 'Click to open inside a sandboxed Silent Browser tab.'}
                      </p>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          paddingTop: 8,
                          borderTop: '1px solid var(--border)',
                          fontSize: 11,
                          color: 'var(--muted)',
                        }}
                      >
                        <span>{item.publishedAt.slice(0, 10)}</span>
                        <span style={{ color: 'var(--brand)', fontWeight: 700 }}>Open Tab →</span>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
