import React from 'react';
import { X } from 'lucide-react';
import {
  AppDiagnosticInfo,
  BrowserSettings,
  SEARCH_ENGINES,
  SearchEngineId,
  ThemeMode,
} from '../../shared/types';

interface SettingsModalProps {
  settings: BrowserSettings;
  diagnostics: AppDiagnosticInfo | null;
  onUpdateSettings: (patch: Partial<BrowserSettings>) => void;
  onClose: () => void;
}

const THEME_OPTIONS: Array<{ value: ThemeMode; label: string; subtitle: string }> = [
  { value: 'white', label: 'White', subtitle: 'Classic light default (#FFFFFF)' },
  { value: 'black', label: 'Black', subtitle: 'Pure AMOLED dark (#000000)' },
  { value: 'midnight', label: 'Midnight', subtitle: 'Deep slate contrast (#0B1120)' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  diagnostics,
  onUpdateSettings,
  onClose,
}) => {
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Browser Settings">
      <div className="modal-card">
        <div className="modal-header">
          <div>
            <h2 style={{ fontSize: 17, fontWeight: 800 }}>Silent Browser Settings</h2>
            <p style={{ fontSize: 12, color: 'var(--muted)' }}>
              Theme choices and privacy shields persist immediately without restarting.
            </p>
          </div>
          <button type="button" className="icon-btn" aria-label="Close settings" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="modal-body">
          <div>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>Theme &amp; Appearance</h3>
            <div className="radio-group" role="radiogroup" aria-label="Theme selection">
              {THEME_OPTIONS.map((opt) => {
                const selected = settings.theme === opt.value;
                return (
                  <label
                    key={opt.value}
                    className={`radio-card ${selected ? 'selected' : ''}`}
                  >
                    <input
                      type="radio"
                      name="theme-mode"
                      checked={selected}
                      onChange={() => onUpdateSettings({ theme: opt.value })}
                    />
                    <div>
                      <div>{opt.label}</div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 500 }}>
                        {opt.subtitle}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="setting-row">
            <div>
              <div style={{ fontWeight: 700, fontSize: 13 }}>Default Search Engine</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                Applied when entering non-URL keywords into the address bar.
              </div>
            </div>
            <select
              className="field-select"
              style={{ width: 185 }}
              value={settings.searchEngine}
              onChange={(e) => onUpdateSettings({ searchEngine: e.target.value as SearchEngineId })}
            >
              {SEARCH_ENGINES.map((eng) => (
                <option key={eng.id} value={eng.id}>
                  {eng.displayName}
                </option>
              ))}
            </select>
          </div>

          {[
            {
              key: 'adblockEnabled' as const,
              title: 'Ad & Tracker Blocking',
              desc: 'Blocks ad networks, behavioral pixels, and cryptominers inside Main webRequest hooks.',
            },
            {
              key: 'antiScamEnabled' as const,
              title: 'Anti-Scam & Punycode Protection',
              desc: 'Blocks suspicious lookalike xn-- domains and common credential phishing routes.',
            },
            {
              key: 'dntEnabled' as const,
              title: 'Send DNT: 1 & Sec-GPC: 1 Headers',
              desc: 'Appends Do Not Track and Global Privacy Control signals on outbound HTTP requests.',
            },
            {
              key: 'httpsEverywhere' as const,
              title: 'Upgrade HTTP Requests to HTTPS',
              desc: 'Redirects unencrypted public HTTP traffic to HTTPS automatically.',
            },
            {
              key: 'alwaysIncognito' as const,
              title: 'Always Open New Tabs in Incognito',
              desc: 'New tabs use ephemeral in-memory session storage and omit local history.',
            },
            {
              key: 'autoPurgeOnExit' as const,
              title: 'Auto-Purge Session on Exit',
              desc: 'Clears persistent web storage and local SQLite history before application quit.',
            },
          ].map((item) => (
            <label key={item.key} className="setting-row" style={{ cursor: 'pointer' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{item.title}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>{item.desc}</div>
              </div>
              <input
                type="checkbox"
                checked={settings[item.key]}
                onChange={(e) => onUpdateSettings({ [item.key]: e.target.checked })}
                style={{ width: 18, height: 18 }}
              />
            </label>
          ))}

          {diagnostics && (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                border: '1px solid var(--border)',
                background: 'var(--surface)',
                fontSize: 11,
                color: 'var(--muted)',
                display: 'grid',
                gap: 4,
              }}
            >
              <strong style={{ color: 'var(--text)', fontSize: 12 }}>
                Diagnostics &amp; Windows AppData Storage Paths
              </strong>
              <span>App v{diagnostics.appVersion} · Electron {diagnostics.electronVersion} ({diagnostics.platform}/{diagnostics.arch})</span>
              <span>UserData: {diagnostics.userDataPath}</span>
              <span>SQLite DB: {diagnostics.dbFilePath}</span>
              <span>Main Log: {diagnostics.logFilePath}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
