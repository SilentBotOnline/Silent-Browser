import React from 'react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: '',
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'Unknown renderer fault',
    };
  }

  private handleReload = (): void => {
    this.setState({ hasError: false, errorMessage: '' });
  };

  render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <div
          style={{
            height: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            background: 'var(--bg)',
            color: 'var(--text)',
          }}
        >
          <div
            style={{
              maxWidth: 480,
              padding: 24,
              borderRadius: 16,
              border: '1px solid var(--border)',
              background: 'var(--surface)',
            }}
          >
            <h2 style={{ marginBottom: 8 }}>Silent Browser UI Recovery</h2>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>
              {this.state.errorMessage}
            </p>
            <button type="button" className="btn btn-primary" onClick={this.handleReload}>
              Recover Interface
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
