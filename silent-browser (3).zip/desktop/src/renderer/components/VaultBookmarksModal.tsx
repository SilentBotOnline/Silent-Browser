import React, { useState } from 'react';
import { Eye, KeyRound, Trash2, X } from 'lucide-react';
import {
  BookmarkRecord,
  HistoryRecord,
  VaultDisplayEntry,
} from '../../shared/types';

interface VaultBookmarksModalProps {
  bookmarks: BookmarkRecord[];
  history: HistoryRecord[];
  vaultEntries: VaultDisplayEntry[];
  onOpenUrl: (url: string) => void;
  onDeleteBookmark: (id: number) => Promise<void>;
  onClearHistory: () => Promise<void>;
  onSaveVaultEntry: (origin: string, username: string, password: string) => Promise<void>;
  onRevealVaultPassword: (id: number) => Promise<string>;
  onDeleteVaultEntry: (id: number) => Promise<void>;
  onClose: () => void;
}

export const VaultBookmarksModal: React.FC<VaultBookmarksModalProps> = ({
  bookmarks,
  history,
  vaultEntries,
  onOpenUrl,
  onDeleteBookmark,
  onClearHistory,
  onSaveVaultEntry,
  onRevealVaultPassword,
  onDeleteVaultEntry,
  onClose,
}) => {
  const [tab, setTab] = useState<'bookmarks' | 'history' | 'vault'>('bookmarks');
  const [origin, setOrigin] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, string>>({});

  const handleSaveVault = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!origin.trim() || !username.trim() || !password) return;
    await onSaveVaultEntry(origin.trim(), username.trim(), password);
    setOrigin('');
    setUsername('');
    setPassword('');
  };

  const handleReveal = async (id: number): Promise<void> => {
    if (revealedPasswords[id]) {
      setRevealedPasswords((prev) => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      return;
    }
    const secret = await onRevealVaultPassword(id);
    setRevealedPasswords((prev) => ({ ...prev, [id]: secret }));
  };

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Library and Password Vault">
      <div className="modal-card">
        <div className="modal-header">
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              className={`filter-tab ${tab === 'bookmarks' ? 'active' : ''}`}
              onClick={() => setTab('bookmarks')}
            >
              Bookmarks ({bookmarks.length})
            </button>
            <button
              type="button"
              className={`filter-tab ${tab === 'history' ? 'active' : ''}`}
              onClick={() => setTab('history')}
            >
              History ({history.length})
            </button>
            <button
              type="button"
              className={`filter-tab ${tab === 'vault' ? 'active' : ''}`}
              onClick={() => setTab('vault')}
            >
              Password Vault ({vaultEntries.length})
            </button>
          </div>
          <button type="button" className="icon-btn" aria-label="Close library" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="modal-body">
          {tab === 'bookmarks' && (
            <>
              {bookmarks.length === 0 ? (
                <p style={{ fontSize: 13, color: 'var(--muted)' }}>
                  No bookmarks saved yet. Use the Bookmark icon in the address bar on any page.
                </p>
              ) : (
                bookmarks.map((bm) => (
                  <div key={bm.id} className="list-item-row">
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 13 }}>{bm.title}</div>
                      <div
                        style={{
                          fontSize: 11,
                          color: 'var(--muted)',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {bm.url}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => {
                          onOpenUrl(bm.url);
                          onClose();
                        }}
                      >
                        Open
                      </button>
                      <button
                        type="button"
                        className="icon-btn"
                        aria-label="Delete bookmark"
                        onClick={() => void onDeleteBookmark(bm.id)}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </>
          )}

          {tab === 'history' && (
            <>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  className="btn btn-danger"
                  disabled={history.length === 0}
                  onClick={() => void onClearHistory()}
                >
                  Clear Local History
                </button>
              </div>
              {history.length === 0 ? (
                <p style={{ fontSize: 13, color: 'var(--muted)' }}>Browsing history is empty.</p>
              ) : (
                history.map((item) => (
                  <div key={item.id} className="list-item-row">
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 13 }}>{item.title}</div>
                      <div
                        style={{
                          fontSize: 11,
                          color: 'var(--muted)',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {item.url} · {item.visitCount} visit(s)
                      </div>
                    </div>
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => {
                        onOpenUrl(item.url);
                        onClose();
                      }}
                    >
                      Open
                    </button>
                  </div>
                ))
              )}
            </>
          )}

          {tab === 'vault' && (
            <>
              <form
                onSubmit={(e) => void handleSaveVault(e)}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 1fr auto',
                  gap: 8,
                }}
              >
                <input
                  type="text"
                  className="field-input"
                  placeholder="Domain (e.g. github.com)"
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  required
                />
                <input
                  type="text"
                  className="field-input"
                  placeholder="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
                <input
                  type="password"
                  className="field-input"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button type="submit" className="btn btn-primary">
                  <KeyRound size={14} />
                  <span>Save</span>
                </button>
              </form>

              {vaultEntries.length === 0 ? (
                <p style={{ fontSize: 13, color: 'var(--muted)' }}>
                  Vault credentials are encrypted locally using Windows DPAPI / AES-256-GCM and are excluded from cloud sync.
                </p>
              ) : (
                vaultEntries.map((entry) => (
                  <div key={entry.id} className="list-item-row">
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 13 }}>
                        {entry.origin} — {entry.username}
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--brand)' }}>
                        {revealedPasswords[entry.id] ?? entry.passwordMasked}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button
                        type="button"
                        className="icon-btn"
                        aria-label="Reveal password"
                        onClick={() => void handleReveal(entry.id)}
                      >
                        <Eye size={15} />
                      </button>
                      <button
                        type="button"
                        className="icon-btn"
                        aria-label="Delete vault entry"
                        onClick={() => void onDeleteVaultEntry(entry.id)}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
