import React from 'react';
import { EyeOff, Plus, X } from 'lucide-react';
import { BrowserTabState } from '../../shared/types';
import brandLogo from '../assets/brand-logo.png';

interface TitleBarProps {
  tabs: BrowserTabState[];
  activeTabId: string;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onNewTab: (incognito: boolean) => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
}) => {
  return (
    <header className="titlebar">
      <div className="titlebar-brand">
        <img src={brandLogo} alt="Silent Browser" />
        <span>SILENT</span>
      </div>

      <div className="tab-strip" role="tablist" aria-label="Browser tabs">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <div
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              tabIndex={0}
              className={`tab-pill ${isActive ? 'active' : ''}`}
              onClick={() => onSelectTab(tab.id)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectTab(tab.id);
                }
              }}
              title={tab.url}
            >
              {tab.isIncognito && <EyeOff size={13} color="var(--brand)" />}
              <span className="tab-title">
                {tab.isLoading ? 'Loading… ' : ''}
                {tab.title || 'Silent Home'}
              </span>
              <button
                type="button"
                className="tab-close-btn"
                aria-label={`Close ${tab.title}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab(tab.id);
                }}
              >
                <X size={12} />
              </button>
            </div>
          );
        })}
      </div>

      <div className="titlebar-actions">
        <button
          type="button"
          className="icon-btn"
          title="New Tab"
          aria-label="New Tab"
          onClick={() => onNewTab(false)}
        >
          <Plus size={16} />
        </button>
        <button
          type="button"
          className="icon-btn"
          title="New Private Incognito Tab"
          aria-label="New Incognito Tab"
          onClick={() => onNewTab(true)}
        >
          <EyeOff size={15} />
        </button>
      </div>
    </header>
  );
};
