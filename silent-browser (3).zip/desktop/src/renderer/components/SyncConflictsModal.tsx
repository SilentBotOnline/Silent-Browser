import React, { useState } from 'react';
import { RefreshCw, X } from 'lucide-react';
import {
  AccountSessionState,
  ConflictResolutionStrategy,
  SyncConflictItem,
} from '../../shared/types';

interface SyncConflictsModalProps {
  account: AccountSessionState;
  conflicts: SyncConflictItem[];
  syncBusy: boolean;
  statusMessage: string | null;
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: (email: string, password: string) => Promise<void>;
  onLogout: () => Promise<void>;
  onRunSync: () => Promise<void>;
  onResolveConflict: (
    conflict: SyncConflictItem,
    strategy: ConflictResolutionStrategy
  ) => Promise<void>;
  onClose: () => void;
}

export const SyncConflictsModal: React.FC<SyncConflictsModalProps> = ({
  account,
  conflicts,
  syncBusy,
  statusMessage,
  onLogin,
  onRegister,
  onLogout,
  onRunSync,
  onResolveConflict,
  onClose,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const handleAuth = async (mode: 'login' | 'register'): Promise<void> => {
    setAuthError(null);
    try {
      if (mode === 'login') {
        await onLogin(email, password);
      } else {
        await onRegister(email, password);
      }
      setPassword('');
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed.');
    }
  };

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Cloud Sync and Conflicts">
      <div className="modal-card">
        <div className="modal-header">
          <div>
            <h2 style={{ fontSize: 17, fontWeight: 800 }}>Silent Sync &amp; Conflict Resolver</h2>
            <p style={{ fontSize: 12, color: 'var(--muted)' }}>
              Endpoint: {account.portalUrl}api.php
            </p>
          </div>
          <button type="button" className="icon-btn" aria-label="Close sync modal" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="modal-body">
          {!account.isSignedIn ? (
            <div style={{ display: 'grid', gap: 10 }}>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Sign In or Create Sync Account</div>
              <input
                type="email"
                className="field-input"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <input
                type="password"
                className="field-input"
                placeholder="Password (minimum 6 characters)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {authError && (
                <div style={{ fontSize: 12, color: 'var(--danger)', fontWeight: 600 }}>
                  {authError}
                </div>
              )}
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={syncBusy}
                  onClick={() => void handleAuth('login')}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  disabled={syncBusy}
                  onClick={() => void handleAuth('register')}
                >
                  Create Account
                </button>
              </div>
            </div>
          ) : (
            <div className="setting-row">
              <div>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{account.email}</div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                  {account.lastSyncedAt
                    ? `Last synced: ${new Date(account.lastSyncedAt).toLocaleString()}`
                    : 'Not synced yet on this desktop'}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={syncBusy}
                  onClick={() => void onRunSync()}
                >
                  <RefreshCw size={14} />
                  <span>{syncBusy ? 'Syncing…' : 'Sync Now'}</span>
                </button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  disabled={syncBusy}
                  onClick={() => void onLogout()}
                >
                  Sign Out
                </button>
              </div>
            </div>
          )}

          {statusMessage && (
            <div
              style={{
                padding: '10px 12px',
                borderRadius: 10,
                background: 'var(--brand-soft)',
                border: '1px solid var(--brand-soft-border)',
                color: 'var(--brand)',
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              {statusMessage}
            </div>
          )}

          <div>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>
              Timestamp-Mismatched Sync Conflicts ({conflicts.length})
            </h3>
            {conflicts.length === 0 ? (
              <div
                style={{
                  padding: 16,
                  borderRadius: 12,
                  border: '1px solid var(--border)',
                  background: 'var(--surface)',
                  fontSize: 13,
                  color: 'var(--muted)',
                }}
              >
                No unresolved sync conflicts. All local bookmarks and history match server state.
              </div>
            ) : (
              <div style={{ display: 'grid', gap: 10 }}>
                {conflicts.map((conflict) => (
                  <div
                    key={conflict.id}
                    style={{
                      padding: 14,
                      borderRadius: 12,
                      border: '1px solid var(--warn)',
                      background: 'var(--surface)',
                      display: 'grid',
                      gap: 8,
                    }}
                  >
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{conflict.url}</div>
                    <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                      Local ({new Date(conflict.localTimestamp).toLocaleTimeString()}): {conflict.localTitle}
                      <br />
                      Remote ({new Date(conflict.remoteTimestamp).toLocaleTimeString()}): {conflict.remoteTitle}
                    </div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="btn btn-primary"
                        disabled={syncBusy}
                        onClick={() => void onResolveConflict(conflict, 'KEEP_LOCAL')}
                      >
                        Keep Local
                      </button>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        disabled={syncBusy}
                        onClick={() => void onResolveConflict(conflict, 'USE_REMOTE')}
                      >
                        Use Remote
                      </button>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        disabled={syncBusy}
                        onClick={() => void onResolveConflict(conflict, 'MERGE')}
                      >
                        Merge
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
