# Silent Browser Desktop (Windows x64)

Production-ready Windows desktop edition of **Silent Browser** built by **Silent Bot LLC** using **Electron 34, TypeScript (`strict: true`), React 18, Vite, `better-sqlite3`, `electron-store`, `electron-log`, and `electron-builder`**.

Portal: https://silentbrowser.silentbot.online/  
Repository: https://github.com/SilentBotOnline/Silent-Browser  
Application ID: `com.silentbot.silentbrowser`

## Core Capabilities

- **Security-Hardened Electron Architecture:** Enforces `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`, typed `contextBridge` API (`src/preload/preload.ts`), single-instance lock, and CSP headers.
- **Native Tabbed Browsing (`WebContentsView`):** Isolated persistent (`persist:silent-session`) and ephemeral incognito (`silent-incognito`) sessions with automatic `DNT: 1` & `Sec-GPC: 1` headers, tracker/ad/punycode scam blocking, and automatic HTTPS upgrades.
- **Themes:** Persisted **White** (default `#FFFFFF`), **Black** (`#000000`), and **Midnight** (`#0B1120`) themes synchronized live with Windows native `titleBarOverlay` caption colors.
- **Local SQLite & Encrypted Vault:** Bookmarks, history, and DPAPI / AES-256-GCM credentials stored strictly under `%APPDATA%\Silent Browser\`.
- **Live Daily Tech News & Trending GitHub:** Real-time daily developer articles and trending GitHub repositories rendered on `silent://home` with proportional `16:9` imagery.
- **Cloud Sync & Conflict Resolver:** Connects to `https://silentbrowser.silentbot.online/api.php` with interactive `Keep Local`, `Use Remote`, and `Merge` buttons for timestamp-mismatched records.
- **Amnesic Panic Wipe:** One-click destruction of open web views, session cookies/caches, and local browsing history.

## Commands (Run Inside `desktop/`)

```bash
# 1. Install pinned dependencies
npm install

# 2. Run strict TypeScript type-checking across Main, Preload & Renderer
npm run typecheck

# 3. Compile Main Process + Production Vite Renderer Bundle
npm run build

# 4. Run in interactive development mode (Vite HMR + Electron)
npm run dev

# 5. Package Windows x64 NSIS Installer & Portable .exe
npm run dist:win
```

Output installers are written to `desktop/release/`:
- `SilentBrowser-Setup-1.0.0-x64.exe` (NSIS installer, selectable install folder, Desktop & Start Menu shortcuts)
- `SilentBrowser-Portable-1.0.0-x64.exe` (Portable standalone executable)
