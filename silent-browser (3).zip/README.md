# Silent Browser

This repository is a **production-ready Electron application shell** that provides:

- A single window UI to control 5 privacy modes: **Tor, I2P, Tails, Mullvad, Brave**
- A **multi-view** layout that embeds multiple `BrowserView`s (2x3 grid)
- Strong Electron defaults (contextIsolation, sandbox) and basic tracker blocking
**Silent Browser** is an Android privacy-first web browser built with Kotlin, Jetpack Compose (Material 3), real Android WebView isolation, Firebase AI Logic (`gemini-3.8-flash`), Google Sign-In via Jetpack Credential Manager, Cloud Firestore sync, and integration with the Silentbot Online portal (`https://browser.silentbot.online/`).

## Features
- **Zero-Account Instant Browsing**: Anyone can launch and use all browser tabs, privacy modes, tracker blocking, local bookmarks/history, AI Guard, and Silentbot Portal tools immediately without creating an account.
- **5+1 Privacy Engine Modes**: Brave Shield, Tor Onion posture, I2P Garlic isolation, Mullvad Tunnel posture, Tails Amnesic auto-purge mode, and adaptive Dual-Pane Multi-View.
- **Hardened WebView Engine**: Real-time tracker/ad request interception (`TrackerBlocker`), automatic HTTPS upgrades, third-party cookie blocking, User-Agent spoofing presets, multi-tab management, external `http`/`https` `ACTION_VIEW` link handling, and one-tap Forensic Panic Wipe.
- **7 Search Gateways**: Silent Stealth (`browser.silentbot.online/search.php`), DuckDuckGo, Brave Search, Startpage, Ecosia, Google, and Bing.
- **AI Guard (Firebase AI Logic + App Check)**: Structured JSON URL/domain privacy risk audits (`privacyScore`, `riskLevel`, `summary`, `recommendations`) and streaming AI privacy assistant powered by `gemini-3.8-flash`.
- **Optional Encrypted Cloud Sync & Vault**: Per-device DataStore vault by default, with optional Google Sign-In (Credential Manager) to sync privacy profiles, bookmarks, history, and AI audits across devices via Cloud Firestore, plus pure-Kotlin QR handoff generation and optional Biometric Vault Lock (`BiometricPrompt`).
- **Silentbot Portal Integration**: Live portal health checks, relay node directory, and cross-platform release catalog fetched via Retrofit & Moshi.
  
Important: The project is intentionally shipped as a **shell**. It does **not** bundle or redistribute third-party privacy tools (Tor/I2P/VPN clients/Tails images). Users can add those binaries into `binaries/` and configure them via `.env`.

## Quick start

```bash
npm install
npm run build
npm run start:prod
```

## Distribution builds

```bash
npm run dist
```

Electron Builder reads `electron-builder.yml`.

## Folder layout

- `src/main` – Electron main process (window + BrowserView grid)
- `src/preload` – safe IPC bridge
- `src/renderer` – React UI (address bar + mode switching)
- `configs/` – security defaults

## User-provided integrations

- **Tor**: place binaries in `binaries/tor/` and implement `TorService.ts` spawn logic.
- **I2P**: place router binaries in `binaries/i2p/` and implement `I2PService.ts`.
- **Mullvad/WireGuard**: integrate via `MullvadService.ts`.
- **Tails**: requires a user-provided image and a virtualization runtime.

## Security notes

- All embedded views are sandboxed and isolated by partition.
- Permissions are denied by default in `SecurityManager`.

